// algorithm.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "..\..\algorithm.h"

int main()
{
	{
		twos_difference({ 4 ,1, 2, 3 });
	}
	{
		std::vector<int> input = //{ 2, 3, 5, 3, 7, 9, 5, 3, 7 };
		{5, 9, 6, 9, 6, 5, 9, 9, 4, 4};
		std::vector<int> result = sortByFrequency(input);
	}
	{
		//RevRot::maxRot(38458215);
	}
	{
		std::string s = "73304991087281576455176044327690580265896896028126182265439";
		std::string res{ "3304991087781576455172509672344060265896896862281621820"};

		std::string expected = RevRot::revRot(s, 11);

		if (expected == res)
			std::cout << "equal ";
	}
	{
		strong_num(1);
	}

	{
		std::vector<std::string> arr = { "ejjjjmmtthh", "zxxuueeg", "aanlljrrrxx", "dqqqaaabbb", "oocccffuucccjjjkkkjyyyeehh" };
		std::string dotest("oocccffuucccjjjkkkjyyyeehh");

		//std::vector<std::string> arr = { "zone", "abigail", "theta", "form", "libe", "zas", "theta", "abigail" };
		//std::string dotest("abigailtheta");
		if (dotest == longestConsec(arr, 1))
			std::cout << "equal ";
	}

	{
		std::string result{ reverseWordsinSentence("Reverse the words in sentence,that it first word as last word") };
	}

	{
		int A[M][N] = { { 1, 1, 1, 1 },
						{ 2, 2, 2, 2 },
						{ 3, 3, 3, 3 } };

		// Note dimensions of B[][]
		int B[N][M], i, j;

		transpose(A, B);

		cout << "Result matrix is \n";
		for (i = 0; i < N; i++)
		{
			for (j = 0; j < M; j++)
				cout << " " << B[i][j];

			cout << "\n";
		}
	}

	{
		std::vector<std::vector<int>> expect =
		{
			{ 4, 8 },
			{ 3, 7 },
			{ 4, 6 },
			{ -1, 5 }
		};

		std::vector<std::vector<int>> matrix =
		{
			{ -1, 4, 3, 4 },
			{ 5, 6, 7, 8 }
		};
		std::vector<std::vector<int>> act = rotateMatrixLeft(matrix);
	}

	{
		std::vector<std::vector<int> > expected, actual;
		expected = { { 3, 4, 4 },{ 6, 4, 4 },{ 2, 2, 4 } };
		actual = matrixAddition({ { 1, 2, 3 },{ 3, 2 , 1 },{ 1, 1, 1 } }, { { 2, 2, 1 },{ 3, 2, 3 },{ 1, 1, 3 } });

		for (std::size_t i{ 0 }; i < actual.size(); ++i)
		{
			for (std::size_t j{ 0 }; j < actual[i].size(); ++j)
			{
				if (expected[i][j] == actual[i][j])
					continue;
				else
					break;
			}
		}

		std::cout << IsPrime<1>::value << ' '
			<< IsPrime<2>::value << '\n';
		std::cout << IsPrime<13>::value << ' '
			<< IsPrime<24>::value << '\n';
	}
	return 0;
}

