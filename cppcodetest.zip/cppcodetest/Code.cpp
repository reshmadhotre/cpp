// Code.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include<string>
#include<algorithm>
#include<unordered_map>
#include<mutex>
#include<execution>
#include<iterator>

template <typename TFunc> void RunAndMeasure(const char* title, TFunc func)
{
	const auto start = std::chrono::steady_clock::now();
	auto ret = func();
	const auto end = std::chrono::steady_clock::now();
	std::cout << title << ": " <<
		std::chrono::duration <double, std::milli>(end - start).count()
		<< " ms, res " << ret << "\n";
}

/*int main()
{
	//std::vector<int> v = { 1, 2, 3 };
	//int sum = 0;
	//std::mutex m;
	//std::for_each(std::execution::par, std::begin(v), std::end(v), [&](int i) {
	//	std::lock_guard<std::mutex> lock{ m };
	//	sum += i * i;
	//	});

	std::vector<double> v(6000000, 0.5);

	RunAndMeasure("std::find, seq", [&v] {
		auto res = std::find(std::execution::seq, std::begin(v), std::end(v), 0.6);
		return res == std::end(v) ? 0.0 : 1.0;
		});

	RunAndMeasure("std::find, par", [&v] {
		auto res = std::find(std::execution::par, std::begin(v), std::end(v), 0.6);
		return res == std::end(v) ? 0.0 : 1.0;
		});

	constexpr long COUNT = 1024 * 1024 * 1024;
	int32_t* data{ new int32_t[COUNT] };

	typedef std::chrono::high_resolution_clock Clock;

	auto t1 = Clock::now();
	std::sort(std::execution::par, data, data + COUNT);
	auto t2 = Clock::now();

	auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(t2 - t1);
	std::cout << elapsed.count() << '\n';

	typedef std::chrono::high_resolution_clock Clock;

	t1 = Clock::now();

	std::sort(data, data + COUNT);
	t2 = Clock::now();

	elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(t2 - t1);
	std::cout << elapsed.count() << '\n';

	std::cout <<"normal :" << std::endl;

	return 0;
}
*/

/*#include <iostream>
#include <map>
#include <shared_mutex>
#include <string>
#include <thread>

std::map<std::string, int> teleBook{ {"Dijkstra",1972},{"Scott",1976},{"Ritchie",1983} };
std::shared_timed_mutex teleBookMutex;

void addToTeleBook(const std::string& na, int tele) {
	std::lock_guard<std::shared_timed_mutex> writerLock(teleBookMutex);
	std::cout << "\nSTARTING UPDATE " << na;
	std::this_thread::sleep_for(std::chrono::milliseconds(500));
	teleBook[na] = tele;
	std::cout << " ... ENDING UPDATE " << na << std::endl;
}

void printNumber(const std::string& na) {
	std::shared_lock<std::shared_timed_mutex> readerLock(teleBookMutex);
	std::cout << na << ": " << teleBook[na] << std::endl;
}

int main()
{
	std::cout << std::endl;

	std::thread reader1([] { printNumber("Scott"); });
	std::thread reader2([] { printNumber("Ritchie"); });
	std::thread w1([] { addToTeleBook("Scott", 1968); });
	std::thread reader3([] { printNumber("Dijkstra"); });
	std::thread reader4([] { printNumber("Scott"); });
	std::thread w2([] { addToTeleBook("Bjarne", 1965); });
	std::thread reader5([] { printNumber("Scott"); });
	std::thread reader6([] { printNumber("Ritchie"); });
	std::thread reader7([] { printNumber("Scott"); });
	std::thread reader8([] { printNumber("Bjarne"); });

	reader1.join();
	reader2.join();
	reader3.join();
	reader4.join();
	reader5.join();
	reader6.join();
	reader7.join();
	reader8.join();
	w1.join();
	w2.join();

	std::cout << std::endl;

	std::cout << "\nThe new telephone book" << std::endl;
	for (auto teleIt : teleBook) {
		std::cout << teleIt.first << ": " << teleIt.second << std::endl;
	}

	std::cout << std::endl;
}

*/
/*
#include <chrono>
#include <iostream>
#include <future>
#include <random>
#include <vector>
#include <numeric>

static const int NUM = 100000000;

long long getDotProduct(std::vector<int>& v, std::vector<int>& w) {

	auto future1 = std::async([&] {return std::inner_product(&v[0], &v[v.size() / 4], &w[0], 0LL); });
	auto future2 = std::async([&] {return std::inner_product(&v[v.size() / 4], &v[v.size() / 2], &w[v.size() / 4], 0LL); });
	auto future3 = std::async([&] {return std::inner_product(&v[v.size() / 2], &v[v.size() * 3 / 4], &w[v.size() / 2], 0LL); });
	auto future4 = std::async([&] {return std::inner_product(&v[v.size() * 3 / 4], &v[v.size()-1], &w[v.size() * 3 / 4], 0LL); });

	return future1.get() + future2.get() + future3.get() + future4.get();
}


int main() {

	std::cout << std::endl;

	// get NUM random numbers from 0 .. 100
	std::random_device seed;

	// generator
	std::mt19937 engine(seed());

	// distribution
	std::uniform_int_distribution<int> dist(0, 100);

	// fill the vectors
	std::vector<int> v, w;
	v.reserve(NUM);
	w.reserve(NUM);
	for (int i = 0; i < NUM; ++i) {
		v.push_back(dist(engine));
		w.push_back(dist(engine));
	}

	// measure the execution time
	std::chrono::system_clock::time_point start = std::chrono::system_clock::now();
	std::cout << "getDotProduct(v,w): " << getDotProduct(v, w) << std::endl;
	std::chrono::duration<double> dur = std::chrono::system_clock::now() - start;
	std::cout << "Parallel Execution: " << dur.count() << std::endl;

	std::cout << std::endl;

	start = std::chrono::system_clock::now();
	std::cout << std::inner_product(&v[0], &v[v.size()-1], &w[0], 0LL)<<std::endl;
	std::chrono::duration<double> dur1 = std::chrono::system_clock::now() - start;
	std::cout << "Sequence Execution: " << dur1.count() << std::endl;

}*/

#include <iostream>
#include <string>

#include "thread.h"

class HelloWorld
{
public:
	DWORD print()
	{
		std::cout << "Hello World!" << std::endl;
		return 0;
	}
};
int main(void)
{
	// Random object with DWORD method (void)
	HelloWorld world;
	// thread should call print method of world.
	Thread<HelloWorld> thread(&world, &HelloWorld::print);
	if (thread.start())
		std::cout << "Thread start()" << std::endl;
	thread.join(); // wait for thread
	return 0;
}