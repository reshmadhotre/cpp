How to compile and run Algorithm
=========================
cmake .. CMakeLists.txt 
cmake  -DCMAKE_BUILD_TYPE=Debug ..
make

./runAlgorithm

https://www.citrix.com/en-in/downloads/workspace-app/linux/workspace-app-for-linux-latest.html
sudo apt list | grep icaclient
sudo apt-get  remove -y icaclient

kpit@L-11587:~/Downloads$ sudo apt-get install ./icaclient_21.3.0.38_amd64.deb 
click no
/etc/icaclient/

set PATH=%PATH%;C:\MinGW\msys\1.0\bin;C:\Program Files\CMake\bin

Launch.json
{
    // Use IntelliSense to learn about possible attributes.
    // Hover to view descriptions of existing attributes.
    // For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
    "version": "0.2.0",
    "configurations": [
       {
            "name": "Python: Current File",
            "type": "python",
            "request": "launch",
            "program": "/home/kpit/magna/repo/FE_RADAR_MERdrDataCubeMidW/Test/AutoGen/Ros2/src/Tools/ros2_tool/main.py",
            "console": "integratedTerminal",
            "justMyCode": true, 
            "cwd":  "/home/kpit/magna/repo/FE_RADAR_MERdrDataCubeMidW/Test/AutoGen/Ros2/src/Tools/ros2_tool"
        }
    ]
}
