 #include <gtest/gtest.h>
#include "algorithm.h"

// TEST()
// {
//     checkBoolValue();
// }

TEST(execute_command_Test, Testexecute_command)
{
    std::string bag_info_file{"bagInfo.txt"};

    // std::string command{"ros2 bag info "};
    // std::string bag_file{" /home/kpit/magna/bag/bag_to_dat/bag_to_dat.db3"};

    // command += bag_file;
    // command += "> ";
    // command += bag_info_file;
    // std::string result = execute_command(command.c_str()); 
    // std::cout<<result;
    // std::cout<<"\nDone\n";

    std::string count_of_topics_command{"grep -o \"Topic:\""};
    count_of_topics_command += bag_info_file;
    count_of_topics_command +=" | wc -l";

    parseFile(bag_info_file, 164);

    
}

TEST(romanToIntTest, romanToInt)
{
    EXPECT_EQ(romanToInt("I"), 1);
    EXPECT_EQ(romanToInt("V"), 5);
    EXPECT_EQ(romanToInt("X"), 10);
    EXPECT_EQ(romanToInt("MMVIII"), 2008);
    EXPECT_EQ(romanToInt("MDCLXVI"), 1666);
}

struct equalId
{
    equalId(uint8_t valueId) : id(valueId) {}
    bool operator()(int x) const { return x == id; }

    uint8_t id;
};
TEST(isIdEqualToObjIdsUsingTransformTest, isIdEqualToObjIdsUsingTransform)
{
    bool expectedObjId[counter] = {0, 1, 0, 0};
    uint8_t prevId[counter] = {1, 2, 3, 4};
    uint8_t objId{2U};
    bool actualObjId[counter];
    std::transform(prevId, prevId + counter, actualObjId, equalId(objId));

    EXPECT_EQ(expectedObjId[0], actualObjId[0]);
    EXPECT_EQ(expectedObjId[1], actualObjId[1]);
    EXPECT_EQ(expectedObjId[2], actualObjId[2]);
    EXPECT_EQ(expectedObjId[3], actualObjId[3]);
}
TEST(TeisIDEqualUsingFindst, isIDEqualUsingFind)
{
    bool expectedObjId[counter] = {0, 1, 0, 0};
    uint8_t prevId[counter] = {1, 2, 3, 2};
    uint8_t objId{2U};
    bool actualObjId[counter];
    std::transform(&prevId[0U], &prevId[counter], &actualObjId[0U], equalId(objId));

    bool *p = std::find(&actualObjId[0U], &actualObjId[counter], true);
    if (p != &actualObjId[counter])
        std::cout << "Element found in myints: " << std::distance(actualObjId, p) << '\n';
    else
        std::cout << "Element not found in myints\n";

    //return (p != actualObjId + counter) ? std::distance(actualObjId, p) : 0;
}

TEST(isIdEqualToObjIdsTest, isIdEqualToObjIds)
{
    bool expectedObjId[counter] = {0, 1, 0, 0};
    uint8_t prevId[counter] = {1, 2, 3, 4};
    bool actualObjId[counter] = {false};
    isIdEqualToObjIds(2, prevId, actualObjId);
    EXPECT_EQ(expectedObjId[0], actualObjId[0]);
    EXPECT_EQ(expectedObjId[1], actualObjId[1]);
    EXPECT_EQ(expectedObjId[2], actualObjId[2]);
    EXPECT_EQ(expectedObjId[3], actualObjId[3]);
}
TEST(isIdEqualToObjIdsReturnPointerTest, isIdEqualToObjIdsReturnPointer)
{
    bool expectedObjId[counter] = {0, 1, 0, 0};
    uint8_t prevId[counter] = {1, 2, 3, 4};
    bool *actualObjId = isIdEqualToObjIdsReturnPointer(2, prevId);
    EXPECT_EQ(expectedObjId[0], actualObjId[0]);
    EXPECT_EQ(expectedObjId[1], actualObjId[1]);
    EXPECT_EQ(expectedObjId[2], actualObjId[2]);
    EXPECT_EQ(expectedObjId[3], actualObjId[3]);
}

int main(int argc, char **argv)
{
   testing::InitGoogleTest(&argc, argv);
   return RUN_ALL_TESTS();

 return 0;
}
 