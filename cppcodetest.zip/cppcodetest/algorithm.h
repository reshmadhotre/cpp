#include <iostream>
#include <algorithm>
#include <map>
#include <string>
#include <stdint.h>
#include <list>
#include <utility>
#include <vector>
#include <numeric>
#include <unordered_map>
#include <cctype>
#include <sstream> 
#include <functional>
#include <iterator>

using namespace std;

#include <cstdio>
#include <memory>
#include <stdexcept>
#include <array>
#include <fstream>

void parseFile(std::string &bag_info_file, int topic_count)
{
	std::ifstream bag_info;
	bag_info.open(bag_info_file);

	std::vector<std::string> topic_names;
	topic_names.reserve(topic_count);
	std::string line;

	std::size_t pos;

	while(getline(bag_info, line))
	{
		pos = line.find("Topic:");
		if (pos != std::string::npos)
		{
			//std::cout<<line<<std::endl;
			pos = pos + 7;
			std::size_t end_pos = line.find("| Type:");
		//	--end_pos;
		//	std::string topic_name = line.substr(pos, end_pos-pos);
		//	std::cout<<topic_name<<std::endl;
			topic_names.push_back(line.substr(pos, end_pos-pos));
		}
	}

	for(auto it: topic_names)
		std::cout<<it<<std::endl;
}

std::string execute_command(const char* cmd) 
{
    std::array<char, 128> buffer;
    std::string result;
    std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(cmd, "r"), pclose);
    if (!pipe) {
        throw std::runtime_error("popen() failed!");
    }
    while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
        result += buffer.data();
    }
    return result;
}

constexpr std::size_t counter{32};
void isIdEqualToObjIds(uint8_t id, uint8_t prevObjId[counter], bool objId[counter])
{
    std::transform(prevObjId, prevObjId + counter, objId, [id](const uint8_t prevId) {
        return id == prevId;
    });
}

bool *isIdEqualToObjIdsReturnPointer(uint8_t id, uint8_t prevObjId[counter])
{
    static bool objId[counter];
    std::transform(prevObjId, prevObjId + counter, objId, [id](const uint8_t prevId) {
        return id == prevId;
    });
    return objId;
}

int romanToInt(const std::string &roman)
{
    std::map<char, int> m{{'I', 1}, {'V', 5}, {'X', 10}, {'L', 50}, {'C', 100}, {'D', 500}, {'M', 1000}};

    std::size_t l = roman.length();
    if (l == 1)
    {
        switch (roman.front())
        {
        case 'I':
            return 1;
        case 'V':
            return 5;
        case 'X':
            return 10;
        case 'L':
            return 50;
        case 'C':
            return 100;
        case 'D':
            return 500;
        case 'M':
            return 1000;
        }
    }

    int result = m[roman[l - 1]];
    for (int i = l - 2; i >= 0; --i)
    {
        int a = m[roman[i]], b = m[roman[i + 1]];
        result = (a < b) ? result - a : result + a;
    }
    return result;
}

int findDeletedNumber(list<int> startingList, list<int> mixedList)
{
    mixedList.sort();
	return std::equal(startingList.begin(), startingList.end(), mixedList.begin()) ? 0 : 1;
}

#include <cmath>
//double distance_between_two_points(Point a, Point b) {
//	return std::hypot(a.x - b.x, a.y - b.y);
//}

long long factorial(const int n)
{
	long long fact{1};
	for (int i{n}; i>1; --i)
		fact *= i;

	return fact;
}
unsigned long long int sum_factorial(std::vector<int> vi)
{
	unsigned long long int sum{0U};
	for (std::size_t j{ 0U }; j <= vi.size(); ++j)
		sum += factorial(vi[j]);

	return sum;
}
template <unsigned p, unsigned i> struct PrimalityTest
{
	enum { value = p % i != 0 && PrimalityTest<p, i - 1>::value };
};

template <unsigned p> struct PrimalityTest<p, 1>
{
	enum { value = 1 };
};

template <unsigned p> struct IsPrime
{
	enum { value = PrimalityTest<p, p - 1>::value };
};

template<>
struct IsPrime<1> { static constexpr bool value = false; };

using matrix_t = std::vector<std::vector<int>>;

matrix_t matrixAddition(matrix_t a, matrix_t b)
{
	matrix_t result{};
	result.resize(a.size());
	for (std::size_t i{ 0 }; i<a.size(); ++i)
		result[i].resize(a[i].size());

	//matrix_t result(a.size(), std::vector<int>(a.size()));

	for (std::size_t i{ 0 }; i<a.size(); ++i)
	{
		for (std::size_t j{ 0 }; j<a[i].size(); ++j)
		{
			result[i].push_back(a[i][j] + b[i][j]);
		}
	}

	/*transform(begin(a), end(a), begin(b), begin(a), [](auto a, auto b) {
		transform(begin(a), end(a), begin(b), begin(a), plus<int>());
		return a;
	});
	
	return a;*/

	return result;
}

#define M 3
#define N 4
// This function stores transpose
// of A[][] in B[][]
void transpose(int A[][N], int B[][M])
{
	int i, j;
	for (i = 0; i < N; i++)
		for (j = 0; j < M; j++)
			B[i][j] = A[j][i];
}


matrix_t rotateMatrixLeft(matrix_t matrix)
{
	int row = matrix.size();
	std::cout << " row size " << row << std::endl;
	int col = matrix[0].size();
	std::cout << " col size " << col << std::endl;

	matrix_t result(col, std::vector<int>(row));

	//Transpose the matrix
	for (int i{ 0 }; i<col; ++i)
		for (int j{ 0 }; j<row; ++j)
			result[i][j] = matrix[j][i];

	//Horizontal reflection
	for (int i{ 0 }; i < row; ++i)
	{
		for (int j{ 0 }, k{ col - 1 }; j <= k; ++j, --k)
		{
			std::cout << "j :" << j << " i :" <<i <<" k :" << k << std::endl;
			std::cout << "result[j][i] : "  << result[j][i]<< "result[k][i]: "<< result[k][i] << std::endl;
			std::swap(result[j][i], result[k][i]);
		}
	}

	return result;
}

std::string switcher(const std::vector<std::string>& arr) {
	std::string s = " zyxwvutsrqponmlkjihgfedcba!? ";
	std::string r;
	for (const std::string& n : arr) r += s[stoi(n)];
	return r;
}

class caseChanger
{
	private:
		enum class caseInput
		{
			camel = 0,
			snake = 1,
			kebab = 2,
			undefined = 3
		};

		std::unordered_map<std::string, caseInput> caseMap{};
		std::string result{}, inputString{};
		caseInput targetcase;

		void camelCase()
		{
			bool takeNext = false;
			for (auto c : inputString)
			{
				if ((c == '_') || (c == '-'))
					takeNext = true;
				else if (std::isalpha(c))
				{
					if (takeNext)
					{
						result += ::toupper(c);
						takeNext = false;
					}
					else
						result += c;
				}
			}
		}
		void snakeCase()
		{
			bool upperFlag{ false };
			for (auto c : inputString)
			{
				if (std::islower(c))
					result += c;
				else if (std::isupper(c))
				{
					upperFlag = true;
					result += "_";
					result += ::tolower(c);
				}
				else if (((c == '_') || (c == '-')) && upperFlag)
				{
					result = "";
					break;
				}
				else if (c == '_')
					result += '_';
				else if (c == '-')
					result += '_';
			}
		}
		void kebabCase()
		{
			bool underscore{ false }, hyphen{ false }, upperFlag{ false };
			for (auto c : inputString)
			{
				if (((c == '_') || (c == '-')) && upperFlag ||
					((c == '_') && hyphen) ||
					((c == '-') && underscore) ||
					(upperFlag && hyphen))
				{
					result = "";
					break;
				}
				else if (c == '_')
				{
					underscore = true;
					result += "-";
				}
				else if (c == '-')
				{
					hyphen = true;
					result += c;
				}
				else if (std::isalpha(c) && std::isupper(c))
				{
					upperFlag = true;
					result += "-";
					result += ::tolower(c);
				}
				else if (std::isalpha(c))
					result += c;
			}
		}

	public:
		caseChanger(const string &identifier, const std::string& targetCase)
		{
			inputString = identifier;
			caseMap = { { "snake", caseInput::snake },
			{ "camel", caseInput::camel },
			{ "kebab", caseInput::kebab } };
			targetcase = caseMap[targetCase];
		}

		void callAppropriateConverter()
		{
			switch (targetcase)
			{
			case caseInput::camel:
				{
					camelCase();
				}
				break;
			case caseInput::snake:
				{
					snakeCase();
				}
				break;
			case caseInput::kebab:
				{
					kebabCase();
				}
				break;
			default:
				break;
			}
		}

		std::string GetResult() const { return result; }
 };

string changeCase(const string &identifier, const string &targetCase)
{
	caseChanger changeCase(identifier, targetCase);
	changeCase.callAppropriateConverter();
	return changeCase.GetResult();
}

using stringArray = std::vector<std::string>;
class WhichAreIn
{
public:
	static stringArray inArray(stringArray &a1, stringArray &a2)
	{
		stringArray result{};
		/*auto it = std::search(a2.begin(), a2.end(), a1.begin(), a1.end(),
			[&](std::string s2, std::string s1){
			if (s2.find(s1) != std::string::npos)
				result.push_back(s1);
		});*/
	}
};

std::string reverseWordsinSentence(const std::string& s)
{
	std::stringstream ss(s);
	string rev, result;
	
	while (ss >> rev)
	{
		reverse(rev.begin(), rev.end());
		result += rev;
		result += " ";
	}
	reverse(result.begin(), result.end());
	return result;
}

static std::string longestConsec(std::vector<std::string> &s, int k)
{
	if ((s.empty()) || (k>s.size()) || (k <= 0))
		return "";

	std::size_t max{ 0 };
	std::string str{}, result{};
	for (std::size_t i{ 0 }; i <= s.size() - k; ++i)
	{
		str = std::accumulate(s.begin() + i, s.begin() + (i + k), str);
		if (str.length() > max)
		{
			result = str;
			max = str.length();
		}
		str = "";
	}
	return result;
}

string strong_num(int n)
{
	vector<int> fact{ 1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880 };
	long sum{ 0 };
	for (int i{ n }; i > 0; i = n/10)
		sum += fact[i%10];

	std::cout << " sum " << sum << std::endl;
	
	std::string s =  (sum == n) ? "STRONG!!!!" : "Not Strong !!";
	return s;
}
using ull = unsigned long long;
ull perimeterOfRectangle(int n)
{
	std::vector<ull> v(n + 1, 1);
	std::adjacent_difference(v.begin(), v.end() - 1, v.begin() + 1, std::plus<ull>());
	return (std::accumulate(v.begin(), v.end(), 0L) * 4);
}

class RevRot
{
public:
	static string revRot(const string &str, unsigned int sz)
	{
		std::cout << str << "\n" << sz << "\n";
		if (sz <= 0) return "";

		std::string result = str.substr(0, str.size() / sz * sz);

		for (int i = 0; i < result.size(); i += sz)
		{
			// iterators for beginning and ending of substring
			auto begin = std::next(result.begin(), i);
			auto end = std::next(result.begin(), i + sz);

			if (std::accumulate(begin, end, 0, [](const int sum, const char& c) {
				return sum + std::pow(c-'0', 3); }) %2 ==0 )
				std::reverse(begin, end);
			else
				std::rotate(begin, begin + 1, end);
					
		}
		return result;
	}

	static long long maxRot(long long n)
	{
		std::cout << n << std::endl;
		string result{ to_string(n) };

		rotate(result.begin(), result.begin() + 1, result.end());
		for (std::size_t i{ 0U }; i<result.length() - 2; ++i)
		{
			std::cout << result  << " i "<<i << std::endl;
			auto begin = std::next(result.begin() + i);
			auto end = std::next(result.begin() + (result.length()-1));
			rotate(begin, begin + 1, end);
		}
		std::cout << result << std::endl;
		return stoll(result);
	}
};

std::string reverse_words(std::string str)
{
	auto start = str.begin();
	for (auto it = str.begin(); it != str.end(); ++it) 
	{
		if (std::isspace(*it)) 
		{
			std::reverse(start, it);
			start = it + 1;
		}
	}
	std::reverse(start, str.end());
	return str;
}
std::vector<int> sortByFrequency(const std::vector<int>& vec)
{
	{
		std::unordered_map<int, int> item_count;
		for (std::size_t i{ 0 }; i < vec.size(); ++i)
			++item_count[vec[i]];

		std::vector<std::pair<int, int> > v;
		std::copy(item_count.begin(), item_count.end(), std::back_inserter(v));
		std::sort(v.begin(), v.end(), [&](std::pair<int, int> a, std::pair<int, int> b) {
			if (a.second == b.second)
				return a.first < b.first;
			return a.second > b.second;
		});

		std::vector<int> result;
		for (std::size_t j{ 0 }; j < v.size(); ++j)
			for (int i{ 0 }; i < v[j].second; ++i)
				result.push_back(v[j].first);

		return result;
	}
	{
		std::unordered_map<int, int> m;
		for (std::size_t i{ 0 }; i < vec.size(); ++i)
			++m[vec[i]];

		auto res = vec;
		std::sort(res.begin(), res.end(), [&](int a, int b) {
			return (m[a] > m[b]) || (m[a] == m[b] && a < b);
		});

		return res;
	}

	{
		auto res = vec;
		sort(res.begin(), res.end(), [&](int a, int b) {
			auto x = std::count(vec.begin(), vec.end(), a), y = std::count(vec.begin(), vec.end(), b);
			return x == y ? a < b : x > y;
		});
		return res;
	}
	{
		std::vector<int> r;
		std::for_each(r.begin(), r.end(), [](const int i) {std::cout << i << " "; });
		std::cout << std::endl;
	}
}

using intPair = std::vector<std::pair<int, int>>;
intPair twos_difference(const std::vector<int> &vec)
{
	std::vector<int> temp = vec;
	std::sort(temp.begin(), temp.end());
	std::for_each(vec.begin(), vec.end(), [](const int i) {std::cout << i << " "; });
	std::cout << std::endl;
	intPair pair;
	for (std::size_t l{ 0 }, r{ 0 }; l < vec.size() ; )
	{
		std::cout << " l " << l << " r " << r << " temp[l] " << temp[l] << " temp[r] " << temp[r] << std::endl;
		if (std::abs(temp[r] - temp[l]) == 2)
		{
			pair.push_back(std::make_pair(temp[r], temp[l]));
			if (r < vec.size())
				++r;
			if (l < vec.size())
				++l;
		}
		else if ((std::abs(temp[r] - temp[l]) > 2) && (r < vec.size()))
			++r;
		else if ((std::abs(temp[r] - temp[l]) < 2) && (l < vec.size()))
			++l;
	}
	return pair;
}

int number_of_valid_ranges_with_subarray_sum_k()
{
 unordered_map<int, int> ptab;
    ptab[0] = 1;
    
    int res =0, psum=0;
    
    vector<int> a={0,1,2,3,4,5,6,7,8};
    int k=18;

    for(int i=0; i<a.size(); ++i)
    {
        psum += a[i];
        std::cout<<psum<<" " <<psum-k<<" "<<std::endl;
        if (ptab.count(psum-k))
         res += ptab[psum-k];
         
        ++ptab[psum]; 
        std::cout<<psum<<" "<<ptab[psum]<<"\n";
    }
    
    std::cout<<res<<std::endl;
    return res;
}
