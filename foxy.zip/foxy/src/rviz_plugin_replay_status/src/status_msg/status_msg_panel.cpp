#include "rviz_plugin_replay_status/status_msg/status_msg_panel.hpp"

namespace rviz_plugin_replay_status
{

const std::string StatusMsgPanel::NODE_FEEDBACK_TYPE{"msg_swc_common/msg/MsgNodeFeedbackType"};
const std::string StatusMsgPanel::VIDEO_NODE_FEEDBACK_TYPE{"server_replay_video/msg/MsgVideoReplayStatus"};


StatusMsgPanel::StatusMsgPanel(QWidget* parent) : Panel(parent)
{
    try
    {
        properties_widget_ = std::make_unique<StatusMsgWidget>(parent);
    }
    catch(std::exception& e)
    {
        std::cout << " StatusMsgPanel Exception 1 " << e.what() << std::endl;
    } 
}

void StatusMsgPanel::onInitialize()
{
    auto node = getDisplayContext()->getRosNodeAbstraction().lock()->get_raw_node();

    replaytool_subscriber = node->create_subscription<msg_replay_status::msg::MsgReplayToolRvizPlugin>(
        "/topic_replay_tool_data",rclcpp::SystemDefaultsQoS(),
        std::bind(&StatusMsgPanel::replayToolFeedbackCB, this, std::placeholders::_1));

    createReplayStatusPublishers();
    addStatusWidget();

    fillTopicList();
    subscribe();
}

void StatusMsgPanel::addStatusWidget()
{
    try
    {
        QVBoxLayout* layout = new QVBoxLayout;
        addTopicFrame();
        layout->addLayout(topic_layout_);

        properties_widget_->createInputFrame();
        layout->addWidget(properties_widget_.get());

        setLayout(layout);
    }
    catch(std::exception& e)
    {
        std::cout << " StatusMsgPanel Exception 2" << e.what() << std::endl;
    }
}

void StatusMsgPanel::addTopicFrame()
{
    topic_layout_ = new QFormLayout;
    QLabel* topic_label_= new QLabel(tr("Topic:"));
    topic_combobox_ = new QComboBox;
    connect(topic_combobox_, QOverload<int>::of(&QComboBox::activated), this,
            &StatusMsgPanel::topic_changed);

    topic_layout_->addRow(topic_label_, topic_combobox_);
}

void StatusMsgPanel::save(rviz_common::Config config) const
{
    Panel::save(config);
}

void StatusMsgPanel::load(const rviz_common::Config& conf)
{
    Panel::load(conf);
}

void StatusMsgPanel::fillTopicList()
{
    auto node = getDisplayContext()->getRosNodeAbstraction().lock()->get_raw_node();
    std::map<std::string, std::vector<std::string>> published_topics = node->get_topic_names_and_types();

    Device device_name = properties_widget_->getDeviceName();
    for (const auto& topic : published_topics)
    {
        for (const auto& type : topic.second)
        {
            if ( (type == NODE_FEEDBACK_TYPE) ||
                 (type == VIDEO_NODE_FEEDBACK_TYPE) )
            {
                    topic_combobox_->addItem(tr(topic.first.c_str()));
            }
        }
    }
}

void StatusMsgPanel::topic_changed(int index)
{
    subscribe();
}

void StatusMsgPanel::subscribe()
{
    if (topic_combobox_->count() > 0)
    {
        std::string topic = topic_combobox_->currentText().toStdString();
        fetchNamespace(topic);
        createTopicNamesFromNamespace();
        auto node = getDisplayContext()->getRosNodeAbstraction().lock()->get_raw_node();

        Device device_name = properties_widget_->getDeviceName();
        if ( (device_name == Device::Radar) ||
             (device_name == Device::CAN) ||
             (device_name == Device::CANVideo)  )
        {
            feedback_subscriber.reset();
            feedback_subscriber = node->create_subscription<msg_swc_common::msg::MsgNodeFeedbackType>(
                    topic, rclcpp::SystemDefaultsQoS(),
                    std::bind(&StatusMsgPanel::nodeFeedbackCB, this, std::placeholders::_1));
        }
        else if (device_name == Device::Video) 
        {
            feedback_video_subscriber.reset();
            feedback_video_subscriber = node->create_subscription<server_replay_video::msg::MsgVideoReplayStatus>(
                    topic, rclcpp::SystemDefaultsQoS(),
                    std::bind(&StatusMsgPanel::nodeVideoFeedbackCB, this, std::placeholders::_1));
        }
    }
}

void StatusMsgPanel::fetchNamespace(std::string topic)
{
    int number_of_slashes = std::count(topic.cbegin(), topic.cend(), '/');
    if (number_of_slashes == 2)
    {
        size_t position_of_second_slash{topic.find_last_of("/")};
        Name_Space = topic.substr(0, (position_of_second_slash));
        //std::cout<<"Name_Space "<<Name_Space<<std::endl;
    }
    else if (number_of_slashes == 1)
    {
        Name_Space = "";
        RADAR_NEXT_FRAME = "/topic_trigger_radar_next_frame";
        RADAR_PAUSE = "/topic_set_radar_pause_mode";

        VIDEO_NEXT_FRAME = "/topic_trigger_video_next_frame";
        VIDEO_PAUSE = "/topic_set_video_pause_mode";

        CAN_NEXT_FRAME = "/topic_trigger_can_next_frame";
        CAN_PAUSE = "/topic_set_can_pause_mode";
    }
}

void StatusMsgPanel::createTopicNamesFromNamespace()
{
    if (!Name_Space.empty())
    {
        RADAR_NEXT_FRAME = Name_Space + RADAR_NEXT_FRAME;
        RADAR_PAUSE = Name_Space + RADAR_PAUSE ;

        VIDEO_NEXT_FRAME = Name_Space + VIDEO_NEXT_FRAME;
        VIDEO_PAUSE = Name_Space + VIDEO_PAUSE;

        CAN_NEXT_FRAME = Name_Space + CAN_NEXT_FRAME;
        CAN_PAUSE = Name_Space + CAN_PAUSE;
    }
    //std::cout<<"RADAR_NEXT_FRAME "<<RADAR_NEXT_FRAME<<std::endl;
    //std::cout<<"RADAR_PAUSE "<<RADAR_PAUSE<<std::endl;
    //std::cout<<"VIDEO_NEXT_FRAME "<<VIDEO_NEXT_FRAME<<std::endl;
    //std::cout<<"VIDEO_PAUSE "<<VIDEO_PAUSE<<std::endl;
    //std::cout<<"CAN_NEXT_FRAME "<<CAN_NEXT_FRAME<<std::endl;
    //std::cout<<"CAN_PAUSE "<<CAN_PAUSE<<std::endl;
    createPublishers();
}

void StatusMsgPanel::nodeFeedbackCB(msg_swc_common::msg::MsgNodeFeedbackType::SharedPtr msg)
{
    std::chrono::steady_clock::time_point msg_receive_time_ = std::chrono::steady_clock::now();
    properties_widget_->updateData(*msg.get());
}

void StatusMsgPanel::nodeVideoFeedbackCB(server_replay_video::msg::MsgVideoReplayStatus::SharedPtr msg)
{
    std::chrono::steady_clock::time_point msg_receive_time_ = std::chrono::steady_clock::now();
    properties_widget_->updateVideoData(*msg.get());
}

void StatusMsgPanel::replayToolFeedbackCB(msg_replay_status::msg::MsgReplayToolRvizPlugin::SharedPtr msg)
{
    properties_widget_->updateReplayToolData(*msg.get());
}

void StatusMsgPanel::createRadarPublishers()
 {
    radar_next_frame_publisher.reset();
    radar_pause_mode_publisher.reset();

    auto node = getDisplayContext()->getRosNodeAbstraction().lock()->get_raw_node();

    radar_next_frame_publisher = node->create_publisher<msg_replay_radar::msg::MsgTriggerSingleFrame>(
        RADAR_NEXT_FRAME, rclcpp::SystemDefaultsQoS());
    radar_pause_mode_publisher = node->create_publisher<msg_replay_radar::msg::MsgSetPauseMode>(
        RADAR_PAUSE, rclcpp::SystemDefaultsQoS());

    properties_widget_->setRadarPublishers(radar_next_frame_publisher, 
                                        radar_pause_mode_publisher);
 }

void StatusMsgPanel::createVideoPublishers()
{
    video_next_frame_publisher.reset();
    video_pause_mode_publisher.reset();

    auto node = getDisplayContext()->getRosNodeAbstraction().lock()->get_raw_node();

    video_next_frame_publisher = node->create_publisher<server_replay_video::msg::MsgTriggerSingleFrame>(
        VIDEO_NEXT_FRAME, rclcpp::SystemDefaultsQoS());
    video_pause_mode_publisher = node->create_publisher<server_replay_video::msg::MsgSetPauseMode>(
        VIDEO_PAUSE, rclcpp::SystemDefaultsQoS());

    properties_widget_->setVideoPublishers(video_next_frame_publisher,
                                        video_pause_mode_publisher);
}

void StatusMsgPanel::createCanPublishers()
{
    can_next_frame_publisher.reset();
    can_pause_mode_publisher.reset();

    auto node = getDisplayContext()->getRosNodeAbstraction().lock()->get_raw_node();

    can_next_frame_publisher = node->create_publisher<server_replay_can::msg::MsgTriggerSingleFrame>(
        CAN_NEXT_FRAME, rclcpp::SystemDefaultsQoS());
    can_pause_mode_publisher = node->create_publisher<server_replay_can::msg::MsgSetPauseMode>(
        CAN_PAUSE, rclcpp::SystemDefaultsQoS());

    properties_widget_->setCANPublishers(can_next_frame_publisher,
                                        can_pause_mode_publisher);
}

void StatusMsgPanel::createReplayStatusPublishers()
{
    auto node = getDisplayContext()->getRosNodeAbstraction().lock()->get_raw_node();
    replaytool_publisher = node->create_publisher<msg_replay_status::msg::MsgReplayToolRvizPlugin>(
        "/topic_replay_tool_data", rclcpp::SystemDefaultsQoS());
    properties_widget_->setReplayStatusPublishers(
                                        replaytool_publisher);
}

void StatusMsgPanel::createPublishers()
{
    createRadarPublishers();
    createVideoPublishers();
    createCanPublishers();
}

} // namespace rviz_plugin_replay_status

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(rviz_plugin_replay_status::StatusMsgPanel, rviz_common::Panel)