#include "rviz_plugin_replay_status/status_msg/status_msg_widget.hpp"

#include <QFormLayout>
#include <QSpacerItem>
#include <QMessageBox>
#include <iostream>
#include <QTimer>

namespace rviz_plugin_replay_status
{

StatusMsgWidget::StatusMsgWidget(QWidget* parent)
: layout_status_{new QVBoxLayout},
  progress_bar_ {new QProgressBar},
  formlayout_{new QFormLayout}
{}

void StatusMsgWidget::createInputFrame()
{
    try
    {
        createStatusFrame();
        createProgressBarFrame();
        createButtonFrame();
        setLayout(layout_status_);
    }
    catch(std::exception& e)
    {
        std::cout << " StatusMsgWidget Exception " << e.what() << std::endl;
    } 
    catch (...)
    {
        std::cout << " StatusMsgWidget default Exception raised"<<std::endl;
    }
}

void StatusMsgWidget::createStatusFrame()
{
    if (create_rosbag_flag_)
    {
        setGeometry(10, 10, 740, 180);
        QLabel *rosbag_path_lbl = createLabel("Rosbag Path:");

        rosbag_path_value_ = createLabel("");
        rosbag_path_value_->setWordWrap(true);

        formlayout_->addRow(rosbag_path_lbl, rosbag_path_value_);
    }
    else
        setGeometry(10, 10, 740, 150);

    QLabel *processing_file_lbl = createLabel("Processing File : ");
    processing_file_value_ = createLabel("");
    processing_file_value_->setMinimumSize(250,50);
    processing_file_value_->setWordWrap(true);

    formlayout_->addRow(processing_file_lbl, processing_file_value_);
    if (stand_alone_device_ == Device::Radar)
    {
        status_lbl_ = createLabel("Status : ");
        status_value_ = createLabel("");

        formlayout_->addRow(status_lbl_, status_value_);
    }

    timestamp_lbl_ = createLabel("Timestamp : ");
    timestamp_value_ = createLabel("");
    timestamp_value_->setWordWrap(true);

    formlayout_->addRow(timestamp_lbl_, timestamp_value_);

    elapsed_time_lbl_ = createLabel("Elapsed Time : ");
    elapsed_time_value_ = createLabel("");
    elapsed_time_value_->setWordWrap(true);

    formlayout_->addRow(elapsed_time_lbl_, elapsed_time_value_);

    layout_status_->addLayout(formlayout_);
}

void StatusMsgWidget::createProgressBarFrame()
{
    QVBoxLayout *layout_progress_bar = new QVBoxLayout;
    layout_progress_bar->setAlignment(Qt::AlignCenter);

    progress_bar_->setStyleSheet("QProgressBar "
            "{"
            "border: 2px solid rgba(33, 37, 43, 180);"
            "border-radius: 5px;"
            "text-align: center;"
            "background-color: rgba(33, 37, 43, 180);"
            "color: white;"
            "}"
            );

    if (stand_alone_device_ == Device::Radar)
        progress_bar_->setValue(progress_bar_value_);

    layout_progress_bar->addWidget(progress_bar_);
    layout_status_->addLayout(layout_progress_bar);
}

void StatusMsgWidget::createButtonFrame()
{
    // Layout for button'''
    QHBoxLayout *horizontal_layout_btn = new QHBoxLayout;
    horizontal_layout_btn->setSpacing(0);

    play_pause_btn_ = new PushButton(pause_text,
        "Play/Pause the Mf4 file",
        u":/16x16/icons/16x16/cil-media-pause.png");

    next_frame_btn_ = new PushButton(next_frame,
        "Choose the next frame of the Mf4 file",
        u":/16x16/icons/16x16/cil-media-step-forward.png");
    next_frame_btn_->setDisabled(true);

    stop_btn_ = new PushButton(stop_text,
        "Stop the launched processes",
         u":/16x16/icons/16x16/cil-media-stop.png");

    QObject::connect(play_pause_btn_, &QPushButton::clicked, this, &StatusMsgWidget::playPauseClicked);
    QObject::connect(next_frame_btn_, &QPushButton::clicked, this,  &StatusMsgWidget::nextFrameClicked);
    QObject::connect(stop_btn_, &QPushButton::clicked, this, &StatusMsgWidget::stopClicked);

    horizontal_layout_btn->addWidget(play_pause_btn_);
    QSpacerItem *spacer1 = new QSpacerItem(10, 0, QSizePolicy::Minimum, QSizePolicy::Minimum);
    horizontal_layout_btn->addSpacerItem(spacer1);
    horizontal_layout_btn->addWidget(next_frame_btn_);
    QSpacerItem *spacer2 = new QSpacerItem(10, 0, QSizePolicy::Minimum, QSizePolicy::Minimum);
    horizontal_layout_btn->addSpacerItem(spacer2);
    horizontal_layout_btn->addWidget(stop_btn_);

    layout_status_->addLayout(horizontal_layout_btn);
}


Device StatusMsgWidget::getDeviceName()
{
    //std::cout <<"device "<< (unsigned)stand_alone_device_<<std::endl;
    return stand_alone_device_;
}

void StatusMsgWidget::updateReplayToolData(const msg_replay_status::msg::MsgReplayToolRvizPlugin& msg)
{
    if (msg.device_name == "Radar") 
        stand_alone_device_ = Device::Radar;
    else if (msg.device_name == "Video") 
        stand_alone_device_ = Device::Video;
    else if (msg.device_name == "CAN") 
        stand_alone_device_ = Device::CAN;
    else if (msg.device_name == "CANVideo") 
        stand_alone_device_ = Device::CANVideo;
    else if (msg.device_name == "NoneType") 
        stand_alone_device_ = Device::NoneType;

    create_rosbag_flag_ = msg.create_rosbag_flag;
}

void StatusMsgWidget::updateData(const msg_swc_common::msg::MsgNodeFeedbackType& msg)
{
   formatNodeFeedback(msg);
}

void StatusMsgWidget::updateVideoData(const server_replay_video::msg::MsgVideoReplayStatus& msg)
{
   formatVideoNodeFeedback(msg);
}

void StatusMsgWidget::formatVideoNodeFeedback(
    const server_replay_video::msg::MsgVideoReplayStatus& node_feedback)
{
    if (stand_alone_device_ == Device::Video)
    {
        status_lbl_->hide();
        progress_bar_->setMinimum(0);
        progress_bar_->setMaximum(0);
        progress_bar_->setValue(0);

        if (node_feedback.status == node_feedback.FINISHED)
        {
            std::string text{"Finished processing all files.\n"};

            QMessageBox::information(this, tr("Status"),
                        tr(text.c_str()),QMessageBox::Ok);
            stopClicked();
        }
        else
        {
            elapsed_time_value_->setText(QString::number(node_feedback.elapsed_time));

            std::string mf4_file{node_feedback.file_under_process};
            if (processing_file_value_->text().toStdString() != mf4_file)
            {
                processing_file_value_->setText(mf4_file.c_str());
            }

            timestamp_value_->setText(QString::number(node_feedback.video_timestamp));
        }
    }
}

void StatusMsgWidget::formatNodeFeedback(
    const msg_swc_common::msg::MsgNodeFeedbackType& node_feedback)
{
    std::string finished_msg;
    if (stand_alone_device_ == Device::Radar)
    {
        timestamp_lbl_->hide();
        elapsed_time_lbl_->hide();
        finished_msg = node_feedback.FINISHED;
    }

    else if ((stand_alone_device_ == Device::CAN) ||
             (stand_alone_device_ == Device::CANVideo))
    {
        timestamp_lbl_->show();

        elapsed_time_lbl_->hide();
        if (stand_alone_device_ == Device::CANVideo)
        {
            status_lbl_->hide();
            progress_bar_->setMinimum(0);
            progress_bar_->setMaximum(0);
            progress_bar_->setValue(0);
        }

        finished_msg = node_feedback.FINISHED;
        timestamp_value_->setText(QString::number(node_feedback.radar_timestamp));
    }

    if (node_feedback.status == finished_msg)
    {
        std::string rosbag_text{"Finished processing all files.\n"};
        if (create_rosbag_flag_)
            rosbag_text =  "Rosbag saved to : " + node_feedback.rosbag_path;

        QMessageBox::information(this, tr("Status"),
                    tr(rosbag_text.c_str()),QMessageBox::Ok);
        stopClicked();
    }
    else
    {
        std::string mf4_file{node_feedback.file_under_process};
        if (processing_file_value_->text().toStdString() != mf4_file)
        {
            processing_file_value_->clear();
            processing_file_value_->setText(mf4_file.c_str());
        }

        if (create_rosbag_flag_)
        {
            std::string rosbag_path = node_feedback.rosbag_path;
            if (rosbag_path_value_->text().toStdString() != rosbag_path)
                rosbag_path_value_->clear();
                rosbag_path_value_->setText(node_feedback.rosbag_path.c_str());
        }

        if (stand_alone_device_ == Device::Radar || stand_alone_device_ == Device::CAN)
        {
            std::string status = "Processing file " + std::to_string(node_feedback.num_files_processed) + " of " + std::to_string(node_feedback.num_files_to_process);
            if (player_mode_ != play_text)
            {
                progress_bar_value_ = progress_bar_value_ + 1;
                float files_to_process{static_cast<float>(node_feedback.num_files_to_process)};
                float files_processed {static_cast<float>(node_feedback.num_files_processed)};
                if (node_feedback.status != node_feedback.FINISHED)
                    if (files_to_process && files_to_process != 1)
                    {
                        progress_bar_value_ = ( files_processed/files_to_process ) * 100;
                        progress_bar_value_ = progress_bar_value_- 5.0;
                    }
                progress_bar_->setValue(progress_bar_value_);
            }
            status_value_->setText(status.c_str());
        }
    }
}

void StatusMsgWidget::playPauseClicked()
{
    if (player_mode_ == stop_text)
        enablePauseMode();

    else if (player_mode_ == play_text)
    {
        enablePauseMode();
        setPauseMsgAndPublish(false);
    }

    else if (player_mode_ == pause_text)
    {
        enablePlayMode();
        setPauseMsgAndPublish(true);
    }
}

void StatusMsgWidget::nextFrameClicked()
{
    setWidgetAbility(next_frame_btn_, false);

    if (player_mode_ == play_text)
    {
        bool pausePlayValue{false};

        if (stand_alone_device_ == Device::Radar)
        {
            auto publish_msg = msg_replay_radar::msg::MsgTriggerSingleFrame();
            publish_msg.publish_next_frame = pausePlayValue;

            radar_next_frame_publisher->publish(publish_msg);

            auto publish_can_msg = server_replay_can::msg::MsgTriggerSingleFrame();
            can_next_frame_publisher->publish(publish_can_msg);

            auto publish_vid_msg = server_replay_video::msg::MsgTriggerSingleFrame();
            video_next_frame_publisher->publish(publish_vid_msg);

        }
        else if ((stand_alone_device_ == Device::CAN) ||
                 (stand_alone_device_ == Device::CANVideo))
        {
            auto publish_msg = server_replay_can::msg::MsgTriggerSingleFrame();
            publish_msg.publish_next_frame = pausePlayValue;

            can_next_frame_publisher->publish(publish_msg);

            auto publish_vid_msg = server_replay_video::msg::MsgTriggerSingleFrame();
            video_next_frame_publisher->publish(publish_vid_msg);
        }
        else if (stand_alone_device_ == Device::Video)
        {
            auto publish_msg = server_replay_video::msg::MsgTriggerSingleFrame();
            publish_msg.publish_image = pausePlayValue;

            video_next_frame_publisher->publish(publish_msg);
        }
        //std::string result{ "pauseplayvalue :" + std::to_string(pausePlayValue)};
        //std::cout <<"next frame publish_msg.publish_next_frame: "<<result<<std::endl;;
    }
    setWidgetAbility(next_frame_btn_, false);
    setWidgetAbility(play_pause_btn_, false);
    setWidgetAbility(stop_btn_, false);
}

void StatusMsgWidget::setPauseMsgAndPublish(bool pause_playback_value)
{
    if (stand_alone_device_ == Device::Radar)
    {
        auto pause_msg = msg_replay_radar::msg::MsgSetPauseMode();
        pause_msg.pause_playback = pause_playback_value;

        radar_pause_mode_publisher->publish(pause_msg);

        auto can_pause_msg = server_replay_can::msg::MsgSetPauseMode();
        can_pause_mode_publisher->publish(can_pause_msg);

        auto vid_pause_msg = server_replay_video::msg::MsgSetPauseMode();
        video_pause_mode_publisher->publish(vid_pause_msg);
    }
    else if ((stand_alone_device_ == Device::CAN) ||
             (stand_alone_device_ == Device::CANVideo))
    {
        auto pause_msg = server_replay_can::msg::MsgSetPauseMode();
        pause_msg.pause_playback = pause_playback_value;

        can_pause_mode_publisher->publish(pause_msg);

        auto vid_pause_msg = server_replay_video::msg::MsgSetPauseMode();
        video_pause_mode_publisher->publish(vid_pause_msg);
    }
    else if (stand_alone_device_ == Device::Video)
    {
        auto pause_msg = server_replay_video::msg::MsgSetPauseMode();
        pause_msg.pause_playback = pause_playback_value;

        video_pause_mode_publisher->publish(pause_msg);
    }
    //std::string result{ "pauseplayvalue :" + std::to_string(pause_playback_value)};
    //std::cout <<"setPauseMsgAndPublish : "<<result<<std::endl;;
}

void StatusMsgWidget::stopClicked()
{
    player_mode_ = stop_text;
    enableStopMode();
    setWidgetAbility(stop_btn_, true);

    auto replay_tool_data = msg_replay_status::msg::MsgReplayToolRvizPlugin();
    replay_tool_data.status_mode = stop_text;
    //since one published data is getting lost, so sending multiple
    for(int i{0}; i<10; ++i)
        replaytool_publisher->publish(replay_tool_data);
}

void StatusMsgWidget::enablePlayMode()
{
    player_mode_ = play_text;
    play_pause_btn_->setText(play_text.c_str());
    // setWidgetIcon(widget=play_pause_btn_,
    //                 icon_png = u":/16x16/icons/16x16/cil-media-play.png");
    setWidgetAbility(stop_btn_, false);
    setWidgetAbility(next_frame_btn_, false);
}

void StatusMsgWidget::enablePauseMode()
{
    player_mode_ = pause_text;
    play_pause_btn_->setText(pause_text.c_str());
    // setWidgetIcon(widget=play_pause_btn_,
    //                 icon_png = u":/16x16/icons/16x16/cil-media-pause.png");
    setWidgetAbility(stop_btn_, false);
    setWidgetAbility(next_frame_btn_, true);
}

void StatusMsgWidget::enableStopMode()
{
    player_mode_ = stop_text;
    play_pause_btn_->setText(play_text.c_str());
    setWidgetAbility(stop_btn_, true);
    setWidgetAbility(next_frame_btn_, true);
}

void StatusMsgWidget::setWidgetAbility(QWidget *widget, bool value)
{
    widget->setDisabled(value);
}

void StatusMsgWidget::setRadarPublishers(
      rclcpp::Publisher<msg_replay_radar::msg::MsgTriggerSingleFrame>::SharedPtr next_frame_publisher,
      rclcpp::Publisher<msg_replay_radar::msg::MsgSetPauseMode>::SharedPtr pause_mode_publisher)
{
    radar_next_frame_publisher = next_frame_publisher;
    radar_pause_mode_publisher = pause_mode_publisher;
}

void StatusMsgWidget::setVideoPublishers(
      rclcpp::Publisher<server_replay_video::msg::MsgTriggerSingleFrame>::SharedPtr next_frame_publisher,
      rclcpp::Publisher<server_replay_video::msg::MsgSetPauseMode>::SharedPtr pause_mode_publisher)
{
    video_next_frame_publisher = next_frame_publisher;
    video_pause_mode_publisher = pause_mode_publisher;
}

void StatusMsgWidget::setCANPublishers(
    rclcpp::Publisher<server_replay_can::msg::MsgTriggerSingleFrame>::SharedPtr next_frame_publisher,
    rclcpp::Publisher<server_replay_can::msg::MsgSetPauseMode>::SharedPtr pause_mode_publisher)
{
    can_next_frame_publisher = next_frame_publisher;
    can_pause_mode_publisher = pause_mode_publisher;
}

void StatusMsgWidget::setReplayStatusPublishers(
    rclcpp::Publisher<msg_replay_status::msg::MsgReplayToolRvizPlugin>::SharedPtr replay_publisher)
{
    replaytool_publisher = replay_publisher;
}


} // namespace rviz_plugin_replay_status