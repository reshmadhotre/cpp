#ifndef QT_UTILS_HPP
#define QT_UTILS_HPP

#include <QPushButton>
#include <QIcon>
#include <QLabel>

namespace rviz_plugin_replay_status
{

class PushButton : public QPushButton
{
    public: 
    PushButton(std::string text, std::string tooltip, bool icon_png=false)
    {
        setText(text.c_str());
        setToolTip(tooltip.c_str());
        setToolTipDuration(1000);

        QFont *font = new QFont;
        font->setFamily("Segoe UI");
        font->setPointSize(9);

        setMinimumSize(QSize(150, 30));
        //setFont(font);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        //setStyleSheet(Style.style_pushbutton);
        // if icon_png
        //     QIcon icon;
        //     icon.addFile(icon_png, QSize(), QIcon.Normal, QIcon.Off);
        //     setIcon(icon);
    }
};

inline QLabel* createLabel(std::string label_text, std::string tooltip="")
{
    QLabel *label = new QLabel;
    label->setText(label_text.c_str());
    label->setToolTip(tooltip.c_str());
    // duration for 5 secs
    label->setToolTipDuration(500);
    label->setTextInteractionFlags(Qt::TextSelectableByMouse);
    label->setTextInteractionFlags(Qt::TextSelectableByKeyboard);
    return label;
}

inline void setWidgetIcon(QWidget *widget, std::string icon_png="")
{
    QIcon *icon = new QIcon;
    icon->addFile(icon_png.c_str(), QSize(), QIcon::Normal, QIcon::Off);
    //widget->setIcon(QIcon(QPixmap(icon_png.c_str())));
}

enum class Device: std::uint8_t
{
     Radar,
     CAN ,
     Video ,
     CANVideo ,
     Rosbag ,
     NoneType
};

} // namespace rviz_plugin_replay_status
#endif