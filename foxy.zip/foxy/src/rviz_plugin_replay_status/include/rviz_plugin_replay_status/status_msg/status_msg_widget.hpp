#ifndef REPLAY_STATUS_WIDGET_HPP
#define REPLAY_STATUS_WIDGET_HPP

#include "rclcpp/rclcpp.hpp"

#include <QVBoxLayout>
#include <QFormLayout>
#include <QProgressBar>
#include <QLabel>
#include <QPushButton>

#include "msg_swc_common/msg/msg_node_feedback_type.hpp"
#include "server_replay_video/msg/msg_video_replay_status.hpp"
#include "msg_replay_status/msg/msg_replay_tool_rviz_plugin.hpp"

#include "msg_replay_radar/msg/msg_trigger_single_frame.hpp"
#include "server_replay_video/msg/msg_trigger_single_frame.hpp"
#include "server_replay_can/msg/msg_trigger_single_frame.hpp"

#include "msg_replay_radar/msg/msg_set_pause_mode.hpp"
#include "server_replay_video/msg/msg_set_pause_mode.hpp"
#include "server_replay_can/msg/msg_set_pause_mode.hpp"

#include "rviz_plugin_replay_status/visibility_control.hpp"
#include "rviz_plugin_replay_status/status_msg/qt_utils.hpp"




namespace rviz_plugin_replay_status
{

class REC_REPLAY_PLUGIN_PUBLIC StatusMsgWidget : public QWidget
{
    Q_OBJECT
  public:
    StatusMsgWidget(QWidget* parent = nullptr);
    void createInputFrame();
    void updateData(const msg_swc_common::msg::MsgNodeFeedbackType& msg);
    void updateVideoData(const server_replay_video::msg::MsgVideoReplayStatus& msg);
    void updateReplayToolData(const msg_replay_status::msg::MsgReplayToolRvizPlugin& msg);

    Device getDeviceName();
    void setRadarPublishers(
      rclcpp::Publisher<msg_replay_radar::msg::MsgTriggerSingleFrame>::SharedPtr next_frame_publisher,
      rclcpp::Publisher<msg_replay_radar::msg::MsgSetPauseMode>::SharedPtr pause_mode_publisher);
    void setVideoPublishers(
      rclcpp::Publisher<server_replay_video::msg::MsgTriggerSingleFrame>::SharedPtr next_frame_publisher,
      rclcpp::Publisher<server_replay_video::msg::MsgSetPauseMode>::SharedPtr pause_mode_publisher);
    void setCANPublishers(
      rclcpp::Publisher<server_replay_can::msg::MsgTriggerSingleFrame>::SharedPtr next_frame_publisher,
      rclcpp::Publisher<server_replay_can::msg::MsgSetPauseMode>::SharedPtr pause_mode_publisher);
    void setReplayStatusPublishers(
      rclcpp::Publisher<msg_replay_status::msg::MsgReplayToolRvizPlugin>::SharedPtr replay_publisher);

  private:
    void createStatusFrame();
    void createProgressBarFrame();
    void createButtonFrame();

    void formatNodeFeedback(const msg_swc_common::msg::MsgNodeFeedbackType& msg);
    void formatVideoNodeFeedback(const server_replay_video::msg::MsgVideoReplayStatus& msg);

    void playPauseClicked();
    void nextFrameClicked();
    void stopClicked();

    void enablePlayMode();
    void enablePauseMode();
    void enableStopMode();
    void setPauseMsgAndPublish(bool pause_playback_value);
    void setWidgetAbility(QWidget *widget, bool value);

    QVBoxLayout *const layout_status_{nullptr};
    QFormLayout *const formlayout_{nullptr};
    QLabel *rosbag_path_value_{nullptr};
    QLabel *processing_file_value_{nullptr};
    QLabel *timestamp_lbl_{nullptr};
    QLabel *timestamp_value_{nullptr};
    QLabel *elapsed_time_lbl_{nullptr};
    QLabel *elapsed_time_value_{nullptr};
    QLabel *status_lbl_{nullptr};
    QLabel *status_value_{nullptr};
    QProgressBar *const progress_bar_{nullptr};
    QPushButton *play_pause_btn_{nullptr};
    QPushButton *next_frame_btn_{nullptr};
    QPushButton *stop_btn_{nullptr};

    bool create_rosbag_flag_{false};
    float progress_bar_value_{1.0F};

    Device stand_alone_device_{Device::Radar};

    const std::string play_text {"  Play"};
    const std::string pause_text {"  Pause"};
    const std::string stop_text {"  Stop"};
    const std::string next_frame {"  Next Frame"};

    std::string player_mode_{pause_text};

    rclcpp::Publisher<msg_replay_status::msg::MsgReplayToolRvizPlugin>::SharedPtr replaytool_publisher;

    rclcpp::Publisher<msg_replay_radar::msg::MsgTriggerSingleFrame>::SharedPtr radar_next_frame_publisher;
    rclcpp::Publisher<server_replay_video::msg::MsgTriggerSingleFrame>::SharedPtr video_next_frame_publisher;
    rclcpp::Publisher<server_replay_can::msg::MsgTriggerSingleFrame>::SharedPtr can_next_frame_publisher;

    rclcpp::Publisher<msg_replay_radar::msg::MsgSetPauseMode>::SharedPtr radar_pause_mode_publisher;
    rclcpp::Publisher<server_replay_video::msg::MsgSetPauseMode>::SharedPtr video_pause_mode_publisher;
    rclcpp::Publisher<server_replay_can::msg::MsgSetPauseMode>::SharedPtr can_pause_mode_publisher;

};
} // namespace rviz_plugin_replay_status
#endif