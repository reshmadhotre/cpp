#ifndef REPLAY_STATUS_PANEL_HPP
#define REPLAY_STATUS_PANEL_HPP

#include "rclcpp/rclcpp.hpp"
#include "rviz_common/display_context.hpp"
#include <rviz_common/panel.hpp>

#include <QVBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QComboBox>

#include "msg_swc_common/msg/msg_node_feedback_type.hpp"
#include "server_replay_video/msg/msg_video_replay_status.hpp"
#include "msg_replay_status/msg/msg_replay_tool_rviz_plugin.hpp"

#include "msg_replay_radar/msg/msg_trigger_single_frame.hpp"
#include "server_replay_video/msg/msg_trigger_single_frame.hpp"
#include "server_replay_can/msg/msg_trigger_single_frame.hpp"

#include "msg_replay_radar/msg/msg_set_pause_mode.hpp"
#include "server_replay_video/msg/msg_set_pause_mode.hpp"
#include "server_replay_can/msg/msg_set_pause_mode.hpp"

#include "rviz_plugin_replay_status/status_msg/status_msg_widget.hpp"
#include "rviz_plugin_replay_status/visibility_control.hpp"



namespace rviz_plugin_replay_status
{
class REC_REPLAY_PLUGIN_PUBLIC StatusMsgPanel : public rviz_common::Panel
{
    Q_OBJECT

  public:
    explicit StatusMsgPanel(QWidget* parent = 0);

    void addStatusWidget();

    void onInitialize() override;
    void save(rviz_common::Config config) const override;
    void load(const rviz_common::Config& config) override;

  private:
    void nodeFeedbackCB(msg_swc_common::msg::MsgNodeFeedbackType::SharedPtr msg);
    void nodeVideoFeedbackCB(server_replay_video::msg::MsgVideoReplayStatus::SharedPtr msg);
    void replayToolFeedbackCB(msg_replay_status::msg::MsgReplayToolRvizPlugin::SharedPtr msg);

    void createPublishers();
    void createRadarPublishers();
    void createVideoPublishers();
    void createCanPublishers();
    void createReplayStatusPublishers();

    void fillTopicList();
    void subscribe();
    void topic_changed(int index);
    void addTopicFrame();
    void fetchNamespace(std::string topic);
    void createTopicNamesFromNamespace();

    std::unique_ptr<StatusMsgWidget> properties_widget_;
    rclcpp::Subscription<msg_replay_status::msg::MsgReplayToolRvizPlugin>::SharedPtr replaytool_subscriber;
    rclcpp::Publisher<msg_replay_status::msg::MsgReplayToolRvizPlugin>::SharedPtr replaytool_publisher;

    rclcpp::Subscription<msg_swc_common::msg::MsgNodeFeedbackType>::SharedPtr feedback_subscriber;
    rclcpp::Subscription<server_replay_video::msg::MsgVideoReplayStatus>::SharedPtr feedback_video_subscriber; 

    rclcpp::Publisher<msg_replay_radar::msg::MsgTriggerSingleFrame>::SharedPtr radar_next_frame_publisher;
    rclcpp::Publisher<server_replay_video::msg::MsgTriggerSingleFrame>::SharedPtr video_next_frame_publisher;
    rclcpp::Publisher<server_replay_can::msg::MsgTriggerSingleFrame>::SharedPtr can_next_frame_publisher;

    rclcpp::Publisher<msg_replay_radar::msg::MsgSetPauseMode>::SharedPtr radar_pause_mode_publisher;
    rclcpp::Publisher<server_replay_video::msg::MsgSetPauseMode>::SharedPtr video_pause_mode_publisher;
    rclcpp::Publisher<server_replay_can::msg::MsgSetPauseMode>::SharedPtr can_pause_mode_publisher;

    QComboBox* topic_combobox_;
    QFormLayout* topic_layout_;

    static const std::string NODE_FEEDBACK_TYPE;
    static const std::string VIDEO_NODE_FEEDBACK_TYPE;

    std::string RADAR_NEXT_FRAME{"/topic_trigger_radar_next_frame"};
    std::string RADAR_PAUSE{"/topic_set_radar_pause_mode"};

    std::string VIDEO_NEXT_FRAME{"/topic_trigger_video_next_frame"};
    std::string VIDEO_PAUSE{"/topic_set_video_pause_mode"};

    std::string CAN_NEXT_FRAME{"/topic_trigger_can_next_frame"};
    std::string CAN_PAUSE{"/topic_set_can_pause_mode"};

    std::string Name_Space{""};
};
} // namespace rviz_plugin_replay_status
#endif