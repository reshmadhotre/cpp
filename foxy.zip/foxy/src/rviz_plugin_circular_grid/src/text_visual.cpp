#include "rviz_plugin_circular_grid/text_visual.hpp"

namespace rviz_plugin_circular_grid
{
TextVisual::TextVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node, const std::string& text)
{
    scene_manager_ = scene_manager;
    frame_node_ = parent_node->createChildSceneNode();

    text_holder_ = std::make_shared<rviz_rendering::MovableText>(text);
    text_holder_->setTextAlignment(rviz_rendering::MovableText::H_CENTER, rviz_rendering::MovableText::V_CENTER);
    frame_node_->attachObject(text_holder_.get());
    frame_node_->setVisible(false);
}

TextVisual::~TextVisual()
{
    frame_node_->detachAllObjects();
    text_holder_.reset();
    scene_manager_->destroySceneNode(frame_node_);
}

void TextVisual::setMessage(const Ogre::Vector3 position, const Ogre::ColourValue& colour)
{
    frame_node_->setVisible(true);
    frame_node_->setPosition(position);
    text_holder_->setColor(colour);
}
} // namespace rviz_plugin_circular_grid