#include "rviz_plugin_circular_grid/circular_grid_display.hpp"
#include <iostream>
namespace rviz_plugin_circular_grid
{
CircularGridDisplay::CircularGridDisplay()
{
    circle_width_property_ = new rviz_common::properties::FloatProperty(
        "Grid Width", circle_width_, "Width of a grid circle in metres.", this, SLOT(updateCircleWidth()));
    circle_width_property_->setMin(0.01f);
    circle_width_property_->setMax(1.0f);

    circle_transparency_property_ = new rviz_common::properties::FloatProperty(
        "Grid Line Transparency", circle_transparency_, "Transparency of grid circle", this,
        SLOT(updateCircleTransparency()));
    circle_transparency_property_->setMin(0.1f);
    circle_transparency_property_->setMax(1.0f);

    grid_step_property_ = new rviz_common::properties::IntProperty(
        "Step size", grid_step_, "Step size for grid circles. Min : 5m", this, SLOT(updateGridStep()));
    grid_step_property_->setMin(5);

    circle_colour_property_ = new rviz_common::properties::ColorProperty(
        "Grid Colour", Qt::gray, "Color to draw the grid circles.", this, SLOT(updateGridColour()));

    show_scale_property_ = new rviz_common::properties::BoolProperty(
        "Show Scale", show_scale_, "Show/Hide scale readings", this, SLOT(updateShowScale()));
}

CircularGridDisplay::~CircularGridDisplay() = default;

void CircularGridDisplay::onInitialize()
{
    QColor colour = circle_colour_property_->getColor();
    colour.setAlphaF(circle_transparency_property_->getFloat());
    circle_colour_ = qtToOgre(colour);
    updateGridCircles();
    updateScaleVisuals();
}

Ogre::ColourValue CircularGridDisplay::qtToOgre(const QColor& c)
{
    return Ogre::ColourValue(c.redF(), c.greenF(), c.blueF(), c.alphaF());
}

bool CircularGridDisplay::validateFloats(const Ogre::Vector3& pos)
{
    bool valid{true};
    valid = valid && validateFloats(pos.x);
    valid = valid && validateFloats(pos.y);
    valid = valid && validateFloats(pos.z);

    return valid;
}

void CircularGridDisplay::updateCircleWidth()
{
    circle_width_ = circle_width_property_->getFloat();
    updateGridCircles();
}

void CircularGridDisplay::updateGridStep()
{
    grid_step_ = grid_step_property_->getInt();
    updateGridCircles();
    updateScaleVisuals();
}

void CircularGridDisplay::updateCircleTransparency()
{
    QColor colour = circle_colour_property_->getColor();
    colour.setAlphaF(circle_transparency_property_->getFloat());
    circle_colour_ = qtToOgre(colour);
    updateGridCircles();
    updateScaleVisuals();
}

void CircularGridDisplay::updateGridColour()
{
    QColor colour = circle_colour_property_->getColor();
    colour.setAlphaF(circle_transparency_property_->getFloat());
    circle_colour_ = qtToOgre(colour);
    updateGridCircles();
    updateScaleVisuals();
}

void CircularGridDisplay::updateShowScale()
{
    show_scale_ = show_scale_property_->getBool();
    updateScaleVisuals();
}

void CircularGridDisplay::updateGridCircles()
{
    grid_circles_.clear();

    int num_circles = max_grid_range_ / grid_step_;

    for (int index = 0; index < num_circles; index++)
    {
        int circle_number = index + 1;
        float circle_radius = grid_step_ * circle_number;

        std::vector<Ogre::Vector3> points_on_circle = getPointsOnCircle(circle_radius);

        auto grid_circle = std::make_shared<rviz_rendering::BillboardLine>(scene_manager_, scene_node_);
        grid_circle->clear();
        grid_circle->setNumLines(1);
        grid_circle->setMaxPointsPerLine(points_on_circle.size());
        grid_circle->setLineWidth(circle_width_);

        addPointsToBillboardLine(grid_circle.get(), points_on_circle, circle_colour_);

        grid_circles_.push_back(grid_circle);
    }
}

void CircularGridDisplay::updateScaleVisuals()
{
    if (!show_scale_)
    {
        x_axis_line_.reset();
        y_axis_line_.reset();
        distance_text_markers_.clear();
        return;
    }
    updateXYAxes();
    updateDistanceMarkers();
}

void CircularGridDisplay::updateXYAxes()
{
    x_axis_line_.reset(new rviz_rendering::BillboardLine(scene_manager_, scene_node_));
    y_axis_line_.reset(new rviz_rendering::BillboardLine(scene_manager_, scene_node_));

    int num_circles = max_grid_range_ / grid_step_;

    auto last_circle_radius = num_circles * grid_step_;
    std::vector<Ogre::Vector3> x_axis_points{Ogre::Vector3(-last_circle_radius, 0.0f, 0.0f),
                                             Ogre::Vector3(last_circle_radius, 0.0f, 0.0f)};
    std::vector<Ogre::Vector3> y_axis_points{Ogre::Vector3(0.0f, -last_circle_radius, 0.0f),
                                             Ogre::Vector3(0.0f, last_circle_radius, 0.0f)};

    addPointsToBillboardLine(x_axis_line_.get(), x_axis_points, circle_colour_);
    addPointsToBillboardLine(y_axis_line_.get(), y_axis_points, circle_colour_);
}

void CircularGridDisplay::updateDistanceMarkers()
{
    distance_text_markers_.clear();

    int num_circles = max_grid_range_ / grid_step_;
    for (int i = 1; i <= num_circles; i++)
    {
        std::string text = std::to_string(int(i * grid_step_)) + "m";
        auto text_marker = std::make_shared<TextVisual>(scene_manager_, scene_node_, text);
        Ogre::Vector3 text_pos(i * grid_step_, 0.0f, 0.0f);
        text_marker->setMessage(text_pos, circle_colour_);

        distance_text_markers_.push_back(text_marker);
    }
}

void CircularGridDisplay::addPointsToBillboardLine(rviz_rendering::BillboardLine* line,
                                                   const std::vector<Ogre::Vector3>& positions,
                                                   const Ogre::ColourValue& colour)
{
    for (const auto& pos : positions)
    {
        if (validateFloats(pos))
        {
            line->addPoint(pos, colour);
        }
    }
}

std::vector<Ogre::Vector3> CircularGridDisplay::getPointsOnCircle(float radius)
{
    std::vector<Ogre::Vector3> positions;

    positions.emplace_back(Ogre::Vector3(radius, 0.0f, 0.0f));

    for (float x = radius - 0.1; x > -radius; x -= 0.1)
    {
        float y = std::sqrt(radius * radius - x * x);
        positions.emplace_back(Ogre::Vector3(x, y, 0.0f));
    }

    positions.emplace_back(Ogre::Vector3(-radius, 0.0f, 0.0f));

    for (float x = -radius + 0.1; x < radius; x += 0.1)
    {
        float y = std::sqrt(radius * radius - x * x);
        positions.emplace_back(Ogre::Vector3(x, -y, 0.0f));
    }

    positions.emplace_back(Ogre::Vector3(radius, 0.0f, 0.0f));

    return positions;
}
} // namespace rviz_plugin_circular_grid

#include <pluginlib/class_list_macros.hpp> // NOLINT
PLUGINLIB_EXPORT_CLASS(rviz_plugin_circular_grid::CircularGridDisplay, rviz_common::Display)