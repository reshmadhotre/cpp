#ifndef TEXT_VISUAL_HPP
#define TEXT_VISUAL_HPP

#include "rviz_rendering/objects/movable_text.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>
#include <OgreVector3.h>

namespace rviz_plugin_circular_grid
{
class TextVisual
{
  public:
    TextVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node, const std::string& text);
    ~TextVisual();
    void setMessage(const Ogre::Vector3 position, const Ogre::ColourValue& colour);

  private:
    Ogre::SceneNode* frame_node_;
    Ogre::SceneManager* scene_manager_;
    std::shared_ptr<rviz_rendering::MovableText> text_holder_;
};
} // namespace rviz_plugin_circular_grid
#endif