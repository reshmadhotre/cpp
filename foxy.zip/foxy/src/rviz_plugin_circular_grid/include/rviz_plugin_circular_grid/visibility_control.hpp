#ifndef REC_REPLAY_PLUGIN__VISIBILITY_CONTROL_H_
#define REC_REPLAY_PLUGIN__VISIBILITY_CONTROL_H_

// This logic was borrowed (then namespaced) from the examples on the gcc wiki:
//     https://gcc.gnu.org/wiki/Visibility

#if defined _WIN32 || defined __CYGWIN__
#ifdef __GNUC__
#define REC_REPLAY_PLUGIN_EXPORT __attribute__((dllexport))
#define REC_REPLAY_PLUGIN_IMPORT __attribute__((dllimport))
#else
#define REC_REPLAY_PLUGIN_EXPORT __declspec(dllexport)
#define REC_REPLAY_PLUGIN_IMPORT __declspec(dllimport)
#endif
#ifdef REC_REPLAY_PLUGIN_BUILDING_LIBRARY
#define REC_REPLAY_PLUGIN_PUBLIC REC_REPLAY_PLUGIN_EXPORT
#else
#define REC_REPLAY_PLUGIN_PUBLIC REC_REPLAY_PLUGIN_IMPORT
#endif
#define REC_REPLAY_PLUGIN_PUBLIC_TYPE REC_REPLAY_PLUGIN_PUBLIC
#define REC_REPLAY_PLUGIN_LOCAL
#else
#define REC_REPLAY_PLUGIN_EXPORT __attribute__((visibility("default")))
#define REC_REPLAY_PLUGIN_IMPORT
#if __GNUC__ >= 4
#define REC_REPLAY_PLUGIN_PUBLIC __attribute__((visibility("default")))
#define REC_REPLAY_PLUGIN_LOCAL __attribute__((visibility("hidden")))
#else
#define REC_REPLAY_PLUGIN_PUBLIC
#define REC_REPLAY_PLUGIN_LOCAL
#endif
#define REC_REPLAY_PLUGIN_PUBLIC_TYPE
#endif

#endif // REC_REPLAY_PLUGIN__VISIBILITY_CONTROL_H_