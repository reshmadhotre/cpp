#ifndef CIRCULAR_GRID_DISPLAY_HPP
#define CIRCULAR_GRID_DISPLAY_HPP

#include "rviz_plugin_circular_grid/text_visual.hpp"
#include "rviz_common/display.hpp"
#include "rviz_rendering/objects/billboard_line.hpp"
#include "visibility_control.hpp"
#include <rviz_common/properties/color_property.hpp>
#include <rviz_common/properties/float_property.hpp>
#include <rviz_common/properties/int_property.hpp>

namespace rviz_plugin_circular_grid
{
class REC_REPLAY_PLUGIN_PUBLIC CircularGridDisplay : public rviz_common::Display
{
    Q_OBJECT

  public:
    CircularGridDisplay();
    ~CircularGridDisplay();

    void onInitialize() override;

  private slots:
    void updateCircleWidth();
    void updateCircleTransparency();
    void updateGridStep();
    void updateGridColour();
    void updateShowScale();

  private:
    std::vector<Ogre::Vector3> getPointsOnCircle(float radius);
    void updateGridCircles();
    void updateScaleVisuals();
    void updateXYAxes();
    void updateDistanceMarkers();
    void addPointsToBillboardLine(rviz_rendering::BillboardLine* line, const std::vector<Ogre::Vector3>& positions,
                                  const Ogre::ColourValue& colour);
    inline bool validateFloats(float val)
    {
        return !(std::isnan(val) || std::isinf(val));
    }
    bool validateFloats(const Ogre::Vector3& pos);
    Ogre::ColourValue qtToOgre(const QColor& c);

    std::vector<std::shared_ptr<rviz_rendering::BillboardLine>> grid_circles_;
    std::shared_ptr<rviz_rendering::BillboardLine> x_axis_line_;
    std::shared_ptr<rviz_rendering::BillboardLine> y_axis_line_;
    std::vector<std::shared_ptr<TextVisual>> distance_text_markers_;

    rviz_common::properties::FloatProperty* circle_width_property_;
    float circle_width_{0.1}; // metres
    rviz_common::properties::FloatProperty* circle_transparency_property_;
    float circle_transparency_{0.5f};
    rviz_common::properties::IntProperty* grid_step_property_;
    int grid_step_{5}; // metres
    rviz_common::properties::ColorProperty* circle_colour_property_;
    Ogre::ColourValue circle_colour_;
    rviz_common::properties::BoolProperty* show_scale_property_;
    bool show_scale_{true};
    int max_grid_range_{300};
};
} // namespace rviz_plugin_circular_grid
#endif