#include "TestMagna2RosConverter.hpp"

TEST_F(TestMagna2RosConverter, rra_scan_param_conversion_default_values)
{
    RRAScanParameters rra_scan_param{};
    auto ros_scan_param_uhdp = std::make_unique<msg_replay_radar::msg::MsgRraScanParameters>();
    converter_->ConvertMessage(rra_scan_param, ros_scan_param_uhdp.get());

    AssertEqual(rra_scan_param, ros_scan_param_uhdp.get());
}

TEST_F(TestMagna2RosConverter, rra_scan_param_conversion_random_values)
{
    RRAScanParameters rra_scan_param = CreateRraScanParameterWithRandomValues();
    auto ros_scan_param_uhdp = std::make_unique<msg_replay_radar::msg::MsgRraScanParameters>();
    converter_->ConvertMessage(rra_scan_param, ros_scan_param_uhdp.get());

    AssertEqual(rra_scan_param, ros_scan_param_uhdp.get());
}

TEST_F(TestMagna2RosConverter, detection_data_conversion_zero_detections)
{
    int num_detections = 0;
    RRADetectionData detection_data;
    auto ros_detection_data = std::make_unique<msg_replay_radar::msg::MsgRraDetectionDataList>();
    converter_->ConvertMessage(detection_data, num_detections, ros_detection_data.get());

    AssertEqual(detection_data, ros_detection_data.get(), num_detections);
}

TEST_F(TestMagna2RosConverter, detection_data_conversion_random_values)
{
    uint16_t num_detections = 1 + GetRandomUnsignedInt();

    RRADetectionData detection_data;
    CreateDetectionDataWithRandomValues(num_detections, detection_data);
    auto ros_detection_data = std::make_unique<msg_replay_radar::msg::MsgRraDetectionDataList>();
    converter_->ConvertMessage(detection_data, num_detections, ros_detection_data.get());
    AssertEqual(detection_data, ros_detection_data.get(), num_detections);
}

TEST_F(TestMagna2RosConverter, point_cloud_conversion_default_values)
{
    auto ros_point_cloud_uhdp = std::make_unique<msg_replay_radar::msg::MsgRraPointCloudDataList>();
    uint32_t num_raw_points = 0;
    RRAPointCloudData point_cloud_data_ptr;
    converter_->ConvertMessage(point_cloud_data_ptr, num_raw_points, ros_point_cloud_uhdp.get());
    AssertEqual(point_cloud_data_ptr, ros_point_cloud_uhdp.get(), num_raw_points);
}

TEST_F(TestMagna2RosConverter, point_cloud_conversion_random_values)
{
    auto ros_point_cloud_uhdp = std::make_unique<msg_replay_radar::msg::MsgRraPointCloudDataList>();
    RRAPointCloudData point_cloud_data_ptr;
    uint32_t num_raw_points = 1 + GetRandomUnsignedInt();
    CreatePointCloudDataWithRandomValues(num_raw_points, point_cloud_data_ptr);
    converter_->ConvertMessage(point_cloud_data_ptr, num_raw_points, ros_point_cloud_uhdp.get());
    AssertEqual(point_cloud_data_ptr, ros_point_cloud_uhdp.get(), num_raw_points);
}

TEST_F(TestMagna2RosConverter, point_cloud_static_conversion_default_values)
{
    RRAPointCloudDataFloat point_cloud_static_alloc_type;
    auto ros_point_cloud = std::make_unique<msg_replay_radar::msg::MsgRraPointCloudDataFloatList>();
    uint32_t num_raw_points = 0;
    converter_->ConvertMessage(point_cloud_static_alloc_type, num_raw_points, ros_point_cloud.get());
    AssertEqual(point_cloud_static_alloc_type, ros_point_cloud.get());
}

TEST_F(TestMagna2RosConverter, point_cloud_static_conversion_random_values)
{
    RRAPointCloudDataFloat point_cloud_static_alloc_type;
    uint32_t num_raw_points = 1 + GetRandomUnsignedInt();
    CreatePointCloudFloatWithRandomValues(num_raw_points, point_cloud_static_alloc_type);
    auto ros_point_cloud = std::make_unique<msg_replay_radar::msg::MsgRraPointCloudDataFloatList>();
    converter_->ConvertMessage(point_cloud_static_alloc_type, num_raw_points, ros_point_cloud.get());
    AssertEqual(point_cloud_static_alloc_type, ros_point_cloud.get());
}

int main(int argc, char** argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
