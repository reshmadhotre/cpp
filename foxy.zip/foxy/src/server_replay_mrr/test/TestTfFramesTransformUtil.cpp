#include "TestTfFramesTransformUtil.hpp"

TEST_F(CLASSNAME(TestTfFramesTransformUtil, RMW_IMPLEMENTATION), sensor_mount_params_not_available)
{
    geometry_msgs::msg::TransformStamped transform_stamped = frames_transform_util_->GetFrameTransform();

    EXPECT_STREQ(transform_stamped.header.frame_id.c_str(), "map");
    EXPECT_STREQ(transform_stamped.child_frame_id.c_str(), expected_namespace.c_str());
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.x, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.y, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.z, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.x, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.y, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.z, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.w, 1.0);
}

TEST_F(CLASSNAME(TestTfFramesTransformUtil, RMW_IMPLEMENTATION), sensor_mount_params_zero_values)
{
    this->SetParameter("sensor_position_x", 0.0);
    this->SetParameter("sensor_position_y", 0.0);
    this->SetParameter("sensor_position_z", 0.0);
    this->SetParameter("sensor_yaw", 0);
    this->SetParameter("sensor_pitch", 0);
    this->SetParameter("sensor_roll", 0);

    geometry_msgs::msg::TransformStamped transform_stamped = frames_transform_util_->GetFrameTransform();

    EXPECT_STREQ(transform_stamped.header.frame_id.c_str(), "map");
    EXPECT_STREQ(transform_stamped.child_frame_id.c_str(), expected_namespace.c_str());
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.x, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.y, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.z, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.x, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.y, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.z, 0.0);
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.w, 1.0);
}

TEST_F(CLASSNAME(TestTfFramesTransformUtil, RMW_IMPLEMENTATION), sensor_mount_params_positive_values)
{
    double sensor_position_x = 3.5;
    double sensor_position_y = 0.1;
    double sensor_position_z = 0.5;

    double sensor_yaw_deg = 30.0;
    double sensor_pitch_deg = 55.0;
    double sensor_roll_deg = 10.0;

    this->SetParameter("sensor_position_x", sensor_position_x);
    this->SetParameter("sensor_position_y", sensor_position_y);
    this->SetParameter("sensor_position_z", sensor_position_z);
    this->SetParameter("sensor_yaw", sensor_yaw_deg);
    this->SetParameter("sensor_pitch", sensor_pitch_deg);
    this->SetParameter("sensor_roll", sensor_roll_deg);

    geometry_msgs::msg::TransformStamped transform_stamped = frames_transform_util_->GetFrameTransform();

    tf2::Quaternion expected_quat =
        ToQuaternion(ToRadians(-1.0 * sensor_yaw_deg), ToRadians(-1.0 * sensor_pitch_deg), ToRadians(sensor_roll_deg));

    EXPECT_STREQ(transform_stamped.header.frame_id.c_str(), "map");
    EXPECT_STREQ(transform_stamped.child_frame_id.c_str(), expected_namespace.c_str());
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.x, sensor_position_x);
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.y, -1.0 * sensor_position_y);
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.z, -1.0 * sensor_position_z);
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.x, expected_quat.x());
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.y, expected_quat.y());
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.z, expected_quat.z());
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.w, expected_quat.w());
}

TEST_F(CLASSNAME(TestTfFramesTransformUtil, RMW_IMPLEMENTATION), sensor_mount_params_negative_values)
{
    double sensor_position_x = -4.7;
    double sensor_position_y = -2.0;
    double sensor_position_z = -1.3;

    double sensor_yaw_deg = -15.5;
    double sensor_pitch_deg = -36.8;
    double sensor_roll_deg = -9.5;

    this->SetParameter("sensor_position_x", sensor_position_x);
    this->SetParameter("sensor_position_y", sensor_position_y);
    this->SetParameter("sensor_position_z", sensor_position_z);
    this->SetParameter("sensor_yaw", sensor_yaw_deg);
    this->SetParameter("sensor_pitch", sensor_pitch_deg);
    this->SetParameter("sensor_roll", sensor_roll_deg);

    geometry_msgs::msg::TransformStamped transform_stamped = frames_transform_util_->GetFrameTransform();

    tf2::Quaternion expected_quat =
        ToQuaternion(ToRadians(-1.0 * sensor_yaw_deg), ToRadians(-1.0 * sensor_pitch_deg), ToRadians(sensor_roll_deg));

    EXPECT_STREQ(transform_stamped.header.frame_id.c_str(), "map");
    EXPECT_STREQ(transform_stamped.child_frame_id.c_str(), expected_namespace.c_str());
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.x, sensor_position_x);
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.y, -1.0 * sensor_position_y);
    EXPECT_FLOAT_EQ(transform_stamped.transform.translation.z, -1.0 * sensor_position_z);
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.x, expected_quat.x());
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.y, expected_quat.y());
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.z, expected_quat.z());
    EXPECT_FLOAT_EQ(transform_stamped.transform.rotation.w, expected_quat.w());
}

int main(int argc, char* argv[])
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
