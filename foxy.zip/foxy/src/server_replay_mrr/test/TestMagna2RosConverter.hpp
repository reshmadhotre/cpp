#ifndef TEST_MAGNA_2_ROS_CONVERTER_HPP
#define TEST_MAGNA_2_ROS_CONVERTER_HPP

#include "Magna2RosConverter.h"
#include "rclcpp/rclcpp.hpp"
#include "gtest/gtest.h"

class TestMagna2RosConverter : public ::testing::Test
{
  public:
    TestMagna2RosConverter()
    {
        converter_ = std::make_shared<Magna2RosConverter>();
        srand(time(0)); // Init seed for random number generation
    }

    RRAScanParameters CreateRraScanParameterWithRandomValues()
    {
        RRAScanParameters rra_scan_param;

        // Fill scanInfo
        rra_scan_param.scanInfo.activation_filter_snr = GetRandomFloat();
        rra_scan_param.scanInfo.analog_die_temp_C = GetRandomFloat();
        rra_scan_param.scanInfo.antenna_config_id = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.az_uniform_vrx = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.az_vrx_spacing_lambda = GetRandomFloat();
        rra_scan_param.scanInfo.azimuth_nyquist_oversampling_factor = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.board_T3_temp_C = GetRandomFloat();
        rra_scan_param.scanInfo.carrier_frequency = GetRandomFloat();
        rra_scan_param.scanInfo.chip_temp_C = GetRandomFloat();
        rra_scan_param.scanInfo.chip_time = GetRandomFloat();
        rra_scan_param.scanInfo.chips_per_pulse = GetRandomInt();
        rra_scan_param.scanInfo.CI_bytes_per_pixel = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.CI_doppler_height = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.CI_doppler_width = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.CI_format = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.CI_height = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.CI_pixel_size_in_meters = GetRandomFloat();
        rra_scan_param.scanInfo.CI_width = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.clock_tick_denominator = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.clock_tick_numerator = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.clutter_image_exponent = GetRandomInt();
        rra_scan_param.scanInfo.code_type = GetRandomInt();
        rra_scan_param.scanInfo.complex_rdc3 = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.connection_uhdp_version = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.current_time = GetRandomUnsignedInt();
        // rra_scan_param.scanInfo.dc_bias; //TODO
        rra_scan_param.scanInfo.dop_rotator_shift = GetRandomFloat();
        rra_scan_param.scanInfo.doppler_bin_width = GetRandomFloat();
        rra_scan_param.scanInfo.ego_angular_velocity_X = GetRandomFloat();
        rra_scan_param.scanInfo.ego_angular_velocity_Y = GetRandomFloat();
        rra_scan_param.scanInfo.ego_angular_velocity_Z = GetRandomFloat();
        rra_scan_param.scanInfo.ego_linear_velocity_X = GetRandomFloat();
        rra_scan_param.scanInfo.ego_linear_velocity_Y = GetRandomFloat();
        rra_scan_param.scanInfo.ego_linear_velocity_Z = GetRandomFloat();
        rra_scan_param.scanInfo.el_uniform_vrx = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.el_vrx_spacing_lambda = GetRandomFloat();
        rra_scan_param.scanInfo.elevation_nyquist_oversampling_factor = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.estimated_ego_flag = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.estimated_ego_velocity_X = GetRandomFloat();
        rra_scan_param.scanInfo.estimated_ego_velocity_Y = GetRandomFloat();
        rra_scan_param.scanInfo.estimated_ego_velocity_Z = GetRandomFloat();
        rra_scan_param.scanInfo.extrapolated_ego_velocity_X = GetRandomFloat();
        rra_scan_param.scanInfo.extrapolated_ego_velocity_Y = GetRandomFloat();
        rra_scan_param.scanInfo.extrapolated_ego_velocity_Z = GetRandomFloat();
        rra_scan_param.scanInfo.num_angle_noise_floor_groups = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_azimuth_angles = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_beamforming_angles = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_channelizer_doppler_bins = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_channelizer_iters = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_detections = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_elevation_angles = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_histograms = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_music_instances = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_pulses = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_range_bins = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_RD_above_cutoff = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_RD_lower = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_RD_upper = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.num_tx_prn = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.number_of_radars = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.overflow_underflow_flags = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.peak_detector_output = GetRandomFloat();
        rra_scan_param.scanInfo.preset_applied = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.preset_diff_flags = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.pulse_time = GetRandomFloat();
        rra_scan_param.scanInfo.radar_status_bitmap = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.range_bin_start = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.range_bin_width = GetRandomFloat();
        rra_scan_param.scanInfo.rb_combine = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.rdc1_full_scale_value = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.rdc1_software_exponent = GetRandomInt();
        rra_scan_param.scanInfo.rdc2_full_scale_value = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.rdc2_software_exponent = GetRandomInt();
        rra_scan_param.scanInfo.rdc2_zd_rb_center = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.rdc2_zd_rb_halfwidth = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.rdc2ch_full_scale_value = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.rdc3_full_scale_value = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.rdc3_software_exponent = GetRandomInt();
        // rra_scan_param.scanInfo.reserved_u32; //TODO
        rra_scan_param.scanInfo.sample_rate = GetRandomFloat();
        rra_scan_param.scanInfo.scan_ID_number = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.scan_loop_idx = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.scan_loop_size = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.scan_sequence_number = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.scan_time = GetRandomFloat();
        rra_scan_param.scanInfo.scan_timestamp = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.sensor_id = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.ss_doppler_0_only = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.SS_size_A = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.SS_size_D = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.SS_size_R = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.system_exponent = GetRandomInt();
        rra_scan_param.scanInfo.total_points = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.total_vrx = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.tx_power_map = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.tx_prn_map = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.tx_prn_map_multi_roc = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.user_data = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.user_frame_delay_us = GetRandomUnsignedInt();
        rra_scan_param.scanInfo.vrx_position_offset_X = GetRandomFloat();
        rra_scan_param.scanInfo.vrx_position_offset_Y = GetRandomFloat();
        rra_scan_param.scanInfo.vrx_position_offset_Z = GetRandomFloat();

        // fill angle_bins
        for (int i = 0; i < MAX_ROUGH_ANGLES; i++)
        {
            rra_scan_param.angleBins[0][i].angle_noise_floorQ8 = GetRandomInt();
            rra_scan_param.angleBins[0][i].azimuth = GetRandomFloat();
            rra_scan_param.angleBins[0][i].elevation = GetRandomFloat();
        }
        return rra_scan_param;
    }

    void CreateDetectionDataWithRandomValues(uint16_t num_detections, RRADetectionData& detection_data)
    {
        for (uint16_t i = 0; i < num_detections; i++)
        {
            detection_data[i].range = GetRandomFloat();
            detection_data[i].azimuth = GetRandomFloat();
            detection_data[i].elevation = GetRandomFloat();
            detection_data[i].doppler = GetRandomFloat();
            detection_data[i].magnitude = GetRandomFloat();
            detection_data[i].snr = GetRandomFloat();
            detection_data[i].rcs = GetRandomFloat();
            detection_data[i].pos_x = GetRandomFloat();
            detection_data[i].pos_y = GetRandomFloat();
            detection_data[i].pos_z = GetRandomFloat();
            detection_data[i].flags = GetRandomUnsignedInt();
        }
    }

    void CreatePointCloudDataWithRandomValues(uint16_t size, RRAPointCloudData& point_cloud_data_ptr)
    {
        for (uint16_t i = 0; i < size; i++)
        {
            point_cloud_data_ptr[i].azimuth_fbin = GetRandomUnsignedInt();
            point_cloud_data_ptr[i].doppler_bin = GetRandomUnsignedInt();
            point_cloud_data_ptr[i].elevation_fbin = GetRandomUnsignedInt();
            point_cloud_data_ptr[i].exponent = GetRandomInt();
            point_cloud_data_ptr[i].flags = GetRandomUnsignedInt();
            point_cloud_data_ptr[i].mag_i = GetRandomInt();
            point_cloud_data_ptr[i].mag_q = GetRandomInt();
            point_cloud_data_ptr[i].range = GetRandomUnsignedInt();
            point_cloud_data_ptr[i].snr_dB = GetRandomUnsignedInt();
        }
    }

    void CreatePointCloudFloatWithRandomValues(uint32 num_points, RRAPointCloudDataFloat& point_cloud_static_alloc_type)
    {
        for (uint32 i = 0; i < num_points; i++)
        {
            point_cloud_static_alloc_type[i].azimuth = GetRandomFloat();
            point_cloud_static_alloc_type[i].doppler = GetRandomFloat();
            point_cloud_static_alloc_type[i].elevation = GetRandomFloat();
            point_cloud_static_alloc_type[i].flags = GetRandomUnsignedInt();
            point_cloud_static_alloc_type[i].mag_i = GetRandomFloat();
            point_cloud_static_alloc_type[i].mag_q = GetRandomFloat();
            point_cloud_static_alloc_type[i].mag_snr = GetRandomFloat();
            point_cloud_static_alloc_type[i].range = GetRandomFloat();
        }
    }

    void AssertEqual(const RRAScanParameters& rra_scan_param,
                     const msg_replay_radar::msg::MsgRraScanParameters* ros_rra_scan_param)
    {
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.activation_filter_snr,
                        rra_scan_param.scanInfo.activation_filter_snr);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.analog_die_temp_c, rra_scan_param.scanInfo.analog_die_temp_C);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.angle_wrap_flags, rra_scan_param.scanInfo.angle_wrap_flags);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.antenna_config_id, rra_scan_param.scanInfo.antenna_config_id);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.az_uniform_vrx, rra_scan_param.scanInfo.az_uniform_vrx);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.az_vrx_spacing_lambda,
                        rra_scan_param.scanInfo.az_vrx_spacing_lambda);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.azimuth_nyquist_oversampling_factor,
                        rra_scan_param.scanInfo.azimuth_nyquist_oversampling_factor);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.board_t3_temp_c, rra_scan_param.scanInfo.board_T3_temp_C);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.carrier_frequency, rra_scan_param.scanInfo.carrier_frequency);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.chip_temp_c, rra_scan_param.scanInfo.chip_temp_C);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.chip_time, rra_scan_param.scanInfo.chip_time);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.chips_per_pulse, rra_scan_param.scanInfo.chips_per_pulse);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ci_bytes_per_pixel, rra_scan_param.scanInfo.CI_bytes_per_pixel);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ci_doppler_height, rra_scan_param.scanInfo.CI_doppler_height);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ci_doppler_width, rra_scan_param.scanInfo.CI_doppler_width);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ci_format, rra_scan_param.scanInfo.CI_format);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ci_height, rra_scan_param.scanInfo.CI_height);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ci_pixel_size_in_meters,
                        rra_scan_param.scanInfo.CI_pixel_size_in_meters);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ci_width, rra_scan_param.scanInfo.CI_width);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.clock_tick_denominator,
                        rra_scan_param.scanInfo.clock_tick_denominator);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.clock_tick_numerator,
                        rra_scan_param.scanInfo.clock_tick_numerator);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.clutter_image_exponent,
                        rra_scan_param.scanInfo.clutter_image_exponent);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.code_type, rra_scan_param.scanInfo.code_type);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.complex_rdc3, rra_scan_param.scanInfo.complex_rdc3);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.connection_uhdp_version,
                        rra_scan_param.scanInfo.connection_uhdp_version);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.current_time, rra_scan_param.scanInfo.current_time);
        // EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.dc_bias,
        // rra_scan_param.scanInfo.dc_bias);
        // // TODO
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.dop_rotator_shift, rra_scan_param.scanInfo.dop_rotator_shift);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.doppler_bin_width, rra_scan_param.scanInfo.doppler_bin_width);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ego_angular_velocity_x,
                        rra_scan_param.scanInfo.ego_angular_velocity_X);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ego_angular_velocity_y,
                        rra_scan_param.scanInfo.ego_angular_velocity_Y);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ego_angular_velocity_z,
                        rra_scan_param.scanInfo.ego_angular_velocity_Z);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ego_linear_velocity_x,
                        rra_scan_param.scanInfo.ego_linear_velocity_X);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ego_linear_velocity_y,
                        rra_scan_param.scanInfo.ego_linear_velocity_Y);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ego_linear_velocity_z,
                        rra_scan_param.scanInfo.ego_linear_velocity_Z);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.el_uniform_vrx, rra_scan_param.scanInfo.el_uniform_vrx);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.el_vrx_spacing_lambda,
                        rra_scan_param.scanInfo.el_vrx_spacing_lambda);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.elevation_nyquist_oversampling_factor,
                        rra_scan_param.scanInfo.elevation_nyquist_oversampling_factor);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.estimated_ego_flag, rra_scan_param.scanInfo.estimated_ego_flag);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.estimated_ego_velocity_x,
                        rra_scan_param.scanInfo.estimated_ego_velocity_X);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.estimated_ego_velocity_y,
                        rra_scan_param.scanInfo.estimated_ego_velocity_Y);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.estimated_ego_velocity_z,
                        rra_scan_param.scanInfo.estimated_ego_velocity_Z);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.extrapolated_ego_velocity_x,
                        rra_scan_param.scanInfo.extrapolated_ego_velocity_X);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.extrapolated_ego_velocity_y,
                        rra_scan_param.scanInfo.extrapolated_ego_velocity_Y);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.extrapolated_ego_velocity_z,
                        rra_scan_param.scanInfo.extrapolated_ego_velocity_Z);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_angle_noise_floor_groups,
                        rra_scan_param.scanInfo.num_angle_noise_floor_groups);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_azimuth_angles, rra_scan_param.scanInfo.num_azimuth_angles);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_beamforming_angles,
                        rra_scan_param.scanInfo.num_beamforming_angles);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_channelizer_doppler_bins,
                        rra_scan_param.scanInfo.num_channelizer_doppler_bins);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_channelizer_iters,
                        rra_scan_param.scanInfo.num_channelizer_iters);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_detections, rra_scan_param.scanInfo.num_detections);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_elevation_angles,
                        rra_scan_param.scanInfo.num_elevation_angles);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_histograms, rra_scan_param.scanInfo.num_histograms);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_music_instances, rra_scan_param.scanInfo.num_music_instances);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_pulses, rra_scan_param.scanInfo.num_pulses);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_range_bins, rra_scan_param.scanInfo.num_range_bins);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_rd_above_cutoff, rra_scan_param.scanInfo.num_RD_above_cutoff);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_rd_lower, rra_scan_param.scanInfo.num_RD_lower);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_rd_upper, rra_scan_param.scanInfo.num_RD_upper);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.num_tx_prn, rra_scan_param.scanInfo.num_tx_prn);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.number_of_radars, rra_scan_param.scanInfo.number_of_radars);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.overflow_underflow_flags,
                        rra_scan_param.scanInfo.overflow_underflow_flags);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.peak_detector_output,
                        rra_scan_param.scanInfo.peak_detector_output);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.preset_applied, rra_scan_param.scanInfo.preset_applied);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.preset_diff_flags, rra_scan_param.scanInfo.preset_diff_flags);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.pulse_time, rra_scan_param.scanInfo.pulse_time);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.radar_status_bitmap, rra_scan_param.scanInfo.radar_status_bitmap);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.range_bin_start, rra_scan_param.scanInfo.range_bin_start);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.range_bin_width, rra_scan_param.scanInfo.range_bin_width);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.rb_combine, rra_scan_param.scanInfo.rb_combine);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.rdc1_full_scale_value,
                        rra_scan_param.scanInfo.rdc1_full_scale_value);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.rdc1_software_exponent,
                        rra_scan_param.scanInfo.rdc1_software_exponent);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.rdc2_full_scale_value,
                        rra_scan_param.scanInfo.rdc2_full_scale_value);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.rdc2_software_exponent,
                        rra_scan_param.scanInfo.rdc2_software_exponent);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.rdc2_zd_rb_center, rra_scan_param.scanInfo.rdc2_zd_rb_center);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.rdc2_zd_rb_halfwidth,
                        rra_scan_param.scanInfo.rdc2_zd_rb_halfwidth);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.rdc2ch_full_scale_value,
                        rra_scan_param.scanInfo.rdc2ch_full_scale_value);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.rdc3_full_scale_value,
                        rra_scan_param.scanInfo.rdc3_full_scale_value);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.rdc3_software_exponent,
                        rra_scan_param.scanInfo.rdc3_software_exponent);
        // EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.reserved_u32,
        // rra_scan_param.scanInfo.reserved_u32); // TODO
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.sample_rate, rra_scan_param.scanInfo.sample_rate);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.scan_id_number, rra_scan_param.scanInfo.scan_ID_number);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.scan_loop_idx, rra_scan_param.scanInfo.scan_loop_idx);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.scan_loop_size, rra_scan_param.scanInfo.scan_loop_size);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.scan_sequence_number,
                        rra_scan_param.scanInfo.scan_sequence_number);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.scan_time, rra_scan_param.scanInfo.scan_time);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.scan_timestamp, rra_scan_param.scanInfo.scan_timestamp);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.sensor_id, rra_scan_param.scanInfo.sensor_id);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ss_doppler_0_only, rra_scan_param.scanInfo.ss_doppler_0_only);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ss_size_a, rra_scan_param.scanInfo.SS_size_A);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ss_size_d, rra_scan_param.scanInfo.SS_size_D);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.ss_size_r, rra_scan_param.scanInfo.SS_size_R);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.system_exponent, rra_scan_param.scanInfo.system_exponent);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.total_points, rra_scan_param.scanInfo.total_points);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.total_vrx, rra_scan_param.scanInfo.total_vrx);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.tx_power_map, rra_scan_param.scanInfo.tx_power_map);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.tx_prn_map, rra_scan_param.scanInfo.tx_prn_map);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.tx_prn_map_multi_roc,
                        rra_scan_param.scanInfo.tx_prn_map_multi_roc);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.user_data, rra_scan_param.scanInfo.user_data);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.user_frame_delay_us, rra_scan_param.scanInfo.user_frame_delay_us);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.vrx_position_offset_x,
                        rra_scan_param.scanInfo.vrx_position_offset_X);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.vrx_position_offset_y,
                        rra_scan_param.scanInfo.vrx_position_offset_Y);
        EXPECT_FLOAT_EQ(ros_rra_scan_param->scan_info.vrx_position_offset_z,
                        rra_scan_param.scanInfo.vrx_position_offset_Z);

        for (int i = 0; i < MAX_ROUGH_ANGLES; i++)
        {
            EXPECT_FLOAT_EQ(ros_rra_scan_param->angle_bins.at(i).angle_noise_floor_q8,
                            rra_scan_param.angleBins[0][i].angle_noise_floorQ8);

            // Check for nan. UhdpScanParameter struct doesn't have a default
            // initializer list. Assert fails in default case.
            if (!std::isnan(ros_rra_scan_param->angle_bins.at(i).azimuth) &&
                !std::isnan(rra_scan_param.angleBins[0][i].azimuth))
            {
                EXPECT_FLOAT_EQ(ros_rra_scan_param->angle_bins.at(i).azimuth, rra_scan_param.angleBins[0][i].azimuth);
            }
            if (!std::isnan(ros_rra_scan_param->angle_bins.at(i).elevation) &&
                !std::isnan(rra_scan_param.angleBins[0][i].elevation))
            {
                EXPECT_FLOAT_EQ(ros_rra_scan_param->angle_bins.at(i).elevation,
                                rra_scan_param.angleBins[0][i].elevation);
            }
        }
    }

    void AssertEqual(RRADetectionData detection_data_ptr,
                     const msg_replay_radar::msg::MsgRraDetectionDataList* ros_detection_list,
                     uint16_t num_valid_detections)
    {
        EXPECT_FLOAT_EQ(ros_detection_list->num_valid_detections, num_valid_detections);

        for (uint16_t i = 0; i < num_valid_detections; i++)
        {
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).range, detection_data_ptr[i].range);
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).azimuth, detection_data_ptr[i].azimuth);
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).elevation, detection_data_ptr[i].elevation);
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).doppler, detection_data_ptr[i].doppler);
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).magnitude, detection_data_ptr[i].magnitude);
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).snr, detection_data_ptr[i].snr);
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).rcs, detection_data_ptr[i].rcs);
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).pos_x, detection_data_ptr[i].pos_x);
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).pos_y, detection_data_ptr[i].pos_y);
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).pos_z, detection_data_ptr[i].pos_z);
            EXPECT_FLOAT_EQ(ros_detection_list->list.at(i).flags, detection_data_ptr[i].flags);
        }
    }

    void AssertEqual(RRAPointCloudData point_cloud_data_ptr,
                     const msg_replay_radar::msg::MsgRraPointCloudDataList* ros_point_cloud_uhdp,
                     uint32_t num_raw_points)
    {
        EXPECT_EQ(ros_point_cloud_uhdp->num_points, num_raw_points);
        for (uint32_t i = 0; i < num_raw_points; i++)
        {
            EXPECT_FLOAT_EQ(ros_point_cloud_uhdp->points.at(i).azimuth_fbin, point_cloud_data_ptr[i].azimuth_fbin);
            EXPECT_FLOAT_EQ(ros_point_cloud_uhdp->points.at(i).doppler_bin, point_cloud_data_ptr[i].doppler_bin);
            EXPECT_FLOAT_EQ(ros_point_cloud_uhdp->points.at(i).elevation_fbin, point_cloud_data_ptr[i].elevation_fbin);
            EXPECT_FLOAT_EQ(ros_point_cloud_uhdp->points.at(i).exponent, point_cloud_data_ptr[i].exponent);
            EXPECT_FLOAT_EQ(ros_point_cloud_uhdp->points.at(i).flags, point_cloud_data_ptr[i].flags);
            EXPECT_FLOAT_EQ(ros_point_cloud_uhdp->points.at(i).mag_i, point_cloud_data_ptr[i].mag_i);
            EXPECT_FLOAT_EQ(ros_point_cloud_uhdp->points.at(i).mag_q, point_cloud_data_ptr[i].mag_q);
            EXPECT_FLOAT_EQ(ros_point_cloud_uhdp->points.at(i).range, point_cloud_data_ptr[i].range);
            EXPECT_FLOAT_EQ(ros_point_cloud_uhdp->points.at(i).snr_db, point_cloud_data_ptr[i].snr_dB);
        }
    }

    void AssertEqual(const RRAPointCloudDataFloat& point_cloud_static_alloc_type,
                     const msg_replay_radar::msg::MsgRraPointCloudDataFloatList* ros_point_cloud)
    {
        for (uint32 i = 0; i < ros_point_cloud->num_points; i++)
        {
            EXPECT_FLOAT_EQ(ros_point_cloud->points.at(i).azimuth, point_cloud_static_alloc_type[i].azimuth);
            EXPECT_FLOAT_EQ(ros_point_cloud->points.at(i).doppler, point_cloud_static_alloc_type[i].doppler);
            EXPECT_FLOAT_EQ(ros_point_cloud->points.at(i).elevation, point_cloud_static_alloc_type[i].elevation);
            EXPECT_FLOAT_EQ(ros_point_cloud->points.at(i).flags, point_cloud_static_alloc_type[i].flags);
            EXPECT_FLOAT_EQ(ros_point_cloud->points.at(i).mag_i, point_cloud_static_alloc_type[i].mag_i);
            EXPECT_FLOAT_EQ(ros_point_cloud->points.at(i).mag_q, point_cloud_static_alloc_type[i].mag_q);
            EXPECT_FLOAT_EQ(ros_point_cloud->points.at(i).mag_snr, point_cloud_static_alloc_type[i].mag_snr);
            EXPECT_FLOAT_EQ(ros_point_cloud->points.at(i).range, point_cloud_static_alloc_type[i].range);
        }
    }

  protected:
    std::shared_ptr<Magna2RosConverter> converter_;

    float GetRandomFloat()
    {
        // Return random float from 0 to 1
        return (float)rand() / RAND_MAX;
    }

    unsigned int GetRandomUnsignedInt()
    {
        // Return random integer from 0 to 255
        return rand() % 256;
    }

    int GetRandomInt()
    {
        // Return random integer from -9 to +9
        return rand() % 19 + (-9);
    }
};

#endif // TEST_MAGNA_2_ROS_CONVERTER_HPP
