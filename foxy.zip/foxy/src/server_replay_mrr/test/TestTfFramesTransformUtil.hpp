#ifndef TEST_TF_FRAMES_TRANSFORM_UTIL_HPP
#define TEST_TF_FRAMES_TRANSFORM_UTIL_HPP

#include "rclcpp/rclcpp.hpp"
#include "rmw/types.h"
#include "gtest/gtest.h"

#include "TfFramesTransformUtil.h"
//#include "MathMisc.hpp"

#ifdef RMW_IMPLEMENTATION
#define CLASSNAME_(NAME, SUFFIX) NAME##__##SUFFIX
#define CLASSNAME(NAME, SUFFIX) CLASSNAME_(NAME, SUFFIX)
#else
#define CLASSNAME(NAME, SUFFIX) NAME
#endif

// defined in test_tfframestransfromutil.test file
static const std::string expected_namespace = "/TEST";

class CLASSNAME(TestTfFramesTransformUtil, RMW_IMPLEMENTATION) : public ::testing::Test
{
  public:
    void SetUp()
    {
        rclcpp::init(0, NULL);
        node_ = rclcpp::Node::make_shared("Test", expected_namespace);
        frames_transform_util_ = std::make_shared<TfFramesTransformUtil>(node_);
    }

    void TearDown()
    {
        rclcpp::shutdown();
    }

    void SetParameter(const std::string& param_name, double param_value)
    {
        rclcpp::Parameter str_param(param_name.c_str(), param_value);
        node_->set_parameter(str_param);
    }

    tf2::Quaternion ToQuaternion(double yaw, double pitch, double roll)
    {
        tf2::Quaternion q;
        q.setRPY(roll, pitch, yaw);
        return q;
    }

    double ToRadians(double degrees)
    {
        return degrees * M_PI / 180;
    }

  protected:
    std::shared_ptr<TfFramesTransformUtil> frames_transform_util_;
    std::shared_ptr<rclcpp::Node> node_;
};

#endif // TEST_TF_FRAMES_TRANSFORM_UTIL_HPP
