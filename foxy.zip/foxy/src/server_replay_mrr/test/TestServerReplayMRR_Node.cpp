#include <functional>
#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

#include "RadarNodeReplay.h"

using std::placeholders::_1;

class TestRadarUhdpServer_Node : public rclcpp::Node
{
  public:
    TestRadarUhdpServer_Node() : Node("radar_replay_server_node_subscriber")
    {
        rraDataSubscription_ = this->create_subscription<msg_replay_radar::msg::MsgMidwIntAllDataType>(
            "topic_rra_data", 10, std::bind(&TestRadarUhdpServer_Node::topic_rra_data_callback, this, _1));

        triggerCyclicSubscription_ = this->create_subscription<msg_swc_common::msg::MsgTriggerCyclicType>(
            "topic_radar_uhdp_server_trigger_cyclic", 10,
            std::bind(&TestRadarUhdpServer_Node::trigger_cyclic_callback, this, _1));

        rraDetectionDataListSubscription_ = this->create_subscription<msg_replay_radar::msg::MsgRdcDetnType>(
            "topic_rra_detection_data_list", 10,
            std::bind(&TestRadarUhdpServer_Node::rra_detection_data_list_callback, this, _1));

        rraPointCloudDataFloatListSubscription_ =
            this->create_subscription<msg_replay_radar::msg::MsgMidwIntConvPointCloudListType>(
                "topic_rra_point_cloud_data_float_list", 10,
                std::bind(&TestRadarUhdpServer_Node::rra_point_cloud_data_float_list_callback, this, _1));
    }

  private:
    void rra_point_cloud_data_float_list_callback(
        const msg_replay_radar::msg::MsgMidwIntConvPointCloudListType::SharedPtr msg) const
    {
        assert(msg->num_elements > 0);
        RCLCPP_INFO(this->get_logger(), "Subscribe: rra_point_cloud_data_float_list counter = '%d' ", msg->num_elements);
    }
    void rra_detection_data_list_callback(const msg_replay_radar::msg::MsgRdcDetnType::SharedPtr msg) const
    {
        assert(msg->num_elem_per_scan.at(0) > 0);
        RCLCPP_INFO(this->get_logger(), "Subscribe: rra detection data list scanseqnum = '%d' ",
                    msg->num_elem_per_scan.at(0));
    }

    void trigger_cyclic_callback(const msg_swc_common::msg::MsgTriggerCyclicType::SharedPtr msg) const
    {
        RCLCPP_INFO(this->get_logger(), "Subscribe: trigger cyclic = '%s'", msg->header.frame_id.c_str());
    }

    void topic_rra_data_callback(const msg_replay_radar::msg::MsgMidwIntAllDataType::SharedPtr msg) const
    {
        assert(msg->scan_info.at(0).scan_sequence_numbers[0] > 0);
        assert(msg->detection_list.at(0).coor_polar.at(0).range > 0);
        RCLCPP_INFO(this->get_logger(), "Subscribe: rra data scan_sequence_number = '%d'",
                    msg->scan_info.at(0).scan_sequence_numbers[0]);

        RCLCPP_INFO(this->get_logger(), "Subscribing: rra_detection_data azimuth [%d].range = '%f'",
                    msg->detection_list.at(0).coor_polar.at(0).range);
    }

    rclcpp::Subscription<msg_replay_radar::msg::MsgMidwIntAllDataType>::SharedPtr rraDataSubscription_;
    rclcpp::Subscription<msg_swc_common::msg::MsgTriggerCyclicType>::SharedPtr triggerCyclicSubscription_;
    rclcpp::Subscription<msg_replay_radar::msg::MsgRdcDetnType>::SharedPtr rraDetectionDataListSubscription_;
    rclcpp::Subscription<msg_replay_radar::msg::MsgMidwIntConvPointCloudListType>::SharedPtr
        rraPointCloudDataFloatListSubscription_;
};

int main(int argc, char* argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<TestRadarUhdpServer_Node>());
    rclcpp::shutdown();

    return 0;
}
