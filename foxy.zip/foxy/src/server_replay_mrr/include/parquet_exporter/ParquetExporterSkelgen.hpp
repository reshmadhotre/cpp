/*
 * Copyright 2019 - 2022 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       ParquetExporterSkelgen.hpp
 * \version    3.3.0 (beta)
 * \date       Oct-31-2022 - 12:07:12
 *
 * \author     Magna Electronics Europe GmbH & Co. OHG, 
 *             63877 Sailauf, Germany
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 * Internal version: 05.37 (Build: 20221029)
 * Based on ARXML interface version: 1.0.0
 */
 
#ifndef PARQUETEXPORTERSKELGEN_HPP_
#define PARQUETEXPORTERSKELGEN_HPP_


#include "ParquetExporterLib.hpp"

#include "msg_swc_common/msg/msg_detn_get_mid_w_data_type.hpp"
//#include "msg_swc_common/msg/msg_envst_type.hpp"
#include "msg_swc_common/msg/msg_rdcst_type.hpp"
#include "msg_swc_common/msg/msg_scaninfo_type.hpp"
#include "msg_swc_common/msg/msg_event_type.hpp"
#include "msg_swc_common/msg/msg_version_me_rdr_data_cube_mid_w_get_version_info_type.hpp"
#include "msg_swc_common/msg/msg_node_feedback_type.hpp"


using namespace parquet_exporter;


class ParquetExportSkelgen : public ParquetWriter
{
public:
	explicit ParquetExportSkelgen();
	virtual ~ParquetExportSkelgen();

    void set_filename(const std::string filename);
    const std::string get_file_suffix() const;
    const std::string get_filename() const;      
    bool is_parquet_file_written();
    void set_parquet_file_completion_flag(const bool status);
    void init_parquet_headers();
    void write_parquet_file();
    void write_parquet();
    
    virtual void parquet_init_detn_getmidwdata(void);
    virtual void parquet_export_detn_getmidwdata(msg_swc_common::msg::MsgDetnGetMidWDataType *msg);

private:
    std::string filename_prefix_{"MIDW"}; //component name
    std::string parquet_extn_{".parquet"};
    std::string node_ns_{""};
    std::string parquet_file_name_{""};
    bool parquet_file_completion_flag_{false};

};	// ParquetExportSkelgen


#endif // PARQUETEXPORTERSKELGEN_HPP_
