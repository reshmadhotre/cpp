  // uhnder specific includes
#if 0
#include "uhnder-common.h"
#include "RDC_ScanInstance_Thunk.h"
#include "rdc.h"
#include "rdc-layer-desc.h"
#include "rdc-scanctrl.h"
#include "rdc-threshctrl.h"
#else
#include "scanobject_impl.h"
#include "pointcloud.h"
#include "RadarRemoteAPI.h"
#include "PlatformAPI.h"


#endif
#include "Rte_MERdrDataCubeMidW_Type.h"
#define ACP_UNWRAP_AMB            1


#ifndef UHNDER_POINTCLOUD_FLAG_AMBIBUOUS
#define UHNDER_POINTCLOUD_FLAG_AMBIBUOUS     5
#endif

#ifndef UHNDER_POINTCLOUD_FLAG_ALIAS
#define UHNDER_POINTCLOUD_FLAG_ALIAS     6
#endif



extern void convert_to_si_patch(PointCloudData& in, //!< Input:  Point cloud point in fixed-point units of "bins"
                                RRAPointCloudPoint& out      //!< Output: Point cloud point converted to floating-point SI unitsstat
);

/*! convert_ambiguous_azbin function converts input azimuth bin in range (0 - 91) into a new bin
* number which is in new range (9 to 100)
* If bin is also ambiguous, it returns true and updates alias_bin
Note: function does not check parameters for validity */
bool convert_ambiguous_azbin(uint16_t& bin, uint16_t& alias_bin);


/*! convert_ambiguous_azbin_range function unwrapps an array of bins into array of bins
* that include ambiguous PCs.
raw_pc: unambiguous bins
raw_pc_out: output
size: number of input PCs
max_size: size of output buffer
buffer_too_small: output buffer is too small for given input.
Function will fill output data up to max_size */
int convert_ambiguous_azbin_range(const PointCloudData* raw_pc,
                                  PointCloudData* raw_pc_out, uint32_t size, uint32_t max_size, bool& buffer_too_small);

PointCloudData* GetAmbiguousDataPtr(uint32* outPcSize);

void custom_scan_processing_extended_fov(ScanObject* rsi);