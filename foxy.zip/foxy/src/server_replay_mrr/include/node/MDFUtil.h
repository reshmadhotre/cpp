#ifndef MDF_UTIL_H
#define MDF_UTIL_H

#include "MDFPlayer.h"
#include "ReplayLibrary.h"
#include "rclcpp/rclcpp.hpp"
class MDFUtil
{
  public:
    MDFUtil(std::shared_ptr<rclcpp::Node> node);
    ~MDFUtil();
    void OpenMf4File(const std::string& file_path);
    void AddDataMask(requested_data_e data_mask);
    bool ConnectToUhnderSimulator(RRADescriptor& rra_descriptor);
    void RegisterReplayLib();
    int64_t ReadNextMessage();
    std::vector<ScanObject*>& GetReplayScanObjects();
    bool GetMidw1dDataList(Rdc_MidWDataType* out_data);
    bool GetMidw2dDataList(Rdc_MidWDataType* out_data);
    bool GetRDC2NearDataList(UHNDER_TYPES::RDC2DataType* out_data);
    bool GetRDC2FarDataList(UHNDER_TYPES::RDC2DataType* out_data);
    bool GetMidwIntAllDataBuf(MidwInt_AllData_Type* out_data);
    void CloseMf4File();

  private:
    mdfp::MDFPlayer mdf_player_;
    ReplayLibrary replay_lib_;

    bool mf4_file_opened_{false};

    std::shared_ptr<rclcpp::Node> node_;
};
#endif