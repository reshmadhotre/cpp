#ifndef RADAR_NODE_H
#define RADAR_NODE_H

#include "ParquetExporterSkelgen.hpp"
#include "RosParamUtil.hpp"
#include "RosbagWriter.hpp"
#include "TfFramesTransformUtil.h"

#include "msg_live_addon/msg/msg_objdata_type.hpp"
#include "msg_replay_radar/msg/msg_midw_int_all_data_type.hpp"
#include "msg_replay_radar/msg/msg_rdc_detn_list_rviz_type.hpp"
#include "msg_replay_radar/msg/msg_rdc_point_cloud_list_rviz_type.hpp"
#include "msg_replay_radar/msg/msg_rdc_scan_info_type.hpp"
#include "msg_replay_radar/msg/msg_rdc_scan_params_type.hpp"
#include "msg_replay_radar/msg/msg_rra_data.hpp"
#include "msg_replay_radar/msg/msg_rra_detection_data_list.hpp"
#include "msg_replay_radar/msg/msg_rra_point_cloud_data_float_list.hpp"
#include "msg_swc_common/msg/msg_base_version_info_type.hpp"
#include "msg_swc_common/msg/msg_detn_get_mid_w_data_type.hpp"
#include "msg_swc_common/msg/msg_detn_get_rdc2_data_type_arr.hpp"
#include "msg_swc_common/msg/msg_event_type.hpp"
#include "msg_swc_common/msg/msg_node_feedback_type.hpp"
#include "msg_swc_common/msg/msg_scaninfo_type.hpp"

#include "msg_swc_common/msg/msg_trigger_cyclic_type.hpp"
#include "msg_swc_common/msg/msg_trigger_init_type.hpp"

#include "rclcpp/rclcpp.hpp"
#include <tf2_ros/static_transform_broadcaster.h>

class RadarNode
{
  public:
    RadarNode(std::shared_ptr<rclcpp::Node> node);

    void SetRosbagPath(const std::string& rosbag_path);
    void SetRosbagWriter(std::shared_ptr<RosbagWriter> rosbag_writer);
    void CloseRosbag();

    virtual void SetEndTimestamp(int64_t timestamp);

    virtual void AddMidwIntAllData(std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> rra_data,
                                   rclcpp::Time timestamp);
    virtual void AddDetnGetMidwDataType(
        std::shared_ptr<msg_swc_common::msg::MsgDetnGetMidWDataType> detn_get_midw_data_type, rclcpp::Time timestamp);
    virtual void AddObjDataType(std::shared_ptr<msg_live_addon::msg::MsgObjdataType> obj_data_type,
                                rclcpp::Time timestamp);
    virtual void AddFeedbackMessage(std::shared_ptr<msg_swc_common::msg::MsgNodeFeedbackType> feedback_msg,
                                    rclcpp::Time timestamp);
    virtual void AddTriggerCyclicMessage(std::shared_ptr<msg_swc_common::msg::MsgTriggerCyclicType> trigger_cyclic_msg,
                                         rclcpp::Time timestamp);
    virtual void AddCompleteTriggerMessage(std::shared_ptr<msg_swc_common::msg::MsgEventType> complete_trigger_msg,
                                           rclcpp::Time timestamp);
    virtual void AddPointCloudForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcPointCloudListRvizType> pcl_msg,
                                      rclcpp::Time timestamp);
    virtual void AddDetnListForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnListRvizType> detn_list,
                                    rclcpp::Time timestamp);
    virtual void SetParquetExporter(std::unique_ptr<ParquetExportSkelgen> parquet_exporter);
    virtual void CloseParquetFileHandle();

  protected:
    std::shared_ptr<rclcpp::Node> node_;
    std::shared_ptr<RosParamUtil> ros_param_util_;
    std::shared_ptr<RosbagWriter> rosbag_writer_;
    bool rosbag_ready_for_write_{false};
    std::string node_namespace_;

  private:
    virtual void InitRosParams();
    virtual void InitPublishers();
    virtual void InitSubscribers();
    virtual void InitTimers();

    void PublishStaticTransform();
    void WriteStaticTransformToRosbag();
    void GetNodeNamespace();

    std::shared_ptr<tf2_ros::StaticTransformBroadcaster> static_transform_broadcaster_;
    std::shared_ptr<TfFramesTransformUtil> tf_frames_transform_util_;
};
#endif