#ifndef ROSBAG_WRITER_HPP
#define ROSBAG_WRITER_HPP

#include "rclcpp/clock.hpp"
#include "rclcpp/serialization.hpp"
#include "rclcpp/serialized_message.hpp"
#include <iostream>
#include <map>
#include <rclcpp/rclcpp.hpp>

#include "rcpputils/filesystem_helper.hpp"
#include "rcutils/time.h"

#include "rosbag2_cpp/reader.hpp"
#include "rosbag2_cpp/readers/sequential_reader.hpp"
#include "rosbag2_cpp/writer.hpp"
#include "rosbag2_cpp/writers/sequential_writer.hpp"

#include "msg_live_addon/msg/msg_objdata_type.hpp"
#include "msg_replay_radar/msg/msg_midw_int_all_data_type.hpp"
#include "msg_replay_radar/msg/msg_rdc_detn_list_rviz_type.hpp"
#include "msg_replay_radar/msg/msg_rdc_point_cloud_list_rviz_type.hpp"
#include "msg_replay_radar/msg/msg_rdc_scan_info_type.hpp"
#include "msg_replay_radar/msg/msg_rdc_scan_params_type.hpp"
#include "msg_replay_radar/msg/msg_rra_data.hpp"
#include "msg_replay_radar/msg/msg_rra_detection_data_list.hpp"
#include "msg_replay_radar/msg/msg_rra_point_cloud_data_float_list.hpp"
#include "msg_swc_common/msg/msg_base_version_info_type.hpp"
#include "msg_swc_common/msg/msg_detn_get_mid_w_data_type.hpp"
#include "msg_swc_common/msg/msg_detn_get_rdc2_data_type_arr.hpp"
#include "msg_swc_common/msg/msg_event_type.hpp"
#include "msg_swc_common/msg/msg_node_feedback_type.hpp"
#include "msg_swc_common/msg/msg_scaninfo_type.hpp"
#include "msg_swc_common/msg/msg_trigger_cyclic_type.hpp"
#include "msg_swc_common/msg/msg_trigger_init_type.hpp"

struct RosbagEntry
{
    rclcpp::Time msg_time;
    std::shared_ptr<rclcpp::SerializedMessage> serialized_msg;
    rosbag2_storage::TopicMetadata topic_meta_data;
};

class RosbagWriter
{
  public:
    RosbagWriter(const std::string& rosbag_path, const std::string& node_namespace);
    ~RosbagWriter();
    bool OpenFile();
    void CloseFile();

    template <class RosMsgClass>
    bool Write(RosMsgClass* msg, const std::string& topic_name, const rclcpp::Time& time, bool append_namespace = true)
    {
        auto rosbag_entry = std::make_shared<RosbagEntry>();
        auto serialized_msg = std::make_shared<rclcpp::SerializedMessage>();
        rclcpp::Serialization<RosMsgClass> serialization;
        serialization.serialize_message(msg, serialized_msg.get());

        rosbag_entry->serialized_msg = serialized_msg;
        auto topic_metadata =
            GetTopicMetadata(rosidl_generator_traits::name<RosMsgClass>(), topic_name, append_namespace);
        rosbag_entry->topic_meta_data = topic_metadata;
        rosbag_entry->msg_time = time;

        return Write(rosbag_entry);
    }

  private:
    std::shared_ptr<rosbag2_storage::SerializedBagMessage> CreateSerializedBagMessage(
        std::shared_ptr<RosbagEntry> rosbag_entry);
    bool Write(std::shared_ptr<RosbagEntry> rosbag_entry);
    rosbag2_storage::TopicMetadata GetTopicMetadata(const std::string& msg_type, const std::string& topic_name,
                                                    bool append_namespace);

    std::string node_namespace_{""};
    std::string rosbag_path_;
    std::shared_ptr<rosbag2_cpp::writers::SequentialWriter> writer_;
    bool writer_initialized_{false};
    std::vector<std::string> created_rosbag_topics_;
    const static uint64_t MAX_FILE_SIZE_BYTES;
};
#endif
