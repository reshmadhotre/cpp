#pragma once

#include "ReplayLibrary.h"
#include "scanobject_impl.h"
#include <iostream>

class RecordReplayTest
{
  public:
    RecordReplayTest();
    virtual ~RecordReplayTest() = default;
    // RecordReplayTest(const RecordReplayTest &other) = delete;
    // RecordReplayTest & operator=(const RecordReplayTest &other) = delete;

  public:
    void Replay(void);
};
