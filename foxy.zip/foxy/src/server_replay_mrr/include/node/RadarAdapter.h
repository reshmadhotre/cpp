#ifndef RADAR_ADAPTER_H
#define RADAR_ADAPTER_H

#include "RadarNode.h"
#include "ReplayLibrary.h"
#include "RosParamUtil.hpp"
#include "rclcpp/rclcpp.hpp"

class RadarAdapter
{
  public:
    RadarAdapter(std::shared_ptr<rclcpp::Node> node);
    void SetRadarNode(std::shared_ptr<RadarNode> radar_node);
    virtual void CloseFileHandles() = 0;

  protected:
    bool FileExists(const std::string& file_path);
    std::shared_ptr<msg_swc_common::msg::MsgTriggerCyclicType> GenerateTriggerCyclicMessage(int64_t timestamp);
    std::shared_ptr<msg_swc_common::msg::MsgEventType> GenerateCompleteTriggerMessage(int64_t timestamp);

    std::shared_ptr<rclcpp::Node> node_;
    std::shared_ptr<RosParamUtil> ros_param_util_;
    std::shared_ptr<RadarNode> radar_node_;
    std::string node_namespace_;
    ReplayLibrary replay_lib_;

  private:
    virtual void InitRosParams() = 0;
    void GetNodeNamespace();

    uint64_t trigger_cyclic_counter_{0};
};
#endif