#ifndef RADAR_NODE_REPLAY_H
#define RADAR_NODE_REPLAY_H

#include "ParquetExporterSkelgen.hpp"
#include "RadarNode.h"
#include "RosParams.h"
#include "RosPublisher.hpp"
#include "RosTopics.h"
#include "msg_replay_radar/msg/msg_set_pause_mode.hpp"
#include "msg_replay_radar/msg/msg_trigger_single_frame.hpp"
#include "msg_swc_common/msg/msg_detn_get_mid_w_data_type.hpp"

class RadarNodeReplay : public RadarNode
{
  public:
    RadarNodeReplay(std::shared_ptr<rclcpp::Node> node);
    void SetEndTimestamp(int64_t timestamp) override;

    void AddMidwIntAllData(std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> rra_data,
                           rclcpp::Time timestamp) override;
    void AddDetnGetMidwDataType(std::shared_ptr<msg_swc_common::msg::MsgDetnGetMidWDataType> detn_get_midw_data_type,
                                rclcpp::Time timestamp) override;

    void AddFeedbackMessage(std::shared_ptr<msg_swc_common::msg::MsgNodeFeedbackType> feedback_msg,
                            rclcpp::Time timestamp) override;

    void AddTriggerCyclicMessage(std::shared_ptr<msg_swc_common::msg::MsgTriggerCyclicType> trigger_cyclic_msg,
                                 rclcpp::Time timestamp) override;
    void AddCompleteTriggerMessage(std::shared_ptr<msg_swc_common::msg::MsgEventType> complete_trigger_msg,
                                   rclcpp::Time timestamp) override;

    void AddPointCloudForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcPointCloudListRvizType> pcl_msg,
                              rclcpp::Time timestamp) override;
    void AddDetnListForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnListRvizType> detn_list,
                            rclcpp::Time timestamp) override;

    void SetParquetExporter(std::unique_ptr<ParquetExportSkelgen> parquet_exporter) override;
    void CloseParquetFileHandle() override;

  private:
    void InitRosParams() override;
    void InitPublishers() override;
    void InitRDC3Publishers();
    void InitMidWDataPublishers();
    void InitRvizDataPublishers();
    void InitSubscribers() override;
    void InitTimers() override;
    void PublishTriggerInit();
    void PublishEmptyScanInfo(); // TODO{@Anurag, @Vivien} Remove publishing empty scan info when other swc components
                                 // need this anymore.
    void PublishNextFrame(int64_t timestamp);
    void PublishMidwAllInputData();
    void PublishNextRDC3Frame();
    void PublishNextMidWFrame();

    void DataPublishTimerCB();
    void CompletetriggerCB(msg_swc_common::msg::MsgEventType::UniquePtr msg);
    void TriggerNextFrameCB(msg_replay_radar::msg::MsgTriggerSingleFrame::UniquePtr msg);
    void SetPauseModeCB(msg_replay_radar::msg::MsgSetPauseMode::UniquePtr msg);

    void UpdateParquet(std::shared_ptr<msg_swc_common::msg::MsgDetnGetMidWDataType> detn_get_midw_data_type);

    const static uint8_t DEFAULT_HISTORY_DEPTH;

    rclcpp::TimerBase::SharedPtr data_publish_timer_;

    bool pause_playback_{false};

    int64_t feedback_check_ts_{0};
    int64_t end_of_replay_ts_{-1};

    uint64_t trigger_cyclic_counter_{0};

    bool received_feedback_{true};

    std::string replay_data_;

    std::string complete_trigger_node_;
    std::queue<std::unique_ptr<ParquetExportSkelgen>> parquet_queue_;

    // Feedback publisher
    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgNodeFeedbackType>> node_feedback_publisher_;

    // RDC3 Data Publishers
    std::shared_ptr<RosPublisher<msg_replay_radar::msg::MsgMidwIntAllDataType>> midw_int_all_data_publisher_;
    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgTriggerCyclicType>> trigger_cyclic_publisher_;
    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgEventType>> completetrigger_publisher_;

    // Midw Data Publishers
    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgDetnGetMidWDataType>> detn_get_midw_data_type_publisher_;
    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgScaninfoType>> scan_info_publisher_;
    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgTriggerInitType>> swc_midw_trigger_init_publisher_;

    // Rviz data publishers
    std::shared_ptr<RosPublisher<msg_replay_radar::msg::MsgRdcDetnListRvizType>> rra_detection_data_list_publisher_;
    std::shared_ptr<RosPublisher<msg_replay_radar::msg::MsgRdcPointCloudListRvizType>>
        rra_point_cloud_data_float_list_publisher_;

    // Subscribers
    rclcpp::Subscription<msg_swc_common::msg::MsgEventType>::SharedPtr completetrigger_subscriber_;
    rclcpp::Subscription<msg_replay_radar::msg::MsgTriggerSingleFrame>::SharedPtr trigger_single_frame_subscriber_;
    rclcpp::Subscription<msg_replay_radar::msg::MsgSetPauseMode>::SharedPtr set_pause_mode_subscriber_;

    static const uint64_t MAX_SLEEP_TIME_NS;
};
#endif