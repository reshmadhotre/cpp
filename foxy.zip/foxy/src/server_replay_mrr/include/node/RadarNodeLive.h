#ifndef RADAR_NODE_LIVE_H
#define RADAR_NODE_LIVE_H

#include "RadarNode.h"
#include "RosParams.h"
#include "RosPublisher.hpp"
#include "RosTopics.h"

class RadarNodeLive : public RadarNode
{
  public:
    RadarNodeLive(std::shared_ptr<rclcpp::Node> node);
    ~RadarNodeLive();

    void AddDetnGetMidwDataType(std::shared_ptr<msg_swc_common::msg::MsgDetnGetMidWDataType> detn_get_midw_data_type,
                                rclcpp::Time timestamp) override;
    void AddObjDataType(std::shared_ptr<msg_live_addon::msg::MsgObjdataType> obj_data_type,
                        rclcpp::Time timestamp) override;
    void AddTriggerCyclicMessage(std::shared_ptr<msg_swc_common::msg::MsgTriggerCyclicType> trigger_cyclic_msg,
                                 rclcpp::Time timestamp) override;

  private:
    void InitPublishers() override;
    void InitRosParams() override;
    std::string GetRosbagName();

    const static uint8_t DEFAULT_HISTORY_DEPTH;

    bool record_rosbags_{false};
    std::string rosbag_path_{""};

    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgDetnGetMidWDataType>> detn_get_midw_data_type_publisher_;
    std::shared_ptr<RosPublisher<msg_live_addon::msg::MsgObjdataType>> objdata_type_publisher_;
    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgTriggerCyclicType>> trigger_cyclic_publisher_;
};
#endif