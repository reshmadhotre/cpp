#ifndef RADAR_REPLAY_ADAPTER_NEW_H
#define RADAR_REPLAY_ADAPTER_NEW_H

#include "MDFUtil.h"
#include "Magna2RosConverter.h"
#include "ParquetExporterSkelgen.hpp"
#include "RadarAdapter.h"
#include "RadarRemoteAPI.h"
#include "RosParams.h"
#include "RosPublisher.hpp"
#include "RosTopics.h"
#include "msg_swc_common/msg/msg_node_feedback_type.hpp"

#define FOV_CORNER_RADAR_ENABLED 1

class RadarAdapterReplay : public RadarAdapter
{

  public:
    RadarAdapterReplay(std::shared_ptr<rclcpp::Node> node);
    void StartReaderThread();
    void StopReaderThread();
    void CloseFileHandles() override;

  private:
    void InitRosParams() override;
    void GetFilePaths();
    void ReadWorker();
    void ReadNextMessage();
    void HandleRDC3Data(int64_t message_timestamp);
    void ProcessReplayScanObject(ScanObject* scan_object, const rclcpp::Time& time);
    void HandleMidWData(int64_t message_timestamp);
    void HandleMidwAllIntData(int64_t message_timestamp);

    ScanSetType_e GetScanSetTypeFromRadarType(const std::string& radar_type);
    std::shared_ptr<msg_replay_radar::msg::MsgRdcScanParamsType> ExtractRdcScanParameters(ScanObject* scan_object,
                                                                                        const rclcpp::Time& time);
    std::shared_ptr<msg_replay_radar::msg::MsgRdcScanInfoType> ExtractRdcScanInfo(ScanObject* scan_object,
                                                                                const rclcpp::Time& time);
    std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnType> ExtractDetectionDataList(ScanObject* scan_object,
                                                                                  const rclcpp::Time& time);
    std::shared_ptr<msg_replay_radar::msg::MsgMidwIntRawPointCloudListType> ExtractRawPointCloud(
        ScanObject* scan_object, const rclcpp::Time& time);
    std::shared_ptr<msg_replay_radar::msg::MsgMidwIntConvPointCloudListType> ExtractConvPointCloud(
        ScanObject* scan_object, const rclcpp::Time& time);
    std::shared_ptr<msg_replay_radar::msg::MsgMidwIntDataHeaderType> ExtractHeaderData();

    void CopyDetnList(int64_t message_timestamp, uint16_t idx,
                      std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> msg);
    void CopyPointCloudList(int64_t message_timestamp, uint16_t idx,
                            std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> msg);
#if FOV_CORNER_RADAR_ENABLED == 1
    std::shared_ptr<msg_replay_radar::msg::MsgRraPointCloudDataList> ExtractPointCloudDataList(
        ScanObject* scan_object, const rclcpp::Time& time, RRADescriptor& rra_descriptor);
    std::shared_ptr<msg_replay_radar::msg::MsgRraPointCloudDataFloatList> ExtractPointCloudDataFloatList(
        ScanObject* scan_object, const rclcpp::Time& time, RRADescriptor& rra_descriptor);
#else
    std::shared_ptr<msg_replay_radar::msg::MsgRraPointCloudDataList> ExtractPointCloudDataList(ScanObject* scan_object,
                                                                                             const rclcpp::Time& time);
    std::shared_ptr<msg_replay_radar::msg::MsgRraPointCloudDataFloatList> ExtractPointCloudDataFloatList(
        ScanObject* scan_object, const rclcpp::Time& time);
#endif
    std::shared_ptr<msg_swc_common::msg::MsgNodeFeedbackType> GenerateFeedbackMessage(const rclcpp::Time& time);
    std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnListRvizType> GenerateDetectionListRviz(
        std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_all_int_data, const rclcpp::Time& time);
    std::shared_ptr<msg_replay_radar::msg::MsgRdcPointCloudListRvizType> GeneratePointCloudRviz(
        std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_all_int_data, const rclcpp::Time& time);

    void ApplyRRAThresholds();
    void ConfigureMDFReader();
    void OpenNextFile();
    void CloseFile();
    std::string RemoveExtensionFromFilePath(const std::string& file_path);
    void SendTriggerCyclicMessage(int64_t timestamp);
    void SendCompleteTriggerMessage(int64_t timestamp);

    const static std::map<std::string, ScanSetType_e> RADAR_TYPE_SCAN_SET_MAP;
    const static uint64_t DELAY_BETWEEN_SCANS_NS;
    const static uint8_t DEFAULT_HISTORY_DEPTH;

    std::shared_ptr<Magna2RosConverter> magna_ros_converter_;
    std::shared_ptr<MDFUtil> mdf_util_;
    msg_replay_radar::msg::MsgMidwIntAllDataType midw_all_int_data_{};
    MidwInt_AllData_Type midw_all_data_{};
    RRADescriptor rra_descriptor_;

    uint8_t num_files_to_process_{0};
    uint8_t num_files_processed_{0};
    bool end_of_mf4_files_{false};
    bool mf4_file_opened_{false};
    std::string file_under_process_{""};
    int64_t prev_radar_timestamp_;
    bool scan_done_[MIDW_ADPR_NUM_SCAN_SETS] = {false};
    uint8_t last_scan_loop_idx_{0xFFU};
    uint8_t current_scan_loop_idx_{0};
    uint8_t scan_loop_size_{0};

    std::thread reader_thread_;
    std::atomic<bool> continue_reading_;

    // ROS PARAM VALUES
    std::string replay_data_;
    std::queue<std::string> mf4_files_queue_;
    bool record_rosbags_;
    bool record_parquet_;
    std::string radar_type_str_;
};
#endif