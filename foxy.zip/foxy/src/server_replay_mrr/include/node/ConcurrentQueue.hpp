#ifndef CONCURRENT_QUEUE_HPP
#define CONCURRENT_QUEUE_HPP

#include <condition_variable>
#include <iostream>
#include <limits>
#include <mutex>
#include <queue>
#include <thread>

template <class T> class ConcurrentQueue
{
  public:
    T Pop()
    {
        std::unique_lock<std::mutex> mlock(mutex_);
        while (queue_.empty())
        {
            cv_.wait(mlock);
        }
        auto val = queue_.front();
        queue_.pop();
        mlock.unlock();
        cv_.notify_one();
        return val;
    }

    T Front()
    {
        std::unique_lock<std::mutex> mlock(mutex_);
        while (queue_.empty())
        {
            cv_.wait(mlock);
        }
        auto val = queue_.front();
        mlock.unlock();
        cv_.notify_one();
        return val;
    }

    void Push(const T& item)
    {

        std::unique_lock<std::mutex> mlock(mutex_);
        while (queue_.size() >= MAX_BUFFER_SIZE)
        {
            cv_.wait(mlock);
        }
        queue_.push(item);
        mlock.unlock();
        cv_.notify_one();
    }

    void Push(T&& item)
    {

        std::unique_lock<std::mutex> mlock(mutex_);
        while (queue_.size() >= MAX_BUFFER_SIZE)
        {
            cv_.wait(mlock);
        }
        queue_.push(std::move(item));
        mlock.unlock();
        cv_.notify_one();
    }

    std::vector<T> PopUntilTime(int64_t timestamp)
    {
        std::vector<T> frames;
        std::unique_lock<std::mutex> mlock(mutex_);

        if (queue_.empty())
        {
            return frames;
        }

        while (!queue_.empty() && (queue_.front().timestamp <= timestamp))
        {
            frames.emplace_back(std::move(queue_.front()));
            queue_.pop();
        }
        mlock.unlock();
        cv_.notify_one();

        return frames;
    }

    bool Empty()
    {
        std::unique_lock<std::mutex> mlock(mutex_);
        bool empty = queue_.empty();
        mlock.unlock();
        return empty;
    }

    ConcurrentQueue() = default;
    ConcurrentQueue(const ConcurrentQueue&) = delete;
    ConcurrentQueue& operator=(const ConcurrentQueue&) = delete;

  private:
    std::queue<T> queue_;
    std::mutex mutex_;
    std::condition_variable cv_;
    const static unsigned int MAX_BUFFER_SIZE = 1000;
};

#endif