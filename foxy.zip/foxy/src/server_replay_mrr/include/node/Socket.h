
#pragma once

#include <arpa/inet.h>
#include <cassert>
#include <cinttypes>
#include <iostream>
#include <cstring>
#include <netinet/ip.h>
#include <sys/socket.h>
#include <net/if.h>
#include <string.h>
#include <ifaddrs.h>
#include <sys/ioctl.h>

/**
 * @brief
 *
 */
class UdpSocket
{
  public:
    enum class type
    {
        UDP,
        TCP
    };
    static const int buflen_max = 9000;

    class Endpoint
    {
      public:
        const std::string ipaddr;
        uint16_t port;
        Endpoint(const std::string ip_address, uint16_t port_number) : ipaddr(ip_address), port(port_number)
        {
        }
    };

    UdpSocket();

    /// Attempt to specify the socket receive and transmit buffer sizes (for performance)
    int setBufferSizes(int sndbuf, int rcvbuf);

    /// Specify ip address of interface to receive data on and port number to listen on
    void setLocalMulticastSocket(const std::string ipaddr, int port);
    void setMulticastClientSocket(const std::string ipaddr_local, const std::string ipaddr_multicast);

    /// Receive data on socket into buffer with specified length
    ssize_t receive(void* receiveBuffer, int bufferSize);
    ssize_t receive_non_blocking(void* buffer, int buflen);  
    void get_ip_address_from_nic(std::string nic, char* ip_address);
    void get_nic_from_ip(std::string ip_address, char* nic_name);

  private:
    int SocketFileDescriptor{-1};
    struct sockaddr_in remoteSockAddr;
    struct sockaddr_in localSockAddr;
    struct ip_mreq group;

    /// wrapper for setsockopt() system call
    int setSockOpt(int option, void* value, int size);
};

/**
 * @brief
 *
 */
class UDPReceiverMulticast : public UdpSocket
{
  public:
    UDPReceiverMulticast(Endpoint local, Endpoint multicast) : UdpSocket()
    {
        std::cout << "============================================" << std::endl;
        std::cout << "  Create UDP receiver for mutlicasting..." << std::endl;
        std::cout << "     local: " << local.ipaddr << "/" << local.port << std::endl;
        std::cout << "     multicast: " << multicast.ipaddr << std::endl;
        std::cout << "============================================" << std::endl;
        std::cout << "Opening datagram socket....OK.\n";
        this->setLocalMulticastSocket(local.ipaddr, local.port);
        // TODO: be sure we have a connection before to join the group - How?!?!?
        this->setMulticastClientSocket(local.ipaddr, multicast.ipaddr);
    };
};
