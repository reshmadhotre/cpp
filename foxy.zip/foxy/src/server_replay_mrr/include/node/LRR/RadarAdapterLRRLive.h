#ifndef RADAR_ADAPTER_LRR_LIVE_H
#define RADAR_ADAPTER_LRR_LIVE_H

#include "Magna2RosConverter.h"
#include "RadarAdapter.h"
#include "RadarRemoteAPI.h"
#include "UhdpLibrary.h"
#include "msg_replay_radar/msg/msg_vehicle_signals.hpp"
#include "scanobject_impl.h"
#include <bitset>

#define MAGNA_MAX_POINT_CLOUD 2048

static const struct default_radar_config
{
    std::string radar_ip_address{"127.0.0.1"};
    int scan_rate{0};
    int scan_loop_count{1};
    std::string detn_thresh_preset{"LOW_SENSITIVITY"};
    std::string scan_preset_1{"VP104"};
    std::string scan_preset_2{"VP104"};
    std::string antenna_cfg_1{"LowerTxAzimuth"};
    std::string antenna_cfg_2{"LowerTxAzimuth"};
} DEFAULT_LRR_CONFIG;

static const std::map<std::string, ThresholdPresetEnum> DETN_THRESH_PRESET_ENUM_MAP = {
    {"HIGH_SENSITIVITY", ThresholdPresetEnum::HIGH_SENSITIVITY},
    {"LOW_SENSITIVITY", ThresholdPresetEnum::LOW_SENSITIVITY},
    //{"FRR_B1",            ThresholdPresetEnum::FRR_B1},
};

static const std::map<std::string, RDC_ScanPresetEnum> SCAN_PRESET_ENUM_MAP = {
    {"VP104", RDC_ScanPresetEnum::VP104}, {"VP105", RDC_ScanPresetEnum::VP105},
    // {"VP104HP", RDC_ScanPresetEnum::VP104HP},
    // {"VP105HP", RDC_ScanPresetEnum::VP105HP},
};

static const std::map<std::string, CerveloAntennaConfigEnum> FRR_ANTENNA_CONFIG_ENUM_MAP = {
    {"LowerTxAzimuth", CerveloAntennaConfigEnum::CAC_AZIMUTH},
    {"AllTxElevation", CerveloAntennaConfigEnum::CAC_ELEVATION},
    {"AllTxAzimuth", CerveloAntennaConfigEnum::CAC_AZIMUTH_12TX},
};

class RadarAdapterLRRLive : public RadarAdapter
{
  public:
    RadarAdapterLRRLive(std::shared_ptr<rclcpp::Node> node);
    bool Connect(void);
    bool Start(void);
    bool Receive(void);
    bool ProcessScanObjectList(void);
    bool Stop(void);
    void Disconnect(void);

    void SetRadarProperties(RRADescriptorLRR& rra_properties);
    bool SetupRadar(void);

  private:
    void InitRosParams() override;
    void InitSubscribers();
    void CloseFileHandles() override;
    void ProcessScanObject(ScanObject* scan_object);
    void VehicleSignalsCallback(msg_replay_radar::msg::MsgVehicleSignals::SharedPtr msg);
    UhdpTelemetryData GetTelemetryFromVehicleSignals(msg_replay_radar::msg::MsgVehicleSignals::SharedPtr msg);

    const char* GetRadarIPAddress() const noexcept;
    uint32_t GetRadarScanRate() const;
    int GetRadarScanLoopCount() const noexcept;
    RDC_ScanPresetEnum GetRadarScanPreset1() const noexcept;
    RDC_ScanPresetEnum GetRadarScanPreset2() const noexcept;
    CerveloAntennaConfigEnum GetAntennaCfg1() const noexcept;
    CerveloAntennaConfigEnum GetAntennaCfg2() const noexcept;
    ThresholdPresetEnum GetRadarDetectionThreshPreset() const noexcept;
    RDC_ScanPresetEnum GetScanPresetEnum(const std::string& scan_preset_string) const noexcept;
    CerveloAntennaConfigEnum GetAntennaConfigEnum(const std::string& frr_antenna_cfg_string) const noexcept;

    std::shared_ptr<msg_replay_radar::msg::MsgMidwIntConvPointCloudListType> ExtractConvPointCloud(
        ScanObject* scan_object);
    std::shared_ptr<msg_replay_radar::msg::MsgMidwIntRawPointCloudListType> ExtractRawPointCloud(ScanObject* scan_object);
    std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnType> ExtractDetectionDataList(ScanObject* scan_object);
    std::shared_ptr<msg_replay_radar::msg::MsgRdcScanParamsType> ExtractRraScanParameters(ScanObject* scan_object);
    std::shared_ptr<msg_replay_radar::msg::MsgRdcScanInfoType> ExtractRraScanInfo(ScanObject* scan_object);
    std::shared_ptr<msg_replay_radar::msg::MsgMidwIntDataHeaderType> GenerateHeaderData();

    std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnListRvizType> GenerateDetectionListRviz(
        std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_all_int_data, const rclcpp::Time& time);
    std::shared_ptr<msg_replay_radar::msg::MsgRdcPointCloudListRvizType> GeneratePointCloudRviz(
        std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_all_int_data, const rclcpp::Time& time);
    void SendTriggerCyclicMessage(const rclcpp::Time& time);
    void SendCompleteTriggerMessage(const rclcpp::Time& time);

    vec3f_t sensor_mount_position_;
    quatf_t sensor_mount_orientation_;

    rclcpp::Subscription<msg_replay_radar::msg::MsgVehicleSignals>::SharedPtr vehicle_signals_subscriber_;
    RRADescriptorLRR radar_poperties_;
    UhdpLibrary uhdp_lib_;
    std::shared_ptr<Magna2RosConverter> magna_ros_converter_;
    std::vector<ScanObject*> scan_object_list_;
    std::bitset<ME_RRA_MAX_SCANS_LRR> scan_object_list_completion_set_;
    static const double DEGREES_TO_RADIANS;
};
#endif