#ifndef RADAR_NODE_LRR_LIVE_H
#define RADAR_NODE_LRR_LIVE_H

#include "RadarNode.h"
#include "RosPublisher.hpp"

class RadarNodeLRRLive : public RadarNode
{
  public:
    RadarNodeLRRLive(std::shared_ptr<rclcpp::Node> node);

    void AddMidwIntAllData(std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> rra_data,
                           rclcpp::Time timestamp) override;
    void AddPointCloudForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcPointCloudListRvizType> pcl_msg,
                              rclcpp::Time timestamp) override;
    void AddDetnListForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnListRvizType> detn_list,
                            rclcpp::Time timestamp) override;
    void AddTriggerCyclicMessage(std::shared_ptr<msg_swc_common::msg::MsgTriggerCyclicType> trigger_cyclic_msg,
                                 rclcpp::Time timestamp) override;
    void AddCompleteTriggerMessage(std::shared_ptr<msg_swc_common::msg::MsgEventType> complete_trigger_msg,
                                   rclcpp::Time timestamp) override;

  private:
    void InitPublishers() override;
    void InitRosParams() override;
    std::string GetRosbagName();

    const static uint8_t DEFAULT_HISTORY_DEPTH;

    uint64_t trigger_cyclic_counter_{0};
    bool record_rosbags_{false};
    std::string rosbag_path_{""};

    std::shared_ptr<RosPublisher<msg_replay_radar::msg::MsgMidwIntAllDataType>> midw_int_all_data_publisher_;
    std::shared_ptr<RosPublisher<msg_replay_radar::msg::MsgRdcDetnListRvizType>> detn_list_rviz_publisher_;
    std::shared_ptr<RosPublisher<msg_replay_radar::msg::MsgRdcPointCloudListRvizType>> pcl_data_rviz_publisher_;
    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgTriggerCyclicType>> trigger_cyclic_publisher_;
    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgEventType>> completetrigger_publisher_;
};
#endif