#ifndef ROS_PARAMS_H
#define ROS_PARAMS_H

#include <string>

namespace ROS_PARAM_NAMES
{

extern const std::string SENSOR_MOUNT_POS_X_PARAM;
extern const std::string SENSOR_MOUNT_POS_Y_PARAM;
extern const std::string SENSOR_MOUNT_POS_Z_PARAM;
extern const std::string SENSOR_MOUNT_YAW_PARAM;
extern const std::string SENSOR_MOUNT_PITCH_PARAM;
extern const std::string SENSOR_MOUNT_ROLL_PARAM;

} // namespace ROS_PARAM_NAMES

namespace ROS_PARAM_NAMES_REPLAY_MODE
{

extern const std::string REPLAY_MF4_FILEPATHS;
extern const std::string REPLAY_DATA;
extern const std::string REPLAY_DATA_RDC3;
extern const std::string REPLAY_DATA_PRE_MIDW;
extern const std::string REPLAY_DATA_POST_MIDW;
extern const std::string RECORD_ROSBAGS;
extern const std::string RADAR_NAME;
extern const std::string RADAR_TYPE;
extern const std::string PARAM_UHDP_COMPLETE_TRIGGER_NODE;
extern const std::string PARAM_RECORD_PARQUETS;
// SCAN Parameters.
extern const std::string SS_DOPPLER_NEAR_RANGE;
extern const std::string SS_DOPPLER_FAR_RANGE;
extern const std::string DETECTION_THRESH_SNR_DB;
extern const std::string CLUTTER_IMAGE_THRESH_SNR_DB;
extern const std::string POINT_CLOUD_THRESH_SNR_DB;
extern const std::string SCALE_DET_THRESH_MAX_RANGE;
extern const std::string SCALE_DET_THRESH_SNR_ADJ;
extern const std::string EGO_ZERO_STATIONARY_THRESHOLD_MPS;
extern const std::string EGO_NONZ_STATIONARY_THRESHOLD_MPS;
extern const std::string NOTCH_WIDTH_RADIANS;
extern const std::string NOTCH_DEPTH_DB;
extern const std::string OUTER_DEPTH_DB;

} // namespace ROS_PARAM_NAMES_REPLAY_MODE

namespace ROS_PARAM_NAMES_LIVE_MODE
{

extern const std::string ADAPTER_IP_ADDRESS;
extern const std::string MIDW_1d_DATA;
extern const std::string MIDW_2d_DATA;
extern const std::string OBJECT_DATA;
extern const std::string RDC3_DATA;
extern const std::string PUBLISH_RBE;
extern const std::string RECORD_ROSBAGS;
extern const std::string ROSBAG_PATH;

} // namespace ROS_PARAM_NAMES_LIVE_MODE

namespace ROS_PARAM_NAMES_LRR_LIVE_MODE
{
extern const std::string RADAR_IP_ADDRESS;
extern const std::string RADAR_SCAN_RATE;
extern const std::string RADAR_SCAN_LOOP;
extern const std::string RADAR_SCAN_PRESET_1;
extern const std::string RADAR_SCAN_PRESET_2;
extern const std::string RADAR_ANTENNA_CONFIG_1;
extern const std::string RADAR_ANTENNA_CONFIG_2;
extern const std::string RADAR_DETN_THRESH_PRESET;
extern const std::string RECORD_ROSBAGS;
extern const std::string ROSBAG_PATH;
} // namespace ROS_PARAM_NAMES_LRR_LIVE_MODE
#endif