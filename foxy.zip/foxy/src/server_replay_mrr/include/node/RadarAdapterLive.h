#ifndef RADAR_ADAPTER_LIVE_H
#define RADAR_ADAPTER_LIVE_H

#include "RadarAdapter.h"
#include "RadarNode.h"
#include "RosParams.h"
#include "Socket.h"
#include "rcl_interfaces/msg/set_parameters_result.hpp"
#include <chrono>
#include <ctime>

static const struct
{
    const std::string Multicast{"239.0.0.0"}; // Fix: Sabine_v0.3.8
    const int DataSize{65000};                // how big should it be?
    const int SocketBufferSize{2000000};
} UDPPortSettings;

class RadarAdapterLive : public RadarAdapter
{
  public:
    RadarAdapterLive(std::shared_ptr<rclcpp::Node> node);
    // ~RadarAdapterLive();

    void ReadNextMessage();
    void CloseFileHandles() override;

  private:
    void InitRosParams() override;
    bool InitUDPReceivers();
    void InitUDPReceiverMidW1D();
    void InitUDPReceiverMidW2D();
    void InitUDPReceiverObjList();
    bool ReadEthernetData(char* buffer, int buffer_size, const uint16_t* udp_port);
    void ReadObjectDataList();
    void ReadMidWData();
    void SendTriggerCyclicMessage();
    rcl_interfaces::msg::SetParametersResult ParamsCallback(const std::vector<rclcpp::Parameter>& changed_parameters);

    rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr params_callback_handle_;
    static const uint16_t BUFFER_SIZE;
    static const uint32_t BUS_SPEC_ID;

    std::shared_ptr<UDPReceiverMulticast> udp_receiver_midw_1d_;
    std::shared_ptr<UDPReceiverMulticast> udp_receiver_midw_2d_;
    std::shared_ptr<UDPReceiverMulticast> udp_receiver_object_list_;
    bool receivers_initialized_{false};
    std::string adapter_ip_address_{""};
    bool is_midw_data_1d_enabled_{false};
    bool is_midw_data_2d_enabled_{false};
    bool is_object_data_enabled_{false};

    char buffer_1d[65200];
    char buffer_2d[65200];
    char buffer_object[65200];
};
#endif
