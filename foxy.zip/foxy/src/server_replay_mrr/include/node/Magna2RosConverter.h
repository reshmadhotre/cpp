#ifndef MAGNA_2_ROS_CONVERTER_H
#define MAGNA_2_ROS_CONVERTER_H

#include "UhnderPatch.hpp"
#include "ReplayLibrary.h"
#include "msg_replay_radar/msg/msg_rra_detection_data_list.hpp"
#include "msg_replay_radar/msg/msg_rra_point_cloud_data_float_list.hpp"
#include "msg_replay_radar/msg/msg_rra_point_cloud_data_list.hpp"
#include "msg_replay_radar/msg/msg_rra_scan_parameters.hpp"
#include "msg_replay_radar/msg/msg_rdc_scan_info_type.hpp"
#include "msg_replay_radar/msg/msg_rdc_detn_type.hpp"
#include "msg_replay_radar/msg/msg_rdc_scan_params_type.hpp"
#include "msg_replay_radar/msg/msg_midw_int_raw_point_cloud_list_type.hpp"
#include "msg_replay_radar/msg/msg_midw_int_conv_point_cloud_list_type.hpp"
#include "scanobject_impl.h"
class Magna2RosConverter final
{
  public:
    void ConvertMessage(const RRAScanParameters& rra_scan_params,
                        msg_replay_radar::msg::MsgRraScanParameters* ros_rra_scan_params) noexcept;
    void ConvertMessage(const RRADetectionData& rra_detection_data, uint16_t num_valid_detections,
                        msg_replay_radar::msg::MsgRraDetectionDataList* ros_rra_detection_data_list) noexcept;
    void ConvertMessage(const RRAPointCloudData& rra_point_cloud_data, const uint32_t& num_raw_points,
                        msg_replay_radar::msg::MsgRraPointCloudDataList* ros_rra_point_cloud_data_list) noexcept;
    void ConvertMessage(
        const RRAPointCloudDataFloat& point_cloud_data_float, const uint32_t& num_points,
        msg_replay_radar::msg::MsgRraPointCloudDataFloatList* ros_rra_point_cloud_data_float_list) noexcept;
    
    void ConvertMessage(const UhdpScanInformation& uhdp_scan_info, 
        msg_replay_radar::msg::MsgRdcScanParamsType* ros_scan_params) noexcept;
    void ConvertMessage(const UhdpScanInformation& uhnder_scan_params, 
        msg_replay_radar::msg::MsgRdcScanInfoType* ros_scan_info) noexcept;
    void ConvertMessage(const DetectionData* uhnder_detn, uint32_t num_uhnder_detn,
        msg_replay_radar::msg::MsgRdcDetnType* ros_detn_list) noexcept;
    void ConvertMessage(const PointCloudData* point_cloud_data, uint32_t num_points,
        msg_replay_radar::msg::MsgMidwIntRawPointCloudListType* ros_raw_point_cloud) noexcept;
    void ConvertMessage(PointCloudData* point_cloud_data, uint32_t num_points,
        msg_replay_radar::msg::MsgMidwIntConvPointCloudListType* ros_conv_point_cloud) noexcept;
    void ConvertMessage(const PointCloud::Point* conv_points, uint32_t num_points,
        msg_replay_radar::msg::MsgMidwIntConvPointCloudListType* ros_conv_point_cloud) noexcept;
};

#endif // MAGNA2_ROS_CONVERTER_H
