# How the MF4 Replay Node Works

The server_replay_mrr ros2 package has a replay mode that accepts a list of MF4 files as input and publishes DetectionList and PointCloud data.

ROS2 Parameters used by the node : *<u>server_replay_mrr/config/params_mrr_center.yaml</u>*

For list of Topics the node subscribes and publishes to : <u>*server_replay_mrr/src/RosTopics.cpp*</u>

###### RadarReplayAdapter Class

The RadarReplayAdapter Class has the following responsibilities : 

- Establish connection to the Uhnder Simulator (only for RDC3 replay).

- Configure RRA Parameters using the values defined by the ROS parameters.

- Open the list of input mf4 files sequentially using the ReplayLibrary class. The ReplayLibrary class handles the raw binary mf4 data transfer to the simulator.

- Helper functions (HandleRDC3Data, HandleRDC2Data and HandleMidWData) receive the corresponding scan data. 

- The **Magna2RosConverter** Class creates the ROS Versions of the scan data.

- The ros messages are sent to the **RadarReplayNode** class for publishing.

The replay adapter spawns a reader thread that continuously reads the mf4 files, creates the ros messges and sends them to the ReplayNode for storing in thread safe concurrent queue. The thread exits once all the messages in the files have been read and processed.

The adapter class creates a NodeFeedbackMsg type ros message that holds the metadata like the message timestamp, filename from which the message was extracted, file count etc.

###### RadarReplayNode Class

The RadarReplayNode Class has the following responsibilities:

- Create the required ROS publishers, subscribers and timers.

- Accept Scan data in the form of ROS messages from the ReplayAdapter and store them in thread safe queues.

- Check for feedback from a preconfigured node. This marks completion of the processing of a single mf4 message. The next set of messages from the queue are published only when this feedback is received.

- A preconfigured timer runs infinitely, checks if the feedback is received. Once the feedback message is received, next set of messages are retrieved from the queue, published and then waits for the feedback.



###### Timestamp Synchronization with CAN replay and Video replay

The feedback message that the server_replay_mrr node publishes contains the mf4 message timestamp. The server_replay_can and server_replay_video nodes subscribe to this feedback message for synchornization purposes. The CAN and Video nodes have a thread that continuously reads the mf4 data and converts them to CAN data and video data respectively. Upon receiving a feedback message from the Radar node, CAN and Video nodes publish all the messages from their queues with timestamps **less than or equal to the Radar timestamp**. This ensures, the CAN and Video data published are as close as possible to the Radar data in time.
