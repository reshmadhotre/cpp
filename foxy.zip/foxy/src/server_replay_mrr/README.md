# Package: server_replay_mrr

*Version: **server_replay_mrr_v1.1.0*** <br/>
*RadarRemote API Version: **v0.81.3*** <br/>
*Release: 29.03.2023* <br/>
*See [logs](./doc/change_log.md)*<br/>

<br/>

## Introduction

ROS Node that can publish RDC3, RDC2 data MidW data. It can be launched in two modes : 

- Replay Mode (From MDF files)

- Live Mode (via an Ethernet connection to a radar)

### 1. Replay Mode

In Replay Mode,  the node can be configured to either replay RDC3 or MidW data from a set of MDF files. Additionally a flag can be toggled to also replay RDC2 data (if available in the recordings). 

*Note : For RDC3 replay, the node expects an instance of the Uhnder Simulator be running. The ReplayLibrary connects to the Uhnder Simulator to decode the binary payload data from the MDF files.*

<br/>

#### The core functionalities of the node can be summarized as :

- Connect to the Uhnder Simulator if necessary(for RDC3 replay).

- Parse the list of MDF files provided as input using the ReplayLibrary package to decode the binary data.

- Convert the decoded data to corresponding ROS messages and store them in queues.

- Publish the ROS messages from the queues. To ensure a deterministic replay, the node requires an acknowledment published from a pre-configured node. In case an acknowledgement is not received, the node currently <u>waits infinitely</u> and will not publish any more messages.

- Pause and Resume playback. Play messages per frame basis.

- Publish status of the replay for other ROS nodes. The status messages are used by other nodes (like video_relay_server and can_replay_server for synchronization purposes.)

- Record rosbags and parquets if requested by the user.

<br/>

*Note : Recorded rosbags and parquet files are created in the same folder as the MDF files. Each MDF file will have its  own rosbag and parquet file created.*

*Pausing and single frame playback functionalities can be achieved using the CLI. This requires publishing messages on dedicated topics to let the node when to pause and when to publish a single frame. <u>Suggested way would be to use the GUI application in the Tools folder for a better experience. </u>*

<br/>

#### Rqt graph (Replay Mode)

![server_replay_mrr_rqt](./doc/pictures/server_replay_mrr_rqt.png "RadarUhdpServer")

***Green:*** *topic as publisher* <br/>

**Blue**: topic as subscriber <br/>

<br/>

#### Publishers and subscribers (Replay Mode)

| Publishers                   | Types                                              | Packages       |
| ---------------------------- | -------------------------------------------------- | -------------- |
| rra_data_publisher_          | msg_replay_radar::msg::MsgRraData                    | msg_replay_radar |
| trigger_cyclic_publisher_    | msg_replay_radar::msg::MsgTriggerCyclicType          | msg_replay_radar |
| detection_list_publisher_    | msg_replay_radar::msg::MsgRraDetectionDataList       | msg_replay_radar |
| point_cloud_float_publisher_ | msg_replay_radar::msg::MsgRraPointCloudDataFloatList | msg_replay_radar |
| tf_frames_transform_util_    | geometry_msgs::msg::TransformStamped               | geometry_msgs  |

| Subscribers                | Types                                      | Packages       |
| -------------------------- | ------------------------------------------ | -------------- |
| trigger_subscriber_        | msg_swc_common::msg::MsgEventType          | msg_swc_common |
| trigger_single_frame__     | msg_replay_radar::msg::MsgTriggerSingleFrame | msg_replay_radar |
| set_pause_mode_subscriber_ | msg_replay_radar::msg::MsgSetPauseMode       | msg_replay_radar |

#### Parameters (Replay Mode)

| Names                                       | Notes                                                                                      |
|:------------------------------------------- |:------------------------------------------------------------------------------------------ |
| replay_mf4_filepaths                        | Array of MF4 filepaths to replay                                                           |
| record_rosbags                              | Boolean flag to record rosbags.                                                            |
| radar_type                                  | Set the Radar Type. Value = SST_MRR_FRONT_CENTER or SST_MRR_FRONT_CORNER                   |
| radar_name                                  | Name of the radar.                                                                         |
| replay_midw_data                            | Boolean flag to set the replay mode. False => Replay RDC3 data \| True=> Replay MidW data. |
| replay_rdc2_data                            | Boolean flag to replay RDC2 data if available in the files.                                |
| param_uhdp_completetrigger_node             | Name of the ROS node that sends a complete feedback signal.                                |
| sensor_pitch                                | Set the sensor pitch                                                                       |
| sensor_roll                                 | Set the sensor roll                                                                        |
| sensor_yaw                                  | Set the sensor yaw                                                                         |
| sensor_position_x                           | Set the sensor position x                                                                  |
| sensor_position_y                           | Set the sensor position y                                                                  |
| sensor_position_z                           | Set the sensor position z                                                                  |
| ss_doppler_near_range                       |                                                                                            |
| ss_doppler_far_range                        |                                                                                            |
| scan**i**.detection_thresh_snr_dB           |                                                                                            |
| scan**i**.clutter_image_thresh_snr_dB       |                                                                                            |
| scan**i**.point_cloud_thresh_snr_dB         |                                                                                            |
| scan**i**.scale_det_thresh_max_range        |                                                                                            |
| scan**i**.scale_det_thresh_snr_adj          |                                                                                            |
| scan**i**.ego_zero_stationary_threshold_mps |                                                                                            |
| scan**i**.ego_nonz_stationary_threshold_mps |                                                                                            |
| scan**i**.notch_width_radians               |                                                                                            |
| scan**i**.notch_depth_dB                    |                                                                                            |
| scan**i**.outer_depth_dB                    |                                                                                            |

**i**  ranges from {0-4} for a total of 4 Scan Sets above.

#### Config file

The parameters to be used by launch file are set in the config file,
which are located at

```
FE_RDARA_MERdrDataCubeMidW/Test/Autogen/Ros2/src/server_replay_mrr/config
```

update the appropriate config file for the selected radar.

#### Launch file

The parameters are set via a launch file located at

```
FE_RDARA_MERdrDataCubeMidW/Test/Autogen/Ros2/src/server_replay_mrr/launch
```

Here is an example how to set the parameters:

```python
def generate_launch_description():

    params_config = os.path.join(
        get_package_share_directory('server_replay_mrr'),
        'config',
        'params_mrr_center.yaml'
    )

    uhdp_node = Node(
        package="server_replay_mrr",
        executable="server_replay_mrr_node",
        name="server_replay_mrr_node",
        output="screen",
        parameters=[
            params_config
        ],
    )

    return LaunchDescription([
        uhdp_node
    ])
```



<br/>

## Ubuntu 20.04

### 1. Compile

You have two possibilities. You can do it manually or use the batch file that runs everything for you.

#### **Using the batch file**

Now build the package using the bash file:

```shell
$ ./cfg_Presets_GCC_9_3.sh
```

Since this bash file compiles the bookshelf component as well, you can add some arguments:

- build arguments: "Debug" or "Release"
  
  - "Debug": will set the cmake argument -DCMAKE_BUILD_TYPE=Debug
  - "Release": will set the cmake argument -DCMAKE_BUILD_TYPE=Release

- target arguments: "lib", "ros", "all"
  
  - "lib": compile only the bookshelf component
  
  - "ros". compile only the ros worksapce
  
  - "all": compile the bookshelf component and the ros workspace
    
    <br/>
    Be aware: the ros workspace is dependent from the bookshelf component. If you compile the ros workspace for the first time, you have to compile the library before.

To clean the project you can use the above mentioned bash file:

```shell
$ ./cfg_Presets_GCC_9_3.sh clean
```

To clean individual components

```shell
$ ./cfg_Presets_GCC_9_3.sh clean <component_name>
```

Following are the component name: lib, dspapp, ros(component names are case-sensitive lib != LIB or Lib). If correct component name is entered by default all three components will be cleaned.

#### **Manually**

To compile the packages, you need to source Ros2 in a new terminal:

```shell
$ source ~/ros2_foxy/ros2-linux/local_setup.bash
```

Now build the package using colcon:

```shell
$ colcon build --packages--up-to server_replay_mrr --event-handlers console_direct+
```

where:<br/>

- --packages-up-to [PKG_NAME [PKG_NAME …]]: select the packages with the passed names as well as their recursive dependencies.

- --event-handlers : list of event handlers to enable (trailing +) or disable (trailing -). See [Event handler arguments](https://colcon.readthedocs.io/en/released/reference/event-handler-arguments.html). Two useful arguments:
  
  - console_cohesion [colcon-output]: pass job output at once to stdout after it has finished.
  
  - console_direct [colcon-output]: pass output directly to stdout / stderr. When processing multiple jobs in parallel the output will likely interleave.
    
    <br/>

### 2. Launch the node

First of all, launch the radar simulation. In a terminal:

```shell
$ cd FE_RADAR_MERdrDataCubeMidW/Test/UhnderSimulation/linux/cervelo-mrr-sim-080AU
$ python3 simulation-boot.py
```

In another terminal, source Ros2 if is not already done:

```shell
$ source ~/ros2_foxy/ros2-linux/setup.bash
```

And source the workspace:

```shell
$ source FE_RADAR_MERdrDataCubeMidW/Test/AutoGen/Ros2/install/local_setup.bash
```

Now you can launch the node by calling the launch file

```shell
$ ros2 launch server_replay_mrr my_radar.py
```

where:<br/>

- ros2 launch: launch command

- server_replay_mrr: package name

- my_radar.py: launch file (provided by FE_RADAR_MERdrDataCubeMidW/Test/AutoGen/Ros2/src/server_replay_mrr/launch)
  
  <br/>

### 3. Run the tests

Below command produces verbose output

```shell
$ colcon test --packages-select server_replay_mrr --event-handlers console_cohesion+
```

Below command runs only specific test

```shell
$ ./build/server_replay_mrr/test_RraPropertiesUtil
```

# 