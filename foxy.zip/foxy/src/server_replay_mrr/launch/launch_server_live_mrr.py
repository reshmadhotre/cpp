from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python import get_package_share_directory
import os


def generate_launch_description():

    params_config = os.path.join(
        get_package_share_directory('server_replay_mrr'),
        'config',
        'params_live.yaml'
    )

    uhdp_node = Node(
        package="server_replay_mrr",
        executable="server_live_mrr_node",
        name="server_live_mrr_node",
        output="screen",
        parameters=[
            params_config
        ],
    )

    return LaunchDescription([
        uhdp_node
    ])
