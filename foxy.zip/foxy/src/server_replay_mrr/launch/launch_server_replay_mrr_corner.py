#
# \file launch_server_replay_mrr.py
#
# \author Magna Electronics Europe GmbH & Co. OHG,
#         63877 Sailauf, Germany
#
# Copyright 2019 - 2021 Magna Electronics Europe GmbH & Co. OHG
# All rights exclusively reserved for Magna Electronics Europe GmbH & Co. OHG,
# unless expressly agreed to otherwise.

from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python import get_package_share_directory
import os


def generate_launch_description():

    params_config = os.path.join(
        get_package_share_directory('server_replay_mrr'),
        'config',
        'config_server_replay_mrr_corner.yaml'
    )

    uhdp_node = Node(
        package="server_replay_mrr",
        executable="server_replay_mrr_app",
        name="server_replay_mrr_node",
        output="screen",
        parameters=[
            params_config
        ],
    )

    return LaunchDescription([
        uhdp_node
    ])
