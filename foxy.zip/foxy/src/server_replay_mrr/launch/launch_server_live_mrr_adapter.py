from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python import get_package_share_directory
import os


def generate_launch_description():

    uhdp_node_front_center = Node(
        package="server_replay_mrr",
        node_namespace="front_center",
        executable="server_live_mrr_node",
        name="server_live_mrr_node",
        output="screen",
        parameters=[
            {"adapter_ip_address": "192.168.0.4"},
            {"sensor_pitch": 0.0},
            {"sensor_roll": 0.0},
            {"sensor_yaw": -1.68},
            {"sensor_position_x": 3.78},
            {"sensor_position_y": 0.2},
            {"sensor_position_z": -0.67}
        ],
    )

    uhdp_node_front_left = Node(
        package="server_replay_mrr",
        node_namespace="front_left",
        executable="server_live_mrr_node",
        name="server_live_mrr_node",
        output="screen",
        parameters=[
            {"adapter_ip_address": "192.168.0.5"},
            {"sensor_pitch": 0.0},
            {"sensor_roll": 0.0},
            {"sensor_yaw": -50},
            {"sensor_position_x": 3.450},
            {"sensor_position_y": -0.862},
            {"sensor_position_z": -0.7}
        ],
    )

    uhdp_node_front_right = Node(
        package="server_replay_mrr",
        node_namespace="front_right",
        executable="server_live_mrr_node",
        name="server_live_mrr_node",
        output="screen",
        parameters=[
            {"adapter_ip_address": "192.168.0.6"},
            {"sensor_pitch": 0.0},
            {"sensor_roll": 0.0},
            {"sensor_yaw": 50.0},
            {"sensor_position_x": 3.45},
            {"sensor_position_y": 0.862},
            {"sensor_position_z": -0.7}
        ],
    )

    uhdp_node_rear_left = Node(
        package="server_replay_mrr",
        node_namespace="rear_left",
        executable="server_live_mrr_node",
        name="server_live_mrr_node",
        output="screen",
        parameters=[
            {"adapter_ip_address": "192.168.0.7"},
            {"sensor_pitch": 0.0},
            {"sensor_roll": 0.0},
            {"sensor_yaw": -140.0},
            {"sensor_position_x": -0.845},
            {"sensor_position_y": -0.75},
            {"sensor_position_z": 0.75}
        ],
    )

    uhdp_node_rear_right = Node(
        package="server_replay_mrr",
        node_namespace="rear_right",
        executable="server_live_mrr_node",
        name="server_live_mrr_node",
        output="screen",
        parameters=[
            {"adapter_ip_address": "192.168.0.8"},
            {"sensor_pitch": 0.0},
            {"sensor_roll": 0.0},
            {"sensor_yaw": 140.0},
            {"sensor_position_x": -0.845},
            {"sensor_position_y": 0.75},
            {"sensor_position_z": 0.75}
        ],
    )

    return LaunchDescription([
        uhdp_node_front_center,
        #uhdp_node_front_left,
        #uhdp_node_front_right,
        #uhdp_node_rear_left,
        #uhdp_node_rear_right
    ])
