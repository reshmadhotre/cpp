#include "TfFramesTransformUtil.h"
#include "rclcpp/rclcpp.hpp"

#include "RadarAdapterLive.h"
#include "RadarNodeLive.h"
#include <csignal>

std::shared_ptr<RadarAdapterLive> radar_live_adapter;
void sigint_handler(int sig_num)
{
    if (radar_live_adapter != nullptr)
    {
        radar_live_adapter->CloseFileHandles();
    }
    rclcpp::shutdown();

    exit(sig_num);
}

int main(int argc, char* argv[])
{
    std::signal(SIGINT, sigint_handler);
    rclcpp::InitOptions options = rclcpp::InitOptions();
    options.shutdown_on_sigint = false;
    rclcpp::init(argc, argv, options);

    auto node = std::make_shared<rclcpp::Node>("radar_uhdp_server_live_node");
    std::shared_ptr<RadarNode> radar_live_server_node = std::make_shared<RadarNodeLive>(node);

    radar_live_adapter = std::make_shared<RadarAdapterLive>(node);
    radar_live_adapter->SetRadarNode(radar_live_server_node);

    try
    {
        while (rclcpp::ok())
        {
            radar_live_adapter->ReadNextMessage();

            rclcpp::spin_some(node);
        }
    }
    catch (const std::exception& e)
    {
        RCLCPP_ERROR(node->get_logger(), e.what());
    }
    radar_live_adapter->CloseFileHandles();
    rclcpp::shutdown();
    return 0;
}
