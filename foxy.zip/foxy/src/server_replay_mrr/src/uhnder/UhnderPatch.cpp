/**
 * @file MERdrDataCubeMidwAdpr_UhPatch.cpp
 * @brief This is the short description of the template module
 *
 * @details This is a FOV patch for Uhnder 081-U1 Version.
 *
 * --------------------------------------------------------------------------
 * @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2014.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * --------------------------------------------------------------------------
 * @author Alexej Bohr (Alexej.Bohr@magna.com)
 */
 /*
  */
  // #include "RTE_MERdrDataCubeMidWAdpr.h"
  // #include "MERdrDataCubeMidWAdpr.hpp"

  // uhnder specific includes
#if 0
#include "uhnder-common.h"
#include "RDC_ScanInstance_Thunk.h"
#include "rdc.h"
#include "rdc-layer-desc.h"
#include "rdc-scanctrl.h"
#include "rdc-threshctrl.h"
#else
#include "UhnderPatch.hpp"
#include <iostream>
#endif

#include "Rte_MERdrDataCubeMidW_Type.h"
#define ACP_UNWRAP_AMB            1


#ifndef UHNDER_POINTCLOUD_FLAG_AMBIBUOUS
#define UHNDER_POINTCLOUD_FLAG_AMBIBUOUS     5
#endif

#ifndef UHNDER_POINTCLOUD_FLAG_ALIAS
#define UHNDER_POINTCLOUD_FLAG_ALIAS     6
#endif

#define NUM_AZ_BINS 101
float azimuth_angles[NUM_AZ_BINS] = {
    -1.441273, -1.33271, -1.259569, -1.20024, -1.14885, -1.102772, -1.060559,
    -1.021316, -0.984442, -0.949512, -0.916208, -0.884292, -0.853573, -0.823901,
    -0.79515, -0.76722, -0.740022, -0.713483, -0.687541, -0.662141, -0.637233,
    -0.612777, -0.588735, -0.565072, -0.541759, -0.518769, -0.496077, -0.47366,
    -0.451498, -0.429572, -0.407864, -0.386357, -0.365038, -0.34389, -0.322902,
    -0.302059, -0.281352, -0.260767, -0.240295, -0.219926, -0.199648, -0.179454,
    -0.159333, -0.139277, -0.119277, -0.099326, -0.079413, -0.059533, -0.039675,
    -0.019834, 0.000000, 0.019834, 0.039675, 0.059533, 0.079413, 0.099326,
    0.119277, 0.139277, 0.159333, 0.179454, 0.199648, 0.219926, 0.240295,
    0.260767, 0.281352, 0.302059, 0.322902, 0.34389, 0.365038, 0.386357,
    0.407864, 0.429572, 0.451498, 0.47366, 0.496077, 0.518769, 0.541759,
    0.565072, 0.588735, 0.612777, 0.637233, 0.662141, 0.687541, 0.713483,
    0.740022, 0.76722, 0.79515, 0.823901, 0.853573, 0.884292, 0.916208,
    0.949512, 0.984442, 1.021316, 1.060559, 1.102772, 1.14885, 1.20024,
    1.259569, 1.33271, 1.441273 };


ScanObject* g_current_rsi;
//RDC_ScanInstance_Thunk *g_current_rsi_Thunk;



extern void convert_to_si_patch(PointCloudData& in, //!< Input:  Point cloud point in fixed-point units of "bins"
                                RRAPointCloudPoint& out      //!< Output: Point cloud point converted to floating-point SI unitsstat
)
{
    //RDC_ScanParams* params = g_current_rsi->get_parameters();

    int16_t az_bin = in.azimuth_fbin >> PointCloudData::PC_AZIMUTH_FRAC_BITS;

    // #if 1
    //     // corner radar scan
    //     //float const zero_doppler_bin = 233.490173;
    //     float zero_doppler_bin = 157.0;
    //     float doppler_bin_width = 0.363053;
    //     // fron radar scan
    // #else
    //     float const zero_doppler_bin = 210.0 ;
    //     float const doppler_bin_width = 0.2722899 ;
    // #endif

    //float zero_doppler_bin = g_current_rsi_Thunk->get_RDC_zero_Doppler_bin_index();
    //float doppler_bin_width = g_current_rsi_Thunk->get_parameters()->doppler_bin_width;    
    UhdpScanInformation scan_info = g_current_rsi->get_scan_info();
    float zero_doppler_bin = 0;
    {

        float zdbin = 0;
        const uint32_t num_pulse = scan_info.num_pulses;
        zdbin = float(num_pulse / 2) + scan_info.dop_rotator_shift / scan_info.doppler_bin_width;

        // handle negative wrap
        while (zdbin < 0) { zdbin += num_pulse; }

        // handle positive wrap
        zdbin -= num_pulse * uh_floorf(zdbin / num_pulse);
        zero_doppler_bin = zdbin;
    }

    float doppler_bin_width = scan_info.doppler_bin_width;




    if (az_bin > static_cast<int16_t>(NUM_AZ_BINS))
    {
        std::cout << "INTERNAL ERROR:  RDC_PointCloud_Impl::convert_to_si():  az_fbin=" << in.azimuth_fbin << ", el_fbin=" << in.elevation_fbin<< std::endl;
                               
    }
    else
    {
        // const FLOAT zero_doppler_bin = rsi->get_RDC_zero_Doppler_bin_index(); // rsi->scan_config->pulses_per_scan / 2;

        out.azimuth = azimuth_angles[az_bin];
        out.elevation = 0;
        //const uint16_t range = in.range + params->first_range_bin;
        const uint16_t range = in.range + g_current_rsi->get_scan_info().range_bin_start;
        //out.range = static_cast<float32_t>(range) * params->range_bin_width;
        out.range = static_cast<float32_t>(range) * g_current_rsi->get_scan_info().range_bin_width;
        out.doppler = (static_cast<float32_t>(in.doppler_bin) - zero_doppler_bin) * doppler_bin_width;
        out.mag_snr = static_cast<float32_t>(in.snr_dB) / static_cast<float32_t>(1 << PointCloudData::PC_SNR_FRAC_BITS);
        out.flags = in.flags;
    }
}
/*! convert_ambiguous_azbin function converts input azimuth bin in range (0 - 91) into a new bin
* number which is in new range (9 to 100)
* If bin is also ambiguous, it returns true and updates alias_bin
Note: function does not check parameters for validity */
bool convert_ambiguous_azbin(uint16_t& bin, uint16_t& alias_bin)
{
    bool ambiguous;
    bin = bin >> PointCloudData::PC_AZIMUTH_FRAC_BITS;
    if (bin <= 4)
    {
        alias_bin = bin + 96;
        ambiguous = true;
    }
    else if (bin >= 88)
    {
        alias_bin = bin - 88;
        ambiguous = true;
    }
    else
    {
        ambiguous = false;
    }
    bin += 4;
    bin = bin << PointCloudData::PC_AZIMUTH_FRAC_BITS;
    alias_bin = alias_bin << PointCloudData::PC_AZIMUTH_FRAC_BITS;
    return ambiguous;
}
/*! convert_ambiguous_azbin_range function unwrapps an array of bins into array of bins
* that include ambiguous PCs.
raw_pc: unambiguous bins
raw_pc_out: output
size: number of input PCs
max_size: size of output buffer
buffer_too_small: output buffer is too small for given input.
Function will fill output data up to max_size */
int convert_ambiguous_azbin_range(const PointCloudData* raw_pc,
                                  PointCloudData* raw_pc_out, uint32_t size, uint32_t max_size, bool& buffer_too_small)
{
    uint32_t current_counter = 0;
    buffer_too_small = false;
    for (uint32_t pc = 0; pc < size; ++pc)
    {
        uint16_t alias_bin;
        PointCloudData pcd;
        pcd = raw_pc[pc];
        bool is_ambiguous = convert_ambiguous_azbin(pcd.azimuth_fbin, alias_bin);
        if (current_counter < max_size)
        {

            raw_pc_out[current_counter++] = pcd;
        }
        else
        {
            buffer_too_small = true;
            break;
        }
        if (is_ambiguous)
        {
            pcd.azimuth_fbin = alias_bin;
            if (current_counter < max_size)
            {
                raw_pc_out[current_counter] = pcd;
                raw_pc_out[current_counter].flags = (1 << UHNDER_POINTCLOUD_FLAG_AMBIBUOUS) | (1 << UHNDER_POINTCLOUD_FLAG_ALIAS);;
                raw_pc_out[current_counter - 1].flags = (1 << UHNDER_POINTCLOUD_FLAG_AMBIBUOUS);
                current_counter++;
            }
            else
            {
                buffer_too_small = true;
                break;
            }
        }
    }
    return current_counter;
}

#ifndef M_1_PI
#define M_1_PI 0.318309886183790671538
#endif
#define MAX_NUM_AMBIG_POINTS 2000
#if defined(__ghs__)
#pragma ghs section bss=".MERdrDataCubeMidw_DDR_BufferData"
#endif
// Defining in data section, in case used in DSP should be non-cacheble
PointCloudData ambiguous_data[MAX_NUM_AMBIG_POINTS];
uint32_t pc_size;
#if defined(__ghs__)
#pragma ghs section bss=default
#endif
extern PointCloudData* GetAmbiguousDataPtr(uint32* outPcSize)
{
    *outPcSize = pc_size;
    return &ambiguous_data[0];
}

extern  void custom_scan_processing_extended_fov(ScanObject* rsi)
{
    if (!rsi)
    {
        pc_size = 0;
        return;
    }
    UhdpScanInformation params = rsi->get_scan_info(); // To get elevation

    g_current_rsi = rsi;

    const PointCloudData* pcData = rsi->get_point_cloud()->get_raw_dynamic_points(pc_size);

    bool buffer_too_small = false;
    int unwrap_size = convert_ambiguous_azbin_range(pcData, ambiguous_data, pc_size, MAX_NUM_AMBIG_POINTS, buffer_too_small);

    pc_size = unwrap_size;

}



