#include "TfFramesTransformUtil.h"

const double TfFramesTransformUtil::DEGREES_TO_RADIANS{M_PI / 180};

TfFramesTransformUtil::TfFramesTransformUtil(rclcpp::Node::SharedPtr node) noexcept : node_(node)
{
    ros_param_util_ = std::make_shared<RosParamUtil>(node_);
    InitRosParams();
}

void TfFramesTransformUtil::InitRosParams()
{
    using namespace ROS_PARAM_NAMES;
    ros_param_util_->DeclareParameter(SENSOR_MOUNT_POS_X_PARAM, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_MOUNT_POS_Y_PARAM, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_MOUNT_POS_Z_PARAM, 0.0f);

    ros_param_util_->DeclareParameter(SENSOR_MOUNT_YAW_PARAM, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_MOUNT_PITCH_PARAM, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_MOUNT_ROLL_PARAM, 0.0f);
}

geometry_msgs::msg::TransformStamped TfFramesTransformUtil::GetFrameTransform() noexcept
{
    static_transformStamped_.header.stamp = node_->get_clock()->now();
    static_transformStamped_.header.frame_id = "map";
    static_transformStamped_.child_frame_id = node_->get_namespace();

    RCLCPP_INFO(node_->get_logger(), "Publishing TF2 Frame Transform from /map to %s", node_->get_namespace());

    UpdateTranslationMatrix();
    UpdateRotationalMatrix();

    return static_transformStamped_;
}

void TfFramesTransformUtil::UpdateTranslationMatrix() noexcept
{
    using namespace ROS_PARAM_NAMES;
    /*  Car coordinate system : positive x-> forward, positive y->right, positive
       z->down ROS coordinate system : positive x->forward, positive y->left,
       positive z-> up Hence we invert y and z coordinates.
    */

    // Get sensor_pos_x
    static_transformStamped_.transform.translation.x =
        ros_param_util_->GetParameter(SENSOR_MOUNT_POS_X_PARAM).as_double();

    // Get sensor_pos_y
    static_transformStamped_.transform.translation.y =
        -1.0 * ros_param_util_->GetParameter(SENSOR_MOUNT_POS_Y_PARAM).as_double();

    // Get sensor_pos_z
    static_transformStamped_.transform.translation.z =
        -1.0 * ros_param_util_->GetParameter(SENSOR_MOUNT_POS_Z_PARAM).as_double();
}

void TfFramesTransformUtil::UpdateRotationalMatrix() noexcept
{
    using namespace ROS_PARAM_NAMES;
    /*  Car coordinate system : positive x-> forward, positive y->right, positive
       z->down ROS coordinate system : positive x->forward, positive y->left,
       positive z-> up Hence we invert yaw and pitch angles.
    */

    tf2::Quaternion quat;
    double yaw{DegreesToRadians(-1.0 * ros_param_util_->GetParameter(SENSOR_MOUNT_YAW_PARAM).as_double())};
    double pitch{DegreesToRadians(-1.0 * ros_param_util_->GetParameter(SENSOR_MOUNT_PITCH_PARAM).as_double())};
    double roll{DegreesToRadians(ros_param_util_->GetParameter(SENSOR_MOUNT_ROLL_PARAM).as_double())};

    quat.setRPY(roll, pitch, yaw);
    static_transformStamped_.transform.rotation.x = quat.x();
    static_transformStamped_.transform.rotation.y = quat.y();
    static_transformStamped_.transform.rotation.z = quat.z();
    static_transformStamped_.transform.rotation.w = quat.w();
}

double TfFramesTransformUtil::DegreesToRadians(const double& degree) noexcept
{
    return degree * TfFramesTransformUtil::DEGREES_TO_RADIANS;
}
