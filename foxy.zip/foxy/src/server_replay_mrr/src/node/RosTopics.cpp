#include "RosTopics.h"

namespace ROS_PUBLISHER_TOPICS
{
const std::string TOPIC_OBJ_DATA = "topic_objdata";

const std::string TOPIC_NODE_FEEDBACK = "topic_node_feedback";

const std::string TOPIC_RRA_DETECTION_DATA_LIST = "topic_rra_detection_data_list";
const std::string TOPIC_RRA_DATA = "topic_rra_data";
const std::string TOPIC_RRA_POINT_CLOUD_DATA_FLOAT_LIST = "topic_rra_point_cloud_data_float_list";
const std::string TOPIC_RADAR_UHDP_SERVER_TRIGGER_CYCLIC = "topic_server_replay_mrr_trigger_cyclic";
const std::string TOPIC_RADAR_UHDP_SERVER_COMPLETETRIGGER = "topic_server_replay_mrr_completetrigger";

const std::string TOPIC_RDC2_DATA = "topic_rdc2_data";

const std::string TOPIC_DETN_GET_MIDW_DATA = "topic_detn_getmidwdata";
const std::string TOPIC_SCAN_INFO = "topic_scaninfo";
const std::string TOPIC_SWC_MERDRDATACUBEMIDW_TRIGGER_CYCLIC = "topic_server_replay_mrr_trigger_cyclic";
const std::string TOPIC_SWC_MERDRDATACUBEMIDW_TRIGGER_INIT = "topic_server_replay_mrr_trigger_init";
const std::string TOPIC_SWC_MERDRDATACUBEMIDW_COMPLETETRIGGER = "topic_server_replay_mrr_trigger";

} // namespace ROS_PUBLISHER_TOPICS

namespace ROS_SUBSCRIBER_TOPICS
{

const std::string TOPIC_TRIGGER_RADAR_NEXT_FRAME = "topic_trigger_radar_next_frame";
const std::string TOPIC_SET_RADAR_PAUSE_MODE = "topic_set_radar_pause_mode";
const std::string TOPIC_CAN_VEHICLE_SIGNALS{"/topic_can_vehicle_signals"};

} // namespace ROS_SUBSCRIBER_TOPICS
