#include "MDFUtil.h"

MDFUtil::MDFUtil(std::shared_ptr<rclcpp::Node> node) : node_(node)
{
    RegisterReplayLib();
}

MDFUtil::~MDFUtil()
{
    CloseMf4File();
}

void MDFUtil::AddDataMask(requested_data_e data_mask)
{
    replay_lib_.m_replayMask |= data_mask;
}

bool MDFUtil::ConnectToUhnderSimulator(RRADescriptor& rra_descriptor)
{
    return replay_lib_.Connect(rra_descriptor);
}

void MDFUtil::RegisterReplayLib()
{
    mdf_player_.RegisterListener(&replay_lib_);
}

void MDFUtil::OpenMf4File(const std::string& file_path)
{
    if (mf4_file_opened_)
    {
        CloseMf4File();
    }

    // replay_lib_.Reset();
    RCLCPP_INFO(node_->get_logger(), "Opening mf4 file : %s", file_path.c_str());
    mf4_file_opened_ = mdf_player_.Open(file_path);
    if (mf4_file_opened_)
    {
        RCLCPP_INFO(node_->get_logger(), "Opened mf4 file : %s", file_path.c_str());
    }
    else
    {
        RCLCPP_ERROR(node_->get_logger(), "Error opening file :  %s", file_path.c_str());
    }
}

void MDFUtil::CloseMf4File()
{
    if (mf4_file_opened_)
    {
        mdf_player_.Close();
        mf4_file_opened_ = false;
    }
}

int64_t MDFUtil::ReadNextMessage()
{
    auto message = mdf_player_.ReadNextMessage();
    if (message == nullptr)
    {
        return -1;
    }

    return message->TimeUnix;
}

std::vector<ScanObject*>& MDFUtil::GetReplayScanObjects()
{
    return replay_lib_.GetReplayScanObjects();
}

bool MDFUtil::GetMidw1dDataList(Rdc_MidWDataType* out_data)
{
    return replay_lib_.GetMidw1dDataList(out_data);
}

bool MDFUtil::GetMidw2dDataList(Rdc_MidWDataType* out_data)
{
    return replay_lib_.GetMidw2dDataList(out_data);
}

bool MDFUtil::GetRDC2NearDataList(UHNDER_TYPES::RDC2DataType* out_data)
{
    return replay_lib_.GetRdc2NearDataList(out_data);
}
bool MDFUtil::GetRDC2FarDataList(UHNDER_TYPES::RDC2DataType* out_data)
{
    return replay_lib_.GetRdc2FarDataList(out_data);
}

bool MDFUtil::GetMidwIntAllDataBuf(MidwInt_AllData_Type* out_data)
{
    return replay_lib_.GetMidwIntAllDataBuf(out_data);
}