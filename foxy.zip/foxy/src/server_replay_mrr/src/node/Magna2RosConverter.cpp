#include "Magna2RosConverter.h"

// ScanParamUhdp Convert
void Magna2RosConverter::ConvertMessage(const RRAScanParameters& rra_scan_params,
                                        msg_replay_radar::msg::MsgRraScanParameters* ros_rra_scan_params) noexcept
{
    memset(ros_rra_scan_params, 0, sizeof(msg_replay_radar::msg::MsgRraScanParameters));
    // Fill ScanInformation
    ros_rra_scan_params->scan_info.activation_filter_snr = rra_scan_params.scanInfo.activation_filter_snr;
    ros_rra_scan_params->scan_info.analog_die_temp_c = rra_scan_params.scanInfo.analog_die_temp_C;
    ros_rra_scan_params->scan_info.angle_wrap_flags = rra_scan_params.scanInfo.angle_wrap_flags;
    ros_rra_scan_params->scan_info.antenna_config_id = rra_scan_params.scanInfo.antenna_config_id;
    ros_rra_scan_params->scan_info.az_uniform_vrx = rra_scan_params.scanInfo.az_uniform_vrx;
    ros_rra_scan_params->scan_info.az_vrx_spacing_lambda = rra_scan_params.scanInfo.az_vrx_spacing_lambda;
    ros_rra_scan_params->scan_info.azimuth_nyquist_oversampling_factor =
        rra_scan_params.scanInfo.azimuth_nyquist_oversampling_factor;

    ros_rra_scan_params->scan_info.board_t3_temp_c = rra_scan_params.scanInfo.board_T3_temp_C;

    ros_rra_scan_params->scan_info.carrier_frequency = rra_scan_params.scanInfo.carrier_frequency;
    ros_rra_scan_params->scan_info.chip_temp_c = rra_scan_params.scanInfo.chip_temp_C;
    ros_rra_scan_params->scan_info.chip_time = rra_scan_params.scanInfo.chip_time;
    ros_rra_scan_params->scan_info.chips_per_pulse = rra_scan_params.scanInfo.chips_per_pulse;
    ros_rra_scan_params->scan_info.ci_bytes_per_pixel = rra_scan_params.scanInfo.CI_bytes_per_pixel;
    ros_rra_scan_params->scan_info.ci_doppler_height = rra_scan_params.scanInfo.CI_doppler_height;
    ros_rra_scan_params->scan_info.ci_doppler_width = rra_scan_params.scanInfo.CI_doppler_width;
    ros_rra_scan_params->scan_info.ci_format = rra_scan_params.scanInfo.CI_format;
    ros_rra_scan_params->scan_info.ci_height = rra_scan_params.scanInfo.CI_height;
    ros_rra_scan_params->scan_info.ci_pixel_size_in_meters = rra_scan_params.scanInfo.CI_pixel_size_in_meters;
    ros_rra_scan_params->scan_info.ci_width = rra_scan_params.scanInfo.CI_width;
    ros_rra_scan_params->scan_info.clock_tick_denominator = rra_scan_params.scanInfo.clock_tick_denominator;
    ros_rra_scan_params->scan_info.clock_tick_numerator = rra_scan_params.scanInfo.clock_tick_numerator;
    ros_rra_scan_params->scan_info.clutter_image_exponent = rra_scan_params.scanInfo.clutter_image_exponent;
    ros_rra_scan_params->scan_info.code_type = rra_scan_params.scanInfo.code_type;
    ros_rra_scan_params->scan_info.complex_rdc3 = rra_scan_params.scanInfo.complex_rdc3;
    ros_rra_scan_params->scan_info.connection_uhdp_version = rra_scan_params.scanInfo.connection_uhdp_version;
    ros_rra_scan_params->scan_info.current_time = rra_scan_params.scanInfo.current_time;

    // TODO{@ANURAG}
    // std::copy(std::begin(rra_scan_params.scanInfo.dc_bias),
    // std::end(rra_scan_params.scanInfo.dc_bias),
    //           std::begin(ros_rra_scan_params->scan_info.dc_bias));
    for(int row=0; row<2; row++)
        for(int col=0; col<8; col++)
        {
            ros_rra_scan_params->scan_info.dc_bias[(row*8)+(col)].i = rra_scan_params.scanInfo.dc_bias[row][col].i;
            ros_rra_scan_params->scan_info.dc_bias[(row*8)+(col)].q = rra_scan_params.scanInfo.dc_bias[row][col].q;
        }

    // std::copy(std::begin(rra_scan_params.scanInfo.dc_bias), std::end(rra_scan_params.scanInfo.dc_bias),

    ros_rra_scan_params->scan_info.sensor_id = rra_scan_params.scanInfo.sensor_id;
    ros_rra_scan_params->scan_info.dop_rotator_shift = rra_scan_params.scanInfo.dop_rotator_shift;
    ros_rra_scan_params->scan_info.doppler_bin_width = rra_scan_params.scanInfo.doppler_bin_width;

    ros_rra_scan_params->scan_info.ego_angular_velocity_x = rra_scan_params.scanInfo.ego_angular_velocity_X;
    ros_rra_scan_params->scan_info.ego_angular_velocity_y = rra_scan_params.scanInfo.ego_angular_velocity_Y;
    ros_rra_scan_params->scan_info.ego_angular_velocity_z = rra_scan_params.scanInfo.ego_angular_velocity_Z;
    ros_rra_scan_params->scan_info.ego_linear_velocity_x = rra_scan_params.scanInfo.ego_linear_velocity_X;
    ros_rra_scan_params->scan_info.ego_linear_velocity_y = rra_scan_params.scanInfo.ego_linear_velocity_Y;
    ros_rra_scan_params->scan_info.ego_linear_velocity_z = rra_scan_params.scanInfo.ego_linear_velocity_Z;
    ros_rra_scan_params->scan_info.el_uniform_vrx = rra_scan_params.scanInfo.el_uniform_vrx;
    ros_rra_scan_params->scan_info.el_vrx_spacing_lambda = rra_scan_params.scanInfo.el_vrx_spacing_lambda;
    ros_rra_scan_params->scan_info.elevation_nyquist_oversampling_factor =
        rra_scan_params.scanInfo.elevation_nyquist_oversampling_factor;
    ros_rra_scan_params->scan_info.estimated_ego_flag = rra_scan_params.scanInfo.estimated_ego_flag;
    ros_rra_scan_params->scan_info.estimated_ego_velocity_x = rra_scan_params.scanInfo.estimated_ego_velocity_X;
    ros_rra_scan_params->scan_info.estimated_ego_velocity_y = rra_scan_params.scanInfo.estimated_ego_velocity_Y;
    ros_rra_scan_params->scan_info.estimated_ego_velocity_z = rra_scan_params.scanInfo.estimated_ego_velocity_Z;
    ros_rra_scan_params->scan_info.extrapolated_ego_velocity_x = rra_scan_params.scanInfo.extrapolated_ego_velocity_X;
    ros_rra_scan_params->scan_info.extrapolated_ego_velocity_y = rra_scan_params.scanInfo.extrapolated_ego_velocity_Y;
    ros_rra_scan_params->scan_info.extrapolated_ego_velocity_z = rra_scan_params.scanInfo.extrapolated_ego_velocity_Z;

    ros_rra_scan_params->scan_info.num_angle_noise_floor_groups = rra_scan_params.scanInfo.num_angle_noise_floor_groups;
    ros_rra_scan_params->scan_info.num_azimuth_angles = rra_scan_params.scanInfo.num_azimuth_angles;
    ros_rra_scan_params->scan_info.num_beamforming_angles = rra_scan_params.scanInfo.num_beamforming_angles;
    ros_rra_scan_params->scan_info.num_channelizer_doppler_bins = rra_scan_params.scanInfo.num_channelizer_doppler_bins;
    ros_rra_scan_params->scan_info.num_channelizer_iters = rra_scan_params.scanInfo.num_channelizer_iters;
    ros_rra_scan_params->scan_info.num_detections = rra_scan_params.scanInfo.num_detections;
    ros_rra_scan_params->scan_info.num_elevation_angles = rra_scan_params.scanInfo.num_elevation_angles;
    ros_rra_scan_params->scan_info.num_music_instances = rra_scan_params.scanInfo.num_music_instances;
    ros_rra_scan_params->scan_info.num_pulses = rra_scan_params.scanInfo.num_pulses;
    ros_rra_scan_params->scan_info.num_range_bins = rra_scan_params.scanInfo.num_range_bins;
    ros_rra_scan_params->scan_info.num_rd_above_cutoff = rra_scan_params.scanInfo.num_RD_above_cutoff;
    ros_rra_scan_params->scan_info.num_rd_lower = rra_scan_params.scanInfo.num_RD_lower;
    ros_rra_scan_params->scan_info.num_rd_upper = rra_scan_params.scanInfo.num_RD_upper;
    ros_rra_scan_params->scan_info.num_tx_prn = rra_scan_params.scanInfo.num_tx_prn;
    ros_rra_scan_params->scan_info.number_of_radars = rra_scan_params.scanInfo.number_of_radars;
    ros_rra_scan_params->scan_info.num_histograms = rra_scan_params.scanInfo.num_histograms;

    ros_rra_scan_params->scan_info.overflow_underflow_flags = rra_scan_params.scanInfo.overflow_underflow_flags;

    ros_rra_scan_params->scan_info.peak_detector_output = rra_scan_params.scanInfo.peak_detector_output;
    ros_rra_scan_params->scan_info.preset_applied = rra_scan_params.scanInfo.preset_applied;
    ros_rra_scan_params->scan_info.preset_diff_flags = rra_scan_params.scanInfo.preset_diff_flags;
    ros_rra_scan_params->scan_info.pulse_time = rra_scan_params.scanInfo.pulse_time;

    ros_rra_scan_params->scan_info.radar_status_bitmap = rra_scan_params.scanInfo.radar_status_bitmap;
    ros_rra_scan_params->scan_info.range_bin_start = rra_scan_params.scanInfo.range_bin_start;
    ros_rra_scan_params->scan_info.range_bin_width = rra_scan_params.scanInfo.range_bin_width;
    ros_rra_scan_params->scan_info.rb_combine = rra_scan_params.scanInfo.rb_combine;
    ros_rra_scan_params->scan_info.rdc1_full_scale_value = rra_scan_params.scanInfo.rdc1_full_scale_value;
    ros_rra_scan_params->scan_info.rdc1_software_exponent = rra_scan_params.scanInfo.rdc1_software_exponent;
    ros_rra_scan_params->scan_info.rdc2_full_scale_value = rra_scan_params.scanInfo.rdc2_full_scale_value;
    ros_rra_scan_params->scan_info.rdc2_software_exponent = rra_scan_params.scanInfo.rdc2_software_exponent;
    ros_rra_scan_params->scan_info.rdc2_zd_rb_center = rra_scan_params.scanInfo.rdc2_zd_rb_center;
    ros_rra_scan_params->scan_info.rdc2_zd_rb_halfwidth = rra_scan_params.scanInfo.rdc2_zd_rb_halfwidth;
    ros_rra_scan_params->scan_info.rdc2ch_full_scale_value = rra_scan_params.scanInfo.rdc2ch_full_scale_value;
    ros_rra_scan_params->scan_info.rdc3_full_scale_value = rra_scan_params.scanInfo.rdc3_full_scale_value;
    ros_rra_scan_params->scan_info.rdc3_software_exponent = rra_scan_params.scanInfo.rdc3_software_exponent;

    std::copy(std::begin(rra_scan_params.scanInfo.reserved_u32), std::end(rra_scan_params.scanInfo.reserved_u32),
              std::begin(ros_rra_scan_params->scan_info.reserved_u32));

    ros_rra_scan_params->scan_info.sample_rate = rra_scan_params.scanInfo.sample_rate;
    ros_rra_scan_params->scan_info.scan_id_number = rra_scan_params.scanInfo.scan_ID_number;
    ros_rra_scan_params->scan_info.scan_loop_idx = rra_scan_params.scanInfo.scan_loop_idx;
    ros_rra_scan_params->scan_info.scan_loop_size = rra_scan_params.scanInfo.scan_loop_size;
    ros_rra_scan_params->scan_info.scan_sequence_number = rra_scan_params.scanInfo.scan_sequence_number;
    ros_rra_scan_params->scan_info.scan_time = rra_scan_params.scanInfo.scan_time;
    ros_rra_scan_params->scan_info.scan_timestamp = rra_scan_params.scanInfo.scan_timestamp;
    ros_rra_scan_params->scan_info.ss_doppler_0_only = rra_scan_params.scanInfo.ss_doppler_0_only;
    ros_rra_scan_params->scan_info.ss_size_a = rra_scan_params.scanInfo.SS_size_A;
    ros_rra_scan_params->scan_info.ss_size_d = rra_scan_params.scanInfo.SS_size_D;
    ros_rra_scan_params->scan_info.ss_size_r = rra_scan_params.scanInfo.SS_size_R;
    ros_rra_scan_params->scan_info.system_exponent = rra_scan_params.scanInfo.system_exponent;

    ros_rra_scan_params->scan_info.total_points = rra_scan_params.scanInfo.total_points;
    ros_rra_scan_params->scan_info.total_vrx = rra_scan_params.scanInfo.total_vrx;
    ros_rra_scan_params->scan_info.tx_power_map = rra_scan_params.scanInfo.tx_power_map;
    ros_rra_scan_params->scan_info.tx_prn_map = rra_scan_params.scanInfo.tx_prn_map;
    ros_rra_scan_params->scan_info.tx_prn_map_multi_roc = rra_scan_params.scanInfo.tx_prn_map_multi_roc;

    ros_rra_scan_params->scan_info.user_data = rra_scan_params.scanInfo.user_data;
    ros_rra_scan_params->scan_info.user_frame_delay_us = rra_scan_params.scanInfo.user_frame_delay_us;

    ros_rra_scan_params->scan_info.vrx_position_offset_x = rra_scan_params.scanInfo.vrx_position_offset_X;
    ros_rra_scan_params->scan_info.vrx_position_offset_y = rra_scan_params.scanInfo.vrx_position_offset_Y;
    ros_rra_scan_params->scan_info.vrx_position_offset_z = rra_scan_params.scanInfo.vrx_position_offset_Z;

    // Fill Angle Bins
    for (int i = 0; i < MAX_ROUGH_ANGLES; i++)
    {
        ros_rra_scan_params->angle_bins.at(i).angle_noise_floor_q8 =
            rra_scan_params.angleBins[0][i].angle_noise_floorQ8;
        ros_rra_scan_params->angle_bins.at(i).azimuth = rra_scan_params.angleBins[0][i].azimuth;
        ros_rra_scan_params->angle_bins.at(i).elevation = rra_scan_params.angleBins[0][i].elevation;
    }

    ros_rra_scan_params->scan_info.gpio_id = rra_scan_params.scanInfo.gpio_id;
    ros_rra_scan_params->scan_info.roc_id = rra_scan_params.scanInfo.roc_id;
    ros_rra_scan_params->scan_info.frame_counter = rra_scan_params.scanInfo.frame_counter;
    ros_rra_scan_params->scan_info.si_sequence_number = rra_scan_params.scanInfo.si_sequence_number;
    ros_rra_scan_params->scan_info.pi_sequence_number = rra_scan_params.scanInfo.pi_sequence_number;
    ros_rra_scan_params->scan_info.first_angle_bin = rra_scan_params.scanInfo.first_angle_bin;
    ros_rra_scan_params->scan_info.total_raw_detections = rra_scan_params.scanInfo.total_raw_detections;


}

// Detection Data Convert
void Magna2RosConverter::ConvertMessage(
    const RRADetectionData& rra_detection_data, uint16_t num_valid_detections,
    msg_replay_radar::msg::MsgRraDetectionDataList* ros_rra_detection_data_list) noexcept
{
    ros_rra_detection_data_list->list.clear();
    ros_rra_detection_data_list->num_valid_detections = num_valid_detections;

    for (uint16_t i = 0; i < num_valid_detections; i++)
    {
        msg_replay_radar::msg::MsgRraDetectionData ros_detection_data;
        ros_detection_data.range = rra_detection_data[i].range;
        ros_detection_data.azimuth = rra_detection_data[i].azimuth;
        ros_detection_data.elevation = rra_detection_data[i].elevation;
        ros_detection_data.doppler = rra_detection_data[i].doppler;
        ros_detection_data.magnitude = rra_detection_data[i].magnitude;
        ros_detection_data.snr = rra_detection_data[i].snr;
        ros_detection_data.rcs = rra_detection_data[i].rcs;
        ros_detection_data.pos_x = rra_detection_data[i].pos_x;
        ros_detection_data.pos_y = rra_detection_data[i].pos_y;
        ros_detection_data.pos_z = rra_detection_data[i].pos_z;
        ros_detection_data.flags = rra_detection_data[i].flags;

        ros_rra_detection_data_list->list.emplace_back(ros_detection_data);
    }
}

// PointCloud Data convert
void Magna2RosConverter::ConvertMessage(
    const RRAPointCloudData& rra_point_cloud_data, const uint32_t& num_raw_points,
    msg_replay_radar::msg::MsgRraPointCloudDataList* ros_rra_point_cloud_data_list) noexcept
{
    // std::fill(ros_rra_point_cloud_data_list->points.begin(), ros_rra_point_cloud_data_list->points.end(), 0);
    ros_rra_point_cloud_data_list->points.clear();
    ros_rra_point_cloud_data_list->num_points = num_raw_points;
    for (uint32_t i = 0; i < num_raw_points; i++)
    {
        msg_replay_radar::msg::MsgRraPointCloudData ros_point_cloud_data;
        ros_point_cloud_data.azimuth_fbin = rra_point_cloud_data[i].azimuth_fbin;
        ros_point_cloud_data.doppler_bin = rra_point_cloud_data[i].doppler_bin;
        ros_point_cloud_data.elevation_fbin = rra_point_cloud_data[i].elevation_fbin;
        ros_point_cloud_data.exponent = rra_point_cloud_data[i].exponent;
        ros_point_cloud_data.flags = rra_point_cloud_data[i].flags;
        ros_point_cloud_data.mag_i = rra_point_cloud_data[i].mag_i;
        ros_point_cloud_data.mag_q = rra_point_cloud_data[i].mag_q;
        ros_point_cloud_data.range = rra_point_cloud_data[i].range;
        ros_point_cloud_data.snr_db = rra_point_cloud_data[i].snr_dB;

        ros_rra_point_cloud_data_list->points.emplace_back(ros_point_cloud_data);
    }
}

void Magna2RosConverter::ConvertMessage(
    const RRAPointCloudDataFloat& point_cloud_data_float, const uint32_t& num_points,
    msg_replay_radar::msg::MsgRraPointCloudDataFloatList* ros_rra_point_cloud_data_float_list) noexcept
{
    // std::fill(ros_rra_point_cloud_data_float_list->points.begin(), ros_rra_point_cloud_data_float_list->points.end(), {});
    ros_rra_point_cloud_data_float_list->points.clear();
    ros_rra_point_cloud_data_float_list->num_points = num_points;

    for (uint32_t i = 0; i < num_points; i++)
    {
        msg_replay_radar::msg::MsgRraPointCloudDataFloat ros_point_cloud_data_float;
        ros_point_cloud_data_float.azimuth = point_cloud_data_float[i].azimuth;
        ros_point_cloud_data_float.doppler = point_cloud_data_float[i].doppler;
        ros_point_cloud_data_float.elevation = point_cloud_data_float[i].elevation;
        ros_point_cloud_data_float.flags = point_cloud_data_float[i].flags;
        ros_point_cloud_data_float.mag_i = point_cloud_data_float[i].mag_i;
        ros_point_cloud_data_float.mag_q = point_cloud_data_float[i].mag_q;
        ros_point_cloud_data_float.range = point_cloud_data_float[i].range;
        ros_point_cloud_data_float.mag_snr = point_cloud_data_float[i].mag_snr;

        ros_rra_point_cloud_data_float_list->points.emplace_back(ros_point_cloud_data_float);
    }
}

void Magna2RosConverter::ConvertMessage(const UhdpScanInformation& uhnder_scan_params, 
                            msg_replay_radar::msg::MsgRdcScanParamsType* ros_scan_params) noexcept
{
    ros_scan_params->scan_time = uhnder_scan_params.scan_time;
    ros_scan_params->pulse_time = uhnder_scan_params.pulse_time;
    ros_scan_params->chip_time = uhnder_scan_params.chip_time;
    ros_scan_params->doppler_bin_width = uhnder_scan_params.doppler_bin_width;
    ros_scan_params->range_bin_width = uhnder_scan_params.range_bin_width;
    ros_scan_params->pulses_per_scan = uhnder_scan_params.num_pulses;
    ros_scan_params->chips_per_pulse = uhnder_scan_params.chips_per_pulse;
    ros_scan_params->code_type = static_cast<sint32>(uhnder_scan_params.code_type);
    ros_scan_params->num_range_bins = static_cast<sint16>(uhnder_scan_params.num_range_bins);
    ros_scan_params->num_azimuth_bins = static_cast<sint16>(uhnder_scan_params.num_azimuth_angles);
    ros_scan_params->num_elevation_bins = static_cast<sint16>(uhnder_scan_params.num_elevation_angles);
    ros_scan_params->num_vrx_used = static_cast<sint16>(uhnder_scan_params.total_vrx);
    ros_scan_params->wrap_azimuth_angles = uhnder_scan_params.angle_wrap_flags;
    ros_scan_params->wrap_elevation_angles = uhnder_scan_params.angle_wrap_flags;
    ros_scan_params->scan_lambda = uhnder_scan_params.az_vrx_spacing_lambda;
    ros_scan_params->first_range_bin = uhnder_scan_params.range_bin_start;
}

void Magna2RosConverter::ConvertMessage(const UhdpScanInformation& uhnder_scan_params, 
                            msg_replay_radar::msg::MsgRdcScanInfoType* ros_scan_info) noexcept
{
    ros_scan_info->scan_sequence_numbers[0] = uhnder_scan_params.scan_sequence_number;
    ros_scan_info->scan_sequence_numbers[1] = 0U;
    ros_scan_info->scan_timestamps[0] = uhnder_scan_params.scan_timestamp;
    ros_scan_info->scan_timestamps[1] = 0U;
    ros_scan_info->ego_rdr.vx = -uhnder_scan_params.ego_linear_velocity_X;
    ros_scan_info->ego_rdr.vy = -uhnder_scan_params.ego_linear_velocity_Y;
    ros_scan_info->ego_rdr.vz = -uhnder_scan_params.ego_linear_velocity_Z;
    const ADPR_ANTENNA_CONFIG_IDs_e antenna_config_id = static_cast<ADPR_ANTENNA_CONFIG_IDs_e>(uhnder_scan_params.antenna_config_id);
    ros_scan_info->scan_dimension = (antenna_config_id != ADPR_ANTENNA_CONFIG_ID_2D) ? SCANDIMENSION_1D : SCANDIMENSION_2D;
}

void Magna2RosConverter::ConvertMessage(const DetectionData* uhnder_detn, uint32_t num_uhnder_detn,
        msg_replay_radar::msg::MsgRdcDetnType* ros_detn_list) noexcept
{
    for(uint32 detn_idx = 0U; detn_idx < num_uhnder_detn; detn_idx++)
    {
        ros_detn_list->coor_polar[detn_idx].range = uhnder_detn[detn_idx].range;
        ros_detn_list->coor_polar[detn_idx].azimuth = uhnder_detn[detn_idx].azimuth;
        ros_detn_list->coor_polar[detn_idx].elevation = uhnder_detn[detn_idx].elevation;
        ros_detn_list->doppler[detn_idx] = uhnder_detn[detn_idx].doppler;
        ros_detn_list->magnitude[detn_idx] = uhnder_detn[detn_idx].magnitude;
        ros_detn_list->sig_to_noise_rat[detn_idx] = uhnder_detn[detn_idx].snr;
        ros_detn_list->rdr_cross_sectn[detn_idx] = uhnder_detn[detn_idx].rcs;
        ros_detn_list->flags[detn_idx] = uhnder_detn[detn_idx].flags;
    }

    ros_detn_list->num_elem_per_scan[0] = static_cast<uint16>(num_uhnder_detn);
    ros_detn_list->num_elem_per_scan[1] = 0U;
}

void Magna2RosConverter::ConvertMessage(const PointCloudData* point_cloud_data, uint32_t num_points,
        msg_replay_radar::msg::MsgMidwIntRawPointCloudListType* ros_raw_point_cloud) noexcept
{
    for (uint16 idx = 0; idx < num_points; idx++)
    {
        ros_raw_point_cloud->range[idx] = point_cloud_data[idx].range;
        ros_raw_point_cloud->azimuth_fbin[idx] = point_cloud_data[idx].azimuth_fbin;
        ros_raw_point_cloud->elevation_fbin[idx] = point_cloud_data[idx].elevation_fbin;
        ros_raw_point_cloud->doppler_bin[idx] = point_cloud_data[idx].doppler_bin;
    }

    ros_raw_point_cloud->num_elements = static_cast<uint16>(num_points);
}

void Magna2RosConverter::ConvertMessage(PointCloudData* point_cloud_data, uint32_t num_points,
        msg_replay_radar::msg::MsgMidwIntConvPointCloudListType* ros_conv_point_cloud) noexcept
{
    RRAPointCloudPoint temp_point_cloud{};
    for (uint16 idx = 0; idx < num_points; idx++)
    {
        convert_to_si_patch(point_cloud_data[idx], temp_point_cloud);
        ros_conv_point_cloud->range[idx] = temp_point_cloud.range;
        ros_conv_point_cloud->azimuth[idx] = temp_point_cloud.azimuth;
        ros_conv_point_cloud->elevation[idx] = temp_point_cloud.elevation;
        ros_conv_point_cloud->doppler[idx] = temp_point_cloud.doppler;
        ros_conv_point_cloud->snr_db[idx] = temp_point_cloud.mag_snr;
        ros_conv_point_cloud->flags[idx] = temp_point_cloud.flags;
    }

    ros_conv_point_cloud->num_elements = static_cast<uint16>(num_points);
}

void Magna2RosConverter::ConvertMessage(const PointCloud::Point* conv_points, uint32_t num_points,
        msg_replay_radar::msg::MsgMidwIntConvPointCloudListType* ros_conv_point_cloud) noexcept
{
    for (uint32 idx = 0; idx < num_points; idx++)
    {
        ros_conv_point_cloud->range[idx] = conv_points[idx].range;
        ros_conv_point_cloud->azimuth[idx] = conv_points[idx].azimuth;
        ros_conv_point_cloud->elevation[idx] = conv_points[idx].elevation;
        ros_conv_point_cloud->doppler[idx] = conv_points[idx].doppler;
        ros_conv_point_cloud->snr_db[idx] = conv_points[idx].mag_snr;
        ros_conv_point_cloud->flags[idx] = conv_points[idx].flags;
    }
    ros_conv_point_cloud->num_elements = static_cast<uint16>(num_points);
}