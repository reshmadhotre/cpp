

#include "Socket.h"


/**
 * @brief Construct a new Udp Socket:: Udp Socket object
 *
 */
UdpSocket::UdpSocket()
{
    if ((SocketFileDescriptor = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    {
        throw std::runtime_error("system error - socket() failed");
    }
}


/**
 * @brief
 *
 * @param sndbuf
 * @param rcvbuf
 * @return int
 */
int UdpSocket::setBufferSizes(int sndbuf, int rcvbuf)
{
    if (sndbuf)
    {
        if (setSockOpt(SO_SNDBUF, &sndbuf, sizeof(sndbuf)) == 0)
            std::cout << "Setting SO_SNDBUF...OK." << std::endl;
        else
            std::cout << "Setting SO_SNDBUF error" << std::endl;
    }
    if (rcvbuf)
    {
        if (setSockOpt(SO_RCVBUF, &rcvbuf, sizeof(rcvbuf)) == 0)
            std::cout << "Setting SO_RCVBUF...OK." << std::endl;
        else
            std::cout << "Setting SO_RCVBUF error" << std::endl;
    }
    return 0;
}


/**
 * @brief
 *
 * @param ipaddr
 * @param port
 */
void UdpSocket::setLocalMulticastSocket(const std::string ip_address, int port)
{
    char nic_name[30];
    get_nic_from_ip(ip_address, &(nic_name[0]));

    if(setsockopt(SocketFileDescriptor, SOL_SOCKET, SO_BINDTODEVICE, (char *)&(nic_name[0]), IF_NAMESIZE) < 0)
    {
        throw std::runtime_error("Setting SO_BINDTODEVICE error");
    }
    else
    {
        std::cout << "Setting SO_BINDTODEVICE...OK.\n";
    }

    /* Bind to the proper port number with the IP address */
    /* specified as INADDR_ANY. */
    struct sockaddr_in localSock;
    std::memset((char*)&localSock, 0, sizeof(localSock));
    localSock.sin_family = AF_INET;
    localSock.sin_port = htons(port);
    localSock.sin_addr.s_addr = INADDR_ANY;

    if (bind(SocketFileDescriptor, (struct sockaddr*)&localSock, sizeof(localSock)))
    {
        throw std::runtime_error("Binding datagram socket error");
    }
    else
    {
        std::cout << "Binding datagram socket...OK.\n";
    }
}


/**
 * @brief
 *
 * @param ipaddr_local
 * @param ipaddr_multicast
 */
void UdpSocket::setMulticastClientSocket(const std::string ipaddr_local, const std::string ipaddr_multicast)
{
    //printf("IP address: %s\n", ipaddr_local.c_str());

    group.imr_multiaddr.s_addr = inet_addr(ipaddr_multicast.c_str());
    group.imr_interface.s_addr = inet_addr(ipaddr_local.c_str());

    if (setsockopt(SocketFileDescriptor, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*)&group, sizeof(group)) < 0)
    {
        throw std::runtime_error("Adding multicast group error");
    }
    else
    {
        std::cout << "Adding multicast group...OK.\n";
    }
}


/**
 * @brief
 *
 * @param nic
 * @return std::string ip_address
 */
void UdpSocket::get_ip_address_from_nic(std::string nic, char* ip_address)
{
    // Create an ifreq structure for passing data in and out of ioctl
    struct ifreq ifr;
    size_t if_name_len = strlen(nic.c_str());
    
    if (if_name_len<sizeof(ifr.ifr_name)) 
    {
        memcpy(ifr.ifr_name, nic.c_str(), if_name_len);
        ifr.ifr_name[if_name_len]=0;
    } else 
    {
        printf("interface name is too long");
    }

    // Provide an open socket descriptor with the address family AF_INET
    // and invoke ioctl
    if (ioctl(SocketFileDescriptor, SIOCGIFADDR, &ifr)==-1)
        printf("Error by searching the IP @\n");
    else
    {
        // Extract the IP address from the ifreq structure
        struct sockaddr_in* ipaddr = (struct sockaddr_in*)&ifr.ifr_addr;
        strcpy(ip_address, inet_ntoa(ipaddr->sin_addr));
        printf("IP address: %s\n", ip_address);
    }
    
}


void UdpSocket::get_nic_from_ip(std::string ip_address, char *nic_name)
{
    struct ifaddrs *addrs, *iap;
    struct sockaddr_in *sa;
    char buf[32];

    getifaddrs(&addrs);
    
    for (iap = addrs; iap != NULL; iap = iap->ifa_next) 
    {
        if (iap->ifa_addr && (iap->ifa_flags & IFF_UP) && iap->ifa_addr->sa_family == AF_INET) 
        {
            sa = (struct sockaddr_in *)(iap->ifa_addr);
            inet_ntop(iap->ifa_addr->sa_family, (void *)&(sa->sin_addr), buf, sizeof(buf));
            if (!strcmp(ip_address.c_str(), buf)) 
            {
                strcpy(nic_name, iap->ifa_name);
                printf("NIC name: %s\n", nic_name);
            }
        }
    }

  freeifaddrs(addrs);
}



/**
 * @brief
 *
 * @param buffer
 * @param buflen
 * @return ssize_t
 */
ssize_t UdpSocket::receive(void* buffer, int buflen)
{
    socklen_t slen = 0;
    // try to receive some data, this is a blocking call
    return recvfrom(SocketFileDescriptor, buffer, buflen, 0, (struct sockaddr*)&remoteSockAddr, &slen);
}


/**
 * @brief
 *
 * @param buffer
 * @param buflen
 * @return ssize_t
 */
ssize_t UdpSocket::receive_non_blocking(void* buffer, int buflen)
{
    socklen_t slen = 0;
    // try to receive some data, this is a non blocking call
    auto val = recvfrom(SocketFileDescriptor, buffer, buflen, /*MSG_PEEK | */MSG_DONTWAIT, (struct sockaddr *)&remoteSockAddr, &slen);
    /*if(val > 0)
    {
        recvfrom(SocketFileDescriptor, buffer, buflen, 0, (struct sockaddr *)&remoteSockAddr, &slen);
    } */
    return  val == -1 ? 0 : val;
}


/**
 * @brief
 *
 * @param option
 * @param value
 * @param size
 * @return int
 */
int UdpSocket::setSockOpt(int option, void* value, int size)
{
    int ret;
    if ((ret = setsockopt(SocketFileDescriptor, SOL_SOCKET, option, value, size)) < 0)
    {
        std::cout << "setsockopt() failed" << std::endl;
    }
    return ret;
}
