#include "RadarAdapterReplay.h"
#include "UhnderPatch.hpp"

const uint64_t RadarAdapterReplay::DELAY_BETWEEN_SCANS_NS = 1.0e+7;
const uint8_t RadarAdapterReplay::DEFAULT_HISTORY_DEPTH = 10;

const std::map<std::string, ScanSetType_e> RadarAdapterReplay::RADAR_TYPE_SCAN_SET_MAP = {
    {"SST_MRR_FRONT_CENTER", ScanSetType_e::e_SST_MRR_FRONT_CENTER},
    {"SST_MRR_FRONT_CORNER", ScanSetType_e::e_SST_MRR_FRONT_CORNER}};

RadarAdapterReplay::RadarAdapterReplay(std::shared_ptr<rclcpp::Node> node) : RadarAdapter(node)
{
    magna_ros_converter_ = std::make_shared<Magna2RosConverter>();
    mdf_util_ = std::make_shared<MDFUtil>(node);
    InitRosParams();
    ConfigureMDFReader();
}

void RadarAdapterReplay::InitRosParams()
{
    using namespace ROS_PARAM_NAMES_REPLAY_MODE;
    ros_param_util_->DeclareParameter(REPLAY_MF4_FILEPATHS, std::vector<std::string>{});
    ros_param_util_->DeclareParameter(REPLAY_DATA, "");
    ros_param_util_->DeclareParameter(RECORD_ROSBAGS, false);
    ros_param_util_->DeclareParameter(RADAR_NAME, "");
    ros_param_util_->DeclareParameter(RADAR_TYPE, "");
    ros_param_util_->DeclareParameter(SS_DOPPLER_NEAR_RANGE, 0.0f);
    ros_param_util_->DeclareParameter(SS_DOPPLER_FAR_RANGE, 0.0f);
    ros_param_util_->DeclareParameter(PARAM_RECORD_PARQUETS, false);

    for (uint8_t i = 0; i < ME_RRA_MAX_SCANS; i++)
    {
        ros_param_util_->DeclareParameter("scan" + std::to_string(i) + "." + DETECTION_THRESH_SNR_DB, 0.0f);
        ros_param_util_->DeclareParameter("scan" + std::to_string(i) + "." + CLUTTER_IMAGE_THRESH_SNR_DB, 0.0f);
        ros_param_util_->DeclareParameter("scan" + std::to_string(i) + "." + POINT_CLOUD_THRESH_SNR_DB, 0.0f);
        ros_param_util_->DeclareParameter("scan" + std::to_string(i) + "." + SCALE_DET_THRESH_MAX_RANGE, 0.0f);
        ros_param_util_->DeclareParameter("scan" + std::to_string(i) + "." + SCALE_DET_THRESH_SNR_ADJ, 0.0f);
        ros_param_util_->DeclareParameter("scan" + std::to_string(i) + "." + EGO_ZERO_STATIONARY_THRESHOLD_MPS, 0.0f);
        ros_param_util_->DeclareParameter("scan" + std::to_string(i) + "." + EGO_NONZ_STATIONARY_THRESHOLD_MPS, 0.0f);
        ros_param_util_->DeclareParameter("scan" + std::to_string(i) + "." + NOTCH_WIDTH_RADIANS, 0.0f);
        ros_param_util_->DeclareParameter("scan" + std::to_string(i) + "." + NOTCH_DEPTH_DB, 0.0f);
        ros_param_util_->DeclareParameter("scan" + std::to_string(i) + "." + OUTER_DEPTH_DB, 0.0f);
    }

    record_rosbags_ = ros_param_util_->GetParameter(RECORD_ROSBAGS).as_bool();
    record_parquet_ = ros_param_util_->GetParameter(PARAM_RECORD_PARQUETS).as_bool();
    replay_data_ = ros_param_util_->GetParameter(REPLAY_DATA).as_string();

    GetFilePaths();
    ApplyRRAThresholds();
}

void RadarAdapterReplay::CloseFileHandles()
{
    CloseFile();
    radar_node_->CloseRosbag();
}

void RadarAdapterReplay::ConfigureMDFReader()
{
    if (replay_data_ == ROS_PARAM_NAMES_REPLAY_MODE::REPLAY_DATA_PRE_MIDW)
    {
        mdf_util_->AddDataMask(requested_data_e::REPLAY_MIDW_RAW_INPUT_DATA);
    }
    if (replay_data_ == ROS_PARAM_NAMES_REPLAY_MODE::REPLAY_DATA_POST_MIDW)
    {
        mdf_util_->AddDataMask(requested_data_e::REPLAY_MIDW_DATA);
    }
    else
    {
        mdf_util_->AddDataMask(requested_data_e::REPLAY_RDC3_DATA);
        mdf_util_->ConnectToUhnderSimulator(rra_descriptor_);
    }
}

void RadarAdapterReplay::GetFilePaths()
{
    using namespace ROS_PARAM_NAMES_REPLAY_MODE;
    auto replay_mf4_filepaths = ros_param_util_->GetParameter(REPLAY_MF4_FILEPATHS).as_string_array();
    for (const auto& filepath : replay_mf4_filepaths)
    {
        if (FileExists(filepath))
        {
            mf4_files_queue_.push(filepath);
        }
    }
    num_files_to_process_ = mf4_files_queue_.size();
}

void RadarAdapterReplay::ApplyRRAThresholds()
{
    using namespace ROS_PARAM_NAMES_REPLAY_MODE;
    // Configure RRA thresholds.
    rra_descriptor_.GenerateBinFiles = false;
    rra_descriptor_.GenerateScanArchive = false;

    rra_descriptor_.SsDopplerNearRange = ros_param_util_->GetParameter(SS_DOPPLER_NEAR_RANGE).as_double();
    rra_descriptor_.SsDopplerFarRange = ros_param_util_->GetParameter(SS_DOPPLER_FAR_RANGE).as_double();

    radar_type_str_ = ros_param_util_->GetParameter(RADAR_TYPE).as_string();
    rra_descriptor_.ScanSet = GetScanSetTypeFromRadarType(radar_type_str_);

    for (uint8_t i = 0; i < ME_RRA_MAX_SCANS; i++)
    {
        rra_descriptor_.Thresholds[i].defaults();
        rra_descriptor_.Thresholds[i].detection_thresh_snr_dB =
            ros_param_util_->GetParameter("scan" + std::to_string(i) + "." + DETECTION_THRESH_SNR_DB).as_double();
        rra_descriptor_.Thresholds[i].clutter_image_thresh_snr_dB =
            ros_param_util_->GetParameter("scan" + std::to_string(i) + "." + CLUTTER_IMAGE_THRESH_SNR_DB).as_double();
        rra_descriptor_.Thresholds[i].point_cloud_thresh_snr_dB =
            ros_param_util_->GetParameter("scan" + std::to_string(i) + "." + POINT_CLOUD_THRESH_SNR_DB).as_double();
        rra_descriptor_.Thresholds[i].scale_det_thresh_max_range =
            ros_param_util_->GetParameter("scan" + std::to_string(i) + "." + SCALE_DET_THRESH_MAX_RANGE).as_double();
        rra_descriptor_.Thresholds[i].scale_det_thresh_snr_adj =
            ros_param_util_->GetParameter("scan" + std::to_string(i) + "." + SCALE_DET_THRESH_SNR_ADJ).as_double();
        rra_descriptor_.Thresholds[i].ego_zero_stationary_threshold_mps =
            ros_param_util_->GetParameter("scan" + std::to_string(i) + "." + EGO_ZERO_STATIONARY_THRESHOLD_MPS)
                .as_double();
        rra_descriptor_.Thresholds[i].ego_nonz_stationary_threshold_mps =
            ros_param_util_->GetParameter("scan" + std::to_string(i) + "." + EGO_NONZ_STATIONARY_THRESHOLD_MPS)
                .as_double();
        rra_descriptor_.Thresholds[i].notch_width_radians =
            ros_param_util_->GetParameter("scan" + std::to_string(i) + "." + NOTCH_WIDTH_RADIANS).as_double();
        rra_descriptor_.Thresholds[i].notch_depth_dB =
            ros_param_util_->GetParameter("scan" + std::to_string(i) + "." + NOTCH_DEPTH_DB).as_double();
        rra_descriptor_.Thresholds[i].outer_depth_dB =
            ros_param_util_->GetParameter("scan" + std::to_string(i) + "." + OUTER_DEPTH_DB).as_double();
    }
}

ScanSetType_e RadarAdapterReplay::GetScanSetTypeFromRadarType(const std::string& radar_type)
{
    auto iter = RADAR_TYPE_SCAN_SET_MAP.find(radar_type);
    if (iter != RADAR_TYPE_SCAN_SET_MAP.end())
    {
        return iter->second;
    }
    RCLCPP_ERROR(node_->get_logger(), "Radar type : %s, INVALID. Setting to SST_MRR_FRONT_CENTER", radar_type.c_str());
    return ScanSetType_e::e_SST_MRR_FRONT_CENTER;
}

void RadarAdapterReplay::StartReaderThread()
{
    continue_reading_.store(true);
    reader_thread_ = std::thread(&RadarAdapterReplay::ReadWorker, this);
}

void RadarAdapterReplay::StopReaderThread()
{
    continue_reading_.store(false);
    if (reader_thread_.joinable())
    {
        reader_thread_.join();
    }
}

void RadarAdapterReplay::ReadWorker()
{
    while (!end_of_mf4_files_ && continue_reading_.load())
    {
        ReadNextMessage();
    }

    // Publish extra dummy feedback messages for parquet nodes to finish
    uint8_t num_extra_feedback{4u};
    for (uint8_t i = 1; i <= num_extra_feedback; i++)
    {
        rclcpp::Time timestamp(prev_radar_timestamp_ + i * DELAY_BETWEEN_SCANS_NS);
        auto feedback_msg = GenerateFeedbackMessage(timestamp);
        radar_node_->AddFeedbackMessage(std::move(feedback_msg), timestamp);
    }
    return;
}

void RadarAdapterReplay::ReadNextMessage()
{
    if (!mf4_file_opened_)
    {
        if (mf4_files_queue_.empty())
        {
            end_of_mf4_files_ = true;
            radar_node_->SetEndTimestamp(prev_radar_timestamp_);

            rclcpp::Time timestamp(prev_radar_timestamp_ + DELAY_BETWEEN_SCANS_NS);
            auto feedback_msg = GenerateFeedbackMessage(timestamp);
            radar_node_->AddFeedbackMessage(std::move(feedback_msg), timestamp);
            radar_node_->CloseRosbag();
            radar_node_->CloseParquetFileHandle();
            return;
        }
        OpenNextFile();

        if (record_parquet_)
        {
            RCLCPP_INFO(node_->get_logger(), "New inst of parquet initialized with %s", file_under_process_.c_str());
            auto parquet_exporter = std::make_unique<ParquetExportSkelgen>();
            parquet_exporter->set_filename(file_under_process_);
            radar_node_->SetParquetExporter(std::move(parquet_exporter));
        }
    }

    int64_t next_msg_timestamp = mdf_util_->ReadNextMessage();
    if (next_msg_timestamp < 0)
    {
        RCLCPP_INFO(node_->get_logger(), "End of file : %s", file_under_process_.c_str());
        CloseFile();
        return;
    }

    prev_radar_timestamp_ = next_msg_timestamp;

    if (replay_data_ == ROS_PARAM_NAMES_REPLAY_MODE::REPLAY_DATA_POST_MIDW)
    {
        HandleMidWData(next_msg_timestamp);
    }
    else if (replay_data_ == ROS_PARAM_NAMES_REPLAY_MODE::REPLAY_DATA_PRE_MIDW)
    {
        HandleMidwAllIntData(next_msg_timestamp);
    }
    else
    {
        HandleRDC3Data(next_msg_timestamp);
    }
}

void RadarAdapterReplay::OpenNextFile()
{

    file_under_process_ = mf4_files_queue_.front();
    mf4_files_queue_.pop();
    num_files_processed_ = num_files_to_process_ - mf4_files_queue_.size();
    mdf_util_->OpenMf4File(file_under_process_);
    mf4_file_opened_ = true;

    if (record_rosbags_)
    {
        auto rosbag_path = RemoveExtensionFromFilePath(file_under_process_) + ".ros2bag";
        auto rosbag_writer = std::make_shared<RosbagWriter>(rosbag_path, node_namespace_);
        if (rosbag_writer->OpenFile())
        {
            radar_node_->SetRosbagWriter(rosbag_writer);
        }
    }
}

void RadarAdapterReplay::CloseFile()
{
    mdf_util_->CloseMf4File();
    file_under_process_ = "";
    mf4_file_opened_ = false;
}

std::string RadarAdapterReplay::RemoveExtensionFromFilePath(const std::string& file_path)
{
    size_t lastdot = file_path.find_last_of(".");
    if (lastdot == std::string::npos)
    {
        return file_path;
    }
    return file_path.substr(0, lastdot);
}

void RadarAdapterReplay::HandleRDC3Data(int64_t message_timestamp)
{
    std::vector<ScanObject*>& replay_scan_objects = mdf_util_->GetReplayScanObjects();
    for (size_t scan_index = 0; scan_index < replay_scan_objects.size(); scan_index++)
    {
        // Every scan_object has the same timestamp in mdf file. Add a delay for the ros messages.
        rclcpp::Time time(message_timestamp + scan_index * DELAY_BETWEEN_SCANS_NS);
        RCLCPP_DEBUG(node_->get_logger(), "Mf4 timestamp = %lu", time.nanoseconds());
        RCLCPP_DEBUG(node_->get_logger(), "scan_index = %d", scan_index);
        ScanObject* current_scan = replay_scan_objects.at(scan_index);
        if (current_scan)
        {
            current_scan_loop_idx_ = current_scan->get_scan_info().scan_loop_idx;
            scan_loop_size_ = current_scan->get_scan_info().scan_loop_size;
            if (current_scan_loop_idx_ == 0)
            {
                memset(&scan_done_[0], 0x00, sizeof(scan_done_));
                memset(&midw_all_int_data_, 0, sizeof(msg_replay_radar::msg::MsgMidwIntAllDataType));
                midw_all_int_data_.r_header.data_valid = false;
            }
            if (((scan_loop_size_ > 1) && (current_scan_loop_idx_ != last_scan_loop_idx_)) || (scan_loop_size_ == 1))
            {
                ProcessReplayScanObject(replay_scan_objects.at(scan_index), time);
            }
            last_scan_loop_idx_ = current_scan_loop_idx_;
            current_scan->release();
        }
    }
    replay_scan_objects.clear(); // ReplayLibrary expects a call to clear the vector of scan_objects
}

void RadarAdapterReplay::CopyDetnList(int64_t message_timestamp, uint16_t idx,
                                      std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> msg)
{
    auto time = rclcpp::Time(message_timestamp);
    msg->header.stamp = time;
    msg->header.frame_id = node_namespace_;

    msg->detection_list.at(idx).num_elem_per_scan.at(0) = midw_all_data_.detectionList[idx].NumElemPerScan[0];
    msg->detection_list.at(idx).num_elem_per_scan.at(1) = midw_all_data_.detectionList[idx].NumElemPerScan[1];
    memcpy(&msg->detection_list.at(idx).coor_polar.at(0), &midw_all_data_.detectionList->CoorPolar[0],
           sizeof(DetnCoorPolarArrType));
    memcpy(&msg->detection_list.at(idx).doppler.at(0), &midw_all_data_.detectionList->Doppler[0],
           sizeof(DetnFloat32ArrType));
    memcpy(&msg->detection_list.at(idx).magnitude.at(0), &midw_all_data_.detectionList->Magnitude[0],
           sizeof(DetnFloat32ArrType));
    memcpy(&msg->detection_list.at(idx).sig_to_noise_rat.at(0), &midw_all_data_.detectionList->SigToNoiseRat[0],
           sizeof(DetnFloat32ArrType));
    memcpy(&msg->detection_list.at(idx).rdr_cross_sectn.at(0), &midw_all_data_.detectionList->RdrCrossSectn[0],
           sizeof(DetnFloat32ArrType));
    memcpy(&msg->detection_list.at(idx).flags.at(0), &midw_all_data_.detectionList->Flags[0],
           sizeof(DetnUInt32ArrType));
}

void RadarAdapterReplay::CopyPointCloudList(int64_t message_timestamp, uint16_t idx,
                                            std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> msg)
{
    auto time = rclcpp::Time(message_timestamp);
    msg->header.stamp = time;
    msg->header.frame_id = node_namespace_;

    msg->conv_point_cloud_list.at(idx).num_elements = midw_all_data_.convPointCloudList[idx].NumElements;
    memcpy(&msg->conv_point_cloud_list.at(idx).range.at(0), &midw_all_data_.convPointCloudList->range[0],
           (sizeof(float32) * MAX_UHNDER_POINTCLOUD_ELEMENTS));
    memcpy(&msg->conv_point_cloud_list.at(idx).azimuth.at(0), &midw_all_data_.convPointCloudList->azimuth[0],
           (sizeof(float32) * MAX_UHNDER_POINTCLOUD_ELEMENTS));
    memcpy(&msg->conv_point_cloud_list.at(idx).elevation.at(0), &midw_all_data_.convPointCloudList->elevation[0],
           (sizeof(float32) * MAX_UHNDER_POINTCLOUD_ELEMENTS));
    memcpy(&msg->conv_point_cloud_list.at(idx).doppler.at(0), &midw_all_data_.convPointCloudList->doppler[0],
           (sizeof(float32) * MAX_UHNDER_POINTCLOUD_ELEMENTS));
    memcpy(&msg->conv_point_cloud_list.at(idx).snr_db.at(0), &midw_all_data_.convPointCloudList->snr_dB[0],
           (sizeof(float32) * MAX_UHNDER_POINTCLOUD_ELEMENTS));
    memcpy(&msg->conv_point_cloud_list.at(idx).flags.at(0), &midw_all_data_.convPointCloudList->flags[0],
           (sizeof(uint32) * MAX_UHNDER_POINTCLOUD_ELEMENTS));
}

void RadarAdapterReplay::HandleMidwAllIntData(int64_t message_timestamp)
{

    auto midw_all_int_data = std::make_shared<msg_replay_radar::msg::MsgMidwIntAllDataType>();
    if (mdf_util_->GetMidwIntAllDataBuf(&midw_all_data_))
    {
        for (uint16 idx = 0; idx < MIDW_ADPR_NUM_SCAN_SETS; idx++)
        {
            memcpy(&midw_all_int_data->r_header, &midw_all_data_.header, sizeof(MidwInt_DataHeader_Type));
            memcpy(&midw_all_int_data->scan_info[idx], &midw_all_data_.scanInfo[idx], sizeof(Rdc_ScanInfoType));
            CopyDetnList(message_timestamp, idx, midw_all_int_data);
            CopyPointCloudList(message_timestamp, idx, midw_all_int_data);
            memcpy(&midw_all_int_data->raw_point_cloud_list[idx], &midw_all_data_.rawPointCloudList[idx],
                   sizeof(MidwInt_RawPointCloudList_Type));
            memcpy(&midw_all_int_data->scan_params[idx], &midw_all_data_.scanParams[idx], sizeof(Rdc_ScanParamsType));
            memcpy(&midw_all_int_data->rdc2_data[idx], &midw_all_data_.rdc2Data[idx], sizeof(MidwInt_Rdc2Data_Type));
            memcpy(&midw_all_int_data->aux_data, &midw_all_data_.auxData, sizeof(MidwInt_AppendixData_Type));
        }

        auto time = rclcpp::Time(message_timestamp);
        midw_all_int_data->header.stamp = time;
        midw_all_int_data->header.frame_id = node_namespace_;
        radar_node_->AddMidwIntAllData(midw_all_int_data, time);
        auto feedback_msg = GenerateFeedbackMessage(time);
        radar_node_->AddFeedbackMessage(feedback_msg, time);

        auto detn_data_rviz = GenerateDetectionListRviz(midw_all_int_data, time);
        radar_node_->AddDetnListForRviz(detn_data_rviz, time);

        auto pcl_data_rviz = GeneratePointCloudRviz(midw_all_int_data, time);
        radar_node_->AddPointCloudForRviz(pcl_data_rviz, time);

        SendTriggerCyclicMessage(time.nanoseconds());
        SendCompleteTriggerMessage(time.nanoseconds());
        memset(&midw_all_data_, 0x00, sizeof(MidwInt_AllData_Type));
    }
}

void RadarAdapterReplay::HandleMidWData(int64_t message_timestamp)
{
    static std::shared_ptr<msg_swc_common::msg::MsgDetnGetMidWDataType> detn_get_midw_type;
    static bool received_1d_midw_data;
    static bool received_2d_midw_data;
    bool is_data_valid{false};
    Rdc_MidWDataType live_midw_data_1d;
    is_data_valid = mdf_util_->GetMidw1dDataList(&live_midw_data_1d);

    if (is_data_valid)
    {
        detn_get_midw_type = std::make_shared<msg_swc_common::msg::MsgDetnGetMidWDataType>();
        memcpy(&detn_get_midw_type->one_d_ptr, &live_midw_data_1d, sizeof(Rdc_MidWDataType));
        received_1d_midw_data = true;
    }

    Rdc_MidWDataType live_midw_data_2d;
    is_data_valid = mdf_util_->GetMidw2dDataList(&live_midw_data_2d);

    if (is_data_valid && received_1d_midw_data)
    {
        memcpy(&detn_get_midw_type->two_d_ptr, &live_midw_data_2d, sizeof(Rdc_MidWDataType));
        received_2d_midw_data = true;
    }

    if (received_1d_midw_data && received_2d_midw_data)
    {
        rclcpp::Time time(message_timestamp);
        detn_get_midw_type->header.stamp = time;
        detn_get_midw_type->header.frame_id = node_namespace_;
        radar_node_->AddDetnGetMidwDataType(std::move(detn_get_midw_type), time);

        auto feedback_msg = GenerateFeedbackMessage(time);
        radar_node_->AddFeedbackMessage(feedback_msg, time);
        SendTriggerCyclicMessage(time.nanoseconds());
        SendCompleteTriggerMessage(time.nanoseconds());

        received_1d_midw_data = false;
        received_2d_midw_data = false;
    }
}

void RadarAdapterReplay::ProcessReplayScanObject(ScanObject* scan_object, const rclcpp::Time& time)
{
    midw_all_int_data_.header.stamp = time;
    midw_all_int_data_.header.frame_id = node_namespace_;

    midw_all_int_data_.conv_point_cloud_list.at(current_scan_loop_idx_) =
        (*ExtractConvPointCloud(scan_object, time).get());
    midw_all_int_data_.raw_point_cloud_list.at(current_scan_loop_idx_) =
        (*ExtractRawPointCloud(scan_object, time).get());
    midw_all_int_data_.detection_list.at(current_scan_loop_idx_) = (*ExtractDetectionDataList(scan_object, time).get());
    midw_all_int_data_.scan_params.at(current_scan_loop_idx_) = (*ExtractRdcScanParameters(scan_object, time).get());
    midw_all_int_data_.scan_info.at(current_scan_loop_idx_) = (*ExtractRdcScanInfo(scan_object, time).get());
    midw_all_int_data_.r_header = (*ExtractHeaderData());
    if (current_scan_loop_idx_ == 3)
    {
        auto feedback_msg = GenerateFeedbackMessage(time);
        auto midw_all_int_data = std::make_shared<msg_replay_radar::msg::MsgMidwIntAllDataType>(midw_all_int_data_);
        radar_node_->AddMidwIntAllData(midw_all_int_data, time);
        radar_node_->AddFeedbackMessage(feedback_msg, time);

        auto detn_data_rviz = GenerateDetectionListRviz(midw_all_int_data, time);
        radar_node_->AddDetnListForRviz(detn_data_rviz, time);

        auto pcl_data_rviz = GeneratePointCloudRviz(midw_all_int_data, time);
        radar_node_->AddPointCloudForRviz(pcl_data_rviz, time);

        SendTriggerCyclicMessage(time.nanoseconds());
        SendCompleteTriggerMessage(time.nanoseconds());
    }
}

std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnListRvizType> RadarAdapterReplay::GenerateDetectionListRviz(
    std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_all_int_data, const rclcpp::Time& time)
{

    auto detn_data_rviz = std::make_shared<msg_replay_radar::msg::MsgRdcDetnListRvizType>();
    detn_data_rviz->header.stamp = time;
    detn_data_rviz->header.frame_id = node_namespace_;

    for (size_t scan_index = 0; scan_index < MIDW_ADPR_NUM_SCAN_SETS; scan_index++)
    {
        const auto& detection_list = midw_all_int_data->detection_list.at(scan_index);
        const auto num_valid_detections = detection_list.num_elem_per_scan[0];
        detn_data_rviz->num_elem_per_scan[0] += num_valid_detections;

        for (size_t i = 0; i < num_valid_detections; i++)
        {
            detn_data_rviz->coor_polar.emplace_back(detection_list.coor_polar.at(i));
            detn_data_rviz->doppler.emplace_back(detection_list.doppler.at(i));
            detn_data_rviz->flags.emplace_back(detection_list.flags.at(i));
            detn_data_rviz->magnitude.emplace_back(detection_list.magnitude.at(i));
            detn_data_rviz->rdr_cross_sectn.emplace_back(detection_list.rdr_cross_sectn.at(i));
            detn_data_rviz->sig_to_noise_rat.emplace_back(detection_list.sig_to_noise_rat.at(i));
        }
    }

    return detn_data_rviz;
}

std::shared_ptr<msg_replay_radar::msg::MsgRdcPointCloudListRvizType> RadarAdapterReplay::GeneratePointCloudRviz(
    std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_all_int_data, const rclcpp::Time& time)
{

    auto pcl_data_rviz = std::make_shared<msg_replay_radar::msg::MsgRdcPointCloudListRvizType>();
    pcl_data_rviz->header.stamp = time;
    pcl_data_rviz->header.frame_id = node_namespace_;

    for (size_t scan_index = 0; scan_index < MIDW_ADPR_NUM_SCAN_SETS; scan_index++)
    {
        const auto& point_cloud = midw_all_int_data->conv_point_cloud_list.at(scan_index);
        const auto num_points = point_cloud.num_elements;
        pcl_data_rviz->num_elements += num_points;

        for (size_t i = 0; i < num_points; i++)
        {
            pcl_data_rviz->azimuth.emplace_back(point_cloud.azimuth.at(i));
            pcl_data_rviz->doppler.emplace_back(point_cloud.doppler.at(i));
            pcl_data_rviz->elevation.emplace_back(point_cloud.elevation.at(i));
            pcl_data_rviz->flags.emplace_back(point_cloud.flags.at(i));
            pcl_data_rviz->range.emplace_back(point_cloud.range.at(i));
            pcl_data_rviz->snr_db.emplace_back(point_cloud.snr_db.at(i));
        }
    }

    return pcl_data_rviz;
}

std::shared_ptr<msg_swc_common::msg::MsgNodeFeedbackType> RadarAdapterReplay::GenerateFeedbackMessage(
    const rclcpp::Time& time)
{
    auto feedback_msg = std::make_shared<msg_swc_common::msg::MsgNodeFeedbackType>();
    feedback_msg->header.stamp = time;
    feedback_msg->header.frame_id = node_namespace_;
    feedback_msg->num_files_to_process = num_files_to_process_;
    feedback_msg->num_files_processed = num_files_processed_;
    feedback_msg->file_under_process = file_under_process_;
    feedback_msg->radar_timestamp = time.nanoseconds();

    if (end_of_mf4_files_)
    {
        feedback_msg->status = msg_swc_common::msg::MsgNodeFeedbackType::FINISHED;
    }
    else
    {
        feedback_msg->status = msg_swc_common::msg::MsgNodeFeedbackType::IN_PROGRESS;
    }
    return feedback_msg;
}

void RadarAdapterReplay::SendTriggerCyclicMessage(int64_t timestamp)
{
    auto trigger_cyclic_msg = GenerateTriggerCyclicMessage(timestamp);
    radar_node_->AddTriggerCyclicMessage(trigger_cyclic_msg, rclcpp::Time(timestamp));
}

void RadarAdapterReplay::SendCompleteTriggerMessage(int64_t timestamp)
{
    auto complete_trigger = GenerateCompleteTriggerMessage(timestamp);
    radar_node_->AddCompleteTriggerMessage(complete_trigger, rclcpp::Time(timestamp));
}

std::shared_ptr<msg_replay_radar::msg::MsgRdcScanParamsType> RadarAdapterReplay::ExtractRdcScanParameters(
    ScanObject* scan_object, const rclcpp::Time& time)
{
    (void)time;
    auto ros_rdc_scan_params = std::make_shared<msg_replay_radar::msg::MsgRdcScanParamsType>();
    const UhdpScanInformation uhnder_scan_info = scan_object->get_scan_info();

    magna_ros_converter_->ConvertMessage(uhnder_scan_info, ros_rdc_scan_params.get());

    return ros_rdc_scan_params;
}

std::shared_ptr<msg_replay_radar::msg::MsgRdcScanInfoType> RadarAdapterReplay::ExtractRdcScanInfo(
    ScanObject* scan_object, const rclcpp::Time& time)
{
    (void)time;
    auto ros_rdc_scan_info = std::make_shared<msg_replay_radar::msg::MsgRdcScanInfoType>();
    const UhdpScanInformation uhnder_scan_info = scan_object->get_scan_info();

    magna_ros_converter_->ConvertMessage(uhnder_scan_info, ros_rdc_scan_info.get());

    return ros_rdc_scan_info;
}

std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnType> RadarAdapterReplay::ExtractDetectionDataList(
    ScanObject* scan_object, const rclcpp::Time& time)
{
    auto ros_rdc_detection_list = std::make_shared<msg_replay_radar::msg::MsgRdcDetnType>();
    ros_rdc_detection_list->header.frame_id = node_namespace_;
    ros_rdc_detection_list->header.stamp = time;

    if (scan_object->get_detections())
    {
        const uint32 num_uhnder_detn = scan_object->get_detections()->get_count();
        const DetectionData* uhnder_detn = &(scan_object->get_detections()->get_detection(0));
        if ((uhnder_detn != nullptr) && (num_uhnder_detn > 0U))
        {
            magna_ros_converter_->ConvertMessage(uhnder_detn, num_uhnder_detn, ros_rdc_detection_list.get());
        }
    }
    return ros_rdc_detection_list;
}

std::shared_ptr<msg_replay_radar::msg::MsgMidwIntRawPointCloudListType> RadarAdapterReplay::ExtractRawPointCloud(
    ScanObject* scan_object, const rclcpp::Time& time)
{
    (void)time;

    auto ros_raw_pcl = std::make_shared<msg_replay_radar::msg::MsgMidwIntRawPointCloudListType>();
    const uint8_t cur_scan_loop_idx = scan_object->get_scan_info().scan_loop_idx;
    uint32_t num_points = 0;
    if (scan_object->get_point_cloud())
    {
        if ((cur_scan_loop_idx == 0) && (radar_type_str_ == "SST_MRR_FRONT_CORNER"))
        {
            custom_scan_processing_extended_fov(scan_object);
            PointCloudData* point_cloud_data = GetAmbiguousDataPtr(&num_points);
            if (point_cloud_data != nullptr)
            {
                magna_ros_converter_->ConvertMessage(point_cloud_data, num_points, ros_raw_pcl.get());
            }
        }
        else
        {
            const PointCloudData* point_cloud_data = scan_object->get_point_cloud()->get_raw_dynamic_points(num_points);
            if (point_cloud_data != nullptr)
            {
                num_points =
                    (num_points > MAX_UHNDER_POINTCLOUD_ELEMENTS) ? MAX_UHNDER_POINTCLOUD_ELEMENTS : num_points;
                magna_ros_converter_->ConvertMessage(point_cloud_data, num_points, ros_raw_pcl.get());
            }
        }
    }
    return ros_raw_pcl;
}

std::shared_ptr<msg_replay_radar::msg::MsgMidwIntConvPointCloudListType> RadarAdapterReplay::ExtractConvPointCloud(
    ScanObject* scan_object, const rclcpp::Time& time)
{
    auto ros_conv_pcl = std::make_shared<msg_replay_radar::msg::MsgMidwIntConvPointCloudListType>();
    ros_conv_pcl->header.frame_id = node_namespace_;
    ros_conv_pcl->header.stamp = time;
    uint32_t num_points = 0;
    if (scan_object->get_point_cloud())
    {
        if ((current_scan_loop_idx_ == 0) && (radar_type_str_ == "SST_MRR_FRONT_CORNER"))
        {
            custom_scan_processing_extended_fov(scan_object);
            PointCloudData* point_cloud_data = GetAmbiguousDataPtr(&num_points);
            if (point_cloud_data != nullptr)
            {
                magna_ros_converter_->ConvertMessage(point_cloud_data, num_points, ros_conv_pcl.get());
            }
        }
        if (radar_type_str_ == "SST_MRR_FRONT_CENTER")
        {
            PointCloud::Point conv_points[MAX_POINT_CLOUDS];
            uint32_t ret_num_points{};
            ret_num_points = scan_object->get_point_cloud()->get_count();
            scan_object->get_point_cloud()->get_points(&conv_points[0]);
            ret_num_points =
                (ret_num_points > MAX_UHNDER_POINTCLOUD_ELEMENTS) ? MAX_UHNDER_POINTCLOUD_ELEMENTS : ret_num_points;
            magna_ros_converter_->ConvertMessage(conv_points, ret_num_points, ros_conv_pcl.get());
        }
    }
    return ros_conv_pcl;
}

std::shared_ptr<msg_replay_radar::msg::MsgMidwIntDataHeaderType> RadarAdapterReplay::ExtractHeaderData()
{
    auto ros_midw_data_header = std::make_shared<msg_replay_radar::msg::MsgMidwIntDataHeaderType>();
    scan_done_[current_scan_loop_idx_] = true;
    uint8_t scans_done_cntr = 0;
    for (uint8_t scan_done_idx = 0; scan_done_idx < scan_loop_size_; scan_done_idx++)
    {
        if (scan_done_[scan_done_idx])
        {
            scans_done_cntr++;
        }
    }
    if (scans_done_cntr == scan_loop_size_)
    {
        ros_midw_data_header->data_valid = true;
        ros_midw_data_header->scan_loop_size = scan_loop_size_;
    }

    return ros_midw_data_header;
}

#if FOV_CORNER_RADAR_ENABLED == 1
std::shared_ptr<msg_replay_radar::msg::MsgRraPointCloudDataList> RadarAdapterReplay::ExtractPointCloudDataList(
    ScanObject* scan_object, const rclcpp::Time& time, RRADescriptor& rra_descriptor)
{
    auto ros_rra_point_cloud_data_list = std::make_shared<msg_replay_radar::msg::MsgRraPointCloudDataList>();
    ros_rra_point_cloud_data_list->header.frame_id = node_namespace_;
    ros_rra_point_cloud_data_list->header.stamp = time;

    RRAPointCloudData point_cloud_data{};
    uint32_t num_raw_points = 0;

    if (scan_object->get_point_cloud())
    {
        if (scan_object->get_scan_info().scan_loop_idx == 0 && rra_descriptor.ScanSet == e_SST_MRR_FRONT_CORNER)
        {
            custom_scan_processing_extended_fov(scan_object);
            const PointCloudData* pcData = GetAmbiguousDataPtr(&num_raw_points);
            memcpy(&point_cloud_data[0], pcData, (num_raw_points * sizeof(PointCloudData)));
        }
        else
        {
            const PointCloudData* pcData = scan_object->get_point_cloud()->get_raw_dynamic_points(num_raw_points);
            if (pcData && num_raw_points > 0)
            {
                memcpy(&point_cloud_data[0], pcData, (num_raw_points * sizeof(PointCloudData)));
            }
        }
    }

    magna_ros_converter_->ConvertMessage(point_cloud_data, num_raw_points, ros_rra_point_cloud_data_list.get());

    return ros_rra_point_cloud_data_list;
}

std::shared_ptr<msg_replay_radar::msg::MsgRraPointCloudDataFloatList> RadarAdapterReplay::ExtractPointCloudDataFloatList(
    ScanObject* scan_object, const rclcpp::Time& time, RRADescriptor& rra_descriptor)
{
    auto ros_rra_point_cloud_data_float_list = std::make_shared<msg_replay_radar::msg::MsgRraPointCloudDataFloatList>();
    ros_rra_point_cloud_data_float_list->header.frame_id = node_namespace_;
    ros_rra_point_cloud_data_float_list->header.stamp = time;

    RRAPointCloudDataFloat point_cloud_data_float{};
    RRAPointCloudData point_cloud_data{};
    uint32_t num_valid_points = 0;

    if (scan_object->get_point_cloud())
    {
        if (scan_object->get_scan_info().scan_loop_idx == 0 && rra_descriptor.ScanSet == e_SST_MRR_FRONT_CORNER)
        {
            uint32_t num_raw_points = 0;
            custom_scan_processing_extended_fov(scan_object);
            const PointCloudData* pcData = GetAmbiguousDataPtr(&num_raw_points);
            memcpy(&point_cloud_data[0], pcData, (num_raw_points * sizeof(PointCloudData)));
            for (uint16_t pc_idx = 0; pc_idx < num_raw_points; pc_idx++)
            {
                convert_to_si_patch(point_cloud_data[pc_idx], point_cloud_data_float[pc_idx]);
            }
        }
        else
        {
            num_valid_points = scan_object->get_point_cloud()->get_count();
            if (num_valid_points < MAX_POINT_CLOUDS)
            {
                scan_object->get_point_cloud()->get_points(&point_cloud_data_float[0]);
            }
            else
            {
                std::cout << "ERROR - point_cloud_data_float exceeded buffer size" << std::endl;
            }
        }
    }

    magna_ros_converter_->ConvertMessage(point_cloud_data_float, num_valid_points,
                                         ros_rra_point_cloud_data_float_list.get());

    return ros_rra_point_cloud_data_float_list;
}
#else

std::shared_ptr<msg_replay_radar::msg::MsgRraPointCloudDataList> RadarAdapterReplay::ExtractPointCloudDataList(
    ScanObject* scan_object, const rclcpp::Time& time)
{
    auto ros_point_cloud_data_list = std::make_shared<msg_replay_radar::msg::MsgRraPointCloudDataList>();
    ros_point_cloud_data_list->header.frame_id = node_namespace_;
    ros_point_cloud_data_list->header.stamp = time;

    RRAPointCloudData point_cloud_data{};
    uint32_t num_raw_points = 0;

    if (scan_object->get_point_cloud())
    {
        const PointCloudData* pcData = scan_object->get_point_cloud()->get_raw_dynamic_points(num_raw_points);

        if (pcData && num_raw_points > 0)
        {
            memcpy(&point_cloud_data[0], pcData, (num_raw_points * sizeof(PointCloudData)));
        }
    }

    magna_ros_converter_->ConvertMessage(point_cloud_data, num_raw_points, ros_point_cloud_data_list.get());

    return ros_point_cloud_data_list;
}

std::shared_ptr<msg_replay_radar::msg::MsgRraPointCloudDataFloatList> RadarAdapterReplay::ExtractPointCloudDataFloatList(
    ScanObject* scan_object, const rclcpp::Time& time)
{
    auto ros_rra_point_cloud_data_float_list = std::make_shared<msg_replay_radar::msg::MsgRraPointCloudDataFloatList>();
    ros_rra_point_cloud_data_float_list->header.frame_id = node_namespace_;
    ros_rra_point_cloud_data_float_list->header.stamp = time;

    RRAPointCloudDataFloat point_cloud_data_float{};
    uint32_t num_valid_points = 0;

    if (scan_object->get_point_cloud())
    {
        num_valid_points = scan_object->get_point_cloud()->get_count();
        if (num_valid_points < MAX_POINT_CLOUDS)
        {
            scan_object->get_point_cloud()->get_points(&point_cloud_data_float[0]);
        }
        else
        {
            std::cout << "ERROR - point_cloud_data_float exceeded buffer size" << std::endl;
        }
    }

    magna_ros_converter_->ConvertMessage(point_cloud_data_float, num_valid_points,
                                         ros_rra_point_cloud_data_float_list.get());
    return ros_rra_point_cloud_data_float_list;
}
#endif
