#include "RadarAdapter.h"
#include <sys/stat.h>

RadarAdapter::RadarAdapter(std::shared_ptr<rclcpp::Node> node)
{
    node_ = node;
    ros_param_util_ = std::make_shared<RosParamUtil>(node);
    GetNodeNamespace();
}

void RadarAdapter::SetRadarNode(std::shared_ptr<RadarNode> radar_node)
{
    radar_node_ = radar_node;
}

void RadarAdapter::GetNodeNamespace()
{
    node_namespace_ = node_->get_namespace();
    if (node_namespace_.length() <= 1)
    {
        node_namespace_ = "/map";
    }
}

bool RadarAdapter::FileExists(const std::string& file_path)
{
    struct stat buffer;
    return (stat(file_path.c_str(), &buffer) == 0);
}

std::shared_ptr<msg_swc_common::msg::MsgTriggerCyclicType> RadarAdapter::GenerateTriggerCyclicMessage(int64_t timestamp)
{
    trigger_cyclic_counter_++;

    auto ros_trigger_cyclic = std::make_shared<msg_swc_common::msg::MsgTriggerCyclicType>();
    ros_trigger_cyclic->header.stamp = rclcpp::Time(timestamp);
    ros_trigger_cyclic->header.frame_id = node_namespace_;
    ros_trigger_cyclic->counter = trigger_cyclic_counter_;

    return ros_trigger_cyclic;
}

std::shared_ptr<msg_swc_common::msg::MsgEventType> RadarAdapter::GenerateCompleteTriggerMessage(int64_t timestamp)
{
    auto msg_event = std::make_shared<msg_swc_common::msg::MsgEventType>();
    msg_event->header.stamp = rclcpp::Time(timestamp);
    msg_event->event = true;

    return msg_event;
}