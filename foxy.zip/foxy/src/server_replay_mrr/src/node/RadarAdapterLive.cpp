#include "RadarAdapterLive.h"
#include <stdexcept>

const uint16_t RadarAdapterLive::BUFFER_SIZE{65200};
const uint32_t RadarAdapterLive::BUS_SPEC_ID{69636};

// char buffer_2d[RadarAdapterLive::BUFFER_SIZE];
uint16_t udp_dst_port_midw_1d = ;
uint16_t udp_dst_port_midw_2d = PORT_MIDW_2D_DATA;
uint16_t udp_dst_port_object = PORT_OBJLIST_DATA;

RadarAdapterLive::RadarAdapterLive(std::shared_ptr<rclcpp::Node> node) : RadarAdapter(node)
{
    InitRosParams();
    params_callback_handle_ = node_->add_on_set_parameters_callback(
        std::bind(&RadarAdapterLive::ParamsCallback, this, std::placeholders::_1));
    receivers_initialized_ = InitUDPReceivers();
}

void RadarAdapterLive::InitRosParams()
{
    using namespace ROS_PARAM_NAMES_LIVE_MODE;
    ros_param_util_->DeclareParameter(ADAPTER_IP_ADDRESS, "");
    ros_param_util_->DeclareParameter(MIDW_1d_DATA, true);
    ros_param_util_->DeclareParameter(MIDW_2d_DATA, true);
    ros_param_util_->DeclareParameter(OBJECT_DATA, true);

    adapter_ip_address_ = ros_param_util_->GetParameter(ADAPTER_IP_ADDRESS).as_string();
    is_midw_data_1d_enabled_ = ros_param_util_->GetParameter(MIDW_1d_DATA).as_bool();
    is_midw_data_2d_enabled_ = ros_param_util_->GetParameter(MIDW_2d_DATA).as_bool();
    is_object_data_enabled_ = ros_param_util_->GetParameter(OBJECT_DATA).as_bool();

    if (is_midw_data_1d_enabled_ || is_midw_data_2d_enabled_)
    {
        replay_lib_.m_replayMask |= REPLAY_MIDW_DATA;
    }

    if (is_object_data_enabled_)
    {
        replay_lib_.m_replayMask |= REPLAY_OBJ_LIST;
    }
}

bool RadarAdapterLive::InitUDPReceivers()
{
    if (adapter_ip_address_.empty())
    {
        RCLCPP_ERROR(node_->get_logger(), "%s value is empty!!", ROS_PARAM_NAMES_LIVE_MODE::ADAPTER_IP_ADDRESS.c_str());
        return false;
    }

    try
    {
        InitUDPReceiverMidW1D();
        InitUDPReceiverMidW2D();
        InitUDPReceiverObjList();
    }
    catch (const std::exception& e)
    {
        RCLCPP_ERROR(node_->get_logger(), "Failed to Initialize UDP Receivers for address : %s",
                     ROS_PARAM_NAMES_LIVE_MODE::ADAPTER_IP_ADDRESS.c_str());
        std::cerr << e.what() << '\n';

        return false;
    }

    return true;
}

void RadarAdapterLive::InitUDPReceiverMidW1D()
{
    UdpSocket::Endpoint local1D(adapter_ip_address_, PORT_MIDW_1D_DATA);
    UdpSocket::Endpoint multicast1D(UDPPortSettings.Multicast, PORT_MIDW_1D_DATA);
    udp_receiver_midw_1d_ = std::make_shared<UDPReceiverMulticast>(local1D, multicast1D);
    udp_receiver_midw_1d_->setBufferSizes(UDPPortSettings.SocketBufferSize, UDPPortSettings.SocketBufferSize);
}

void RadarAdapterLive::InitUDPReceiverMidW2D()
{
    UdpSocket::Endpoint local2D(adapter_ip_address_, PORT_MIDW_2D_DATA);
    UdpSocket::Endpoint multicast2D(UDPPortSettings.Multicast, PORT_MIDW_2D_DATA);
    udp_receiver_midw_2d_ = std::make_shared<UDPReceiverMulticast>(local2D, multicast2D);
    udp_receiver_midw_2d_->setBufferSizes(UDPPortSettings.SocketBufferSize, UDPPortSettings.SocketBufferSize);
}

void RadarAdapterLive::InitUDPReceiverObjList()
{
    UdpSocket::Endpoint localObject(adapter_ip_address_, PORT_OBJLIST_DATA);
    UdpSocket::Endpoint multicastObject(UDPPortSettings.Multicast, PORT_OBJLIST_DATA);
    udp_receiver_object_list_ = std::make_shared<UDPReceiverMulticast>(localObject, multicastObject);
    udp_receiver_object_list_->setBufferSizes(UDPPortSettings.SocketBufferSize, UDPPortSettings.SocketBufferSize);
}

rcl_interfaces::msg::SetParametersResult RadarAdapterLive::ParamsCallback(
    const std::vector<rclcpp::Parameter>& changed_parameters)
{
    rcl_interfaces::msg::SetParametersResult result;
    result.successful = true;

    using namespace ROS_PARAM_NAMES_LIVE_MODE;
    for (const auto& param : changed_parameters)
    {
        if (param.get_name() == MIDW_1d_DATA)
        {
            // Be sure we target the OBJ_LIST
            replay_lib_.m_replayMask |= REPLAY_MIDW_DATA;

            if (param.get_type() != rclcpp::ParameterType::PARAMETER_BOOL)
            {
                result.reason = "Expected a boolean value for parameter : " + MIDW_1d_DATA;
                result.successful = false;
                return result;
            }

            is_midw_data_1d_enabled_ = param.as_bool();
        }

        if (param.get_name() == MIDW_2d_DATA)
        {
            // Be sure we target the OBJ_LIST
            replay_lib_.m_replayMask |= REPLAY_MIDW_DATA;

            if (param.get_type() != rclcpp::ParameterType::PARAMETER_BOOL)
            {
                result.reason = "Expected a boolean value for parameter : " + MIDW_2d_DATA;
                result.successful = false;
                return result;
            }

            is_midw_data_2d_enabled_ = param.as_bool();
        }

        if (param.get_name() == OBJECT_DATA)
        {
            // Be sure we target the OBJ_LIST
            replay_lib_.m_replayMask |= REPLAY_OBJ_LIST;

            if (param.get_type() != rclcpp::ParameterType::PARAMETER_BOOL)
            {
                result.reason = "Expected a boolean value for parameter : " + OBJECT_DATA;
                result.successful = false;
                return result;
            }

            is_object_data_enabled_ = param.as_bool();
        }
    }

    return result;
}

void RadarAdapterLive::ReadNextMessage()
{
    if (receivers_initialized_)
    {

        if (is_object_data_enabled_)
        {
            ReadObjectDataList();
        }

        if (is_midw_data_1d_enabled_ || is_midw_data_2d_enabled_)
        {
            ReadMidWData();
        }

        SendTriggerCyclicMessage();
    }

    else
    {
        throw std::runtime_error("UDP receiver not initialized");
    }
}

void RadarAdapterLive::ReadMidWData()
{
    rclcpp::Time timestamp = node_->get_clock()->now();

    auto det_get_midw_data_type = std::make_shared<msg_swc_common::msg::MsgDetnGetMidWDataType>();

    static Rdc_MidWDataType live_midw_data_1d;
    bool received_1d_data{false};

    // 1D Data
    if (is_midw_data_1d_enabled_)
    {
        ssize_t size_1d = udp_receiver_midw_1d_->receive_non_blocking(buffer_1d, RadarAdapterLive::BUFFER_SIZE);
        if (size_1d > 0)
        {
            ReadEthernetData(buffer_1d, size_1d, &udp_dst_port_midw_1d);
            bool is_data_valid = replay_lib_.GetMidw1dDataList(&live_midw_data_1d);
            if (is_data_valid)
            {
                memcpy(&det_get_midw_data_type->one_d_ptr, &live_midw_data_1d, sizeof(Rdc_MidWDataType));
                received_1d_data = true;
            }
        }

        if (received_1d_data && !is_midw_data_2d_enabled_)
        {
            det_get_midw_data_type->header.stamp = timestamp;
            det_get_midw_data_type->header.frame_id = node_namespace_;
            radar_node_->AddDetnGetMidwDataType(det_get_midw_data_type, timestamp);
        }
    }

    // 2D Data
    if (is_midw_data_2d_enabled_)
    {
        bool received_2d_data{false};
        ssize_t size_2d = udp_receiver_midw_2d_->receive_non_blocking(buffer_2d, RadarAdapterLive::BUFFER_SIZE);
        if (size_2d > 0)
        {
            ReadEthernetData(buffer_2d, size_2d, &udp_dst_port_midw_2d);

            static Rdc_MidWDataType live_midw_data_2d;
            bool is_data_valid = replay_lib_.GetMidw2dDataList(&live_midw_data_2d);

            if (is_data_valid)
            {
                memcpy(&det_get_midw_data_type->two_d_ptr, &live_midw_data_2d, sizeof(Rdc_MidWDataType));
                received_2d_data = true;
            }
        }

        if (received_2d_data)
        {
            if (!received_1d_data)
            {
                memcpy(&det_get_midw_data_type->one_d_ptr, &live_midw_data_1d, sizeof(Rdc_MidWDataType));
            }
            det_get_midw_data_type->header.stamp = timestamp;
            det_get_midw_data_type->header.frame_id = node_namespace_;
            radar_node_->AddDetnGetMidwDataType(det_get_midw_data_type, timestamp);
        }
    }
}

void RadarAdapterLive::ReadObjectDataList()
{
    rclcpp::Time timestamp = node_->get_clock()->now();
    auto object_data_type = std::make_shared<msg_live_addon::msg::MsgObjdataType>();
    bool received_object_data = false;

    ssize_t size_message =
        udp_receiver_object_list_->receive_non_blocking(buffer_object, RadarAdapterLive::BUFFER_SIZE);

    if (size_message > 0)
    {
        ReadEthernetData(buffer_object, size_message, &udp_dst_port_object);

        static ObjListType objdata;
        bool is_data_valid = replay_lib_.GetObjDataList(&objdata);

        if (is_data_valid)
        {
            memcpy(&(object_data_type->obj_list), &objdata, sizeof(ObjListType));
            received_object_data = true;
        }
    }

    if (received_object_data)
    {
        object_data_type->header.stamp = timestamp;
        object_data_type->header.frame_id = node_namespace_;
        radar_node_->AddObjDataType(std::move(object_data_type), timestamp);
    }
}

void RadarAdapterLive::SendTriggerCyclicMessage()
{
    int64_t timestamp = node_->get_clock()->now().nanoseconds();
    auto trigger_cyclic_msg = GenerateTriggerCyclicMessage(timestamp);
    radar_node_->AddTriggerCyclicMessage(trigger_cyclic_msg, rclcpp::Time(timestamp));
}

bool RadarAdapterLive::ReadEthernetData(char* buffer, int buffer_size, const uint16_t* udp_port)
{
    mdfp::EthernetData_s ethernetData;
    ethernetData.BusSpecID = RadarAdapterLive::BUS_SPEC_ID;
    ethernetData.Payload.clear();

    for (size_t buffIdx = 0; buffIdx < buffer_size; ++buffIdx)
    {
        ethernetData.Payload.push_back(buffer[buffIdx]);
    }

    replay_lib_.HandleEthMessage(ethernetData, udp_port);

    return true;
}

void RadarAdapterLive::CloseFileHandles()
{
    radar_node_->CloseRosbag();
}
