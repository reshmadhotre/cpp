#include "RadarNode.h"

RadarNode::RadarNode(std::shared_ptr<rclcpp::Node> node)
{
    node_ = node;
    ros_param_util_ = std::make_shared<RosParamUtil>(node);
    tf_frames_transform_util_ = std::make_shared<TfFramesTransformUtil>(node);
    static_transform_broadcaster_ = std::make_shared<tf2_ros::StaticTransformBroadcaster>(node);
    GetNodeNamespace();
    PublishStaticTransform();
}

void RadarNode::SetRosbagPath(const std::string& rosbag_path)
{
    CloseRosbag();
    rosbag_writer_.reset();
    rosbag_writer_ = std::make_shared<RosbagWriter>(rosbag_path, node_namespace_);
    rosbag_ready_for_write_ = rosbag_writer_->OpenFile();
    WriteStaticTransformToRosbag();
}

void RadarNode::SetRosbagWriter(std::shared_ptr<RosbagWriter> rosbag_writer)
{
    CloseRosbag();
    rosbag_writer_.reset();
    rosbag_writer_ = rosbag_writer;
    rosbag_ready_for_write_ = true;
    WriteStaticTransformToRosbag();
}

void RadarNode::SetEndTimestamp(int64_t timestamp)
{
}

void RadarNode::CloseRosbag()
{
    if (rosbag_writer_ != nullptr)
    {
        rosbag_writer_->CloseFile();
    }
    rosbag_ready_for_write_ = false;
}

void RadarNode::InitRosParams()
{
}
void RadarNode::InitPublishers()
{
}
void RadarNode::InitSubscribers()
{
}
void RadarNode::InitTimers()
{
}

void RadarNode::PublishStaticTransform()
{
    geometry_msgs::msg::TransformStamped transform_stamped = tf_frames_transform_util_->GetFrameTransform();
    static_transform_broadcaster_->sendTransform(transform_stamped);
}

void RadarNode::WriteStaticTransformToRosbag()
{
    if (rosbag_ready_for_write_)
    {
        geometry_msgs::msg::TransformStamped transform_stamped = tf_frames_transform_util_->GetFrameTransform();
        rosbag_writer_->Write(&transform_stamped, "tf_static", transform_stamped.header.stamp, false);
    }
}

void RadarNode::GetNodeNamespace()
{
    node_namespace_ = node_->get_namespace();
    if (node_namespace_.length() <= 1)
    {
        node_namespace_ = "/map";
    }
}

void RadarNode::AddMidwIntAllData(std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> rra_data,
                                  rclcpp::Time timestamp)
{
}

void RadarNode::AddDetnGetMidwDataType(
    std::shared_ptr<msg_swc_common::msg::MsgDetnGetMidWDataType> detn_get_midw_data_type, rclcpp::Time timestamp)
{
}
void RadarNode::AddObjDataType(std::shared_ptr<msg_live_addon::msg::MsgObjdataType> obj_data_type,
                               rclcpp::Time timestamp)
{
}

void RadarNode::AddFeedbackMessage(std::shared_ptr<msg_swc_common::msg::MsgNodeFeedbackType> feedback_msg,
                                   rclcpp::Time timestamp)
{
}

void RadarNode::AddTriggerCyclicMessage(std::shared_ptr<msg_swc_common::msg::MsgTriggerCyclicType> trigger_cyclic_msg,
                                        rclcpp::Time timestamp)
{
}

void RadarNode::AddCompleteTriggerMessage(std::shared_ptr<msg_swc_common::msg::MsgEventType> complete_trigger_msg,
                                          rclcpp::Time timestamp)
{
}

void RadarNode::SetParquetExporter(std::unique_ptr<ParquetExportSkelgen> parquet_exporter)
{
}

void RadarNode::CloseParquetFileHandle()
{
}

void RadarNode::AddPointCloudForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcPointCloudListRvizType> pcl_msg,
                                     rclcpp::Time timestamp)
{
}
void RadarNode::AddDetnListForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnListRvizType> detn_list,
                                   rclcpp::Time timestamp)
{
}