#include "RadarNodeLRRLive.h"
#include "RosTopics.h"

const uint8_t RadarNodeLRRLive::DEFAULT_HISTORY_DEPTH = 10;

RadarNodeLRRLive::RadarNodeLRRLive(std::shared_ptr<rclcpp::Node> node) : RadarNode(node)
{
    InitRosParams();
    InitPublishers();
}

void RadarNodeLRRLive::InitPublishers()
{
    using namespace ROS_PUBLISHER_TOPICS;
    midw_int_all_data_publisher_ = std::make_shared<RosPublisher<msg_replay_radar::msg::MsgMidwIntAllDataType>>(
        node_, TOPIC_RRA_DATA, DEFAULT_HISTORY_DEPTH);
    trigger_cyclic_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgTriggerCyclicType>>(
        node_, TOPIC_RADAR_UHDP_SERVER_TRIGGER_CYCLIC, DEFAULT_HISTORY_DEPTH);
    completetrigger_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgEventType>>(
        node_, TOPIC_RADAR_UHDP_SERVER_COMPLETETRIGGER, DEFAULT_HISTORY_DEPTH);

    detn_list_rviz_publisher_ = std::make_shared<RosPublisher<msg_replay_radar::msg::MsgRdcDetnListRvizType>>(
        node_, TOPIC_RRA_DETECTION_DATA_LIST, DEFAULT_HISTORY_DEPTH);
    pcl_data_rviz_publisher_ = std::make_shared<RosPublisher<msg_replay_radar::msg::MsgRdcPointCloudListRvizType>>(
        node_, TOPIC_RRA_POINT_CLOUD_DATA_FLOAT_LIST, DEFAULT_HISTORY_DEPTH);
}

void RadarNodeLRRLive::InitRosParams()
{
    using namespace ROS_PARAM_NAMES_LIVE_MODE;

    ros_param_util_->DeclareParameter(RECORD_ROSBAGS, false);
    ros_param_util_->DeclareParameter(ROSBAG_PATH, "");

    record_rosbags_ = ros_param_util_->GetParameter(RECORD_ROSBAGS).as_bool();

    if (record_rosbags_)
    {
        rosbag_path_ = ros_param_util_->GetParameter(ROSBAG_PATH).as_string();
        std::string full_rosbag_path = rosbag_path_ + "/" + GetRosbagName();
        SetRosbagPath(full_rosbag_path);
    }
}

void RadarNodeLRRLive::AddPointCloudForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcPointCloudListRvizType> pcl_msg,
                                            rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {
        rosbag_writer_->Write(pcl_msg.get(), ROS_PUBLISHER_TOPICS::TOPIC_RRA_POINT_CLOUD_DATA_FLOAT_LIST, timestamp);
    }
    pcl_data_rviz_publisher_->PublishMessage(std::move(pcl_msg));
}

void RadarNodeLRRLive::AddDetnListForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnListRvizType> detn_list,
                                          rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {
        rosbag_writer_->Write(detn_list.get(), ROS_PUBLISHER_TOPICS::TOPIC_RRA_DETECTION_DATA_LIST, timestamp);
    }
    detn_list_rviz_publisher_->PublishMessage(std::move(detn_list));
}

void RadarNodeLRRLive::AddMidwIntAllData(std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_int_all_data,
                                         rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {
        rosbag_writer_->Write(midw_int_all_data.get(), ROS_PUBLISHER_TOPICS::TOPIC_RRA_DATA, timestamp);
    }
    midw_int_all_data_publisher_->PublishMessage(std::move(midw_int_all_data));
}

void RadarNodeLRRLive::AddTriggerCyclicMessage(
    std::shared_ptr<msg_swc_common::msg::MsgTriggerCyclicType> trigger_cyclic_msg, rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {

        rosbag_writer_->Write(trigger_cyclic_msg.get(), ROS_PUBLISHER_TOPICS::TOPIC_RADAR_UHDP_SERVER_TRIGGER_CYCLIC,
                              rclcpp::Time(timestamp));
    }

    trigger_cyclic_publisher_->PublishMessage(std::move(trigger_cyclic_msg));
}

void RadarNodeLRRLive::AddCompleteTriggerMessage(
    std::shared_ptr<msg_swc_common::msg::MsgEventType> complete_trigger_msg, rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {

        rosbag_writer_->Write(complete_trigger_msg.get(), ROS_PUBLISHER_TOPICS::TOPIC_RADAR_UHDP_SERVER_COMPLETETRIGGER,
                              rclcpp::Time(timestamp));
    }

    completetrigger_publisher_->PublishMessage(std::move(complete_trigger_msg));
}

std::string RadarNodeLRRLive::GetRosbagName()
{
    using namespace std::chrono;
    auto now = system_clock::now();
    std::time_t now_c = system_clock::to_time_t(now);
    struct std::tm* parts = std::localtime(&now_c);

    std::stringstream rosbag_name;

    rosbag_name << "RADAR"
                << "_";
    rosbag_name << (1900 + parts->tm_year) << (1 + parts->tm_mon) << parts->tm_mday << "_";
    rosbag_name << parts->tm_hour << parts->tm_min << parts->tm_sec << "_";
    rosbag_name << node_->get_namespace() << ".ros2bag";

    return rosbag_name.str();
}