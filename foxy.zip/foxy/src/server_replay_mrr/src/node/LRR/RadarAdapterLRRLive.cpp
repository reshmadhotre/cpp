#include "RadarAdapterLRRLive.h"
#include "RosTopics.h"

const double RadarAdapterLRRLive::DEGREES_TO_RADIANS{M_PI / 180.0f};

RadarAdapterLRRLive::RadarAdapterLRRLive(std::shared_ptr<rclcpp::Node> node) : RadarAdapter(node)
{
    magna_ros_converter_ = std::make_shared<Magna2RosConverter>();
    InitRosParams();
}

void RadarAdapterLRRLive::InitRosParams()
{
    using namespace ROS_PARAM_NAMES_LRR_LIVE_MODE;
    ros_param_util_->DeclareParameter(RADAR_IP_ADDRESS, "127.0.0.1");
    ros_param_util_->DeclareParameter(RADAR_SCAN_RATE, 0);
    ros_param_util_->DeclareParameter(RADAR_SCAN_LOOP, 1);
    ros_param_util_->DeclareParameter(RADAR_DETN_THRESH_PRESET, "LOW_SENSITIVITY");
    ros_param_util_->DeclareParameter(RADAR_SCAN_PRESET_1, "VP104");
    ros_param_util_->DeclareParameter(RADAR_SCAN_PRESET_2, "VP105");
    ros_param_util_->DeclareParameter(RADAR_ANTENNA_CONFIG_1, "LowerTxAzimuth");
    ros_param_util_->DeclareParameter(RADAR_ANTENNA_CONFIG_2, "LowerTxAzimuth");

    using namespace ROS_PARAM_NAMES;
    ros_param_util_->DeclareParameter(SENSOR_MOUNT_POS_X_PARAM, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_MOUNT_POS_Y_PARAM, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_MOUNT_POS_Z_PARAM, 0.0f);

    ros_param_util_->DeclareParameter(SENSOR_MOUNT_YAW_PARAM, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_MOUNT_PITCH_PARAM, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_MOUNT_ROLL_PARAM, 0.0f);

    sensor_mount_position_.x = ros_param_util_->GetParameter(SENSOR_MOUNT_POS_X_PARAM).as_double();
    sensor_mount_position_.y = ros_param_util_->GetParameter(SENSOR_MOUNT_POS_Y_PARAM).as_double();
    sensor_mount_position_.z = ros_param_util_->GetParameter(SENSOR_MOUNT_POS_Z_PARAM).as_double();

    float sensor_roll = DEGREES_TO_RADIANS * ros_param_util_->GetParameter(SENSOR_MOUNT_ROLL_PARAM).as_double();
    float sensor_pitch =
        -1.0f * DEGREES_TO_RADIANS * ros_param_util_->GetParameter(SENSOR_MOUNT_PITCH_PARAM).as_double();
    float sensor_yaw = -1.0f * DEGREES_TO_RADIANS * ros_param_util_->GetParameter(SENSOR_MOUNT_YAW_PARAM).as_double();

    sensor_mount_orientation_ = quatf_t(sensor_roll, sensor_yaw, sensor_pitch);
}

void RadarAdapterLRRLive::InitSubscribers()
{
    vehicle_signals_subscriber_ = node_->create_subscription<msg_replay_radar::msg::MsgVehicleSignals>(
        ROS_SUBSCRIBER_TOPICS::TOPIC_CAN_VEHICLE_SIGNALS, 1,
        std::bind(&RadarAdapterLRRLive::VehicleSignalsCallback, this, std::placeholders::_1));
}

void RadarAdapterLRRLive::VehicleSignalsCallback(msg_replay_radar::msg::MsgVehicleSignals::SharedPtr msg)
{
    auto telemetry = GetTelemetryFromVehicleSignals(msg);
    uhdp_lib_.SendTelemetry(telemetry);
}

UhdpTelemetryData RadarAdapterLRRLive::GetTelemetryFromVehicleSignals(
    msg_replay_radar::msg::MsgVehicleSignals::SharedPtr msg)
{
    UhdpTelemetryData telemetry;

    // Calculate age of the measurement
    rclcpp::Time msg_receive_time = node_->get_clock()->now();
    rclcpp::Time telemetry_meas_time = msg->meas_time; // This is the time when the measurement was taken.
    uint32_t meas_age_micro_secs =
        static_cast<uint32_t>((msg_receive_time.nanoseconds() - telemetry_meas_time.nanoseconds()) * 1e-3);
    telemetry.telemetry_age_us = meas_age_micro_secs;

    std::string ego_motion_direction = msg->motion_state;
    float ego_yaw_rate = msg->ego_vehicle_yaw_rate_raw;
    float ego_velocity_x = msg->veh_speed;

    if (ego_motion_direction == msg->MTN_STATE_BACKWARD)
    {
        ego_velocity_x = -1.0f * ego_velocity_x;
    }

    vec3f_t ego_linear_velocity(ego_velocity_x, 0.0f, 0.0f);
    vec3f_t ego_angular_velocity(0.0f, 0.0f, ego_yaw_rate);

    // component of linear velocity caused by angular velocity
    vec3f_t normal_velocity = sensor_mount_position_.cross(ego_angular_velocity);

    // total linear velocity at the sensor position is the linear velocity
    // measured at the INS plus the normal velocity caused by platform
    // angular velocity (presuming this is a rigid body)
    telemetry.ego_linear_velocity = ego_linear_velocity + normal_velocity;

    // rotate this platform coordinate system ego velocity (at this
    // position) into the sensor coordinate system (accounting for yaw,
    // pitch, and roll)
    telemetry.ego_linear_velocity = sensor_mount_orientation_.rotateInv(telemetry.ego_linear_velocity);
    telemetry.ego_angular_velocity = sensor_mount_orientation_.rotateInv(ego_angular_velocity);

    // the sensor needs to know the velocity of the world relative to its
    // coordinate system, which is the negative of its own velocity
    telemetry.ego_linear_velocity *= vec3f_t(-1.0f);
    telemetry.ego_angular_velocity *= vec3f_t(-1.0f);

    return telemetry;
}

void RadarAdapterLRRLive::SetRadarProperties(RRADescriptorLRR& rra_properties)
{
    // rra_properties.sBase.nScanInterval = GetRadarScanRate();
    rra_properties.frame_control.scan_loop_count = GetRadarScanLoopCount();

    rra_properties.threshold_preset[0] = GetRadarDetectionThreshPreset();
    rra_properties.threshold_preset[1] = GetRadarDetectionThreshPreset();

    rra_properties.scan_preset[0] = GetRadarScanPreset1();
    rra_properties.scan_preset[1] = GetRadarScanPreset2();

    rra_properties.scan_control[0].antenna_config_id = GetAntennaCfg1();
    rra_properties.scan_control[1].antenna_config_id = GetAntennaCfg2();
}

void RadarAdapterLRRLive::CloseFileHandles()
{
}

bool RadarAdapterLRRLive::Connect(void)
{
    const char* radar_ip_address;

    radar_ip_address = GetRadarIPAddress();

    RCLCPP_DEBUG(node_->get_logger(), "Attempt to connect to the radar");
    if (uhdp_lib_.Connect(radar_ip_address))
    {
        RCLCPP_INFO(node_->get_logger(), "OK.....Connection to the Radar");
        return true;
    }
    RCLCPP_ERROR(node_->get_logger(), "ERROR.....Connection to the Radar");
    return false;
}

bool RadarAdapterLRRLive::SetupRadar(void)
{
    // Get the properties defined by the user
    SetRadarProperties(radar_poperties_);

    // Capture control
    if (!uhdp_lib_.SetupCaptureControl(radar_poperties_))
    {
        RCLCPP_ERROR(node_->get_logger(), "ERROR....Setup capture control");
        return false;
    }
    RCLCPP_INFO(node_->get_logger(), "OK....Setup capture control");

    // Scans
    if (!uhdp_lib_.SetupScan(radar_poperties_))
    {
        RCLCPP_ERROR(node_->get_logger(), "ERROR....Setup scan(s) property");
        return false;
    }
    RCLCPP_INFO(node_->get_logger(), "OK....Setup scan(s) property");

    // Thresholds
    if (!uhdp_lib_.SetupThresholds(radar_poperties_))
    {
        RCLCPP_ERROR(node_->get_logger(), "ERROR....Setup thresholds");
        return false;
    }
    RCLCPP_INFO(node_->get_logger(), "OK....Setup thresholds");

    return true;
}

bool RadarAdapterLRRLive::Start(void)
{
    return uhdp_lib_.Start(radar_poperties_);
}

bool RadarAdapterLRRLive::Stop(void)
{
    return uhdp_lib_.Stop(radar_poperties_);
}

bool RadarAdapterLRRLive::Receive(void)
{
    scan_object_list_ = uhdp_lib_.Receive();
    return false == scan_object_list_.empty();
}

void RadarAdapterLRRLive::Disconnect()
{
    uhdp_lib_.Disconnect();
}

bool RadarAdapterLRRLive::ProcessScanObjectList(void)
{
    if (scan_object_list_.empty())
    {
        return false;
    }

    for (auto scan_object : scan_object_list_)
    {
        ProcessScanObject(scan_object);
        scan_object->release();
    }
    scan_object_list_.clear();
    return true;
}

void RadarAdapterLRRLive::ProcessScanObject(ScanObject* scan_object)
{
    static std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_all_int_data;

    auto scan_loop_index = scan_object->get_scan_info().scan_loop_idx;
    rclcpp::Time time = node_->get_clock()->now();

    if (scan_object)
    {
        // If scan loop index = 0, reset and start populating data.
        if (scan_loop_index == 0)
        {
            midw_all_int_data = std::make_shared<msg_replay_radar::msg::MsgMidwIntAllDataType>();
            midw_all_int_data->r_header.data_valid = false;
            scan_object_list_completion_set_.reset();
        }

        scan_object_list_completion_set_.set(scan_loop_index);

        if (midw_all_int_data != nullptr)
        {
            midw_all_int_data->header.stamp = time;
            midw_all_int_data->header.frame_id = node_namespace_;

            midw_all_int_data->conv_point_cloud_list.at(scan_loop_index) = (*ExtractConvPointCloud(scan_object).get());
            midw_all_int_data->raw_point_cloud_list.at(scan_loop_index) = (*ExtractRawPointCloud(scan_object).get());
            midw_all_int_data->detection_list.at(scan_loop_index) = (*ExtractDetectionDataList(scan_object).get());
            midw_all_int_data->scan_params.at(scan_loop_index) = (*ExtractRraScanParameters(scan_object).get());
            midw_all_int_data->scan_info.at(scan_loop_index) = (*ExtractRraScanInfo(scan_object).get());
        }

        if (scan_object_list_completion_set_.all())
        {
            midw_all_int_data->r_header = (*GenerateHeaderData());
            radar_node_->AddMidwIntAllData(midw_all_int_data, time);

            auto detn_data_rviz = GenerateDetectionListRviz(midw_all_int_data, time);
            radar_node_->AddDetnListForRviz(detn_data_rviz, time);

            auto pcl_data_rviz = GeneratePointCloudRviz(midw_all_int_data, time);
            radar_node_->AddPointCloudForRviz(pcl_data_rviz, time);

            SendTriggerCyclicMessage(time);
            SendCompleteTriggerMessage(time);
            scan_object_list_completion_set_.reset();
        }
    }
}

std::shared_ptr<msg_replay_radar::msg::MsgMidwIntConvPointCloudListType> RadarAdapterLRRLive::ExtractConvPointCloud(
    ScanObject* scan_object)
{
    auto ros_conv_pcl = std::make_shared<msg_replay_radar::msg::MsgMidwIntConvPointCloudListType>();
    uint32_t num_points = 0;

    if (scan_object->get_point_cloud())
    {

        PointCloud::Point conv_points[MAX_POINT_CLOUDS];
        uint32_t ret_num_points{};
        ret_num_points = scan_object->get_point_cloud()->get_count();
        scan_object->get_point_cloud()->get_points(&conv_points[0]);

        // ret_num_points = (ret_num_points > MAGNA_MAX_POINT_CLOUD) ? MAGNA_MAX_POINT_CLOUD : ret_num_points;
        ret_num_points =
            (ret_num_points > MAX_UHNDER_POINTCLOUD_ELEMENTS) ? MAX_UHNDER_POINTCLOUD_ELEMENTS : ret_num_points;

        magna_ros_converter_->ConvertMessage(conv_points, ret_num_points, ros_conv_pcl.get());
    }
    return ros_conv_pcl;
}

std::shared_ptr<msg_replay_radar::msg::MsgMidwIntRawPointCloudListType> RadarAdapterLRRLive::ExtractRawPointCloud(
    ScanObject* scan_object)
{
    auto ros_raw_pcl = std::make_shared<msg_replay_radar::msg::MsgMidwIntRawPointCloudListType>();
    const uint8_t cur_scan_loop_idx = scan_object->get_scan_info().scan_loop_idx;
    uint32_t num_points = 0;

    if (scan_object->get_point_cloud())
    {
        const PointCloudData* point_cloud_data = scan_object->get_point_cloud()->get_raw_dynamic_points(num_points);
        if (point_cloud_data != nullptr)
        {
            // num_points = (num_points > MAGNA_MAX_POINT_CLOUD) ? MAGNA_MAX_POINT_CLOUD : num_points;
            num_points = (num_points > MAX_UHNDER_POINTCLOUD_ELEMENTS) ? MAX_UHNDER_POINTCLOUD_ELEMENTS : num_points;
            magna_ros_converter_->ConvertMessage(point_cloud_data, num_points, ros_raw_pcl.get());
        }
    }
    return ros_raw_pcl;
}

std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnType> RadarAdapterLRRLive::ExtractDetectionDataList(
    ScanObject* scan_object)
{
    auto ros_rdc_detection_list = std::make_shared<msg_replay_radar::msg::MsgRdcDetnType>();

    if (scan_object->get_detections())
    {
        const uint32 num_uhnder_detn = scan_object->get_detections()->get_count();
        const DetectionData* uhnder_detn = &(scan_object->get_detections()->get_detection(0));
        if ((uhnder_detn != nullptr) && (num_uhnder_detn > 0U))
        {
            magna_ros_converter_->ConvertMessage(uhnder_detn, num_uhnder_detn, ros_rdc_detection_list.get());
        }
    }
    return ros_rdc_detection_list;
}

std::shared_ptr<msg_replay_radar::msg::MsgRdcScanParamsType> RadarAdapterLRRLive::ExtractRraScanParameters(
    ScanObject* scan_object)
{
    auto ros_rdc_scan_params = std::make_shared<msg_replay_radar::msg::MsgRdcScanParamsType>();
    const UhdpScanInformation uhnder_scan_info = scan_object->get_scan_info();

    magna_ros_converter_->ConvertMessage(uhnder_scan_info, ros_rdc_scan_params.get());

    return ros_rdc_scan_params;
}

std::shared_ptr<msg_replay_radar::msg::MsgRdcScanInfoType> RadarAdapterLRRLive::ExtractRraScanInfo(
    ScanObject* scan_object)
{
    auto ros_rdc_scan_info = std::make_shared<msg_replay_radar::msg::MsgRdcScanInfoType>();
    const UhdpScanInformation uhnder_scan_info = scan_object->get_scan_info();

    magna_ros_converter_->ConvertMessage(uhnder_scan_info, ros_rdc_scan_info.get());

    return ros_rdc_scan_info;
}

std::shared_ptr<msg_replay_radar::msg::MsgMidwIntDataHeaderType> RadarAdapterLRRLive::GenerateHeaderData()
{
    auto ros_midw_data_header = std::make_shared<msg_replay_radar::msg::MsgMidwIntDataHeaderType>();

    ros_midw_data_header->data_valid = true;
    ros_midw_data_header->scan_loop_size = ME_RRA_MAX_SCANS_LRR;

    return ros_midw_data_header;
}

std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnListRvizType> RadarAdapterLRRLive::GenerateDetectionListRviz(
    std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_all_int_data, const rclcpp::Time& time)
{

    auto detn_data_rviz = std::make_shared<msg_replay_radar::msg::MsgRdcDetnListRvizType>();
    detn_data_rviz->header.stamp = time;
    detn_data_rviz->header.frame_id = node_namespace_;

    for (size_t scan_index = 0; scan_index < ME_RRA_MAX_SCANS_LRR; scan_index++)
    {
        const auto& detection_list = midw_all_int_data->detection_list.at(scan_index);
        const auto num_valid_detections = detection_list.num_elem_per_scan[0];
        detn_data_rviz->num_elem_per_scan[0] += num_valid_detections;

        for (size_t i = 0; i < num_valid_detections; i++)
        {
            detn_data_rviz->coor_polar.emplace_back(detection_list.coor_polar.at(i));
            detn_data_rviz->doppler.emplace_back(detection_list.doppler.at(i));
            detn_data_rviz->flags.emplace_back(detection_list.flags.at(i));
            detn_data_rviz->magnitude.emplace_back(detection_list.magnitude.at(i));
            detn_data_rviz->rdr_cross_sectn.emplace_back(detection_list.rdr_cross_sectn.at(i));
            detn_data_rviz->sig_to_noise_rat.emplace_back(detection_list.sig_to_noise_rat.at(i));
        }
    }

    return detn_data_rviz;
}

std::shared_ptr<msg_replay_radar::msg::MsgRdcPointCloudListRvizType> RadarAdapterLRRLive::GeneratePointCloudRviz(
    std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_all_int_data, const rclcpp::Time& time)
{

    auto pcl_data_rviz = std::make_shared<msg_replay_radar::msg::MsgRdcPointCloudListRvizType>();
    pcl_data_rviz->header.stamp = time;
    pcl_data_rviz->header.frame_id = node_namespace_;

    for (size_t scan_index = 0; scan_index < ME_RRA_MAX_SCANS_LRR; scan_index++)
    {
        const auto& point_cloud = midw_all_int_data->conv_point_cloud_list.at(scan_index);
        const auto num_points = point_cloud.num_elements;
        pcl_data_rviz->num_elements += num_points;

        for (size_t i = 0; i < num_points; i++)
        {
            pcl_data_rviz->azimuth.emplace_back(point_cloud.azimuth.at(i));
            pcl_data_rviz->doppler.emplace_back(point_cloud.doppler.at(i));
            pcl_data_rviz->elevation.emplace_back(point_cloud.elevation.at(i));
            pcl_data_rviz->flags.emplace_back(point_cloud.flags.at(i));
            pcl_data_rviz->range.emplace_back(point_cloud.range.at(i));
            pcl_data_rviz->snr_db.emplace_back(point_cloud.snr_db.at(i));
        }
    }

    return pcl_data_rviz;
}

void RadarAdapterLRRLive::SendTriggerCyclicMessage(const rclcpp::Time& time)
{
    auto trigger_cyclic_msg = GenerateTriggerCyclicMessage(time.nanoseconds());
    radar_node_->AddTriggerCyclicMessage(trigger_cyclic_msg, time);
}

void RadarAdapterLRRLive::SendCompleteTriggerMessage(const rclcpp::Time& time)
{
    auto complete_trigger = GenerateCompleteTriggerMessage(time.nanoseconds());
    radar_node_->AddCompleteTriggerMessage(complete_trigger, time);
}

const char* RadarAdapterLRRLive::GetRadarIPAddress() const noexcept
{
    static std::string radar_ip_address;
    radar_ip_address = ros_param_util_->GetParameter(ROS_PARAM_NAMES_LRR_LIVE_MODE::RADAR_IP_ADDRESS).as_string();

    if (radar_ip_address.empty())
    {
        radar_ip_address = DEFAULT_LRR_CONFIG.radar_ip_address;
        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved Radar IP Address : %s."
                    "Setting to default : %s",
                    "", radar_ip_address.c_str());
    }
    return radar_ip_address.c_str();
}

uint32_t RadarAdapterLRRLive::GetRadarScanRate() const
{
    uint32_t scan_rate;
    try
    {
        scan_rate = static_cast<uint32_t>(
            ros_param_util_->GetParameter(ROS_PARAM_NAMES_LRR_LIVE_MODE::RADAR_SCAN_RATE).as_int());
    }
    catch (const std::exception& e)
    {
        uint32_t default_scan_rate = DEFAULT_LRR_CONFIG.scan_rate;
        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved radar scan rate : %d invalid. Setting to default "
                    "value : %d",
                    scan_rate, default_scan_rate);
        scan_rate = default_scan_rate;
    }
    return scan_rate;
}

int RadarAdapterLRRLive::GetRadarScanLoopCount() const noexcept
{
    uint8_t scan_loop_count;
    try
    {
        scan_loop_count = static_cast<uint8_t>(
            ros_param_util_->GetParameter(ROS_PARAM_NAMES_LRR_LIVE_MODE::RADAR_SCAN_LOOP).as_int());
        if (scan_loop_count != 1 && scan_loop_count != 2)
        {
            uint8_t default_scan_loop_count = DEFAULT_LRR_CONFIG.scan_loop_count;

            RCLCPP_WARN(node_->get_logger(),
                        "Retrieved Radar Scan Loop count : %d invalid!!!. Setting to "
                        "default value : %d",
                        scan_loop_count, default_scan_loop_count);
            scan_loop_count = default_scan_loop_count;
        }
    }
    catch (const std::exception& e)
    {
        uint8_t default_scan_loop_count = DEFAULT_LRR_CONFIG.scan_loop_count;

        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved Radar Scan Loop count : %d invalid!!!. Setting to "
                    "default value : %d",
                    scan_loop_count, default_scan_loop_count);
        scan_loop_count = default_scan_loop_count;
    }
    return scan_loop_count;
}

RDC_ScanPresetEnum RadarAdapterLRRLive::GetRadarScanPreset1() const noexcept
{
    std::string scan_preset;
    try
    {
        scan_preset = ros_param_util_->GetParameter(ROS_PARAM_NAMES_LRR_LIVE_MODE::RADAR_SCAN_PRESET_1).as_string();
        return GetScanPresetEnum(scan_preset);
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        return GetScanPresetEnum(DEFAULT_LRR_CONFIG.scan_preset_1);
    }
}

RDC_ScanPresetEnum RadarAdapterLRRLive::GetRadarScanPreset2() const noexcept
{
    std::string scan_preset;
    try
    {
        scan_preset = ros_param_util_->GetParameter(ROS_PARAM_NAMES_LRR_LIVE_MODE::RADAR_SCAN_PRESET_2).as_string();
        return GetScanPresetEnum(scan_preset);
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        return GetScanPresetEnum(DEFAULT_LRR_CONFIG.scan_preset_2);
    }
}

CerveloAntennaConfigEnum RadarAdapterLRRLive::GetAntennaCfg1() const noexcept
{
    std::string antenna_config;
    try
    {
        antenna_config =
            ros_param_util_->GetParameter(ROS_PARAM_NAMES_LRR_LIVE_MODE::RADAR_ANTENNA_CONFIG_1).as_string();
        return GetAntennaConfigEnum(antenna_config);
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        return GetAntennaConfigEnum(DEFAULT_LRR_CONFIG.antenna_cfg_1);
    }
}

CerveloAntennaConfigEnum RadarAdapterLRRLive::GetAntennaCfg2() const noexcept
{
    std::string antenna_config;
    try
    {
        antenna_config =
            ros_param_util_->GetParameter(ROS_PARAM_NAMES_LRR_LIVE_MODE::RADAR_ANTENNA_CONFIG_2).as_string();
        return GetAntennaConfigEnum(antenna_config);
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        return GetAntennaConfigEnum(DEFAULT_LRR_CONFIG.antenna_cfg_2);
    }
}

ThresholdPresetEnum RadarAdapterLRRLive::GetRadarDetectionThreshPreset() const noexcept
{
    std::string detn_thresh;
    try
    {
        detn_thresh =
            ros_param_util_->GetParameter(ROS_PARAM_NAMES_LRR_LIVE_MODE::RADAR_DETN_THRESH_PRESET).as_string();
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        const std::string& default_detn_thresh_preset = DEFAULT_LRR_CONFIG.detn_thresh_preset;
        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved Radar Detection Threshold Preset: %s invalid!!. "
                    "Setting to default : %s",
                    detn_thresh.c_str(), default_detn_thresh_preset.c_str());
        detn_thresh = default_detn_thresh_preset;
    }

    auto iter = DETN_THRESH_PRESET_ENUM_MAP.find(detn_thresh);
    if (iter != DETN_THRESH_PRESET_ENUM_MAP.end())
    {
        return iter->second;
    }
    else
    {
        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved Radar Detection Threshold Preset: %s invalid!!. "
                    "Setting to default : %s",
                    detn_thresh.c_str(), DEFAULT_LRR_CONFIG.detn_thresh_preset.c_str());
        return DETN_THRESH_PRESET_ENUM_MAP.find(DEFAULT_LRR_CONFIG.detn_thresh_preset)->second;
    }
}

RDC_ScanPresetEnum RadarAdapterLRRLive::GetScanPresetEnum(const std::string& scan_preset_string) const noexcept
{
    auto iter = SCAN_PRESET_ENUM_MAP.find(scan_preset_string);

    if (iter != SCAN_PRESET_ENUM_MAP.end())
    {
        return iter->second;
    }

    else
    {
        std::string default_scan_preset = DEFAULT_LRR_CONFIG.scan_preset_1;
        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved Scan Preset: %s invalid!!. "
                    "Setting to default : %s",
                    scan_preset_string.c_str(), default_scan_preset.c_str());

        iter = SCAN_PRESET_ENUM_MAP.find(default_scan_preset);
        return iter->second;
    }
}

CerveloAntennaConfigEnum RadarAdapterLRRLive::GetAntennaConfigEnum(
    const std::string& frr_antenna_cfg_string) const noexcept
{
    auto iter = FRR_ANTENNA_CONFIG_ENUM_MAP.find(frr_antenna_cfg_string);
    if (iter != FRR_ANTENNA_CONFIG_ENUM_MAP.end())
    {
        return iter->second;
    }

    else
    {
        const std::string& default_frr_antenna_config = DEFAULT_LRR_CONFIG.antenna_cfg_1;

        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved FRR Antenna Config: %s invalid!!. "
                    "Setting to default : %s",
                    frr_antenna_cfg_string.c_str(), default_frr_antenna_config.c_str());

        iter = FRR_ANTENNA_CONFIG_ENUM_MAP.find(default_frr_antenna_config);
        return iter->second;
    }
}