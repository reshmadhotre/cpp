
#include "RecordReplayTest.hpp"

RecordReplayTest::RecordReplayTest()
{
}

void RecordReplayTest::Replay()
{
    std::string file_to_play("/home/kpit/magna/RDC3_Data_test.mf4");
    ReplayLibrary replayLib;
    mdfp::MDFPlayer player;

    RRADescriptor desc;
    RRAScanParameters m_ScanParamUhdp;
    RRADetectionData m_DetectionData;
    RRAPointCloudData m_PointCloudData;
    RRAPointCloudDataFloat m_PointCloudDataFloat;
    desc.GenerateBinFiles = false;

    std::cout << "RegisterListener..." << std::endl;
    player.RegisterListener(&replayLib);
    std::cout << "RegisterListener OK!" << std::endl;

    replayLib.Disconnect();
    replayLib.Connect(desc);

    std::cout << "Open " << file_to_play << "..." << std::endl;
    if (player.Open(file_to_play))
    {
        std::cout << "Open " << file_to_play << " OK!" << std::endl;

        std::cout << "Read messages... " << std::endl;
        mdfp::MessageInfo_s* message = player.ReadNextMessage();
        uint32_t scan_id = 0;

        while (message)
        {
            message = player.ReadNextMessage();
            std::vector<ScanObject*>& replayScanObjects = replayLib.GetReplayScanObjects();

            for (size_t i = 0; i < replayScanObjects.size(); ++i)
            {
                ScanObject* currentScan = replayScanObjects[i];
                if (currentScan)
                {
                    scan_id++;
                    std::cout << "   |- Scan #" << scan_id << std::endl;

                    // Scan info
                    const UhdpScanInformation& scanInfo = currentScan->get_scan_info();
                    memcpy(&m_ScanParamUhdp.scanInfo, &scanInfo, sizeof(scanInfo));
                    ScanObject_Impl* scanObj_impl = dynamic_cast<ScanObject_Impl*>(currentScan);
                    if (scanObj_impl && scanObj_impl->angle_bins && scanInfo.num_beamforming_angles > 0)
                    {
                        memcpy(&m_ScanParamUhdp.angleBins[0][0], scanObj_impl->angle_bins,
                               scanInfo.num_beamforming_angles * sizeof(UhdpAngleBinInfo));
                    }
                    std::cout << "     |- Transmit scan info" << std::endl;

                    // Detections
                    memset(&m_DetectionData[0], 0, sizeof(m_DetectionData));
                    if (currentScan->get_detections() && currentScan->get_detections()->get_count() > 0)
                    {
                        memcpy(&m_DetectionData[0], &currentScan->get_detections()->get_detection(0),
                               size_t(currentScan->get_detections()->get_count() * sizeof(DetectionData)));
                    }
                    std::cout << "     |- Transmit detections" << std::endl;

                    // PointCloud
                    memset(&m_PointCloudData[0], 0, sizeof(m_PointCloudData));
                    memset(&m_PointCloudDataFloat[0], 0, sizeof(m_PointCloudDataFloat));
                    if (currentScan->get_point_cloud())
                    {
                        uint32_t numRawPoints = 0;
                        const PointCloudData* pcData =
                            currentScan->get_point_cloud()->get_raw_dynamic_points(numRawPoints);

                        if (pcData && numRawPoints > 0)
                        {
                            memcpy(&m_PointCloudData[0], pcData, (numRawPoints * sizeof(PointCloudData)));
                        }

                        if (currentScan->get_point_cloud()->get_count() < MAX_POINT_CLOUDS)
                        {
                            currentScan->get_point_cloud()->get_points(&m_PointCloudDataFloat[0]);
                        }
                        else
                        {
                            std::cout << "ERROR - m_PointCloudDataFloat exceeded buffer size" << std::endl;
                        }
                    }
                    // Raw PC
                    std::cout << "     |- Transmit raw point cloud" << std::endl;

                    // PC float
                    std::cout << "     |- Transmit floating point cloud" << std::endl;

                    // Cyclic trigger
                    std::cout << "     |- Transmit trigger" << std::endl;

                    currentScan->release();
                }
            }
            replayScanObjects.clear();
        }
    }
    else
        std::cout << "Open " << file_to_play << " NOT OK!" << std::endl;

    replayLib.Disconnect();
}
