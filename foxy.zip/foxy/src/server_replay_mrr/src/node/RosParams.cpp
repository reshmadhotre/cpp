
#include "RosParams.h"

namespace ROS_PARAM_NAMES
{

const std::string SENSOR_MOUNT_POS_X_PARAM = "sensor_position_x";
const std::string SENSOR_MOUNT_POS_Y_PARAM = "sensor_position_y";
const std::string SENSOR_MOUNT_POS_Z_PARAM = "sensor_position_z";
const std::string SENSOR_MOUNT_YAW_PARAM = "sensor_yaw";
const std::string SENSOR_MOUNT_PITCH_PARAM = "sensor_pitch";
const std::string SENSOR_MOUNT_ROLL_PARAM = "sensor_roll";

} // namespace ROS_PARAM_NAMES

namespace ROS_PARAM_NAMES_REPLAY_MODE
{
const std::string REPLAY_MF4_FILEPATHS = "replay_mf4_filepaths";
const std::string REPLAY_DATA = "replay_data";
const std::string REPLAY_DATA_RDC3 = "rdc3";
const std::string REPLAY_DATA_PRE_MIDW = "pre_midw";
const std::string REPLAY_DATA_POST_MIDW = "post_midw";
const std::string RECORD_ROSBAGS = "record_rosbags";
const std::string RADAR_NAME = "radar_name";
const std::string RADAR_TYPE = "radar_type";
const std::string PARAM_UHDP_COMPLETE_TRIGGER_NODE = "param_uhdp_completetrigger_node";
const std::string PARAM_RECORD_PARQUETS = "param_record_output_parquets";

// SCAN Parameters.
const std::string SS_DOPPLER_NEAR_RANGE = "ss_doppler_near_range";
const std::string SS_DOPPLER_FAR_RANGE = "ss_doppler_far_range";
const std::string DETECTION_THRESH_SNR_DB = "detection_thresh_snr_dB";
const std::string CLUTTER_IMAGE_THRESH_SNR_DB = "clutter_image_thresh_snr_dB";
const std::string POINT_CLOUD_THRESH_SNR_DB = "point_cloud_thresh_snr_dB";
const std::string SCALE_DET_THRESH_MAX_RANGE = "scale_det_thresh_max_range";
const std::string SCALE_DET_THRESH_SNR_ADJ = "scale_det_thresh_snr_adj";
const std::string EGO_ZERO_STATIONARY_THRESHOLD_MPS = "ego_zero_stationary_threshold_mps";
const std::string EGO_NONZ_STATIONARY_THRESHOLD_MPS = "ego_nonz_stationary_threshold_mps";
const std::string NOTCH_WIDTH_RADIANS = "notch_width_radians";
const std::string NOTCH_DEPTH_DB = "notch_depth_dB";
const std::string OUTER_DEPTH_DB = "outer_depth_dB";

} // namespace ROS_PARAM_NAMES_REPLAY_MODE

namespace ROS_PARAM_NAMES_LIVE_MODE
{

const std::string ADAPTER_IP_ADDRESS = "adapter_ip_address";
const std::string MIDW_1d_DATA = "midw_1d_data";
const std::string MIDW_2d_DATA = "midw_2d_data";
const std::string OBJECT_DATA = "objects_data";
const std::string RDC3_DATA = "rdc3_data";
const std::string PUBLISH_RBE = "publish_road_boarder_estimation";
const std::string RECORD_ROSBAGS = "record_rosbags";
const std::string ROSBAG_PATH = "rosbag_path";

} // namespace ROS_PARAM_NAMES_LIVE_MODE

namespace ROS_PARAM_NAMES_LRR_LIVE_MODE
{
const std::string RADAR_IP_ADDRESS{"radar_ip_address"};
const std::string RADAR_SCAN_RATE{"radar_scan_rate_micro_secs"};
const std::string RADAR_SCAN_LOOP{"radar_scan_loop_count"};
const std::string RADAR_SCAN_PRESET_1{"radar_scan_preset_1"};
const std::string RADAR_SCAN_PRESET_2{"radar_scan_preset_2"};
const std::string RADAR_ANTENNA_CONFIG_1{"radar_antenna_config_1"};
const std::string RADAR_ANTENNA_CONFIG_2{"radar_antenna_config_2"};
const std::string RADAR_DETN_THRESH_PRESET{"radar_detection_threshold_preset"};
const std::string RECORD_ROSBAGS = "record_rosbags";
const std::string ROSBAG_PATH = "rosbag_path";
} // namespace ROS_PARAM_NAMES_LRR_LIVE_MODE