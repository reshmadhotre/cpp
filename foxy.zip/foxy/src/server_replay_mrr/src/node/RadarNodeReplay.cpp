#include "RadarNodeReplay.h"
#include <limits>

const uint8_t RadarNodeReplay::DEFAULT_HISTORY_DEPTH = 10;
const uint64_t RadarNodeReplay::MAX_SLEEP_TIME_NS = 200 * 1e6; // 200 milliseconds

RadarNodeReplay::RadarNodeReplay(std::shared_ptr<rclcpp::Node> node) : RadarNode(node)
{
    InitRosParams();
    InitPublishers();
    InitSubscribers();
    InitTimers();
    end_of_replay_ts_ = std::numeric_limits<int64_t>::max();
}

void RadarNodeReplay::InitRosParams()
{
    using namespace ROS_PARAM_NAMES_REPLAY_MODE;
    ros_param_util_->DeclareParameter(PARAM_UHDP_COMPLETE_TRIGGER_NODE, "");
    ros_param_util_->DeclareParameter(REPLAY_DATA, "");

    complete_trigger_node_ = ros_param_util_->GetParameter(PARAM_UHDP_COMPLETE_TRIGGER_NODE).as_string();
    replay_data_ = ros_param_util_->GetParameter(REPLAY_DATA).as_string();
}

void RadarNodeReplay::InitPublishers()
{
    if (replay_data_ == ROS_PARAM_NAMES_REPLAY_MODE::REPLAY_DATA_POST_MIDW)
    {
        InitMidWDataPublishers();
        PublishTriggerInit();
    }
    else
    {
        InitRDC3Publishers();
        InitRvizDataPublishers();
    }

    node_feedback_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgNodeFeedbackType>>(
        node_, ROS_PUBLISHER_TOPICS::TOPIC_NODE_FEEDBACK, DEFAULT_HISTORY_DEPTH);
}

void RadarNodeReplay::InitMidWDataPublishers()
{
    using namespace ROS_PUBLISHER_TOPICS;
    detn_get_midw_data_type_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgDetnGetMidWDataType>>(
        node_, TOPIC_DETN_GET_MIDW_DATA, DEFAULT_HISTORY_DEPTH);
    scan_info_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgScaninfoType>>(node_, TOPIC_SCAN_INFO,
                                                                                                DEFAULT_HISTORY_DEPTH);
    swc_midw_trigger_init_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgTriggerInitType>>(
        node_, TOPIC_SWC_MERDRDATACUBEMIDW_TRIGGER_INIT, DEFAULT_HISTORY_DEPTH);
    trigger_cyclic_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgTriggerCyclicType>>(
        node_, TOPIC_SWC_MERDRDATACUBEMIDW_TRIGGER_CYCLIC, DEFAULT_HISTORY_DEPTH);
    completetrigger_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgEventType>>(
        node_, TOPIC_SWC_MERDRDATACUBEMIDW_COMPLETETRIGGER, DEFAULT_HISTORY_DEPTH);
}

void RadarNodeReplay::InitRvizDataPublishers()
{
    using namespace ROS_PUBLISHER_TOPICS;
    rra_detection_data_list_publisher_ = std::make_shared<RosPublisher<msg_replay_radar::msg::MsgRdcDetnListRvizType>>(
        node_, TOPIC_RRA_DETECTION_DATA_LIST, DEFAULT_HISTORY_DEPTH);
    rra_point_cloud_data_float_list_publisher_ =
        std::make_shared<RosPublisher<msg_replay_radar::msg::MsgRdcPointCloudListRvizType>>(
            node_, TOPIC_RRA_POINT_CLOUD_DATA_FLOAT_LIST, DEFAULT_HISTORY_DEPTH);
}

void RadarNodeReplay::InitRDC3Publishers()
{
    using namespace ROS_PUBLISHER_TOPICS;
    midw_int_all_data_publisher_ = std::make_shared<RosPublisher<msg_replay_radar::msg::MsgMidwIntAllDataType>>(
        node_, TOPIC_RRA_DATA, DEFAULT_HISTORY_DEPTH);
    trigger_cyclic_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgTriggerCyclicType>>(
        node_, TOPIC_RADAR_UHDP_SERVER_TRIGGER_CYCLIC, DEFAULT_HISTORY_DEPTH);
    completetrigger_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgEventType>>(
        node_, TOPIC_RADAR_UHDP_SERVER_COMPLETETRIGGER, DEFAULT_HISTORY_DEPTH);
}

void RadarNodeReplay::InitSubscribers()
{
    using namespace ROS_SUBSCRIBER_TOPICS;
    if (!complete_trigger_node_.empty())
    {
        completetrigger_subscriber_ = node_->create_subscription<msg_swc_common::msg::MsgEventType>(
            "topic_" + complete_trigger_node_ + "_trigger", 10,
            std::bind(&RadarNodeReplay::CompletetriggerCB, this, std::placeholders::_1));
    }
    else
    {
        RCLCPP_ERROR(node_->get_logger(), "Complete Trigger is not set/fetched");
    }

    trigger_single_frame_subscriber_ = node_->create_subscription<msg_replay_radar::msg::MsgTriggerSingleFrame>(
        TOPIC_TRIGGER_RADAR_NEXT_FRAME, 10,
        std::bind(&RadarNodeReplay::TriggerNextFrameCB, this, std::placeholders::_1));

    set_pause_mode_subscriber_ = node_->create_subscription<msg_replay_radar::msg::MsgSetPauseMode>(
        TOPIC_SET_RADAR_PAUSE_MODE, 10, std::bind(&RadarNodeReplay::SetPauseModeCB, this, std::placeholders::_1));
}

void RadarNodeReplay::InitTimers()
{
    data_publish_timer_ =
        node_->create_wall_timer(std::chrono::milliseconds(1), std::bind(&RadarNodeReplay::DataPublishTimerCB, this));
}

void RadarNodeReplay::PublishTriggerInit()
{
    auto msg = std::make_shared<msg_swc_common::msg::MsgTriggerInitType>();
    swc_midw_trigger_init_publisher_->PublishMessage(std::move(msg));
}

void RadarNodeReplay::CompletetriggerCB(msg_swc_common::msg::MsgEventType::UniquePtr msg)
{
    auto msg_ts = rclcpp::Time(msg->header.stamp).nanoseconds();
    if (msg_ts == feedback_check_ts_)
    {
        received_feedback_ = true;
    }
}

void RadarNodeReplay::TriggerNextFrameCB(msg_replay_radar::msg::MsgTriggerSingleFrame::UniquePtr msg)
{

    // Only in pause mode.
    if (pause_playback_ && received_feedback_)
    {
        int64_t next_timestamp = node_feedback_publisher_->GetNextTimestamp();
        if (next_timestamp > 0)
        {
            PublishNextFrame(next_timestamp);
        }
    }
}

void RadarNodeReplay::SetPauseModeCB(msg_replay_radar::msg::MsgSetPauseMode::UniquePtr msg)
{
    pause_playback_ = msg->pause_playback;
}

void RadarNodeReplay::AddMidwIntAllData(std::shared_ptr<msg_replay_radar::msg::MsgMidwIntAllDataType> midw_int_all_data,
                                        rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {
        rosbag_writer_->Write(midw_int_all_data.get(), ROS_PUBLISHER_TOPICS::TOPIC_RRA_DATA, timestamp);
    }
    midw_int_all_data_publisher_->AddMessage(std::move(midw_int_all_data), timestamp.nanoseconds());
}

void RadarNodeReplay::AddPointCloudForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcPointCloudListRvizType> pcl_msg,
                                           rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {
        rosbag_writer_->Write(pcl_msg.get(), ROS_PUBLISHER_TOPICS::TOPIC_RRA_POINT_CLOUD_DATA_FLOAT_LIST, timestamp);
    }
    rra_point_cloud_data_float_list_publisher_->AddMessage(std::move(pcl_msg), timestamp.nanoseconds());
}

void RadarNodeReplay::AddDetnListForRviz(std::shared_ptr<msg_replay_radar::msg::MsgRdcDetnListRvizType> detn_list,
                                         rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {
        rosbag_writer_->Write(detn_list.get(), ROS_PUBLISHER_TOPICS::TOPIC_RRA_DETECTION_DATA_LIST, timestamp);
    }
    rra_detection_data_list_publisher_->AddMessage(std::move(detn_list), timestamp.nanoseconds());
}

void RadarNodeReplay::AddDetnGetMidwDataType(
    std::shared_ptr<msg_swc_common::msg::MsgDetnGetMidWDataType> detn_get_midw_data_type, rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {
        rosbag_writer_->Write(detn_get_midw_data_type.get(), ROS_PUBLISHER_TOPICS::TOPIC_DETN_GET_MIDW_DATA, timestamp);
    }

    if (!parquet_queue_.empty())
    {
        UpdateParquet(detn_get_midw_data_type);
    }

    detn_get_midw_data_type_publisher_->AddMessage(std::move(detn_get_midw_data_type), timestamp.nanoseconds());
}

void RadarNodeReplay::AddFeedbackMessage(std::shared_ptr<msg_swc_common::msg::MsgNodeFeedbackType> feedback_msg,
                                         rclcpp::Time timestamp)
{
    node_feedback_publisher_->AddMessage(std::move(feedback_msg), timestamp.nanoseconds());
}

void RadarNodeReplay::SetEndTimestamp(int64_t timestamp)
{
    end_of_replay_ts_ = timestamp;
}

void RadarNodeReplay::AddTriggerCyclicMessage(
    std::shared_ptr<msg_swc_common::msg::MsgTriggerCyclicType> trigger_cyclic_msg, rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {
        std::string topic{""};
        if (replay_data_ == ROS_PARAM_NAMES_REPLAY_MODE::REPLAY_DATA_POST_MIDW)
        {
            topic = ROS_PUBLISHER_TOPICS::TOPIC_SWC_MERDRDATACUBEMIDW_TRIGGER_CYCLIC;
        }
        else
        {
            topic = ROS_PUBLISHER_TOPICS::TOPIC_RADAR_UHDP_SERVER_TRIGGER_CYCLIC;
        }

        rosbag_writer_->Write(trigger_cyclic_msg.get(), topic, rclcpp::Time(timestamp));
    }

    trigger_cyclic_publisher_->AddMessage(std::move(trigger_cyclic_msg), timestamp.nanoseconds());
}

void RadarNodeReplay::AddCompleteTriggerMessage(std::shared_ptr<msg_swc_common::msg::MsgEventType> complete_trigger_msg,
                                                rclcpp::Time timestamp)
{
    if (rosbag_ready_for_write_)
    {
        std::string topic{""};
        if (replay_data_ == ROS_PARAM_NAMES_REPLAY_MODE::REPLAY_DATA_POST_MIDW)
        {
            topic = ROS_PUBLISHER_TOPICS::TOPIC_SWC_MERDRDATACUBEMIDW_COMPLETETRIGGER;
        }
        else
        {
            topic = ROS_PUBLISHER_TOPICS::TOPIC_RADAR_UHDP_SERVER_COMPLETETRIGGER;
        }

        rosbag_writer_->Write(complete_trigger_msg.get(), topic, rclcpp::Time(timestamp));
    }

    completetrigger_publisher_->AddMessage(std::move(complete_trigger_msg), timestamp.nanoseconds());
}

void RadarNodeReplay::UpdateParquet(
    std::shared_ptr<msg_swc_common::msg::MsgDetnGetMidWDataType> detn_get_midw_data_type)
{
    parquet_queue_.back()->parquet_export_detn_getmidwdata(detn_get_midw_data_type.get());
}

void RadarNodeReplay::DataPublishTimerCB()
{
    static std::chrono::time_point<std::chrono::system_clock> prev_publish_system_time;
    static int64_t prev_message_timestamp = 0;
    static bool first_message{true};

    // TODO : @Anurag {Remove sleep and implement Trigger Init on a latched topic}
    if (first_message)
    {
        using namespace std::chrono_literals;
        std::this_thread::sleep_for(5000ms);
        first_message = false;
    }

    if (pause_playback_)
    {
        // Reset the prev message timestamp to continue the timepoint from now.
        prev_message_timestamp = 0;
        return;
    }

    if (!received_feedback_)
    {
        return;
    }

    int64_t next_timestamp = node_feedback_publisher_->GetNextTimestamp();

    if (next_timestamp > 0 && next_timestamp <= end_of_replay_ts_)
    {
        if (prev_message_timestamp == 0)
        {
            prev_message_timestamp = next_timestamp;
            prev_publish_system_time = std::chrono::system_clock::now();
        }

        auto time_delta = next_timestamp - prev_message_timestamp;

        if (time_delta > MAX_SLEEP_TIME_NS)
        {
            RCLCPP_INFO(node_->get_logger(),
                        "Encountered sleep time between consecutive messages greater than : %lld nanoseconds.Skipping "
                        "sleep_until.",
                        (long long)MAX_SLEEP_TIME_NS);
        }

        else
        {
            auto time_delta_ns = std::chrono::nanoseconds(time_delta);
            std::this_thread::sleep_until(prev_publish_system_time +
                                          std::chrono::duration_cast<std::chrono::nanoseconds>(time_delta_ns));
        }

        PublishNextFrame(next_timestamp);
        prev_publish_system_time = std::chrono::system_clock::now();
        prev_message_timestamp = next_timestamp;
        feedback_check_ts_ = next_timestamp;
        received_feedback_ = false;
    }

    if (next_timestamp > end_of_replay_ts_)
    {
        // Empty the extra feedback messages for parquets
        node_feedback_publisher_->PublishNextMessage();
        return;
    }
}

void RadarNodeReplay::PublishNextFrame(int64_t timestamp)
{
    // please donot change the ordering of the node_feedback_publisher_
    node_feedback_publisher_->PublishNextMessage();

    if (replay_data_ == ROS_PARAM_NAMES_REPLAY_MODE::REPLAY_DATA_POST_MIDW)
    {
        PublishNextMidWFrame();
    }
    else
    {
        rra_detection_data_list_publisher_->PublishNextMessage();
        rra_point_cloud_data_float_list_publisher_->PublishNextMessage();
        if (replay_data_ == ROS_PARAM_NAMES_REPLAY_MODE::REPLAY_DATA_PRE_MIDW)
        {
            PublishMidwAllInputData();
        }
        else
        {
            PublishNextRDC3Frame();
        }
    }

    completetrigger_publisher_->PublishNextMessage();
    trigger_cyclic_publisher_->PublishNextMessage();
}

void RadarNodeReplay::PublishNextRDC3Frame()
{
    midw_int_all_data_publisher_->PublishNextMessage();
    RCLCPP_DEBUG(node_->get_logger(), "PublishNextRDC3Frame calling");
}

void RadarNodeReplay::PublishMidwAllInputData()
{
    PublishNextRDC3Frame();
}

void RadarNodeReplay::PublishNextMidWFrame()
{
    detn_get_midw_data_type_publisher_->PublishNextMessage();
    PublishEmptyScanInfo();
}

void RadarNodeReplay::PublishEmptyScanInfo()
{
    // TODO : Anurag / Vivien. Remove ScanInfo publish when not required anymore.
    // Publishing empty message for now.
    auto scan_info = std::make_shared<msg_swc_common::msg::MsgScaninfoType>();
    scan_info->header.frame_id = node_namespace_;
    scan_info_publisher_->PublishMessage(std::move(scan_info));
}

// void RadarNodeReplay::PublishCompleteTrigger(int64_t timestamp)
// {
//     auto msg_event = std::make_shared<msg_swc_common::msg::MsgEventType>();
//     msg_event->header.stamp = rclcpp::Time(timestamp);
//     msg_event->event = true;
//     completetrigger_publisher_->PublishMessage(std::move(msg_event));
// }

void RadarNodeReplay::SetParquetExporter(std::unique_ptr<ParquetExportSkelgen> parquet_exporter)
{
    if (!parquet_queue_.empty())
    {
        parquet_queue_.back()->write_parquet_file();
        if (parquet_queue_.front()->is_parquet_file_written())
        {
            parquet_queue_.pop();
        }
    }
    parquet_queue_.push(std::move(parquet_exporter));
}

void RadarNodeReplay::CloseParquetFileHandle()
{
    if (!parquet_queue_.empty())
    {
        parquet_queue_.back()->write_parquet_file();
        if (parquet_queue_.front()->is_parquet_file_written())
        {
            parquet_queue_.pop();
        }
    }
}