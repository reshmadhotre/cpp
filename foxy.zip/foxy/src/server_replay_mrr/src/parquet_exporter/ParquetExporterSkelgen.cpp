/*
 * Copyright 2019 - 2022 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       ParquetExporterSkelgen.cpp
 * \version    3.3.0 (beta)
 * \date       Oct-31-2022 - 12:07:12
 *
 * \author     Magna Electronics Europe GmbH & Co. OHG, 
 *             63877 Sailauf, Germany
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 * Internal version: 05.37 (Build: 20221029)
 * Based on ARXML interface version: 1.0.0
 */


#include "ParquetExporterSkelgen.hpp"

#include <thread>
#include <iostream>
#include "rclcpp/rclcpp.hpp"



ParquetExportSkelgen::ParquetExportSkelgen()
{
    init_parquet_headers();
}


ParquetExportSkelgen::~ParquetExportSkelgen()
{
}

void ParquetExportSkelgen::set_filename(const std::string filename)
{
    parquet_file_name_ = filename;
}

const std::string ParquetExportSkelgen::get_file_suffix() const
{
    return filename_prefix_;
}

const std::string ParquetExportSkelgen::get_filename() const
{
	return parquet_file_name_;
}


bool ParquetExportSkelgen::is_parquet_file_written()
{
	return parquet_file_completion_flag_;
}


void ParquetExportSkelgen::set_parquet_file_completion_flag(const bool status)
{
	parquet_file_completion_flag_ = status;
}


void ParquetExportSkelgen::write_parquet_file()
{
	auto file_name = get_filename();
	auto file_suffix = get_file_suffix();
	save_to_disk(file_name, file_suffix);
	set_parquet_file_completion_flag(true);
}


void ParquetExportSkelgen::init_parquet_headers()
{
	parquet_init_detn_getmidwdata();
}


/*----------------------------------------------------------------------------*/
/*  INITIALIZE DATA FOR PARQUET                                               */
/*----------------------------------------------------------------------------*/
void ParquetExportSkelgen::parquet_init_detn_getmidwdata(void)
{
    add_message("DETN_GetMidWData", "timestamp", {{"timestamp", parquet_exporter::DataType::INT64}});

    add_signals("DETN_GetMidWData", {
        {"OneDPtr_ScanInfo_ScanSet", parquet_exporter::DataType::UINT8},
        {"OneDPtr_ScanInfo_ScanDimension", parquet_exporter::DataType::UINT8},
        {"OneDPtr_ScanInfo_EgoRdr_VX", parquet_exporter::DataType::FLOAT32},
        {"OneDPtr_ScanInfo_EgoRdr_VY", parquet_exporter::DataType::FLOAT32},
        {"OneDPtr_ScanInfo_EgoRdr_VZ", parquet_exporter::DataType::FLOAT32},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VX", parquet_exporter::DataType::FLOAT32},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VY", parquet_exporter::DataType::FLOAT32},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VZ", parquet_exporter::DataType::FLOAT32},
        {"OneDPtr_ClusterData_NumClusters", parquet_exporter::DataType::UINT16},
        {"OneDPtr_ClusterData_NumExpandedClusters", parquet_exporter::DataType::UINT16},
        {"TwoDPtr_ScanInfo_ScanSet", parquet_exporter::DataType::UINT8},
        {"TwoDPtr_ScanInfo_ScanDimension", parquet_exporter::DataType::UINT8},
        {"TwoDPtr_ScanInfo_EgoRdr_VX", parquet_exporter::DataType::FLOAT32},
        {"TwoDPtr_ScanInfo_EgoRdr_VY", parquet_exporter::DataType::FLOAT32},
        {"TwoDPtr_ScanInfo_EgoRdr_VZ", parquet_exporter::DataType::FLOAT32},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VX", parquet_exporter::DataType::FLOAT32},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VY", parquet_exporter::DataType::FLOAT32},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VZ", parquet_exporter::DataType::FLOAT32},
        {"TwoDPtr_ClusterData_NumClusters", parquet_exporter::DataType::UINT16},
        {"TwoDPtr_ClusterData_NumExpandedClusters", parquet_exporter::DataType::UINT16}
    });

    for(uint i=0 ; i<2 ; i++)
    {
        add_signals("DETN_GetMidWData", {
            {"OneDPtr_ScanInfo_ScanSequenceNumbers", parquet_exporter::DataType::UINT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanInfo_ScanTimestamps", parquet_exporter::DataType::UINT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_StaticDetns_NumElemPerScan", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_DynamicDetns_NumElemPerScan", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_PointCloudList_NumElemPerScan", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_ScanTime", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_PulseTime", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_ChipTime", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_DopplerBinWidth", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_RangeBinWidth", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_PulsesPerScan", parquet_exporter::DataType::INT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_ChipsPerPulse", parquet_exporter::DataType::INT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_CodeType", parquet_exporter::DataType::INT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_NumRangeBins", parquet_exporter::DataType::INT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_NumAzimuthBins", parquet_exporter::DataType::INT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_NumElevationBins", parquet_exporter::DataType::INT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_NumVRXUsed", parquet_exporter::DataType::INT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_WrapAzimuthAngles", parquet_exporter::DataType::BOOL, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_WrapElevationAngles", parquet_exporter::DataType::BOOL, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_ScanLambda", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_FirstRangeBin", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_AzimuthSineBinSize", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_AzimuthSineZeroLocation", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_ElevationSineBinSize", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ScanParams_ElevationSineZeroLocation", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanInfo_ScanSequenceNumbers", parquet_exporter::DataType::UINT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanInfo_ScanTimestamps", parquet_exporter::DataType::UINT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_StaticDetns_NumElemPerScan", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_DynamicDetns_NumElemPerScan", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_PointCloudList_NumElemPerScan", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_ScanTime", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_PulseTime", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_ChipTime", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_DopplerBinWidth", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_RangeBinWidth", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_PulsesPerScan", parquet_exporter::DataType::INT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_ChipsPerPulse", parquet_exporter::DataType::INT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_CodeType", parquet_exporter::DataType::INT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_NumRangeBins", parquet_exporter::DataType::INT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_NumAzimuthBins", parquet_exporter::DataType::INT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_NumElevationBins", parquet_exporter::DataType::INT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_NumVRXUsed", parquet_exporter::DataType::INT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_WrapAzimuthAngles", parquet_exporter::DataType::BOOL, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_WrapElevationAngles", parquet_exporter::DataType::BOOL, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_ScanLambda", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_FirstRangeBin", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_AzimuthSineBinSize", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_AzimuthSineZeroLocation", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_ElevationSineBinSize", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ScanParams_ElevationSineZeroLocation", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST}
        });
    }

    for(uint i=0 ; i<512 ; i++)
    {
        add_signals("DETN_GetMidWData", {
            {"OneDPtr_DetectionList_StaticDetns_CoorPolar_Range", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_StaticDetns_CoorPolar_Azimuth", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_StaticDetns_CoorPolar_Elevation", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_StaticDetns_Doppler", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_StaticDetns_Magnitude", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_StaticDetns_SigToNoiseRat", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_StaticDetns_RdrCrossSectn", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_StaticDetns_Flags", parquet_exporter::DataType::UINT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_DynamicDetns_CoorPolar_Range", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_DynamicDetns_CoorPolar_Azimuth", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_DynamicDetns_CoorPolar_Elevation", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_DynamicDetns_Doppler", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_DynamicDetns_Magnitude", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_DynamicDetns_SigToNoiseRat", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_DynamicDetns_RdrCrossSectn", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_DetectionList_DynamicDetns_Flags", parquet_exporter::DataType::UINT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_StaticDetns_CoorPolar_Range", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_StaticDetns_CoorPolar_Azimuth", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_StaticDetns_CoorPolar_Elevation", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_StaticDetns_Doppler", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_StaticDetns_Magnitude", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_StaticDetns_SigToNoiseRat", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_StaticDetns_RdrCrossSectn", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_StaticDetns_Flags", parquet_exporter::DataType::UINT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Range", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Azimuth", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Elevation", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_DynamicDetns_Doppler", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_DynamicDetns_Magnitude", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_DynamicDetns_SigToNoiseRat", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_DynamicDetns_RdrCrossSectn", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_DetectionList_DynamicDetns_Flags", parquet_exporter::DataType::UINT32, parquet_exporter::ValueType::LIST}
        });
    }

    for(uint i=0 ; i<2048 ; i++)
    {
        add_signals("DETN_GetMidWData", {
            {"OneDPtr_PointCloudList_range_" ,    parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_PointCloudList_azimuth_" ,  parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_PointCloudList_elevation_", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_PointCloudList_doppler_" ,  parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_PointCloudList_snr_dB_" ,   parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_PointCloudList_flags_" ,    parquet_exporter::DataType::UINT32,  parquet_exporter::ValueType::LIST},
	        {"OneDPtr_PointCloudList_mag_i_" ,    parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_PointCloudList_mag_q_" ,    parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_PointCloudList_rcs_" ,      parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ClusterData_Indices_" ,     parquet_exporter::DataType::UINT16,  parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ClusterData_ClusterIDs_" ,  parquet_exporter::DataType::UINT16,  parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_PointCloudList_range_" ,    parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_PointCloudList_azimuth_" ,  parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_PointCloudList_elevation_", parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_PointCloudList_doppler_" ,  parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_PointCloudList_snr_dB_" ,   parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_PointCloudList_flags_" ,    parquet_exporter::DataType::UINT32,  parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_PointCloudList_mag_i_" ,    parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_PointCloudList_mag_q_" ,    parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_PointCloudList_rcs_" ,      parquet_exporter::DataType::FLOAT32, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ClusterData_Indices_" ,     parquet_exporter::DataType::UINT16,  parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ClusterData_ClusterIDs_" ,  parquet_exporter::DataType::UINT16,  parquet_exporter::ValueType::LIST}
        });
    }

    for(uint i=0 ; i<128 ; i++)
    {
        add_signals("DETN_GetMidWData", {
            {"OneDPtr_ClusterData_ClusterInfo_maxSNRIndx", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ClusterData_ClusterInfo_ClusterSize", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ClusterData_ClusterInfo_MinRangeIndx", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"OneDPtr_ClusterData_ClusterInfo_StartingPointIndx", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ClusterData_ClusterInfo_maxSNRIndx", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ClusterData_ClusterInfo_ClusterSize", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ClusterData_ClusterInfo_MinRangeIndx", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
	        {"TwoDPtr_ClusterData_ClusterInfo_StartingPointIndx", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST}
        });
    }
}


/*----------------------------------------------------------------------------*/
/*  WRITE DATA INTO PARQUET                                                   */
/*----------------------------------------------------------------------------*/
void ParquetExportSkelgen::parquet_export_detn_getmidwdata(
    msg_swc_common::msg::MsgDetnGetMidWDataType *msg)
{
    append_values("DETN_GetMidWData", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"OneDPtr_ScanInfo_ScanSet", msg->one_d_ptr.scan_info.scan_set},
        {"OneDPtr_ScanInfo_ScanDimension", msg->one_d_ptr.scan_info.scan_dimension},
        {"OneDPtr_ScanInfo_EgoRdr_VX", msg->one_d_ptr.scan_info.ego_rdr.vx},
        {"OneDPtr_ScanInfo_EgoRdr_VY", msg->one_d_ptr.scan_info.ego_rdr.vy},
        {"OneDPtr_ScanInfo_EgoRdr_VZ", msg->one_d_ptr.scan_info.ego_rdr.vz},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VX", msg->one_d_ptr.scan_info.ego_rdr_estimd.vx},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VY", msg->one_d_ptr.scan_info.ego_rdr_estimd.vy},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VZ", msg->one_d_ptr.scan_info.ego_rdr_estimd.vz},
        {"OneDPtr_ClusterData_NumClusters", msg->one_d_ptr.cluster_data.num_clusters},
        {"OneDPtr_ClusterData_NumExpandedClusters", msg->one_d_ptr.cluster_data.num_expanded_clusters},
        {"TwoDPtr_ScanInfo_ScanSet", msg->two_d_ptr.scan_info.scan_set},
        {"TwoDPtr_ScanInfo_ScanDimension", msg->two_d_ptr.scan_info.scan_dimension},
        {"TwoDPtr_ScanInfo_EgoRdr_VX", msg->two_d_ptr.scan_info.ego_rdr.vx},
        {"TwoDPtr_ScanInfo_EgoRdr_VY", msg->two_d_ptr.scan_info.ego_rdr.vy},
        {"TwoDPtr_ScanInfo_EgoRdr_VZ", msg->two_d_ptr.scan_info.ego_rdr.vz},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VX", msg->two_d_ptr.scan_info.ego_rdr_estimd.vx},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VY", msg->two_d_ptr.scan_info.ego_rdr_estimd.vy},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VZ", msg->two_d_ptr.scan_info.ego_rdr_estimd.vz},
        {"TwoDPtr_ClusterData_NumClusters", msg->two_d_ptr.cluster_data.num_clusters},
        {"TwoDPtr_ClusterData_NumExpandedClusters", msg->two_d_ptr.cluster_data.num_expanded_clusters}
    });
	
	parquet_exporter::SignalValuesListType list_signal_values;
    for(uint i=0 ; i<2 ; i++)
    {
        list_signal_values["OneDPtr_ScanInfo_ScanSequenceNumbers"].push_back(msg->one_d_ptr.scan_info.scan_sequence_numbers[i]);
	    list_signal_values["OneDPtr_ScanInfo_ScanTimestamps"].push_back(msg->one_d_ptr.scan_info.scan_timestamps[i]);
	    list_signal_values["OneDPtr_DetectionList_StaticDetns_NumElemPerScan"].push_back(msg->one_d_ptr.detection_list.static_detns.num_elem_per_scan[i]);
	    list_signal_values["OneDPtr_DetectionList_DynamicDetns_NumElemPerScan"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.num_elem_per_scan[i]);
	    list_signal_values["OneDPtr_PointCloudList_NumElemPerScan"].push_back(msg->one_d_ptr.point_cloud_list.num_elem_per_scan[i]);
	    list_signal_values["OneDPtr_ScanParams_ScanTime"].push_back(msg->one_d_ptr.scan_params[i].scan_time);
	    list_signal_values["OneDPtr_ScanParams_PulseTime"].push_back(msg->one_d_ptr.scan_params[i].pulse_time);
	    list_signal_values["OneDPtr_ScanParams_ChipTime"].push_back(msg->one_d_ptr.scan_params[i].chip_time);
	    list_signal_values["OneDPtr_ScanParams_DopplerBinWidth"].push_back(msg->one_d_ptr.scan_params[i].doppler_bin_width);
	    list_signal_values["OneDPtr_ScanParams_RangeBinWidth"].push_back(msg->one_d_ptr.scan_params[i].range_bin_width);
	    list_signal_values["OneDPtr_ScanParams_PulsesPerScan"].push_back(msg->one_d_ptr.scan_params[i].pulses_per_scan);
	    list_signal_values["OneDPtr_ScanParams_ChipsPerPulse"].push_back(msg->one_d_ptr.scan_params[i].chips_per_pulse);
	    list_signal_values["OneDPtr_ScanParams_CodeType"].push_back(msg->one_d_ptr.scan_params[i].code_type);
	    list_signal_values["OneDPtr_ScanParams_NumRangeBins"].push_back(msg->one_d_ptr.scan_params[i].num_range_bins);
	    list_signal_values["OneDPtr_ScanParams_NumAzimuthBins"].push_back(msg->one_d_ptr.scan_params[i].num_azimuth_bins);
	    list_signal_values["OneDPtr_ScanParams_NumElevationBins"].push_back(msg->one_d_ptr.scan_params[i].num_elevation_bins);
	    list_signal_values["OneDPtr_ScanParams_NumVRXUsed"].push_back(msg->one_d_ptr.scan_params[i].num_vrx_used);
	    list_signal_values["OneDPtr_ScanParams_WrapAzimuthAngles"].push_back(msg->one_d_ptr.scan_params[i].wrap_azimuth_angles);
	    list_signal_values["OneDPtr_ScanParams_WrapElevationAngles"].push_back(msg->one_d_ptr.scan_params[i].wrap_elevation_angles);
	    list_signal_values["OneDPtr_ScanParams_ScanLambda"].push_back(msg->one_d_ptr.scan_params[i].scan_lambda);
	    list_signal_values["OneDPtr_ScanParams_FirstRangeBin"].push_back(msg->one_d_ptr.scan_params[i].first_range_bin);
	    list_signal_values["OneDPtr_ScanParams_AzimuthSineBinSize"].push_back(msg->one_d_ptr.scan_params[i].azimuth_sine_bin_size);
	    list_signal_values["OneDPtr_ScanParams_AzimuthSineZeroLocation"].push_back(msg->one_d_ptr.scan_params[i].azimuth_sine_zero_location);
	    list_signal_values["OneDPtr_ScanParams_ElevationSineBinSize"].push_back(msg->one_d_ptr.scan_params[i].elevation_sine_bin_size);
	    list_signal_values["OneDPtr_ScanParams_ElevationSineZeroLocation"].push_back(msg->one_d_ptr.scan_params[i].elevation_sine_zero_location);
	    list_signal_values["TwoDPtr_ScanInfo_ScanSequenceNumbers"].push_back(msg->two_d_ptr.scan_info.scan_sequence_numbers[i]);
	    list_signal_values["TwoDPtr_ScanInfo_ScanTimestamps"].push_back(msg->two_d_ptr.scan_info.scan_timestamps[i]);
	    list_signal_values["TwoDPtr_DetectionList_StaticDetns_NumElemPerScan"].push_back(msg->two_d_ptr.detection_list.static_detns.num_elem_per_scan[i]);
	    list_signal_values["TwoDPtr_DetectionList_DynamicDetns_NumElemPerScan"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.num_elem_per_scan[i]);
	    list_signal_values["TwoDPtr_PointCloudList_NumElemPerScan"].push_back(msg->two_d_ptr.point_cloud_list.num_elem_per_scan[i]);
	    list_signal_values["TwoDPtr_ScanParams_ScanTime"].push_back(msg->two_d_ptr.scan_params[i].scan_time);
	    list_signal_values["TwoDPtr_ScanParams_PulseTime"].push_back(msg->two_d_ptr.scan_params[i].pulse_time);
	    list_signal_values["TwoDPtr_ScanParams_ChipTime"].push_back(msg->two_d_ptr.scan_params[i].chip_time);
	    list_signal_values["TwoDPtr_ScanParams_DopplerBinWidth"].push_back(msg->two_d_ptr.scan_params[i].doppler_bin_width);
	    list_signal_values["TwoDPtr_ScanParams_RangeBinWidth"].push_back(msg->two_d_ptr.scan_params[i].range_bin_width);
	    list_signal_values["TwoDPtr_ScanParams_PulsesPerScan"].push_back(msg->two_d_ptr.scan_params[i].pulses_per_scan);
	    list_signal_values["TwoDPtr_ScanParams_ChipsPerPulse"].push_back(msg->two_d_ptr.scan_params[i].chips_per_pulse);
	    list_signal_values["TwoDPtr_ScanParams_CodeType"].push_back(msg->two_d_ptr.scan_params[i].code_type);
	    list_signal_values["TwoDPtr_ScanParams_NumRangeBins"].push_back(msg->two_d_ptr.scan_params[i].num_range_bins);
	    list_signal_values["TwoDPtr_ScanParams_NumAzimuthBins"].push_back(msg->two_d_ptr.scan_params[i].num_azimuth_bins);
	    list_signal_values["TwoDPtr_ScanParams_NumElevationBins"].push_back(msg->two_d_ptr.scan_params[i].num_elevation_bins);
	    list_signal_values["TwoDPtr_ScanParams_NumVRXUsed"].push_back(msg->two_d_ptr.scan_params[i].num_vrx_used);
	    list_signal_values["TwoDPtr_ScanParams_WrapAzimuthAngles"].push_back(msg->two_d_ptr.scan_params[i].wrap_azimuth_angles);
	    list_signal_values["TwoDPtr_ScanParams_WrapElevationAngles"].push_back(msg->two_d_ptr.scan_params[i].wrap_elevation_angles);
	    list_signal_values["TwoDPtr_ScanParams_ScanLambda"].push_back(msg->two_d_ptr.scan_params[i].scan_lambda);
	    list_signal_values["TwoDPtr_ScanParams_FirstRangeBin"].push_back(msg->two_d_ptr.scan_params[i].first_range_bin);
	    list_signal_values["TwoDPtr_ScanParams_AzimuthSineBinSize"].push_back(msg->two_d_ptr.scan_params[i].azimuth_sine_bin_size);
	    list_signal_values["TwoDPtr_ScanParams_AzimuthSineZeroLocation"].push_back(msg->two_d_ptr.scan_params[i].azimuth_sine_zero_location);
	    list_signal_values["TwoDPtr_ScanParams_ElevationSineBinSize"].push_back(msg->two_d_ptr.scan_params[i].elevation_sine_bin_size);
	    list_signal_values["TwoDPtr_ScanParams_ElevationSineZeroLocation"].push_back(msg->two_d_ptr.scan_params[i].elevation_sine_zero_location);
    }
	append_values("DETN_GetMidWData", list_signal_values);
	list_signal_values.clear();

    for(uint i=0 ; i<512 ; i++)
    {
        list_signal_values["OneDPtr_DetectionList_StaticDetns_CoorPolar_Range"].push_back(msg->one_d_ptr.detection_list.static_detns.coor_polar[i].range);
	    list_signal_values["OneDPtr_DetectionList_StaticDetns_CoorPolar_Azimuth"].push_back(msg->one_d_ptr.detection_list.static_detns.coor_polar[i].azimuth);
	    list_signal_values["OneDPtr_DetectionList_StaticDetns_CoorPolar_Elevation"].push_back(msg->one_d_ptr.detection_list.static_detns.coor_polar[i].elevation);
	    list_signal_values["OneDPtr_DetectionList_StaticDetns_Doppler"].push_back(msg->one_d_ptr.detection_list.static_detns.doppler[i]);
	    list_signal_values["OneDPtr_DetectionList_StaticDetns_Magnitude"].push_back(msg->one_d_ptr.detection_list.static_detns.magnitude[i]);
	    list_signal_values["OneDPtr_DetectionList_StaticDetns_SigToNoiseRat"].push_back(msg->one_d_ptr.detection_list.static_detns.sig_to_noise_rat[i]);
	    list_signal_values["OneDPtr_DetectionList_StaticDetns_RdrCrossSectn"].push_back(msg->one_d_ptr.detection_list.static_detns.rdr_cross_sectn[i]);
	    list_signal_values["OneDPtr_DetectionList_StaticDetns_Flags"].push_back(msg->one_d_ptr.detection_list.static_detns.flags[i]);
	    list_signal_values["OneDPtr_DetectionList_DynamicDetns_CoorPolar_Range"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.coor_polar[i].range);
	    list_signal_values["OneDPtr_DetectionList_DynamicDetns_CoorPolar_Azimuth"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.coor_polar[i].azimuth);
	    list_signal_values["OneDPtr_DetectionList_DynamicDetns_CoorPolar_Elevation"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.coor_polar[i].elevation);
	    list_signal_values["OneDPtr_DetectionList_DynamicDetns_Doppler"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.doppler[i]);
	    list_signal_values["OneDPtr_DetectionList_DynamicDetns_Magnitude"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.magnitude[i]);
	    list_signal_values["OneDPtr_DetectionList_DynamicDetns_SigToNoiseRat"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.sig_to_noise_rat[i]);
	    list_signal_values["OneDPtr_DetectionList_DynamicDetns_RdrCrossSectn"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.rdr_cross_sectn[i]);
	    list_signal_values["OneDPtr_DetectionList_DynamicDetns_Flags"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.flags[i]);
	    list_signal_values["TwoDPtr_DetectionList_StaticDetns_CoorPolar_Range"].push_back(msg->two_d_ptr.detection_list.static_detns.coor_polar[i].range);
	    list_signal_values["TwoDPtr_DetectionList_StaticDetns_CoorPolar_Azimuth"].push_back(msg->two_d_ptr.detection_list.static_detns.coor_polar[i].azimuth);
	    list_signal_values["TwoDPtr_DetectionList_StaticDetns_CoorPolar_Elevation"].push_back(msg->two_d_ptr.detection_list.static_detns.coor_polar[i].elevation);
	    list_signal_values["TwoDPtr_DetectionList_StaticDetns_Doppler"].push_back(msg->two_d_ptr.detection_list.static_detns.doppler[i]);
	    list_signal_values["TwoDPtr_DetectionList_StaticDetns_Magnitude"].push_back(msg->two_d_ptr.detection_list.static_detns.magnitude[i]);
	    list_signal_values["TwoDPtr_DetectionList_StaticDetns_SigToNoiseRat"].push_back(msg->two_d_ptr.detection_list.static_detns.sig_to_noise_rat[i]);
	    list_signal_values["TwoDPtr_DetectionList_StaticDetns_RdrCrossSectn"].push_back(msg->two_d_ptr.detection_list.static_detns.rdr_cross_sectn[i]);
	    list_signal_values["TwoDPtr_DetectionList_StaticDetns_Flags"].push_back(msg->two_d_ptr.detection_list.static_detns.flags[i]);
	    list_signal_values["TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Range"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.coor_polar[i].range);
	    list_signal_values["TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Azimuth"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.coor_polar[i].azimuth);
	    list_signal_values["TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Elevation"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.coor_polar[i].elevation);
	    list_signal_values["TwoDPtr_DetectionList_DynamicDetns_Doppler"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.doppler[i]);
	    list_signal_values["TwoDPtr_DetectionList_DynamicDetns_Magnitude"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.magnitude[i]);
	    list_signal_values["TwoDPtr_DetectionList_DynamicDetns_SigToNoiseRat"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.sig_to_noise_rat[i]);
	    list_signal_values["TwoDPtr_DetectionList_DynamicDetns_RdrCrossSectn"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.rdr_cross_sectn[i]);
	    list_signal_values["TwoDPtr_DetectionList_DynamicDetns_Flags"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.flags[i]);
    }

	append_values("DETN_GetMidWData", list_signal_values);
	list_signal_values.clear();

    for(uint i=0 ; i<2048 ; i++)
    {
        list_signal_values["OneDPtr_PointCloudList_range_"].push_back(msg->one_d_ptr.point_cloud_list.range[i]);
	    list_signal_values["OneDPtr_PointCloudList_azimuth_"].push_back(msg->one_d_ptr.point_cloud_list.azimuth[i]);
	    list_signal_values["OneDPtr_PointCloudList_elevation_"].push_back(msg->one_d_ptr.point_cloud_list.elevation[i]);
	    list_signal_values["OneDPtr_PointCloudList_doppler_"].push_back(msg->one_d_ptr.point_cloud_list.doppler[i]);
	    list_signal_values["OneDPtr_PointCloudList_snr_dB_"].push_back(msg->one_d_ptr.point_cloud_list.snrd_b[i]);
	    list_signal_values["OneDPtr_PointCloudList_flags_"].push_back(msg->one_d_ptr.point_cloud_list.flags[i]);
	    list_signal_values["OneDPtr_PointCloudList_mag_i_"].push_back(msg->one_d_ptr.point_cloud_list.magi[i]);
	    list_signal_values["OneDPtr_PointCloudList_mag_q_"].push_back(msg->one_d_ptr.point_cloud_list.magq[i]);
	    list_signal_values["OneDPtr_PointCloudList_rcs_"].push_back(msg->one_d_ptr.point_cloud_list.rcs[i]);
	    list_signal_values["OneDPtr_ClusterData_Indices_"].push_back(msg->one_d_ptr.cluster_data.indices[i]);
	    list_signal_values["OneDPtr_ClusterData_ClusterIDs_"].push_back(msg->one_d_ptr.cluster_data.cluster_i_ds[i]);
	    list_signal_values["TwoDPtr_PointCloudList_range_"].push_back(msg->two_d_ptr.point_cloud_list.range[i]);
	    list_signal_values["TwoDPtr_PointCloudList_azimuth_"].push_back(msg->two_d_ptr.point_cloud_list.azimuth[i]);
	    list_signal_values["TwoDPtr_PointCloudList_elevation_"].push_back(msg->two_d_ptr.point_cloud_list.elevation[i]);
	    list_signal_values["TwoDPtr_PointCloudList_doppler_"].push_back(msg->two_d_ptr.point_cloud_list.doppler[i]);
	    list_signal_values["TwoDPtr_PointCloudList_snr_dB_"].push_back(msg->two_d_ptr.point_cloud_list.snrd_b[i]);
	    list_signal_values["TwoDPtr_PointCloudList_flags_"].push_back(msg->two_d_ptr.point_cloud_list.flags[i]);
	    list_signal_values["TwoDPtr_PointCloudList_mag_i_"].push_back(msg->two_d_ptr.point_cloud_list.magi[i]);
	    list_signal_values["TwoDPtr_PointCloudList_mag_q_"].push_back(msg->two_d_ptr.point_cloud_list.magq[i]);
	    list_signal_values["TwoDPtr_PointCloudList_rcs_"].push_back(msg->two_d_ptr.point_cloud_list.rcs[i]);
	    list_signal_values["TwoDPtr_ClusterData_Indices_"].push_back(msg->two_d_ptr.cluster_data.indices[i]);
	    list_signal_values["TwoDPtr_ClusterData_ClusterIDs_"].push_back(msg->two_d_ptr.cluster_data.cluster_i_ds[i]);
    }

	append_values("DETN_GetMidWData", list_signal_values);
	list_signal_values.clear();

    for(uint i=0 ; i<128 ; i++)
    {
            list_signal_values["OneDPtr_ClusterData_ClusterInfo_maxSNRIndx"].push_back(msg->one_d_ptr.cluster_data.cluster_info[i].max_snr_indx);
	        list_signal_values["OneDPtr_ClusterData_ClusterInfo_ClusterSize"].push_back(msg->one_d_ptr.cluster_data.cluster_info[i].cluster_size);
	        list_signal_values["OneDPtr_ClusterData_ClusterInfo_MinRangeIndx"].push_back(msg->one_d_ptr.cluster_data.cluster_info[i].min_range_indx);
	        list_signal_values["OneDPtr_ClusterData_ClusterInfo_StartingPointIndx"].push_back(msg->one_d_ptr.cluster_data.cluster_info[i].starting_point_indx);
	        list_signal_values["TwoDPtr_ClusterData_ClusterInfo_maxSNRIndx"].push_back(msg->two_d_ptr.cluster_data.cluster_info[i].max_snr_indx);
	        list_signal_values["TwoDPtr_ClusterData_ClusterInfo_ClusterSize"].push_back(msg->two_d_ptr.cluster_data.cluster_info[i].cluster_size);
	        list_signal_values["TwoDPtr_ClusterData_ClusterInfo_MinRangeIndx"].push_back(msg->two_d_ptr.cluster_data.cluster_info[i].min_range_indx);
	        list_signal_values["TwoDPtr_ClusterData_ClusterInfo_StartingPointIndx"].push_back(msg->two_d_ptr.cluster_data.cluster_info[i].starting_point_indx);
    }

	append_values("DETN_GetMidWData", list_signal_values);
	list_signal_values.clear();
}


void ParquetExportSkelgen::write_parquet()
{
    std::thread thrd(std::bind(&ParquetExportSkelgen::write_parquet_file, this));
    thrd.detach();
}
