//
//  \file main
//
//  \author Magna Electronics Europe GmbH & Co. OHG,
//          63877 Sailauf, Germany
//
//  Copyright 2019 - 2021 Magna Electronics Europe GmbH & Co.OHG
//  All rights exclusively reserved for Magna Electronics Europe GmbH& Co.OHG,
//  unless expressly agreed to otherwise.

#include "TfFramesTransformUtil.h"
#include "rclcpp/rclcpp.hpp"

#include "RadarAdapterReplay.h"
#include "RadarNodeReplay.h"

#include <csignal>

std::shared_ptr<RadarAdapterReplay> radar_replay_adapter;

void sigint_handler(int sig_num)
{
    if (radar_replay_adapter != nullptr)
    {
        radar_replay_adapter->CloseFileHandles();
    }
    rclcpp::shutdown();

    exit(sig_num);
}
int main(int argc, char* argv[])
{
    std::signal(SIGINT, sigint_handler);
    rclcpp::InitOptions options = rclcpp::InitOptions();
    options.shutdown_on_sigint = false;
    rclcpp::init(argc, argv, options);
    auto node = std::make_shared<rclcpp::Node>("radar_uhdp_server_node");

    auto radar_replay_server_node = std::make_shared<RadarNodeReplay>(node);

    radar_replay_adapter = std::make_shared<RadarAdapterReplay>(node);

    radar_replay_adapter->SetRadarNode(radar_replay_server_node);

    radar_replay_adapter->StartReaderThread();
    rclcpp::spin(node);
    radar_replay_adapter->StopReaderThread();
    radar_replay_adapter->CloseFileHandles();
    rclcpp::shutdown();
    return 0;
}
