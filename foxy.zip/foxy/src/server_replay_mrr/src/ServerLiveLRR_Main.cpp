#include "RadarAdapterLRRLive.h"
#include "RadarNodeLRRLive.h"
#include "rclcpp/rclcpp.hpp"
#include <csignal>

std::shared_ptr<RadarAdapterLRRLive> radar_adapter_lrr;

void sigint_handler(int sig_num)
{
    if (radar_adapter_lrr != nullptr)
    {
        radar_adapter_lrr->Stop();
    }
    rclcpp::shutdown();
    exit(sig_num);
}

int main(int argc, char* argv[])
{
    std::signal(SIGINT, sigint_handler);
    rclcpp::InitOptions options = rclcpp::InitOptions();
    options.shutdown_on_sigint = false;
    rclcpp::init(argc, argv, options);

    auto node = std::make_shared<rclcpp::Node>("radar_uhdp_server_lrr_live");
    auto lrr_node = std::make_shared<RadarNodeLRRLive>(node);

    radar_adapter_lrr = std::make_shared<RadarAdapterLRRLive>(node);
    radar_adapter_lrr->SetRadarNode(lrr_node);

    if (radar_adapter_lrr->Connect())
    {
        if (radar_adapter_lrr->SetupRadar())
        {
            radar_adapter_lrr->Start();
        }
    }

    while (rclcpp::ok())
    {
        rclcpp::spin_some(node);
        if (radar_adapter_lrr->Receive())
        {
            radar_adapter_lrr->ProcessScanObjectList();
        }
    }
    radar_adapter_lrr->Stop();
    rclcpp::shutdown();
    return 0;
}