#include "lrr_free_space_visual.h"

namespace rviz_plugin_server_uhdp_lrr
{
LRRFreeSpaceVisual::LRRFreeSpaceVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node, float length,
                                       float free_space_width)
{
    scene_manager_ = scene_manager;
    frame_node_ = parent_node->createChildSceneNode();

    range_label_pivot_ =
        std::make_shared<rviz_rendering::Shape>(rviz_rendering::Shape::Sphere, scene_manager_, frame_node_);
    range_label_pivot_->setScale(Ogre::Vector3(0.05, 0.05, 0.05));
    range_label_pivot_->setPosition(Ogre::Vector3(3.0, -20.0, 0.0));

    free_space_shape_.reset(new rviz_rendering::Shape(rviz_rendering::Shape::Cube, scene_manager_, frame_node_));
    free_space_shape_->setColor(0, 255, 0, 0.5); // Green
    setFreeSpaceShapeScale(length, free_space_width, 0.0);
    updateRangeLabel(length);
}

LRRFreeSpaceVisual::~LRRFreeSpaceVisual()
{
    free_space_shape_.reset();
    range_label_pivot_.reset();
    range_label_.reset();
}

void LRRFreeSpaceVisual::setFramePosition(const Ogre::Vector3& position)
{
    frame_node_->setPosition(position);
}

void LRRFreeSpaceVisual::setFrameOrientation(const Ogre::Quaternion& orientation)
{
    frame_node_->setOrientation(orientation);
}

void LRRFreeSpaceVisual::setFreeSpaceShapeScale(float length, float width, float height)
{
    if (free_space_shape_)
    {
        Ogre::Vector3 scale(length, width, height);
        free_space_shape_->setScale(scale);

        Ogre::Vector3 position;
        position[0] = length / 2.0;
        position[1] = 0.0;
        position[2] = 0.0;

        free_space_shape_->setPosition(position);

        if (length == FREE_SPACE_LENGTH_MAX)
        {
            free_space_shape_->setColor(255, 255, 255, 0.5); // Green
        }
        else
        {
            free_space_shape_->setColor(0, 255, 0, 0.5); // Green
        }

        updateRangeLabel(length);
    }
}

void LRRFreeSpaceVisual::updateRangeLabel(float range)
{
    // std::string range_str = std::to_string(range);
    // range_str = range_str.substr(0, range_str.find(".") + 3);
    // std::string text = "Range : " + range_str + " m";
    std::stringstream stream;
    stream << "Range : " << std::fixed << std::setprecision(3) << range << " m";
    range_label_.reset();
    range_label_ =
        std::make_shared<rviz_rendering::MovableText>(stream.str(), "Liberation Sans", range_label_text_size_);
    range_label_->setTextAlignment(rviz_rendering::MovableText::H_CENTER, rviz_rendering::MovableText::V_CENTER);
    range_label_pivot_->getRootNode()->attachObject(range_label_.get());
}

bool LRRFreeSpaceVisual::isDetectionInFreeSpaceROI(const server_replay_lrr::msg::MsgDetectionUhdp& detection,
                                                   float free_space_width)
{
    const float& range = detection.range;
    const float& azimuth = detection.azimuth;
    float pos_y = range * sin(azimuth);

    return (pos_y >= -free_space_width / 2.0 && pos_y <= free_space_width / 2.0);
}
} // namespace rviz_plugin_server_uhdp_lrr