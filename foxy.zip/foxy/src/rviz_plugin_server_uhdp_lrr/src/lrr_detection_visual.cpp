#include "lrr_detection_visual.hpp"
#include "rclcpp/rclcpp.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>
#include <OgreVector3.h>
#include <iostream>
namespace rviz_plugin_server_uhdp_lrr
{

const float LRRDetectionVisual::DETECTION_SPHERE_RADIUS = 0.5;
const Ogre::ColourValue LRRDetectionVisual::STATIC_DETECTION_COLOUR_VALUE_YELLOW =
    Ogre::ColourValue(1.0f, 1.0f, 0.0f, 0.7f);
const Ogre::ColourValue LRRDetectionVisual::DYNAMIC_DETECTION_COLOUR_VALUE_GREEN =
    Ogre::ColourValue(0.0f, 1.0f, 0.0f, 0.7f);
const rviz_rendering::Shape::Type LRRDetectionVisual::STATIC_DETECTION_SHAPE_TYPE = rviz_rendering::Shape::Cube;
const rviz_rendering::Shape::Type LRRDetectionVisual::DYNAMIC_DETECTION_SHAPE_TYPE = rviz_rendering::Shape::Sphere;

LRRDetectionVisual::LRRDetectionVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node,
                                       LRRDetectionVisual::DetectionType_E detection_type)
{
    scene_manager_ = scene_manager;

    frame_node_ = parent_node->createChildSceneNode();

    if (detection_type == LRRDetectionVisual::DetectionType_E::STATIC)
    {
        detection_shape_.reset(new rviz_rendering::Shape(STATIC_DETECTION_SHAPE_TYPE, scene_manager_, frame_node_));
        detection_shape_->setColor(STATIC_DETECTION_COLOUR_VALUE_YELLOW);
    }

    else
    {
        detection_shape_.reset(new rviz_rendering::Shape(DYNAMIC_DETECTION_SHAPE_TYPE, scene_manager_, frame_node_));
        detection_shape_->setColor(DYNAMIC_DETECTION_COLOUR_VALUE_GREEN);
    }

    Ogre::Vector3 scale(DETECTION_SPHERE_RADIUS, DETECTION_SPHERE_RADIUS, 0.0f);
    detection_shape_->setScale(scale);
}

LRRDetectionVisual::~LRRDetectionVisual()
{
    scene_manager_->destroySceneNode(frame_node_);
}

void LRRDetectionVisual::setMessage(const server_replay_lrr::msg::MsgDetectionUhdp& detection)
{

    Ogre::Vector3 cartersian_position = getROSCartesianCoordinates(detection);
    detection_shape_->setPosition(cartersian_position);
}

void LRRDetectionVisual::setFramePosition(const Ogre::Vector3& position)
{
    frame_node_->setPosition(position);
}

void LRRDetectionVisual::setFrameOrientation(const Ogre::Quaternion& orientation)
{
    frame_node_->setOrientation(orientation);
}

void LRRDetectionVisual::setColor(float r, float g, float b, float a)
{
    detection_shape_->setColor(r, g, b, a);
}

Ogre::Vector3 LRRDetectionVisual::getROSCartesianCoordinates(const server_replay_lrr::msg::MsgDetectionUhdp& detection)
{
    Ogre::Vector3 cartesian_position;

    float range = detection.range;
    float azimuth = detection.azimuth;
    float elevation = detection.elevation;

    float dx = range * cos(azimuth);
    float dy = range * sin(azimuth);
    float dz = range * sin(elevation);

    cartesian_position[0] = dx;
    cartesian_position[1] = -dy; //- for conversion from LHS to RHS system.
                                 // Radar publishes in LHS. Rviz renders in RHS
    cartesian_position[2] = -dz;

    return cartesian_position;
}
} // namespace rviz_plugin_server_uhdp_lrr