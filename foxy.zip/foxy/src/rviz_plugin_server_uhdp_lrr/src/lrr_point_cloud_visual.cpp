#include "lrr_point_cloud_visual.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>
#include <OgreVector3.h>

namespace rviz_plugin_server_uhdp_lrr
{

LRRPointCloudVisual::LRRPointCloudVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node)
{
    scene_manager_ = scene_manager;
    frame_node_ = parent_node->createChildSceneNode();
}

LRRPointCloudVisual::~LRRPointCloudVisual()
{
    scene_manager_->destroySceneNode(frame_node_);
}

void LRRPointCloudVisual::setMessage(const server_replay_lrr::msg::MsgPoint& point)
{
    point_shape_.reset(new rviz_rendering::Shape(rviz_rendering::Shape::Sphere, scene_manager_, frame_node_));
    point_shape_->setColor(255, 0, 0, 1); // Red

    Ogre::Vector3 cartersian_position = getROSCartesianCoordinates(point);
    point_shape_->setPosition(cartersian_position);

    Ogre::Vector3 scale(point_sphere_radius_, point_sphere_radius_, 0);
    point_shape_->setScale(scale);
}

void LRRPointCloudVisual::setFramePosition(const Ogre::Vector3& position)
{
    frame_node_->setPosition(position);
}

void LRRPointCloudVisual::setFrameOrientation(const Ogre::Quaternion& orientation)
{
    frame_node_->setOrientation(orientation);
}

void LRRPointCloudVisual::setColor(float r, float g, float b, float a)
{
    point_shape_->setColor(r, g, b, a);
}

Ogre::Vector3 LRRPointCloudVisual::getROSCartesianCoordinates(const server_replay_lrr::msg::MsgPoint& point)
{
    Ogre::Vector3 cartesian_position;

    float range = point.range;
    float azimuth = point.azimuth;
    float elevation = point.elevation;

    float dx = range * cos(azimuth);
    float dy = range * sin(azimuth);
    float dz = range * sin(elevation);

    cartesian_position[0] = dx;
    cartesian_position[1] = -dy; //- for conversion from LHS to RHS system.
                                 // Radar publishes in LHS. Rviz renders in RHS
    cartesian_position[2] = dz;

    return cartesian_position;
}
} // namespace rviz_plugin_server_uhdp_lrr