#include "lrr_point_cloud_display.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>

namespace rviz_plugin_server_uhdp_lrr
{

LRRPointCloudDisplay::LRRPointCloudDisplay()
{
    keep_visualizations_ = false;
    keep_visualizations_property_ = new rviz_common::properties::BoolProperty(
        "Keep Visualizations", false, "Keep Visualizations if no update received. Visualizations for this \
				display plugin are not cleared after set timeout and \
				persist until a new message is recieved.",
        this, SLOT(updateKeepVisualizations()));

    restrict_fov_value_ = false;
    restrict_fov_property_ = new rviz_common::properties::BoolProperty(
        "Restrict FOV", restrict_fov_value_, "Restrict FOV to the value defined by FOV Value property.", this,
        SLOT(updateRestrictFOV()));

    fov_value_radians_ = (Ogre::Math::PI * 90.0) / 180.0; // -90 deg to +90 deg
    fov_value_property_ = new rviz_common::properties::FloatProperty(
        "FOV Value (degrees)", 90.0,
        "FOV (degrees) of the points to display. Points in the range +value to -value are displayed.", this,
        SLOT(updateFOV()));

    fov_value_property_->setHidden(!restrict_fov_property_->getBool());
}

LRRPointCloudDisplay::~LRRPointCloudDisplay()
{
}

void LRRPointCloudDisplay::onInitialize()
{
    MFDClass::onInitialize();
}

void LRRPointCloudDisplay::reset()
{
    MFDClass::reset();
    clearVisuals();
}

void LRRPointCloudDisplay::onEnable()
{
    MFDClass::onEnable();
}

void LRRPointCloudDisplay::onDisable()
{
    MFDClass::onDisable();
}

void LRRPointCloudDisplay::updateKeepVisualizations()
{
    keep_visualizations_ = keep_visualizations_property_->getBool();
}

void LRRPointCloudDisplay::updateRestrictFOV()
{
    restrict_fov_value_ = restrict_fov_property_->getBool();
    fov_value_property_->setHidden(!restrict_fov_value_);
}

void LRRPointCloudDisplay::updateFOV()
{
    float fov_value_degrees = fov_value_property_->getFloat();
    fov_value_radians_ = (Ogre::Math::PI * fov_value_degrees) / 180.0;
}

void LRRPointCloudDisplay::clearVisuals()
{
    point_cloud_visuals_.clear();
}

bool LRRPointCloudDisplay::displayPoint(const server_replay_lrr::msg::MsgPoint& point)
{
    bool display_point{true};

    // Check if detection is within the set FOV
    if (restrict_fov_value_)
    {
        display_point = display_point && (point.azimuth <= fov_value_radians_ && point.azimuth >= -fov_value_radians_);
    }

    return display_point;
}

// Update function used to clear visuals after a certain decay time.
void LRRPointCloudDisplay::update(float wall_dt, float ros_dt)
{
    Q_UNUSED(wall_dt);
    Q_UNUSED(ros_dt);

    if (!keep_visualizations_)
    {
        auto current_time = std::chrono::steady_clock::now();
        std::chrono::duration<float, std::milli> time_elapsed_secs = ((current_time - msg_receive_time_) / 1000.0);

        if (time_elapsed_secs.count() >= visual_decay_time_secs_)
        {
            clearVisuals();
        }
    }
}

void LRRPointCloudDisplay::processMessage(server_replay_lrr::msg::MsgPointCloud::ConstSharedPtr msg)
{
    msg_receive_time_ = std::chrono::steady_clock::now();

    Ogre::Quaternion orientation;
    Ogre::Vector3 position;
    if (!context_->getFrameManager()->getTransform(msg->header.frame_id, msg->header.stamp, position, orientation))
    {
        RCLCPP_INFO(rclcpp::get_logger("Uhdp Pointcloud Display"), "Error transforming from frame '%s' to frame '%s'",
                    msg->header.frame_id.c_str(), qPrintable(fixed_frame_));
        return;
    }

    uint32_t num_valid_points = msg->num_points;

    point_cloud_visuals_.resize(num_valid_points);

    for (uint32_t index = 0; index < num_valid_points; index++)
    {
        auto point = msg->points.at(index);
        if (displayPoint(point))
        {
            if (point_cloud_visuals_.at(index) == nullptr)
            {
                point_cloud_visuals_.at(index) =
                    std::make_shared<LRRPointCloudVisual>(context_->getSceneManager(), scene_node_);
            }
            auto point_visual = point_cloud_visuals_.at(index);

            point_visual->setFramePosition(position);
            point_visual->setFrameOrientation(orientation);
            point_visual->setMessage(point);
        }

        else
        {
            point_cloud_visuals_.at(index).reset();
        }
    }
}

} // namespace rviz_plugin_server_uhdp_lrr

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(rviz_plugin_server_uhdp_lrr::LRRPointCloudDisplay, rviz_common::Display)
