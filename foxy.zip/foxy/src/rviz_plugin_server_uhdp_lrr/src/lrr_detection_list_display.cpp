#include "lrr_detection_list_display.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>

namespace rviz_plugin_server_uhdp_lrr
{

LRRDetectionListDisplay::LRRDetectionListDisplay()
{
    keep_visualizations_ = false;
    keep_visualizations_property_ = new rviz_common::properties::BoolProperty(
        "Keep Visualizations", false, "Keep Visualizations if no update received. Visualizations for this \
				display plugin are not cleared after set timeout and \
				persist until a new message is recieved.",
        this, SLOT(updateKeepVisualizations()));

    restrict_fov_value_ = false;
    restrict_fov_property_ = new rviz_common::properties::BoolProperty(
        "Restrict FOV", restrict_fov_value_, "Restrict FOV to the value defined by FOV Value property.", this,
        SLOT(updateRestrictFOV()));

    fov_value_radians_ = (Ogre::Math::PI * 90.0) / 180.0; // -90 deg to +90 deg
    fov_value_property_ = new rviz_common::properties::FloatProperty(
        "FOV Value (degrees)", 90.0,
        "FOV (degrees) of the detections to display. Detections in the range +value to -value are displayed.", this,
        SLOT(updateFOV()));

    fov_value_property_->setHidden(!restrict_fov_property_->getBool());

    show_free_space_ = true;
    show_free_space_property_ = new rviz_common::properties::BoolProperty(
        "Show Free Space", show_free_space_, "Enable/Disable the free space region marker.", this,
        SLOT(updateShowFreeSpace()));

    free_space_width_ = DEFAULT_FREE_SPACE_WIDTH;
    free_space_width_property_ = new rviz_common::properties::FloatProperty("Free Space Width", free_space_width_,
                                                                            "Total Width of the free space marker.",
                                                                            this, SLOT(updateFreeSpaceWidth()));
    free_space_width_property_->setMin(1.0f);
    free_space_width_property_->setMax(10.0f);

    use_static_detn_free_space_ = true;
    use_static_detn_free_space_property_ = new rviz_common::properties::BoolProperty(
        "Use Static Detn for Free Space", use_static_detn_free_space_,
        "Calculate Free space based on Static Detections", this, SLOT(updateUseStaticDetnFreeSpace()));

    use_dynamic_detn_free_space_ = false;
    use_dynamic_detn_free_space_property_ = new rviz_common::properties::BoolProperty(
        "Use Dynamic Detn for Free Space", use_dynamic_detn_free_space_,
        "Calculate Free space based on Dynamic Detections", this, SLOT(updateUseDynamicDetnFreeSpace()));
}

void LRRDetectionListDisplay::onInitialize()
{
    MFDClass::onInitialize();
}

LRRDetectionListDisplay::~LRRDetectionListDisplay()
{
}

void LRRDetectionListDisplay::reset()
{
    MFDClass::reset();
    clearVisuals();
}

void LRRDetectionListDisplay::onEnable()
{
    MFDClass::onEnable();
}

void LRRDetectionListDisplay::onDisable()
{
    MFDClass::onDisable();
}

void LRRDetectionListDisplay::addFreeSpaceVisual()
{
    free_space_visual_.reset(new LRRFreeSpaceVisual(context_->getSceneManager(), scene_node_, 0.0, free_space_width_));
}

void LRRDetectionListDisplay::removeFreeSpaceVisual()
{
    free_space_visual_.reset();
}

void LRRDetectionListDisplay::clearVisuals()
{
    static_detection_visuals_.clear();
    dynamic_detection_visuals_.clear();
    removeFreeSpaceVisual();
}

void LRRDetectionListDisplay::updateKeepVisualizations()
{
    keep_visualizations_ = keep_visualizations_property_->getBool();
}

void LRRDetectionListDisplay::updateRestrictFOV()
{
    restrict_fov_value_ = restrict_fov_property_->getBool();
    fov_value_property_->setHidden(!restrict_fov_value_);
}

void LRRDetectionListDisplay::updateFOV()
{
    float fov_value_degrees = fov_value_property_->getFloat();
    fov_value_radians_ = (Ogre::Math::PI * fov_value_degrees) / 180.0;
}

void LRRDetectionListDisplay::updateShowFreeSpace()
{
    show_free_space_ = show_free_space_property_->getBool();
    if (show_free_space_)
    {
        addFreeSpaceVisual();
    }
    else
    {
        removeFreeSpaceVisual();
    }
}

void LRRDetectionListDisplay::updateFreeSpaceWidth()
{
    free_space_width_ = free_space_width_property_->getFloat();
}

void LRRDetectionListDisplay::updateUseStaticDetnFreeSpace()
{
    use_static_detn_free_space_ = use_static_detn_free_space_property_->getBool();
}

void LRRDetectionListDisplay::updateUseDynamicDetnFreeSpace()
{
    use_dynamic_detn_free_space_ = use_dynamic_detn_free_space_property_->getBool();
}

void LRRDetectionListDisplay::update(float wall_dt, float ros_dt)
{
    Q_UNUSED(wall_dt);
    Q_UNUSED(ros_dt);

    if (!keep_visualizations_)
    {
        auto current_time = std::chrono::steady_clock::now();
        std::chrono::duration<float, std::milli> time_elapsed_secs = ((current_time - msg_receive_time_) / 1000.0);
        if (time_elapsed_secs.count() >= visual_decay_time_secs_)
        {
            clearVisuals();
        }
    }
}

bool LRRDetectionListDisplay::displayDetection(const server_replay_lrr::msg::MsgDetectionUhdp& detection)
{
    bool display_detection{true};

    // Check if detection is within the set FOV
    if (restrict_fov_value_)
    {
        display_detection =
            display_detection && (detection.azimuth <= fov_value_radians_ && detection.azimuth >= -fov_value_radians_);
    }

    return display_detection;
}

void LRRDetectionListDisplay::processMessage(server_replay_lrr::msg::MsgDetectionListUhdp::ConstSharedPtr msg)
{
    msg_receive_time_ = std::chrono::steady_clock::now();

    Ogre::Quaternion orientation;
    Ogre::Vector3 position;
    if (!context_->getFrameManager()->getTransform(msg->header.frame_id, msg->header.stamp, position, orientation))
    {
        std::cout << "Error transforming from frame : " << msg->header.frame_id.c_str()
                  << " to frame : " << qPrintable(fixed_frame_);
        return;
    }
    uint16_t num_valid_detections = msg->num_valid_detections;

    static_detection_visuals_.resize(num_valid_detections);
    dynamic_detection_visuals_.resize(num_valid_detections);
    uint16_t num_static_detections{0};
    uint16_t num_dynamic_detections{0};

    float distance_to_nearest_detection = FREE_SPACE_LENGTH_MAX;
    if (!free_space_visual_ && show_free_space_)
    {
        addFreeSpaceVisual();
        free_space_visual_->setFramePosition(position);
        free_space_visual_->setFrameOrientation(orientation);
    }

    for (uint16_t i = 0; i < num_valid_detections; i++)
    {

        server_replay_lrr::msg::MsgDetectionUhdp detection = msg->list[i];
        std::shared_ptr<LRRDetectionVisual> detection_visual;

        if (displayDetection(detection))
        {
            auto detection_flags = detection.flags;

            // Static Detections
            if (detection_flags & LRRDetectionListDisplay::eDetFlags::DF_Static ||
                detection_flags & LRRDetectionListDisplay::eDetFlags::DF_FromStaticSlice)
            {
                // Create new visual if required
                if (static_detection_visuals_.at(num_static_detections) == nullptr)
                {
                    static_detection_visuals_.at(num_static_detections) = std::make_shared<LRRDetectionVisual>(
                        context_->getSceneManager(), scene_node_, LRRDetectionVisual::DetectionType_E::STATIC);
                }

                // Check if detection is free space region of interest
                if (show_free_space_ && use_static_detn_free_space_ &&
                    free_space_visual_->isDetectionInFreeSpaceROI(detection, free_space_width_))
                {
                    const float& range = detection.range;
                    const float& azimuth = detection.azimuth;
                    float pos_x = range * cos(azimuth);

                    if (pos_x < distance_to_nearest_detection)
                    {
                        distance_to_nearest_detection = pos_x;
                    }
                }

                detection_visual = static_detection_visuals_.at(num_static_detections);
                detection_visual->setFramePosition(position);
                detection_visual->setFrameOrientation(orientation);
                detection_visual->setMessage(detection);

                num_static_detections++;
            }

            // Dynamic Detections
            else
            {
                // Create new visual if required
                if (dynamic_detection_visuals_.at(num_dynamic_detections) == nullptr)
                {
                    dynamic_detection_visuals_.at(num_dynamic_detections) = std::make_shared<LRRDetectionVisual>(
                        context_->getSceneManager(), scene_node_, LRRDetectionVisual::DetectionType_E::DYNAMIC);
                }

                // Check if detection is free space region of interest
                if (show_free_space_ && use_dynamic_detn_free_space_ &&
                    free_space_visual_->isDetectionInFreeSpaceROI(detection, free_space_width_))
                {
                    const float& range = detection.range;
                    const float& azimuth = detection.azimuth;
                    float pos_x = range * cos(azimuth);

                    if (pos_x < distance_to_nearest_detection)
                    {
                        distance_to_nearest_detection = pos_x;
                    }
                }

                detection_visual = dynamic_detection_visuals_.at(num_dynamic_detections);
                detection_visual->setFramePosition(position);
                detection_visual->setFrameOrientation(orientation);
                detection_visual->setMessage(detection);

                num_dynamic_detections++;
            }
        }
    }

    // Remove any extra visuals
    static_detection_visuals_.resize(num_static_detections);
    dynamic_detection_visuals_.resize(num_dynamic_detections);

    // Update free space size
    if (free_space_visual_)
    {
        free_space_visual_->setFreeSpaceShapeScale(distance_to_nearest_detection, free_space_width_, 0.0);
    }
}

} // namespace rviz_plugin_server_uhdp_lrr

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(rviz_plugin_server_uhdp_lrr::LRRDetectionListDisplay, rviz_common::Display)
