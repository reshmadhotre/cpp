#ifndef LRR_DETECTION_VISUAL_H
#define LRR_DETECTION_VISUAL_H

#include "server_replay_lrr/msg/msg_detection_uhdp.hpp"
#include "visibility_control.hpp"
#include <rviz_rendering/objects/shape.hpp>

namespace rviz_plugin_server_uhdp_lrr
{

class REC_REPLAY_PLUGIN_PUBLIC LRRDetectionVisual
{
  public:
    enum DetectionType_E
    {
        STATIC = 0,
        DYNAMIC
    };

    LRRDetectionVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node,
                       LRRDetectionVisual::DetectionType_E detection_type);
    virtual ~LRRDetectionVisual();

    void setMessage(const server_replay_lrr::msg::MsgDetectionUhdp& detection);
    void setFramePosition(const Ogre::Vector3& position);
    void setFrameOrientation(const Ogre::Quaternion& orientation);
    void setColor(float r, float g, float b, float a);

  private:
    Ogre::Vector3 getROSCartesianCoordinates(const server_replay_lrr::msg::MsgDetectionUhdp& detection);
    std::shared_ptr<rviz_rendering::Shape> detection_shape_;

    Ogre::SceneNode* frame_node_;
    Ogre::SceneManager* scene_manager_;

    const static float DETECTION_SPHERE_RADIUS;
    const static Ogre::ColourValue STATIC_DETECTION_COLOUR_VALUE_YELLOW;
    const static Ogre::ColourValue DYNAMIC_DETECTION_COLOUR_VALUE_GREEN;
    const static rviz_rendering::Shape::Type STATIC_DETECTION_SHAPE_TYPE;
    const static rviz_rendering::Shape::Type DYNAMIC_DETECTION_SHAPE_TYPE;
};
} // namespace rviz_plugin_server_uhdp_lrr

#endif