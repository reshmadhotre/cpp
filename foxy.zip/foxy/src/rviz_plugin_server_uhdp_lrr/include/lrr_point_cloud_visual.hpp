#ifndef LRR_POINT_CLOUD_VISUAL_H
#define LRR_POINT_CLOUD_VISUAL_H

#include "server_replay_lrr/msg/msg_point_cloud.hpp"
#include "visibility_control.hpp"
#include <rviz_rendering/objects/shape.hpp>

namespace rviz_plugin_server_uhdp_lrr
{

class REC_REPLAY_PLUGIN_PUBLIC LRRPointCloudVisual
{
  public:
    explicit LRRPointCloudVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node);
    virtual ~LRRPointCloudVisual();

    void setMessage(const server_replay_lrr::msg::MsgPoint& point);
    void setFramePosition(const Ogre::Vector3& position);
    void setFrameOrientation(const Ogre::Quaternion& orientation);
    void setColor(float r, float g, float b, float a);

  private:
    Ogre::Vector3 getROSCartesianCoordinates(const server_replay_lrr::msg::MsgPoint& detection);

    std::shared_ptr<rviz_rendering::Shape> point_shape_;
    Ogre::SceneNode* frame_node_;
    Ogre::SceneManager* scene_manager_;

    float point_sphere_radius_{0.5};
};
} // namespace rviz_plugin_server_uhdp_lrr

#endif