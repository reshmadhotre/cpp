#ifndef FREE_SPACE_VISUAL_H
#define FREE_SPACE_VISUAL_H

#include "OgreSceneManager.h"
#include "OgreSceneNode.h"
#include "server_replay_lrr/msg/msg_detection_uhdp.hpp"
#include "visibility_control.hpp"
#include <iomanip>
#include <rviz_rendering/objects/movable_text.hpp>
#include <rviz_rendering/objects/shape.hpp>

namespace rviz_plugin_server_uhdp_lrr
{
class LRRFreeSpaceVisual
{
  public:
    LRRFreeSpaceVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node, float length,
                       float free_space_width);
    ~LRRFreeSpaceVisual();
    void setFreeSpaceShapeScale(float length, float width, float height);
    bool isDetectionInFreeSpaceROI(const server_replay_lrr::msg::MsgDetectionUhdp& detection, float free_space_width);
    void setColor(float r, float g, float b, float a);
    void setFramePosition(const Ogre::Vector3& position);
    void setFrameOrientation(const Ogre::Quaternion& orientation);

  private:
    void updateRangeLabel(float range);

    Ogre::SceneNode* frame_node_;
    Ogre::SceneManager* scene_manager_;
    std::shared_ptr<rviz_rendering::Shape> free_space_shape_;
    std::shared_ptr<rviz_rendering::Shape> range_label_pivot_;
    std::shared_ptr<rviz_rendering::MovableText> range_label_;
    const float FREE_SPACE_LENGTH_MAX{160.0f};
    const float DEFAULT_FREE_SPACE_WIDTH{4.0f};
    float range_label_text_size_{60.0f};
    float free_space_width_;
};
} // namespace rviz_plugin_server_uhdp_lrr
#endif