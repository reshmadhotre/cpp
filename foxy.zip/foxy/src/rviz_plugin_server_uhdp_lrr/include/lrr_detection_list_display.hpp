#ifndef LRR_DETECTION_LIST_DISPLAY_H
#define LRR_DETECTION_LIST_DISPLAY_H

#include "lrr_detection_visual.hpp"
#include "lrr_free_space_visual.h"
#include "server_replay_lrr/msg/msg_detection_list_uhdp.hpp"
#include "visibility_control.hpp"
#include <algorithm>
#include <chrono>
#include <rviz_common/message_filter_display.hpp>
#include <rviz_common/properties/bool_property.hpp>
#include <rviz_common/properties/float_property.hpp>

namespace rviz_plugin_server_uhdp_lrr
{
class REC_REPLAY_PLUGIN_PUBLIC LRRDetectionListDisplay
    : public rviz_common::MessageFilterDisplay<server_replay_lrr::msg::MsgDetectionListUhdp>
{
    Q_OBJECT

    enum eDetFlags
    {
        DF_Static = (1 << 0),
        DF_Filtered = (1 << 1),
        DF_Reinterpolate = (1 << 2),
        DF_FromStaticSlice = (1 << 3),
    };

  public:
    LRRDetectionListDisplay();
    ~LRRDetectionListDisplay();

    void onInitialize() override;
    void reset() override;
    virtual void update(float wall_dt, float ros_dt);

  protected:
    void onEnable() override;
    void onDisable() override;

  private slots:
    void updateKeepVisualizations();
    void updateRestrictFOV();
    void updateFOV();
    void updateShowFreeSpace();
    void updateFreeSpaceWidth();
    void updateUseStaticDetnFreeSpace();
    void updateUseDynamicDetnFreeSpace();

  private:
    void processMessage(server_replay_lrr::msg::MsgDetectionListUhdp::ConstSharedPtr msg) override;
    void clearVisuals();
    bool displayDetection(const server_replay_lrr::msg::MsgDetectionUhdp& detection);
    void addFreeSpaceVisual();
    void removeFreeSpaceVisual();

    std::chrono::steady_clock::time_point msg_receive_time_;
    std::vector<std::shared_ptr<LRRDetectionVisual>> static_detection_visuals_;
    std::vector<std::shared_ptr<LRRDetectionVisual>> dynamic_detection_visuals_;
    std::shared_ptr<LRRFreeSpaceVisual> free_space_visual_;

    float visual_decay_time_secs_{0.5};
    rviz_common::properties::BoolProperty* keep_visualizations_property_;
    rviz_common::properties::BoolProperty* restrict_fov_property_;
    rviz_common::properties::FloatProperty* fov_value_property_;
    rviz_common::properties::BoolProperty* show_free_space_property_;
    rviz_common::properties::FloatProperty* free_space_width_property_;
    rviz_common::properties::BoolProperty* use_static_detn_free_space_property_;
    rviz_common::properties::BoolProperty* use_dynamic_detn_free_space_property_;

    bool keep_visualizations_;
    bool restrict_fov_value_;
    float fov_value_radians_;
    float free_space_width_;
    bool show_free_space_;
    bool use_static_detn_free_space_;
    bool use_dynamic_detn_free_space_;

    const float FREE_SPACE_LENGTH_MAX{160.0};
    const float DEFAULT_FREE_SPACE_WIDTH{4.0};
};
} // namespace rviz_plugin_server_uhdp_lrr

#endif