#ifndef LRR_POINT_CLOUD_DISPLAY_H
#define LRR_POINT_CLOUD_DISPLAY_H

#include "lrr_point_cloud_visual.hpp"
#include "server_replay_lrr/msg/msg_point_cloud.hpp"
#include "visibility_control.hpp"
#include <algorithm>
#include <chrono>
#include <rviz_common/message_filter_display.hpp>
#include <rviz_common/properties/bool_property.hpp>
#include <rviz_common/properties/float_property.hpp>

namespace rviz_plugin_server_uhdp_lrr
{
class REC_REPLAY_PLUGIN_PUBLIC LRRPointCloudDisplay
    : public rviz_common::MessageFilterDisplay<server_replay_lrr::msg::MsgPointCloud>
{
    Q_OBJECT

  public:
    LRRPointCloudDisplay();
    ~LRRPointCloudDisplay();

    void onInitialize() override;
    void reset() override;
    virtual void update(float wall_dt, float ros_dt);

  protected:
    void onEnable() override;
    void onDisable() override;

  private slots:
    void updateKeepVisualizations();
    void updateRestrictFOV();
    void updateFOV();

  private:
    void processMessage(server_replay_lrr::msg::MsgPointCloud::ConstSharedPtr msg) override;
    void clearVisuals();
    bool displayPoint(const server_replay_lrr::msg::MsgPoint& point);

    std::chrono::steady_clock::time_point msg_receive_time_;
    std::vector<std::shared_ptr<LRRPointCloudVisual>> point_cloud_visuals_;
    float visual_decay_time_secs_{0.5};
    rviz_common::properties::BoolProperty* keep_visualizations_property_;
    rviz_common::properties::BoolProperty* restrict_fov_property_;
    rviz_common::properties::FloatProperty* fov_value_property_;
    bool keep_visualizations_;
    bool restrict_fov_value_;
    float fov_value_radians_;
};
} // namespace rviz_plugin_server_uhdp_lrr
#endif