#include "midw_point_cloud_display.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>
#include <iostream>
namespace rviz_plugin_swc_merdrdatacubemidw
{

MidWPointCloudDisplay::MidWPointCloudDisplay()
{
    keep_visualizations_ = false;
    keep_visualizations_property_ = new rviz_common::properties::BoolProperty(
        "Keep Visualizations", false, "Keep Visualizations if no update received. Visualizations for this \
				display plugin are not cleared after set timeout and \
				persist until a new message is recieved.",
        this, SLOT(updateKeepVisualizations()));

    restrict_fov_value_ = false;
    restrict_fov_property_ = new rviz_common::properties::BoolProperty(
        "Restrict FOV", false, "Restrict FOV to the value defined by FOV Value property.", this,
        SLOT(updateRestrictFOV()));

    fov_value_radians_ = (Ogre::Math::PI * 90.0) / 180.0; // -90 deg to +90 deg
    fov_value_property_ = new rviz_common::properties::FloatProperty(
        "FOV Value (degrees)", 90.0,
        "FOV (degrees) of the points to display. Points in the range +value to -value are displayed.", this,
        SLOT(updateFOV()));

    fov_value_property_->setHidden(!restrict_fov_property_->getBool());
}

MidWPointCloudDisplay::~MidWPointCloudDisplay()
{
}

void MidWPointCloudDisplay::onInitialize()
{
    MFDClass::onInitialize();
}

void MidWPointCloudDisplay::reset()
{
    MFDClass::reset();
    clearAllVisuals();
}

void MidWPointCloudDisplay::onEnable()
{
    MFDClass::onEnable();
}

void MidWPointCloudDisplay::onDisable()
{
    MFDClass::onDisable();
}

void MidWPointCloudDisplay::updateKeepVisualizations()
{
    keep_visualizations_ = keep_visualizations_property_->getBool();
}

void MidWPointCloudDisplay::updateRestrictFOV()
{
    restrict_fov_value_ = restrict_fov_property_->getBool();
    fov_value_property_->setHidden(!restrict_fov_value_);
}

void MidWPointCloudDisplay::updateFOV()
{
    float fov_value_degrees = fov_value_property_->getFloat();
    fov_value_radians_ = (Ogre::Math::PI * fov_value_degrees) / 180.0;
}

void MidWPointCloudDisplay::clearAllVisuals()
{
    point_cloud_visuals_1d_.clear();
    point_cloud_visuals_2d_.clear();
}

bool MidWPointCloudDisplay::displayPoint(const msg_swc_common::msg::MsgGenCoorPolarType& coor_polar_type)
{
    bool display_point{true};

    // Check if detection is within the set FOV
    if (restrict_fov_value_)
    {
        display_point = display_point && (coor_polar_type.azimuth <= fov_value_radians_ &&
                                          coor_polar_type.azimuth >= -fov_value_radians_);
    }

    return display_point;
}

// Update function used to clear visuals after a certain decay time.
void MidWPointCloudDisplay::update(float wall_dt, float ros_dt)
{
    Q_UNUSED(wall_dt);
    Q_UNUSED(ros_dt);

    if (!keep_visualizations_)
    {
        auto current_time = std::chrono::steady_clock::now();
        auto time_elapsed_secs =
            std::chrono::duration_cast<std::chrono::milliseconds>(current_time - msg_receive_time).count();
        time_elapsed_secs /= 1000.0;

        if (time_elapsed_secs >= visual_decay_time_secs_)
        {
            clearAllVisuals();
        }
    }
}

void MidWPointCloudDisplay::processMessage(msg_swc_common::msg::MsgDetnGetMidWDataType::ConstSharedPtr msg)
{
    msg_receive_time = std::chrono::steady_clock::now();

    if (!context_->getFrameManager()->getTransform(msg->header.frame_id, msg->header.stamp, frame_position_,
                                                   frame_orientation_))
    {
        RCLCPP_INFO(rclcpp::get_logger("Middleware Detection list Display"),
                    "Error transforming from frame '%s' to frame '%s'", msg->header.frame_id.c_str(),
                    qPrintable(fixed_frame_));
        return;
    }

    uint32_t num_1d_points =
        msg->one_d_ptr.point_cloud_list.num_elem_per_scan[0] + msg->one_d_ptr.point_cloud_list.num_elem_per_scan[1];
    updatePointCloud(num_1d_points, msg->one_d_ptr.point_cloud_list, point_cloud_visuals_1d_);

    uint32_t num_2d_points =
        msg->two_d_ptr.point_cloud_list.num_elem_per_scan[0] + msg->two_d_ptr.point_cloud_list.num_elem_per_scan[1];
    updatePointCloud(num_2d_points, msg->two_d_ptr.point_cloud_list, point_cloud_visuals_2d_);
}

void MidWPointCloudDisplay::updatePointCloud(uint32_t num_points,
                                             const msg_swc_common::msg::MsgRdcConvPcType& point_cloud_type,
                                             std::vector<std::shared_ptr<MidWPointCloudVisual>>& visuals_container)
{
    visuals_container.resize(num_points);
    for (uint32_t index = 0; index < num_points; index++)
    {

        msg_swc_common::msg::MsgGenCoorPolarType coor_polar_type;
        coor_polar_type.range = point_cloud_type.range.at(index);
        coor_polar_type.azimuth = point_cloud_type.azimuth.at(index);
        coor_polar_type.elevation = point_cloud_type.elevation.at(index);

        if (displayPoint(coor_polar_type))
        {
            if (visuals_container.at(index) == nullptr)
            {
                visuals_container.at(index) =
                    std::make_shared<MidWPointCloudVisual>(context_->getSceneManager(), scene_node_);
            }
            auto point_visual = visuals_container.at(index);
            point_visual->setFrameOrientation(frame_orientation_);
            point_visual->setFramePosition(frame_position_);
            point_visual->setMessage(coor_polar_type);
        }
        else
        {
            visuals_container.at(index).reset();
        }
    }
}
} // namespace rviz_plugin_swc_merdrdatacubemidw

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(rviz_plugin_swc_merdrdatacubemidw::MidWPointCloudDisplay, rviz_common::Display)