#include "midw_point_cloud_visual.hpp"
#include "rclcpp/rclcpp.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>
#include <OgreVector3.h>
#include <iostream>
namespace rviz_plugin_swc_merdrdatacubemidw
{

const float MidWPointCloudVisual::POINT_SPHERE_RADIUS = 0.5;
const Ogre::ColourValue MidWPointCloudVisual::POINT_COLOUR_VALUE_RED = Ogre::ColourValue(1.0f, 0.0f, 0.0f, 1.0f);
const rviz_rendering::Shape::Type MidWPointCloudVisual::POINT_SHAPE_TYPE = rviz_rendering::Shape::Sphere;

MidWPointCloudVisual::MidWPointCloudVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node)
{
    scene_manager_ = scene_manager;

    frame_node_ = parent_node->createChildSceneNode();

    point_shape_.reset(new rviz_rendering::Shape(POINT_SHAPE_TYPE, scene_manager_, frame_node_));
    point_shape_->setColor(POINT_COLOUR_VALUE_RED); // Red

    Ogre::Vector3 scale(POINT_SPHERE_RADIUS, POINT_SPHERE_RADIUS, 0.0f);
    point_shape_->setScale(scale);
}

MidWPointCloudVisual::~MidWPointCloudVisual()
{
    point_shape_.reset();
    scene_manager_->destroySceneNode(frame_node_);
}

void MidWPointCloudVisual::setMessage(const msg_swc_common::msg::MsgGenCoorPolarType& point_coor_polar)
{
    Ogre::Vector3 cartersian_position = getROSCartesianCoordinates(point_coor_polar);
    point_shape_->setPosition(cartersian_position);
}

void MidWPointCloudVisual::setFramePosition(const Ogre::Vector3& position)
{
    frame_node_->setPosition(position);
}

void MidWPointCloudVisual::setFrameOrientation(const Ogre::Quaternion& orientation)
{
    frame_node_->setOrientation(orientation);
}

Ogre::Vector3 MidWPointCloudVisual::getROSCartesianCoordinates(
    const msg_swc_common::msg::MsgGenCoorPolarType& point_coor_polar)
{
    Ogre::Vector3 cartesian_position;

    float range = point_coor_polar.range;
    float azimuth = point_coor_polar.azimuth;
    float elevation = point_coor_polar.elevation;

    float dx = range * cos(azimuth);
    float dy = range * sin(azimuth);
    float dz = range * sin(elevation);

    cartesian_position[0] = dx;
    cartesian_position[1] = -dy; //- for conversion from LHS to RHS system.
                                 // Radar publishes in LHS. Rviz renders in RHS
    cartesian_position[2] = -dz;

    return cartesian_position;
}
} // namespace rviz_plugin_swc_merdrdatacubemidw