#include "midw_detection_list_display.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>
#include <iostream>
namespace rviz_plugin_swc_merdrdatacubemidw
{

MidWDetectionListDisplay::MidWDetectionListDisplay()
{
    keep_visualizations_ = true;
    keep_visualizations_property_ =
        new rviz_common::properties::BoolProperty("Keep Visualizations", keep_visualizations_,
                                                  "Keep Visualizations if no update received. Visualizations for this \
				display plugin are not cleared after set timeout and \
				persist until a new message is recieved.",
                                                  this, SLOT(updateKeepVisualizations()));

    restrict_fov_value_ = false;
    restrict_fov_property_ = new rviz_common::properties::BoolProperty(
        "Restrict FOV", restrict_fov_value_, "Restrict FOV to the value defined by FOV Value property.", this,
        SLOT(updateRestrictFOV()));

    fov_value_radians_ = (Ogre::Math::PI * 90.0) / 180.0; // -90 deg to +90 deg
    fov_value_property_ = new rviz_common::properties::FloatProperty(
        "FOV Value (degrees)", 90.0,
        "FOV (degrees) of the detections to display. Detections in the range +value to -value are displayed.", this,
        SLOT(updateFOV()));

    fov_value_property_->setHidden(!restrict_fov_property_->getBool());

    show_1d_detections_ = true;
    show_1d_detections_property_ = new rviz_common::properties::BoolProperty(
        "Show 1D Detections", show_1d_detections_, "Show/Hide 1D Static and Dynamic Detections.", this,
        SLOT(updateShow1DDetections()));

    show_2d_detections_ = true;
    show_2d_detections_property_ = new rviz_common::properties::BoolProperty(
        "Show 2D Detections", show_2d_detections_, "Show/Hide 2D Static and Dynamic Detections.", this,
        SLOT(updateShow2DDetections()));
}

MidWDetectionListDisplay::~MidWDetectionListDisplay()
{
}

void MidWDetectionListDisplay::onInitialize()
{
    MFDClass::onInitialize();
}

void MidWDetectionListDisplay::reset()
{
    MFDClass::reset();
    clearAllVisuals();
}

void MidWDetectionListDisplay::onEnable()
{
    MFDClass::onEnable();
}

void MidWDetectionListDisplay::onDisable()
{
    MFDClass::onDisable();
}

void MidWDetectionListDisplay::updateKeepVisualizations()
{
    keep_visualizations_ = keep_visualizations_property_->getBool();
}

void MidWDetectionListDisplay::updateRestrictFOV()
{
    restrict_fov_value_ = restrict_fov_property_->getBool();
    fov_value_property_->setHidden(!restrict_fov_value_);
}

void MidWDetectionListDisplay::updateFOV()
{
    float fov_value_degrees = fov_value_property_->getFloat();
    fov_value_radians_ = (Ogre::Math::PI * fov_value_degrees) / 180.0;
}

void MidWDetectionListDisplay::updateShow1DDetections()
{
    show_1d_detections_ = show_1d_detections_property_->getBool();
}

void MidWDetectionListDisplay::updateShow2DDetections()
{
    show_2d_detections_ = show_2d_detections_property_->getBool();
}

void MidWDetectionListDisplay::clearAllVisuals()
{
    static_1d_detection_visuals_.clear();
    static_2d_detection_visuals_.clear();
    dynamic_1d_detection_visuals_.clear();
    dynamic_2d_detection_visuals_.clear();
}

// Update function used to clear visuals after a certain decay time.
void MidWDetectionListDisplay::update(float wall_dt, float ros_dt)
{
    Q_UNUSED(wall_dt);
    Q_UNUSED(ros_dt);

    if (!keep_visualizations_)
    {
        auto current_time = std::chrono::steady_clock::now();
        auto time_elapsed_secs =
            std::chrono::duration_cast<std::chrono::milliseconds>(current_time - msg_receive_time).count();
        time_elapsed_secs /= 1000.0;

        if (time_elapsed_secs >= visual_decay_time_secs_)
        {
            clearAllVisuals();
        }
    }
}

bool MidWDetectionListDisplay::displayDetection(const msg_swc_common::msg::MsgGenCoorPolarType& detection_coor_polar)
{
    bool display_detection{true};

    // Check if detection is within the set FOV
    if (restrict_fov_value_)
    {
        display_detection = display_detection && (detection_coor_polar.azimuth <= fov_value_radians_ &&
                                                  detection_coor_polar.azimuth >= -fov_value_radians_);
    }

    return display_detection;
}

void MidWDetectionListDisplay::processMessage(msg_swc_common::msg::MsgDetnGetMidWDataType::ConstSharedPtr msg)
{
    msg_receive_time = std::chrono::steady_clock::now();

    if (!context_->getFrameManager()->getTransform(msg->header.frame_id, msg->header.stamp, frame_position_,
                                                   frame_orientation_))
    {
        std::cout << "Error transforming from frame :" << msg->header.frame_id
                  << "to frame : " << qPrintable(fixed_frame_) << std::endl;
        return;
    }

    if (show_1d_detections_)
    {
        uint32_t num_valid_static_1d_detections = msg->one_d_ptr.detection_list.static_detns.num_elem_per_scan[0] +
                                                  msg->one_d_ptr.detection_list.static_detns.num_elem_per_scan[1];
        updateDetections(num_valid_static_1d_detections, msg->one_d_ptr.detection_list.static_detns,
                         MidWDetectionVisual::DetectionType_E::STATIC, static_1d_detection_visuals_);

        uint32_t num_valid_dynamic_1d_detections = msg->one_d_ptr.detection_list.dynamic_detns.num_elem_per_scan[0] +
                                                   msg->one_d_ptr.detection_list.dynamic_detns.num_elem_per_scan[1];
        updateDetections(num_valid_dynamic_1d_detections, msg->one_d_ptr.detection_list.dynamic_detns,
                         MidWDetectionVisual::DetectionType_E::DYNAMIC, dynamic_1d_detection_visuals_);
    }

    else
    {
        static_1d_detection_visuals_.clear();
        dynamic_1d_detection_visuals_.clear();
    }

    if (show_2d_detections_)
    {
        uint32_t num_valid_static_2d_detections = msg->two_d_ptr.detection_list.static_detns.num_elem_per_scan[0] +
                                                  msg->two_d_ptr.detection_list.static_detns.num_elem_per_scan[1];
        updateDetections(num_valid_static_2d_detections, msg->two_d_ptr.detection_list.static_detns,
                         MidWDetectionVisual::DetectionType_E::STATIC, static_2d_detection_visuals_);

        uint32_t num_valid_dynamic_2d_detections = msg->two_d_ptr.detection_list.dynamic_detns.num_elem_per_scan[0] +
                                                   msg->two_d_ptr.detection_list.dynamic_detns.num_elem_per_scan[1];
        updateDetections(num_valid_dynamic_2d_detections, msg->two_d_ptr.detection_list.dynamic_detns,
                         MidWDetectionVisual::DetectionType_E::DYNAMIC, dynamic_2d_detection_visuals_);
    }

    else
    {
        static_2d_detection_visuals_.clear();
        dynamic_2d_detection_visuals_.clear();
    }
}

void MidWDetectionListDisplay::updateDetections(uint32_t num_detections,
                                                const msg_swc_common::msg::MsgRdcDetnType& detections,
                                                MidWDetectionVisual::DetectionType_E detection_type,
                                                std::vector<std::shared_ptr<MidWDetectionVisual>>& visuals_container)
{

    visuals_container.resize(num_detections);
    for (uint32_t index = 0; index < num_detections; index++)
    {
        if (displayDetection(detections.coor_polar[index]))
        {

            if (visuals_container.at(index) == nullptr)
            {
                visuals_container.at(index) =
                    std::make_shared<MidWDetectionVisual>(context_->getSceneManager(), scene_node_, detection_type);
            }
            auto detection_visual = visuals_container.at(index);
            detection_visual->setFrameOrientation(frame_orientation_);
            detection_visual->setFramePosition(frame_position_);
            detection_visual->setMessage(detections.coor_polar[index]);
        }
        else
        {
            visuals_container.at(index).reset();
        }
    }
}
} // namespace rviz_plugin_swc_merdrdatacubemidw

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(rviz_plugin_swc_merdrdatacubemidw::MidWDetectionListDisplay, rviz_common::Display)