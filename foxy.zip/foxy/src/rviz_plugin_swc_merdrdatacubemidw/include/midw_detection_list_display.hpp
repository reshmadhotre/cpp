#ifndef MIDW_DETECTION_LIST_DISPLAY_H
#define MIDW_DETECTION_LIST_DISPLAY_H

#include "midw_detection_visual.hpp"
#include "msg_swc_common/msg/msg_detn_get_mid_w_data_type.hpp"
#include <chrono>
#include <rviz_common/message_filter_display.hpp>
#include <rviz_common/properties/bool_property.hpp>
#include <rviz_common/properties/float_property.hpp>

namespace rviz_plugin_swc_merdrdatacubemidw
{
class REC_REPLAY_PLUGIN_PUBLIC MidWDetectionListDisplay
    : public rviz_common::MessageFilterDisplay<msg_swc_common::msg::MsgDetnGetMidWDataType>
{
    Q_OBJECT

    enum eDetFlags
    {
        DF_Static = (1 << 0),
        DF_Filtered = (1 << 1),
        DF_Reinterpolate = (1 << 2),
        DF_FromStaticSlice = (1 << 3),
    };

  public:
    MidWDetectionListDisplay();
    ~MidWDetectionListDisplay();

    void onInitialize() override;
    void reset() override;

    virtual void update(float wall_dt, float ros_dt);
    void updateDetections(uint32_t num_detections, const msg_swc_common::msg::MsgRdcDetnType& detections,
                          MidWDetectionVisual::DetectionType_E detection_type,
                          std::vector<std::shared_ptr<MidWDetectionVisual>>& visuals_container);

  protected:
    void onEnable() override;
    void onDisable() override;

  private slots:
    void updateKeepVisualizations();
    void updateRestrictFOV();
    void updateFOV();
    void updateShow1DDetections();
    void updateShow2DDetections();

  private:
    void processMessage(msg_swc_common::msg::MsgDetnGetMidWDataType::ConstSharedPtr msg) override;
    void clearAllVisuals();
    bool displayDetection(const msg_swc_common::msg::MsgGenCoorPolarType& detection_coor_polar);

    std::vector<std::shared_ptr<MidWDetectionVisual>> static_1d_detection_visuals_;
    std::vector<std::shared_ptr<MidWDetectionVisual>> static_2d_detection_visuals_;
    std::vector<std::shared_ptr<MidWDetectionVisual>> dynamic_1d_detection_visuals_;
    std::vector<std::shared_ptr<MidWDetectionVisual>> dynamic_2d_detection_visuals_;

    Ogre::Quaternion frame_orientation_;
    Ogre::Vector3 frame_position_;
    std::chrono::steady_clock::time_point msg_receive_time;
    float visual_decay_time_secs_{0.5};
    rviz_common::properties::BoolProperty* keep_visualizations_property_;
    rviz_common::properties::BoolProperty* restrict_fov_property_;
    rviz_common::properties::FloatProperty* fov_value_property_;
    rviz_common::properties::BoolProperty* show_1d_detections_property_;
    rviz_common::properties::BoolProperty* show_2d_detections_property_;
    bool keep_visualizations_;
    bool restrict_fov_value_;
    float fov_value_radians_;
    bool show_1d_detections_;
    bool show_2d_detections_;
};
} // namespace rviz_plugin_swc_merdrdatacubemidw
#endif