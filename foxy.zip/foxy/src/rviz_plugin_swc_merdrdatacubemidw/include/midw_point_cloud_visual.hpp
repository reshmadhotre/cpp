#ifndef MIDW_POINT_CLOUD_VISUAL_HPP
#define MIDW_POINT_CLOUD_VISUAL_HPP

#include "msg_swc_common/msg/msg_rdc_mid_w_data_type.hpp"
#include "visibility_control.hpp"
#include <rviz_rendering/objects/shape.hpp>

namespace rviz_plugin_swc_merdrdatacubemidw
{

class REC_REPLAY_PLUGIN_PUBLIC MidWPointCloudVisual
{
  public:
    MidWPointCloudVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node);
    virtual ~MidWPointCloudVisual();

    void setMessage(const msg_swc_common::msg::MsgGenCoorPolarType& point_coor_polar);
    void setFramePosition(const Ogre::Vector3& position);
    void setFrameOrientation(const Ogre::Quaternion& orientation);

  private:
    Ogre::Vector3 getROSCartesianCoordinates(const msg_swc_common::msg::MsgGenCoorPolarType& point_coor_polar);
    std::shared_ptr<rviz_rendering::Shape> point_shape_;

    Ogre::SceneNode* frame_node_;
    Ogre::SceneManager* scene_manager_;

    const static float POINT_SPHERE_RADIUS;
    const static Ogre::ColourValue POINT_COLOUR_VALUE_RED;
    const static rviz_rendering::Shape::Type POINT_SHAPE_TYPE;
};
} // namespace rviz_plugin_swc_merdrdatacubemidw
#endif