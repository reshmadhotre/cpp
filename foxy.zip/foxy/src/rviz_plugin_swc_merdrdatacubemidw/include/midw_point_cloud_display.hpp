#ifndef MIDW_POINT_CLOUD_DISPLAY_HPP
#define MIDW_POINT_CLOUD_DISPLAY_HPP

#include "midw_point_cloud_visual.hpp"
#include "msg_swc_common/msg/msg_detn_get_mid_w_data_type.hpp"
#include <chrono>
#include <rviz_common/message_filter_display.hpp>
#include <rviz_common/properties/bool_property.hpp>
#include <rviz_common/properties/float_property.hpp>

namespace rviz_plugin_swc_merdrdatacubemidw
{
class REC_REPLAY_PLUGIN_PUBLIC MidWPointCloudDisplay
    : public rviz_common::MessageFilterDisplay<msg_swc_common::msg::MsgDetnGetMidWDataType>
{
    Q_OBJECT

  public:
    MidWPointCloudDisplay();
    ~MidWPointCloudDisplay();
    void onInitialize() override;
    void reset() override;
    virtual void update(float wall_dt, float ros_dt);

  protected:
    void onEnable() override;
    void onDisable() override;

  private slots:
    void updateKeepVisualizations();
    void updateRestrictFOV();
    void updateFOV();

  private:
    void processMessage(msg_swc_common::msg::MsgDetnGetMidWDataType::ConstSharedPtr msg) override;
    void clearAllVisuals();
    bool displayPoint(const msg_swc_common::msg::MsgGenCoorPolarType& coor_polar_type);
    void updatePointCloud(uint32_t num_points, const msg_swc_common::msg::MsgRdcConvPcType& point_cloud_type,
                          std::vector<std::shared_ptr<MidWPointCloudVisual>>& visuals_container);

    std::vector<std::shared_ptr<MidWPointCloudVisual>> point_cloud_visuals_1d_;
    std::vector<std::shared_ptr<MidWPointCloudVisual>> point_cloud_visuals_2d_;

    Ogre::Quaternion frame_orientation_;
    Ogre::Vector3 frame_position_;
    std::chrono::steady_clock::time_point msg_receive_time;
    float visual_decay_time_secs_{0.5};
    rviz_common::properties::BoolProperty* keep_visualizations_property_;
    rviz_common::properties::BoolProperty* restrict_fov_property_;
    rviz_common::properties::FloatProperty* fov_value_property_;
    bool keep_visualizations_;
    bool restrict_fov_value_;
    float fov_value_radians_;
};
} // namespace rviz_plugin_swc_merdrdatacubemidw
#endif