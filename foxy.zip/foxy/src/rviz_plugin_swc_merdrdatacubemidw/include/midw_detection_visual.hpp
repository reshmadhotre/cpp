#ifndef MIDW_DETECTION_VISUAL_H
#define MIDW_DETECTION_VISUAL_H

#include "msg_swc_common/msg/msg_rdc_mid_w_data_type.hpp"
#include "visibility_control.hpp"
#include <rviz_rendering/objects/shape.hpp>

namespace rviz_plugin_swc_merdrdatacubemidw
{

class REC_REPLAY_PLUGIN_PUBLIC MidWDetectionVisual
{
  public:
    enum DetectionType_E
    {
        STATIC = 0,
        DYNAMIC
    };

    MidWDetectionVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node,
                        MidWDetectionVisual::DetectionType_E detection_type);
    virtual ~MidWDetectionVisual();

    void setMessage(const msg_swc_common::msg::MsgGenCoorPolarType& detection_coor_polar);
    void setFramePosition(const Ogre::Vector3& position);
    void setFrameOrientation(const Ogre::Quaternion& orientation);

  private:
    Ogre::Vector3 getROSCartesianCoordinates(const msg_swc_common::msg::MsgGenCoorPolarType& detection_coor_polar);
    std::shared_ptr<rviz_rendering::Shape> detection_shape_;

    Ogre::SceneNode* frame_node_;
    Ogre::SceneManager* scene_manager_;

    const static float DETECTION_SPHERE_RADIUS;
    const static Ogre::ColourValue STATIC_DETECTION_COLOUR_VALUE;
    const static Ogre::ColourValue DYNAMIC_DETECTION_COLOUR_VALUE;
    const static rviz_rendering::Shape::Type STATIC_DETECTION_SHAPE_TYPE;
    const static rviz_rendering::Shape::Type DYNAMIC_DETECTION_SHAPE_TYPE;
};
} // namespace rviz_plugin_swc_merdrdatacubemidw

#endif