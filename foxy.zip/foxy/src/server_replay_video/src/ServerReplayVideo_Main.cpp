#include "VideoReplayAdapter.h"
#include "rclcpp/rclcpp.hpp"

int main(int argc, char* argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<rclcpp::Node>("server_replay_video_node");

    auto video_replay_adapter = std::make_shared<VideoReplayAdapter>(node);
    video_replay_adapter->StartReaderThread();

    rclcpp::spin(node);
    video_replay_adapter->StopReaderThread();
    video_replay_adapter->CloseFileHandles();
    video_replay_adapter.reset();
    rclcpp::shutdown();

    return 0;
}
