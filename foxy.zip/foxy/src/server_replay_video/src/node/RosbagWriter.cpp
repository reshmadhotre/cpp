#include "RosbagWriter.hpp"

const std::map<std::string, std::string> RosbagWriter::TOPIC_MSG_TYPE_MAP = {
    {rosidl_generator_traits::name<sensor_msgs::msg::Image>(), "topic_mf4_video"}};

RosbagWriter::RosbagWriter(const std::string& rosbag_path, const std::string& node_namespace)
{
    rosbag_path_ = rosbag_path;
    writer_ = std::make_shared<rosbag2_cpp::writers::SequentialWriter>();
    node_namespace_ = node_namespace;
}

RosbagWriter::~RosbagWriter()
{
    CloseFile();
}

bool RosbagWriter::OpenFile()
{
    try
    {
        auto rosbag_dir = rcpputils::fs::path(rosbag_path_);

        // clear the rosbag_dir if not empty
        rcpputils::fs::remove_all(rosbag_dir);
        rcpputils::fs::create_directories(rosbag_dir);

        const rosbag2_cpp::StorageOptions storage_options({rosbag_dir.string(), "sqlite3"});
        const rosbag2_cpp::ConverterOptions converter_options({"cdr", "cdr"});

        writer_->open(storage_options, converter_options);
        writer_initialized_ = true;

        return true;
    }
    catch (const std::exception& e)
    {
        std::cout << "Rosbag dir : " << rosbag_path_ << " could not be opened for rosbag write."
                  << "\n";
        std::cerr << e.what() << '\n';

        return false;
    }
}

bool RosbagWriter::Write(std::shared_ptr<RosbagEntry> rosbag_entry)
{
    try
    {
        const std::string& topic = rosbag_entry->topic_meta_data.name;
        const std::string& msg_type = rosbag_entry->topic_meta_data.type;
        const std::string& serialization_format = rosbag_entry->topic_meta_data.serialization_format;
        if (std::find(created_rosbag_topics_.begin(), created_rosbag_topics_.end(), topic) ==
            created_rosbag_topics_.end())
        {
            writer_->create_topic({topic, msg_type, serialization_format, ""});
            created_rosbag_topics_.push_back(topic);
        }

        auto serialized_bag_message = CreateSerializedBagMessage(rosbag_entry);
        writer_->write(serialized_bag_message);

        return true;
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        return false;
    }
}

std::shared_ptr<rosbag2_storage::SerializedBagMessage> RosbagWriter::CreateSerializedBagMessage(
    std::shared_ptr<RosbagEntry> rosbag_entry)
{
    auto bag_message = std::make_shared<rosbag2_storage::SerializedBagMessage>();
    bag_message->time_stamp = rosbag_entry->msg_time.nanoseconds();
    bag_message->topic_name = rosbag_entry->topic_meta_data.name;
    bag_message->serialized_data =
        std::shared_ptr<rcutils_uint8_array_t>(new rcutils_uint8_array_t, [](rcutils_uint8_array_t* msg) {
            auto fini_return = rcutils_uint8_array_fini(msg);
            delete msg;

            if (fini_return != RCUTILS_RET_OK)
            {
                std::cout << "Failed to destroy serialized message : " << rcutils_get_error_string().str << "\n";
            }
        });
    *bag_message->serialized_data = rosbag_entry->serialized_msg->release_rcl_serialized_message();

    return bag_message;
}

rosbag2_storage::TopicMetadata RosbagWriter::GetTopicMetadataFromMsgType(const std::string& msg_type)
{
    rosbag2_storage::TopicMetadata topic_metadata;

    auto iter = TOPIC_MSG_TYPE_MAP.find(msg_type);
    if (iter != TOPIC_MSG_TYPE_MAP.end())
    {
        topic_metadata.type = msg_type;
        std::string topic_name = "";
        if (node_namespace_ == "" || node_namespace_ == "/map")
        {
            topic_name = "/" + iter->second;
        }
        else
        {
            topic_name = node_namespace_ + "/" + iter->second;
        }
        topic_metadata.name = topic_name;
        topic_metadata.serialization_format = "cdr";
    }

    return topic_metadata;
}

void RosbagWriter::CloseFile()
{
    if (writer_ != nullptr)
    {
        writer_->reset();
        writer_.reset();
    }
}