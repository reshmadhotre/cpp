#include "VideoReplayAdapter.h"

VideoReplayAdapter::VideoReplayAdapter(std::shared_ptr<rclcpp::Node> node) : node_(node)
{
    InitRosParams();
    GetFilePaths();
    InitSubscribers();
    InitPublishers();
    InitTimers();

    mdf_player_.RegisterListener(&replay_lib_);
}

VideoReplayAdapter::~VideoReplayAdapter()
{
    StopReaderThread();
    CloseFileHandles();
}

void VideoReplayAdapter::InitRosParams()
{
    using namespace ROS_PARAM_NAMES;
    std::vector<std::string> default_file_paths{};
    node_->declare_parameter(REPLAY_MF4_VIDEO_FILEPATHS, default_file_paths);
    node_->declare_parameter(RECORD_ROSBAGS, false);
    node_->declare_parameter(STANDALONE_MODE, true);
    node_->declare_parameter(SHOW_TIMESTAMP, true);

    mf4_files_to_play_ = node_->get_parameter(REPLAY_MF4_VIDEO_FILEPATHS).as_string_array();
    standalone_mode_ = node_->get_parameter(STANDALONE_MODE).as_bool();
    record_rosbags_ = node_->get_parameter(RECORD_ROSBAGS).as_bool();
    show_timestamp_ = node_->get_parameter(SHOW_TIMESTAMP).as_bool();
}

void VideoReplayAdapter::GetFilePaths()
{

    for (const auto& mf4_filepath : mf4_files_to_play_)
    {
        mf4_files_queue_.push(mf4_filepath);
    }
    num_files_to_process_ = mf4_files_queue_.size();
}

void VideoReplayAdapter::InitPublishers()
{
    using namespace ROS_PUBLISHER_TOPICS;
    mf4_video_publisher_ = image_transport::create_publisher(node_.get(), TOPIC_MF4_VIDEO);
    status_publisher_ =
        node_->create_publisher<server_replay_video::msg::MsgVideoReplayStatus>(TOPIC_SERVER_REPLAY_VIDEO_STATUS, 10);
}

void VideoReplayAdapter::InitSubscribers()
{
    using namespace ROS_SUBSCRIBER_TOPICS;
    if (!standalone_mode_)
    {
        radar_feedback_subscriber_ = node_->create_subscription<msg_swc_common::msg::MsgNodeFeedbackType>(
            TOPIC_NODE_FEEDBACK, 10, std::bind(&VideoReplayAdapter::RadarFeedbackCB, this, std::placeholders::_1));

        return;
    }

    trigger_single_frame_subscriber_ = node_->create_subscription<server_replay_video::msg::MsgTriggerSingleFrame>(
        TOPIC_TRIGGER_VIDEO_NEXT_FRAME, 10,
        std::bind(&VideoReplayAdapter::TriggerNextFrameCB, this, std::placeholders::_1));

    set_pause_mode_subscriber_ = node_->create_subscription<server_replay_video::msg::MsgSetPauseMode>(
        TOPIC_SET_VIDEO_PAUSE_MODE, 10, std::bind(&VideoReplayAdapter::SetPauseModeCB, this, std::placeholders::_1));
}

void VideoReplayAdapter::InitTimers()
{
    if (standalone_mode_)
    {
        publish_timer_ = node_->create_wall_timer(std::chrono::milliseconds(TIMER_MS),
                                                  std::bind(&VideoReplayAdapter::PublishTimerCB, this));
    }
}

void VideoReplayAdapter::RadarFeedbackCB(msg_swc_common::msg::MsgNodeFeedbackType::UniquePtr msg)
{
    auto radar_ts = msg->radar_timestamp;
    PublishVideoFramesUntil(radar_ts);
}

void VideoReplayAdapter::TriggerNextFrameCB(server_replay_video::msg::MsgTriggerSingleFrame::UniquePtr msg)
{
    (void)msg;
    // Only in pause mode.
    if (pause_playback_)
    {
        PublishNextVideoFrame();
    }
}

void VideoReplayAdapter::SetPauseModeCB(server_replay_video::msg::MsgSetPauseMode::UniquePtr msg)
{
    pause_playback_ = msg->pause_playback;
}

void VideoReplayAdapter::PublishTimerCB()
{
    static std::chrono::time_point<std::chrono::system_clock> start_time;
    static int64_t first_message_timestamp = 0;

    if (pause_playback_)
    {
        first_message_timestamp = 0;
        return;
    }

    if (!video_frames_queue_.Empty())
    {
        auto ros_video_frame = video_frames_queue_.Pop();
        int64_t next_timestamp = ros_video_frame.timestamp;

        if (first_message_timestamp == 0)
        {
            first_message_timestamp = next_timestamp;
            start_time = std::chrono::system_clock::now();
        }

        auto time_delta = std::chrono::nanoseconds(next_timestamp - first_message_timestamp);
        std::this_thread::sleep_until(start_time + std::chrono::duration_cast<std::chrono::nanoseconds>(time_delta));

        mf4_video_publisher_.publish(std::move(ros_video_frame.image_ptr));
        PublishStatus(ros_video_frame);
    }
}

void VideoReplayAdapter::StartReaderThread()
{
    continue_reading_.store(true);
    reader_thread_ = std::thread(&VideoReplayAdapter::ReadWorker, this);
}

void VideoReplayAdapter::PublishNextVideoFrame()
{
    if (!video_frames_queue_.Empty())
    {
        auto ros_video_frame = video_frames_queue_.Pop();
        mf4_video_publisher_.publish(std::move(ros_video_frame.image_ptr));
        PublishStatus(ros_video_frame);
    }
}

void VideoReplayAdapter::PublishVideoFramesUntil(int64_t timestamp)
{
    if (!end_of_mf4_files_ || !video_frames_queue_.Empty())
    {
        auto next_frames = video_frames_queue_.PopUntilTime(timestamp);
        for (const auto& frame : next_frames)
        {
            mf4_video_publisher_.publish(std::move(frame.image_ptr));
            PublishStatus(frame);
        }
    }
}

void VideoReplayAdapter::PublishStatus(const RosVideoFrame& ros_video_frame)
{
    auto status_msg = std::make_unique<server_replay_video::msg::MsgVideoReplayStatus>();
    rclcpp::Time time(ros_video_frame.timestamp);
    status_msg->header.stamp = time;

    status_msg->video_timestamp = ros_video_frame.timestamp;
    status_msg->file_under_process = ros_video_frame.file_name;
    status_msg->elapsed_time = ros_video_frame.elapsed_time;

    if (end_of_mf4_files_ && video_frames_queue_.Empty())
    {
        status_msg->status = server_replay_video::msg::MsgVideoReplayStatus::FINISHED;
    }
    else
    {
        status_msg->status = server_replay_video::msg::MsgVideoReplayStatus::IN_PROGRESS;
    }

    status_publisher_->publish(std::move(status_msg));
}

void VideoReplayAdapter::StopReaderThread()
{
    continue_reading_.store(false);
    if (reader_thread_.joinable())
    {
        reader_thread_.join();
    }
}

void VideoReplayAdapter::ReadWorker()
{
    while (!end_of_mf4_files_ && continue_reading_.load())
    {
        ReadNextFile();
    }
}

void VideoReplayAdapter::ReadNextFile()
{
    static bool new_file = false;
    if (!mf4_file_opened_)
    {
        if (mf4_files_queue_.empty())
        {
            end_of_mf4_files_ = true;
            return;
        }

        replay_lib_.Reset();
        std::string next_mf4_file = mf4_files_queue_.front();
        mf4_files_queue_.pop();
        num_files_processed_ = num_files_to_process_ - mf4_files_queue_.size();
        OpenMf4File(next_mf4_file);
        new_file = true;

        if (record_rosbags_)
        {
            std::string rosbag_path = RemoveExtensionFromFilePath(next_mf4_file) + ".ros2bag";
            rosbag_writer_.reset();
            rosbag_writer_ = std::make_shared<RosbagWriter>(rosbag_path, "");
            rosbag_ready_for_write_ = rosbag_writer_->OpenFile();
        }
    }

    auto mdf_message = mdf_player_.ReadNextMessage();
    if (mdf_message == nullptr)
    {
        CloseMf4File();
        return;
    }

    if (!replay_lib_.m_VideoDataRef.empty())
    {

        while (replay_lib_.m_VideoDataRef.empty() == false)
        {
            VideoData_s* video_data = replay_lib_.m_VideoDataRef.front();

            if (video_data->isValid)
            {
                ProcessVideoFrame(*video_data, opened_mf4_file_path_, new_file);
                new_file = false;
            }
            replay_lib_.m_VideoDataRef.pop();
        }
    }
}

void VideoReplayAdapter::ProcessVideoFrame(const VideoData_s& video_data, const std::string& mf4_file_path,
                                           bool new_file)
{

    static int64_t file_first_timestamp{0};
    std::vector<std::uint8_t> jpeg_data{};
    jpeg_data = video_data.JPegHeader;

    const std::uint8_t* jpeg_payload_ptr = &video_data.JPEGPayload[0];
    auto curr_jpeg_data_size = video_data.JPEGPayload.size();
    auto previous_jpeg_data_size = jpeg_data.size();
    jpeg_data.resize(curr_jpeg_data_size + previous_jpeg_data_size);
    std::memcpy(&jpeg_data[previous_jpeg_data_size], jpeg_payload_ptr, curr_jpeg_data_size);

    cv::Mat jpeg_buf(1, jpeg_data.size(), CV_8UC1, (void*)jpeg_data.data());
    cv::Mat decoded_data = cv::imdecode(jpeg_buf, cv::IMREAD_ANYCOLOR);

    if (show_timestamp_)
    {
        std::string timestamp_str = "Timestamp : " + std::to_string(video_data.TimeStamp);
        cv::putText(decoded_data, timestamp_str, cv::Point(10, 30), cv::FONT_HERSHEY_DUPLEX, 1.2, CV_RGB(255, 0, 0), 2);
    }

    auto header = std_msgs::msg::Header();
    header.frame_id = "/map";
    rclcpp::Time time(video_data.TimeStamp);
    header.stamp = time;
    cv_bridge::CvImage mdf_image_data(header, "bgr8", decoded_data);

    RosVideoFrame ros_video_frame;
    ros_video_frame.image_ptr = mdf_image_data.toImageMsg();
    ros_video_frame.timestamp = video_data.TimeStamp;

    if (new_file)
    {
        file_first_timestamp = video_data.TimeStamp;
    }
    ros_video_frame.elapsed_time = (float)(video_data.TimeStamp - file_first_timestamp) * 1e-9;
    ros_video_frame.file_name = mf4_file_path;

    if (rosbag_ready_for_write_)
    {
        rosbag_writer_->Write(ros_video_frame.image_ptr.get(), time);
    }

    video_frames_queue_.Push(std::move(ros_video_frame));
}

void VideoReplayAdapter::OpenMf4File(const std::string& file_path)

{
    CloseMf4File();
    if (file_path.length() > 0 && FileExists(file_path))

    {
        mf4_file_opened_ = mdf_player_.Open(file_path);
        if (mf4_file_opened_)
        {
            RCLCPP_INFO(node_->get_logger(), "Opened video mf4 file : %s", file_path.c_str());
            opened_mf4_file_path_ = file_path;
            end_of_mf4_files_ = false;
        }
    }

    else
    {
        RCLCPP_ERROR(node_->get_logger(), "Error opening file : %s. Check if file exists!!", file_path.c_str());
    }
}

void VideoReplayAdapter::CloseMf4File()
{
    if (mf4_file_opened_)
    {
        mdf_player_.Close();
        mf4_file_opened_ = false;
    }
}

void VideoReplayAdapter::CloseFileHandles()
{
    CloseMf4File();
    if (rosbag_writer_)
    {
        rosbag_writer_->CloseFile();
    }
}

bool VideoReplayAdapter::FileExists(const std::string& file_path)
{
    struct stat buffer;
    return (stat(file_path.c_str(), &buffer) == 0);
}

std::string VideoReplayAdapter::RemoveExtensionFromFilePath(const std::string& file_path)
{
    size_t lastdot = file_path.find_last_of(".");
    if (lastdot == std::string::npos)
    {
        return file_path;
    }
    return file_path.substr(0, lastdot);
}