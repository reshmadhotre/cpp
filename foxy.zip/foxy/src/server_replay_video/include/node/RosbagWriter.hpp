#ifndef ROSBAG_WRITER_HPP
#define ROSBAG_WRITER_HPP

#include "rclcpp/clock.hpp"
#include "rclcpp/serialization.hpp"
#include "rclcpp/serialized_message.hpp"
#include <iostream>
#include <map>

#include "rcpputils/filesystem_helper.hpp"
#include "rcutils/time.h"

#include "rosbag2_cpp/reader.hpp"
#include "rosbag2_cpp/readers/sequential_reader.hpp"
#include "rosbag2_cpp/writer.hpp"
#include "rosbag2_cpp/writers/sequential_writer.hpp"

#include "sensor_msgs/msg/image.hpp"
struct RosbagEntry
{
    rclcpp::Time msg_time;
    std::shared_ptr<rclcpp::SerializedMessage> serialized_msg;
    rosbag2_storage::TopicMetadata topic_meta_data;
};
class RosbagWriter
{
  public:
    RosbagWriter(const std::string& rosbag_path, const std::string& node_namespace);
    ~RosbagWriter();
    bool OpenFile();
    void CloseFile();

    template <class RosMsgClass> bool Write(RosMsgClass* msg, const rclcpp::Time& time)
    {
        auto rosbag_entry = std::make_shared<RosbagEntry>();
        auto serialized_msg = std::make_shared<rclcpp::SerializedMessage>();
        rclcpp::Serialization<RosMsgClass> serialization;
        serialization.serialize_message(msg, serialized_msg.get());

        rosbag_entry->serialized_msg = serialized_msg;
        auto topic_metadata = GetTopicMetadataFromMsgType(rosidl_generator_traits::name<RosMsgClass>());
        if (topic_metadata.name == "")
        {
            return false;
        }
        rosbag_entry->topic_meta_data = topic_metadata;
        rosbag_entry->msg_time = time;

        return Write(rosbag_entry);
    }

  private:
    std::shared_ptr<rosbag2_storage::SerializedBagMessage> CreateSerializedBagMessage(
        std::shared_ptr<RosbagEntry> rosbag_entry);
    bool Write(std::shared_ptr<RosbagEntry> rosbag_entry);
    rosbag2_storage::TopicMetadata GetTopicMetadataFromMsgType(const std::string& msg_type);

    std::string node_namespace_{""};
    std::string rosbag_path_;
    std::shared_ptr<rosbag2_cpp::writers::SequentialWriter> writer_;
    bool writer_initialized_{false};
    std::vector<std::string> created_rosbag_topics_;
    const static std::map<std::string, std::string> TOPIC_MSG_TYPE_MAP;
};
#endif
