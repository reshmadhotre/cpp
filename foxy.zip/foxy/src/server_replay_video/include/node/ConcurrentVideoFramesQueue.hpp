#ifndef CONCURRENT_VIDEO_FRAMES_QUEUE_HPP
#define CONCURRENT_VIDEO_FRAMES_QUEUE_HPP

#include "sensor_msgs/msg/image.hpp"
#include <condition_variable>
#include <iostream>
#include <mutex>
#include <queue>
#include <thread>

struct RosVideoFrame
{
    std::shared_ptr<sensor_msgs::msg::Image> image_ptr;
    int64_t timestamp;
    std::string file_name;
    float elapsed_time;
};

class ConcurrentVideoFramesQueue
{
  public:
    RosVideoFrame Pop()
    {
        std::unique_lock<std::mutex> mlock(mutex_);
        while (queue_.empty())
        {
            cv_.wait(mlock);
        }
        auto val = queue_.front();
        queue_.pop();
        mlock.unlock();
        cv_.notify_all();
        return val;
    }

    std::vector<RosVideoFrame> PopUntilTime(int64_t timestamp)
    {
        std::unique_lock<std::mutex> mlock(mutex_);
        while (queue_.empty())
        {
            cv_.wait(mlock);
        }

        std::vector<RosVideoFrame> frames;
        bool found_timestamp{false};

        while (!queue_.empty() && !found_timestamp)
        {
            auto next_frame = queue_.front();
            auto ts = next_frame.timestamp;

            if (ts > timestamp)
            {
                found_timestamp = true;
            }
            else
            {
                frames.push_back(next_frame);
                queue_.pop();
            }
        }
        mlock.unlock();
        cv_.notify_all();

        return frames;
    }

    void Push(const RosVideoFrame& item)
    {

        std::unique_lock<std::mutex> mlock(mutex_);
        while (queue_.size() >= MAX_BUFFER_SIZE)
        {
            cv_.wait(mlock);
        }
        queue_.push(item);
        mlock.unlock();
        cv_.notify_all();
    }

    void Push(RosVideoFrame&& item)
    {
        std::unique_lock<std::mutex> mlock(mutex_);
        while (queue_.size() >= MAX_BUFFER_SIZE)
        {
            cv_.wait(mlock);
        }
        queue_.push(std::move(item));
        mlock.unlock();
        cv_.notify_all();
    }

    bool Empty()
    {
        std::unique_lock<std::mutex> mlock(mutex_);
        bool empty = queue_.empty();
        mlock.unlock();
        cv_.notify_all();
        return empty;
    }

    ConcurrentVideoFramesQueue() = default;
    ConcurrentVideoFramesQueue(const ConcurrentVideoFramesQueue&) = delete;
    ConcurrentVideoFramesQueue& operator=(const ConcurrentVideoFramesQueue&) = delete;

  private:
    std::queue<RosVideoFrame> queue_;
    std::mutex mutex_;
    std::condition_variable cv_;
    const static unsigned int MAX_BUFFER_SIZE = 500;
};

#endif