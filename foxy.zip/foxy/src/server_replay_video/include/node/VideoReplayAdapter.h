#ifndef VIDEO_REPLAY_ADAPTER_H
#define VIDEO_REPLAY_ADAPTER_H

#include "ConcurrentVideoFramesQueue.hpp"
#include "ReplayLibrary.h"
#include "RosbagWriter.hpp"
#include "msg_swc_common/msg/msg_node_feedback_type.hpp"
#include "opencv4/opencv2/opencv.hpp"
#include "rcl_interfaces/msg/set_parameters_result.hpp"
#include "server_replay_video/msg/msg_set_pause_mode.hpp"
#include "server_replay_video/msg/msg_trigger_single_frame.hpp"
#include "server_replay_video/msg/msg_video_replay_status.hpp"
#include <atomic>
#include <cv_bridge/cv_bridge.h>
#include <image_transport/image_transport.hpp>
#include <queue>

namespace ROS_PARAM_NAMES
{
const std::string REPLAY_MF4_VIDEO_FILEPATHS{"replay_mf4_video_filepaths"};
const std::string RECORD_ROSBAGS{"record_rosbags"};
const std::string STANDALONE_MODE{"standalone_mode"};
const std::string SHOW_TIMESTAMP{"show_timestamp"};
} // namespace ROS_PARAM_NAMES

namespace ROS_PUBLISHER_TOPICS
{
const std::string TOPIC_MF4_VIDEO{"topic_mf4_video"};
const std::string TOPIC_SERVER_REPLAY_VIDEO_STATUS{"topic_server_replay_video_status"};
} // namespace ROS_PUBLISHER_TOPICS

namespace ROS_SUBSCRIBER_TOPICS
{
const std::string TOPIC_NODE_FEEDBACK{"topic_node_feedback"};
const std::string TOPIC_TRIGGER_VIDEO_NEXT_FRAME{"topic_trigger_video_next_frame"};
const std::string TOPIC_SET_VIDEO_PAUSE_MODE{"topic_set_video_pause_mode"};
} // namespace ROS_SUBSCRIBER_TOPICS

const uint32_t TIMER_MS{1};
class VideoReplayAdapter
{
  public:
    VideoReplayAdapter(std::shared_ptr<rclcpp::Node> node);
    ~VideoReplayAdapter();
    void StartReaderThread();
    void StopReaderThread();
    void CloseFileHandles();
    void ReadNextFile();

  private:
    void InitRosParams();
    void GetFilePaths();
    void InitSubscribers();
    void InitPublishers();
    void InitTimers();

    // Callbacks
    void RadarFeedbackCB(msg_swc_common::msg::MsgNodeFeedbackType::UniquePtr msg);
    void TriggerNextFrameCB(server_replay_video::msg::MsgTriggerSingleFrame::UniquePtr msg);
    void SetPauseModeCB(server_replay_video::msg::MsgSetPauseMode::UniquePtr msg);
    void PublishTimerCB();

    void OpenMf4File(const std::string& file_path);
    void CloseMf4File();
    bool FileExists(const std::string& file_path);
    void ProcessVideoFrame(const VideoData_s& video_data, const std::string& mf4_file_path, bool new_file);
    void ReadWorker();
    void PublishNextVideoFrame();
    void PublishVideoFramesUntil(int64_t timestamp);
    void PublishStatus(const RosVideoFrame& ros_video_frame);
    std::string RemoveExtensionFromFilePath(const std::string& file_path);

    mdfp::MDFPlayer mdf_player_;
    ReplayLibrary replay_lib_;

    std::shared_ptr<RosbagWriter> rosbag_writer_;
    bool rosbag_ready_for_write_{false};

    // ROS Params
    std::vector<std::string> mf4_files_to_play_;
    bool record_rosbags_;
    bool standalone_mode_;
    bool show_timestamp_;
    bool pause_playback_{false};

    std::thread reader_thread_;
    std::atomic<bool> continue_reading_;
    ConcurrentVideoFramesQueue video_frames_queue_;

    std::queue<std::string> mf4_files_queue_;
    bool end_of_mf4_files_{false};
    bool mf4_file_opened_{false};
    std::string opened_mf4_file_path_{""};
    int64_t file_first_timestamp_{0};
    uint8_t num_files_to_process_{0};
    uint8_t num_files_processed_{0};

    std::shared_ptr<rclcpp::Node> node_;
    rclcpp::Subscription<msg_swc_common::msg::MsgNodeFeedbackType>::SharedPtr radar_feedback_subscriber_;
    rclcpp::Subscription<server_replay_video::msg::MsgTriggerSingleFrame>::SharedPtr trigger_single_frame_subscriber_;
    rclcpp::Subscription<server_replay_video::msg::MsgSetPauseMode>::SharedPtr set_pause_mode_subscriber_;
    image_transport::Publisher mf4_video_publisher_;
    rclcpp::Publisher<server_replay_video::msg::MsgVideoReplayStatus>::SharedPtr status_publisher_;
    rclcpp::TimerBase::SharedPtr publish_timer_;
};
#endif