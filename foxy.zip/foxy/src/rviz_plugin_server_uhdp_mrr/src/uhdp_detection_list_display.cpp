#include "uhdp_detection_list_display.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>

namespace rviz_plugin_server_uhdp_mrr
{

UhdpDetectionListDisplay::UhdpDetectionListDisplay()
{
    keep_visualizations_ = true;
    keep_visualizations_property_ =
        new rviz_common::properties::BoolProperty("Keep Visualizations", keep_visualizations_,
                                                  "Keep Visualizations if no update received. Visualizations for this \
				display plugin are not cleared after set timeout and \
				persist until a new message is recieved.",
                                                  this, SLOT(updateKeepVisualizations()));

    restrict_fov_value_ = false;
    restrict_fov_property_ = new rviz_common::properties::BoolProperty(
        "Restrict FOV", restrict_fov_value_, "Restrict FOV to the value defined by FOV Value property.", this,
        SLOT(updateRestrictFOV()));

    fov_value_radians_ = (Ogre::Math::PI * 90.0) / 180.0; // -90 deg to +90 deg
    fov_value_property_ = new rviz_common::properties::FloatProperty(
        "FOV Value (degrees)", 90.0,
        "FOV (degrees) of the detections to display. Detections in the range +value to -value are displayed.", this,
        SLOT(updateFOV()));

    fov_value_property_->setHidden(!restrict_fov_property_->getBool());
}

void UhdpDetectionListDisplay::onInitialize()
{
    MFDClass::onInitialize();
}

UhdpDetectionListDisplay::~UhdpDetectionListDisplay()
{
}

void UhdpDetectionListDisplay::reset()
{
    MFDClass::reset();
    clearVisuals();
}

void UhdpDetectionListDisplay::onEnable()
{
    MFDClass::onEnable();
}

void UhdpDetectionListDisplay::onDisable()
{
    MFDClass::onDisable();
}

void UhdpDetectionListDisplay::clearVisuals()
{
    static_detection_visuals_.clear();
    dynamic_detection_visuals_.clear();
}

void UhdpDetectionListDisplay::updateKeepVisualizations()
{
    keep_visualizations_ = keep_visualizations_property_->getBool();
}

void UhdpDetectionListDisplay::updateRestrictFOV()
{
    restrict_fov_value_ = restrict_fov_property_->getBool();
    fov_value_property_->setHidden(!restrict_fov_value_);
}

void UhdpDetectionListDisplay::updateFOV()
{
    float fov_value_degrees = fov_value_property_->getFloat();
    fov_value_radians_ = (Ogre::Math::PI * fov_value_degrees) / 180.0;
}

void UhdpDetectionListDisplay::update(float wall_dt, float ros_dt)
{
    Q_UNUSED(wall_dt);
    Q_UNUSED(ros_dt);

    if (!keep_visualizations_)
    {
        auto current_time = std::chrono::steady_clock::now();
        std::chrono::duration<float, std::milli> time_elapsed_secs = ((current_time - msg_receive_time_) / 1000.0);
        if (time_elapsed_secs.count() >= visual_decay_time_secs_)
        {
            clearVisuals();
        }
    }
}

bool UhdpDetectionListDisplay::displayDetection(const msg_replay_radar::msg::MsgGenCoorPolarType& detection)
{
    bool display_detection{true};

    // Check if detection is within the set FOV
    if (restrict_fov_value_)
    {
        display_detection =
            display_detection && (detection.azimuth <= fov_value_radians_ && detection.azimuth >= -fov_value_radians_);
    }

    return display_detection;
}

void UhdpDetectionListDisplay::processMessage(msg_replay_radar::msg::MsgRdcDetnListRvizType::ConstSharedPtr msg)
{
    msg_receive_time_ = std::chrono::steady_clock::now();

    Ogre::Quaternion orientation;
    Ogre::Vector3 position;
    if (!context_->getFrameManager()->getTransform(msg->header.frame_id, msg->header.stamp, position, orientation))
    {
        std::cout << "Error transforming from frame :" << msg->header.frame_id
                  << "to frame : " << qPrintable(fixed_frame_) << std::endl;

        return;
    }
    uint16_t num_valid_detections = msg->num_elem_per_scan[0];

    static_detection_visuals_.resize(num_valid_detections);
    dynamic_detection_visuals_.resize(num_valid_detections);

    uint16_t num_static_detections{0};
    uint16_t num_dynamic_detections{0};
    msg_replay_radar::msg::MsgGenCoorPolarType detection{};
    for (uint16_t i = 0; i < num_valid_detections; i++)
    {

        detection = msg->coor_polar.at(i);
        std::shared_ptr<UhdpDetectionVisual> detection_visual;

        if (displayDetection(detection))
        {
            auto detection_flags = msg->flags.at(i);

            // Static Detections
            if (detection_flags & UhdpDetectionListDisplay::eDetFlags::DF_Static ||
                detection_flags & UhdpDetectionListDisplay::eDetFlags::DF_FromStaticSlice)
            {
                // Create new visual if required
                if (static_detection_visuals_.at(num_static_detections) == nullptr)
                {
                    static_detection_visuals_.at(num_static_detections) = std::make_shared<UhdpDetectionVisual>(
                        context_->getSceneManager(), scene_node_, UhdpDetectionVisual::DetectionType_E::STATIC);
                }

                detection_visual = static_detection_visuals_.at(num_static_detections);
                detection_visual->setFramePosition(position);
                detection_visual->setFrameOrientation(orientation);
                detection_visual->setMessage(detection);

                num_static_detections++;
            }

            // Dynamic Detections
            else
            {
                // Create new visual if required
                if (dynamic_detection_visuals_.at(num_dynamic_detections) == nullptr)
                {
                    dynamic_detection_visuals_.at(num_dynamic_detections) = std::make_shared<UhdpDetectionVisual>(
                        context_->getSceneManager(), scene_node_, UhdpDetectionVisual::DetectionType_E::DYNAMIC);
                }

                detection_visual = dynamic_detection_visuals_.at(num_dynamic_detections);
                detection_visual->setFramePosition(position);
                detection_visual->setFrameOrientation(orientation);
                detection_visual->setMessage(detection);

                num_dynamic_detections++;
            }
        }
    }

    // Remove any extra visuals
    static_detection_visuals_.resize(num_static_detections);
    dynamic_detection_visuals_.resize(num_dynamic_detections);
}

} // namespace rviz_plugin_server_uhdp_mrr

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(rviz_plugin_server_uhdp_mrr::UhdpDetectionListDisplay, rviz_common::Display)
