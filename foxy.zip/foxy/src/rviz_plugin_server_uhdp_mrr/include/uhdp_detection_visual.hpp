#ifndef UHDP_DETECTION_VISUAL_H
#define UHDP_DETECTION_VISUAL_H
#include "msg_replay_radar/msg/msg_rra_detection_data.hpp"
#include "msg_replay_radar/msg/msg_gen_coor_polar_type.hpp"
#include "visibility_control.hpp"
#include <rviz_rendering/objects/shape.hpp>

namespace rviz_plugin_server_uhdp_mrr
{

class REC_REPLAY_PLUGIN_PUBLIC UhdpDetectionVisual
{
  public:
    enum DetectionType_E
    {
        STATIC = 0,
        DYNAMIC
    };

    UhdpDetectionVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node,
                        UhdpDetectionVisual::DetectionType_E detection_type);
    virtual ~UhdpDetectionVisual();

    void setMessage(const msg_replay_radar::msg::MsgGenCoorPolarType& detection);
    void setFramePosition(const Ogre::Vector3& position);
    void setFrameOrientation(const Ogre::Quaternion& orientation);

  private:
    Ogre::Vector3 getROSCartesianCoordinates(const msg_replay_radar::msg::MsgGenCoorPolarType& detection);
    std::shared_ptr<rviz_rendering::Shape> detection_shape_;

    Ogre::SceneNode* frame_node_;
    Ogre::SceneManager* scene_manager_;

    const static float DETECTION_SPHERE_RADIUS;
    const static Ogre::ColourValue STATIC_DETECTION_COLOUR_VALUE_YELLOW;
    const static Ogre::ColourValue DYNAMIC_DETECTION_COLOUR_VALUE_GREEN;
    const static rviz_rendering::Shape::Type STATIC_DETECTION_SHAPE_TYPE;
    const static rviz_rendering::Shape::Type DYNAMIC_DETECTION_SHAPE_TYPE;
};
} // namespace rviz_plugin_server_uhdp_mrr

#endif