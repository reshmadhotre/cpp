#ifndef UHDP_POINT_CLOUD_UHDP_DISPLAY_H
#define UHDP_POINT_CLOUD_UHDP_DISPLAY_H

#include "msg_replay_radar/msg/msg_rdc_point_cloud_list_rviz_type.hpp"
#include "uhdp_point_cloud_visual.hpp"
#include "visibility_control.hpp"
#include <algorithm>
#include <chrono>
#include <rviz_common/message_filter_display.hpp>
#include <rviz_common/properties/bool_property.hpp>
#include <rviz_common/properties/float_property.hpp>

namespace rviz_plugin_server_uhdp_mrr
{
class REC_REPLAY_PLUGIN_PUBLIC UhdpPointCloudDisplay
    : public rviz_common::MessageFilterDisplay<msg_replay_radar::msg::MsgRdcPointCloudListRvizType>
{
    Q_OBJECT

  public:
    UhdpPointCloudDisplay();
    ~UhdpPointCloudDisplay();

    void onInitialize() override;
    void reset() override;
    virtual void update(float wall_dt, float ros_dt);

  protected:
    void onEnable() override;
    void onDisable() override;

  private slots:
    void updateKeepVisualizations();
    void updateRestrictFOV();
    void updateFOV();

  private:
    void processMessage(msg_replay_radar::msg::MsgRdcPointCloudListRvizType::ConstSharedPtr msg) override;
    void clearVisuals();
    bool displayPoint(const point_cloud_list& point);

    std::chrono::steady_clock::time_point msg_receive_time_;
    std::vector<std::shared_ptr<UhdpPointCloudVisual>> point_cloud_visuals_;
    float visual_decay_time_secs_{0.5};
    rviz_common::properties::BoolProperty* keep_visualizations_property_;
    rviz_common::properties::BoolProperty* restrict_fov_property_;
    rviz_common::properties::FloatProperty* fov_value_property_;
    bool keep_visualizations_;
    bool restrict_fov_value_;
    float fov_value_radians_;
};
} // namespace rviz_plugin_server_uhdp_mrr
#endif