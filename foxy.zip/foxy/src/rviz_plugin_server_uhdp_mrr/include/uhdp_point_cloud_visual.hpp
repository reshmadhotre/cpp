#ifndef UHDP_POINT_CLOUD_VISUAL_H
#define UHDP_POINT_CLOUD_VISUAL_H

#include "msg_replay_radar/msg/msg_rra_point_cloud_data_float.hpp"
#include "visibility_control.hpp"
#include <rviz_rendering/objects/shape.hpp>

namespace rviz_plugin_server_uhdp_mrr
{

struct point_cloud_list
{
  float range; 
  float azimuth;
  float elevation;
};

class REC_REPLAY_PLUGIN_PUBLIC UhdpPointCloudVisual
{
  public:
    explicit UhdpPointCloudVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node);
    virtual ~UhdpPointCloudVisual();

    void setMessage(const point_cloud_list& point);
    void setFramePosition(const Ogre::Vector3& position);
    void setFrameOrientation(const Ogre::Quaternion& orientation);

  private:
    Ogre::Vector3 getROSCartesianCoordinates(const point_cloud_list& detection);

    std::shared_ptr<rviz_rendering::Shape> point_shape_;
    Ogre::SceneNode* frame_node_;
    Ogre::SceneManager* scene_manager_;

    const static float POINT_SPHERE_RADIUS;
    const static Ogre::ColourValue POINT_COLOUR_VALUE_RED;
    const static rviz_rendering::Shape::Type POINT_SHAPE_TYPE;
};
} // namespace rviz_plugin_server_uhdp_mrr

#endif