#ifndef UHDP_DETECTION_LIST_DISPLAY_H
#define UHDP_DETECTION_LIST_DISPLAY_H

#include "msg_replay_radar/msg/msg_rdc_detn_list_rviz_type.hpp"
#include "uhdp_detection_visual.hpp"
#include "visibility_control.hpp"
#include <algorithm>
#include <chrono>
#include <rviz_common/message_filter_display.hpp>
#include <rviz_common/properties/bool_property.hpp>
#include <rviz_common/properties/float_property.hpp>

namespace rviz_plugin_server_uhdp_mrr
{
class REC_REPLAY_PLUGIN_PUBLIC UhdpDetectionListDisplay
    : public rviz_common::MessageFilterDisplay<msg_replay_radar::msg::MsgRdcDetnListRvizType>
{
    Q_OBJECT

    enum eDetFlags
    {
        DF_Static = (1 << 0),
        DF_Filtered = (1 << 1),
        DF_Reinterpolate = (1 << 2),
        DF_FromStaticSlice = (1 << 3),
    };

  public:
    UhdpDetectionListDisplay();
    ~UhdpDetectionListDisplay();

    void onInitialize() override;
    void reset() override;
    virtual void update(float wall_dt, float ros_dt);

  protected:
    void onEnable() override;
    void onDisable() override;

  private slots:
    void updateKeepVisualizations();
    void updateRestrictFOV();
    void updateFOV();

  private:
    void processMessage(msg_replay_radar::msg::MsgRdcDetnListRvizType::ConstSharedPtr msg) override;
    void clearVisuals();
    bool displayDetection(const msg_replay_radar::msg::MsgGenCoorPolarType& detection);

    std::chrono::steady_clock::time_point msg_receive_time_;
    std::vector<std::shared_ptr<UhdpDetectionVisual>> static_detection_visuals_;
    std::vector<std::shared_ptr<UhdpDetectionVisual>> dynamic_detection_visuals_;

    float visual_decay_time_secs_{0.5};
    rviz_common::properties::BoolProperty* keep_visualizations_property_;
    rviz_common::properties::BoolProperty* restrict_fov_property_;
    rviz_common::properties::FloatProperty* fov_value_property_;
    bool keep_visualizations_;
    bool restrict_fov_value_;
    float fov_value_radians_;
};
} // namespace rviz_plugin_server_uhdp_mrr

#endif
