/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_Parquet_In.cpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */


#include "MERdrDataCubeMidW_Parquet_In.hpp"

#include <thread>
#include <iostream>
#include "rclcpp/rclcpp.hpp"



MERdrDataCubeMidW_Parquet_In::MERdrDataCubeMidW_Parquet_In() : MERdrDataCubeMidW_Parquet()
{
    init_parquet_headers();
}


MERdrDataCubeMidW_Parquet_In::~MERdrDataCubeMidW_Parquet_In()
{
}


void MERdrDataCubeMidW_Parquet_In::init_parquet_headers()
{
    parquet_init_midw_all_int_data();
    parquet_init_blkgroad();
    parquet_init_completetrigger();
    parquet_init_diagscan();
    parquet_init_radarcfg();
    parquet_init_recordreplay();
    parquet_init_scan();
    parquet_init_scanpara();
    parquet_init_scanready();
    parquet_init_sensrmtn();
    parquet_init_trigger_process();
    parquet_init_trigger_cyclic();
}


/*----------------------------------------------------------------------------*/
/*  INITIALIZE DATA FOR PARQUET                                               */
/*----------------------------------------------------------------------------*/

void MERdrDataCubeMidW_Parquet_In::parquet_init_midw_all_int_data(void)
{
    add_message("Midw_All_Int_Data", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});
    
    add_signals("Midw_All_Int_Data", {
        {"R_Header_Data_Valid", parquet_lib::DataType::BOOL},
        {"R_Header_Data_Busy", parquet_lib::DataType::BOOL},
        {"R_Header_Scan_Loop_Size", parquet_lib::DataType::UINT8},
        {"R_Header_Header_Size", parquet_lib::DataType::UINT8},
        {"R_Header_Main_Data_Size", parquet_lib::DataType::UINT32},
        {"R_Header_Aux_Data_Size", parquet_lib::DataType::UINT32},
        {"Aux_Data_Aux", parquet_lib::DataType::UINT32},
    });

    std::string prefix{""};
    for (size_t idx = 0; idx < 4; idx++)
    {
        prefix = "_#_" + std::to_string(idx) + "_";
        add_signals("Midw_All_Int_Data", {
            {"Scan_Info"+prefix+"Scan_Sequence_Numbers", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"Scan_Info"+prefix+"Scan_Timestamps", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"Detection_List"+prefix+"Num_Elem_Per_Scan", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"Detection_List"+prefix+"Coor_Polar_Range", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Detection_List"+prefix+"Coor_Polar_Azimuth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Detection_List"+prefix+"Coor_Polar_Elevation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Detection_List"+prefix+"Doppler", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Detection_List"+prefix+"Magnitude", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Detection_List"+prefix+"Sig_To_Noise_Rat", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Detection_List"+prefix+"Rdr_Cross_Sectn", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Detection_List"+prefix+"Flags", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"Rdc2_Data_Rdc2_Arr_Data_"+prefix+"_I", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Rdc2_Data_Rdc2_Arr_Data_"+prefix+"_Q", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Conv_Point_Cloud_list"+prefix+"Range", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Conv_Point_Cloud_list"+prefix+"Azimuth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Conv_Point_Cloud_list"+prefix+"Elevation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Conv_Point_Cloud_list"+prefix+"Doppler", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Conv_Point_Cloud_list"+prefix+"Snr_Db", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"Conv_Point_Cloud_list"+prefix+"Flags", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"Raw_Point_Cloud_list"+prefix+"Range", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"Raw_Point_Cloud_list"+prefix+"Azimuth_Fbin", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"Raw_Point_Cloud_list"+prefix+"Elevation_Fbin", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"Raw_Point_Cloud_list"+prefix+"Doppler_bin", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
        });

        add_signals("Midw_All_Int_Data", {
            {"Scan_Info"+prefix+"Scan_Dimension", parquet_lib::DataType::UINT8},
            {"Scan_Info"+prefix+"Scan_Set", parquet_lib::DataType::UINT8},
            {"Scan_Info"+prefix+"Ego_Rdr_VX", parquet_lib::DataType::FLOAT32},
            {"Scan_Info"+prefix+"Ego_Rdr_VY", parquet_lib::DataType::FLOAT32},
            {"Scan_Info"+prefix+"Ego_Rdr_VZ", parquet_lib::DataType::FLOAT32},
            {"Scan_Info"+prefix+"Ego_Rdr_Estimd_VX", parquet_lib::DataType::FLOAT32},
            {"Scan_Info"+prefix+"Ego_Rdr_Estimd_VY", parquet_lib::DataType::FLOAT32},
            {"Scan_Info"+prefix+"Ego_Rdr_Estimd_VZ", parquet_lib::DataType::FLOAT32},
            {"Scan_Params"+prefix+"Scan_Time", parquet_lib::DataType::FLOAT32},
            {"Scan_Params"+prefix+"Pulse_Time", parquet_lib::DataType::FLOAT32},
            {"Scan_Params"+prefix+"Chip_Time", parquet_lib::DataType::FLOAT32},
            {"Scan_Params"+prefix+"Doppler_Bin_Width", parquet_lib::DataType::FLOAT32},
            {"Scan_Params"+prefix+"Range_Bin_Width", parquet_lib::DataType::FLOAT32},
            {"Scan_Params"+prefix+"Pulses_Per_Scan", parquet_lib::DataType::UINT32},
            {"Scan_Params"+prefix+"Chips_Per_Pulse", parquet_lib::DataType::UINT32},
            {"Scan_Params"+prefix+"Code_Type", parquet_lib::DataType::UINT32},
            {"Scan_Params"+prefix+"Num_Range_Bins", parquet_lib::DataType::UINT16},
            {"Scan_Params"+prefix+"Num_Azimuth_Bins", parquet_lib::DataType::UINT16},
            {"Scan_Params"+prefix+"Num_Elevation_Bins", parquet_lib::DataType::UINT16},
            {"Scan_Params"+prefix+"Num_Vrx_Used", parquet_lib::DataType::UINT16},
            {"Scan_Params"+prefix+"Wrap_Azimuth_Angles", parquet_lib::DataType::BOOL},
            {"Scan_Params"+prefix+"Wrap_Elevation_Angles", parquet_lib::DataType::BOOL},
            {"Scan_Params"+prefix+"Scan_Lambda", parquet_lib::DataType::FLOAT32},
            {"Scan_Params"+prefix+"First_Range_Bin", parquet_lib::DataType::UINT16},
            {"Scan_Params"+prefix+"Azimuth_Sine_Bin_Size", parquet_lib::DataType::FLOAT32},
            {"Scan_Params"+prefix+"Azimuth_Sine_Zero_Location", parquet_lib::DataType::FLOAT32},
            {"Scan_Params"+prefix+"Elevation_Sine_Bin_Size", parquet_lib::DataType::FLOAT32},
            {"Scan_Params"+prefix+"Elevation_Sine_Zero_Location", parquet_lib::DataType::FLOAT32},
            {"Rdc2_Data_"+prefix+"_Num_Rd", parquet_lib::DataType::UINT32},
            {"Conv_Point_Cloud_list_"+prefix+"_Num_Elements", parquet_lib::DataType::UINT16},
            {"Raw_Point_Cloud_list_"+prefix+"_Num_Elements", parquet_lib::DataType::UINT16},
        });
    }
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_blkgroad(void)
{
    add_message("BLKGROAD", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("BLKGROAD", {
        {"RoadDetnEnblRq", parquet_lib::DataType::UINT8},
        {"RoadDetnDist", parquet_lib::DataType::FLOAT32}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_completetrigger(void)
{
    add_message("COMPLETETRIGGER", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("COMPLETETRIGGER", {
        {"ActivateAlgoProcessing", parquet_lib::DataType::BOOL}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_diagscan(void)
{
    add_message("DIAGSCAN", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("DIAGSCAN", {
        {"DiagScanSet_ScanSetHeader_NumScans", parquet_lib::DataType::UINT8},
        {"DiagScanSet_ScanSetHeader_ScanSetInterval", parquet_lib::DataType::UINT32},
        {"DiagnosticScanRq", parquet_lib::DataType::UINT8}
    });

    for(uint i=0 ; i<5 ; i++)
    {
        add_signals("DIAGSCAN", {
            {"DiagScanSet_ScanParameterArr_ScanPreset", parquet_lib::DataType::INT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_num_pi", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_num_si", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_ScanDimension", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_ScanType", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_detection_thresh_snr_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_clutter_image_thresh_snr_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_point_cloud_thresh_snr_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_scale_det_thresh_max_range", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_scale_det_thresh_snr_adj", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_ego_zero_stationary_threshold_mps", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_ego_nonz_stationary_threshold_mps", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_notch_width_radians", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_notch_depth_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_outer_depth_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_ridge_extra_thresh_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_FlagsOverrideEnable1", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_FlagsOverrideEnable2", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_FlagsOverrideValue1", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"DiagScanSet_ScanParameterArr_FlagsOverrideValue2", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST}
        });
    }
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_radarcfg(void)
{
    add_message("RADARCFG", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("RADARCFG", {
        {"RadarRole", parquet_lib::DataType::UINT8},
        {"FuncArr", parquet_lib::DataType::UINT32}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_recordreplay(void)
{
    add_message("RECORDREPLAY", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("RECORDREPLAY", {
        {"RecordReplaySt", parquet_lib::DataType::UINT8}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_scan(void)
{
    add_message("SCAN", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("SCAN", {
        {"ScanCfg", parquet_lib::DataType::UINT8}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_scanpara(void)
{
    add_message("SCANPARA", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    for(uint i=0 ; i<3 ; i++)
    {
        add_signals("SCANPARA", {
            {"ScanSets_ScanSetHeader_NumScans", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanSetHeader_ScanSetInterval", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST}
        });
    }

    for(uint i=0 ; i<5 ; i++)
    {
        add_signals("SCANPARA", {
            {"ScanSets_ScanParameterArr_ScanPreset", parquet_lib::DataType::INT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_num_pi", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_num_si", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_ScanDimension", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_ScanType", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_detection_thresh_snr_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_clutter_image_thresh_snr_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_point_cloud_thresh_snr_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_scale_det_thresh_max_range", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_scale_det_thresh_snr_adj", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_ego_zero_stationary_threshold_mps", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_ego_nonz_stationary_threshold_mps", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_notch_width_radians", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_notch_depth_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_outer_depth_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_ridge_extra_thresh_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_FlagsOverrideEnable1", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_FlagsOverrideEnable2", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_FlagsOverrideValue1", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"ScanSets_ScanParameterArr_FlagsOverrideValue2", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST}
        });
    }
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_scanready(void)
{
    add_message("SCANREADY", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("SCANREADY", {
        {"ScanReady", parquet_lib::DataType::BOOL}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_sensrmtn(void)
{
    add_message("SENSRMTN", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("SENSRMTN", {
        {"SnsrMtnData_V_VX", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_V_VY", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_V_VZ", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_VStdDe_VX", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_VStdDe_VY", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_VStdDe_VZ", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_VEstimnSt", parquet_lib::DataType::UINT8},
        {"SnsrMtnData_A_AX", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_A_AY", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_A_AZ", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_AStdDe_AX", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_AStdDe_AY", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_AStdDe_AZ", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_AEstimnSt", parquet_lib::DataType::UINT8},
        {"SnsrMtnData_YawRate", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_YawRateStdDe", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_YawRateSt", parquet_lib::DataType::UINT8},
        {"SnsrMtnData_CrvRd", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_CrvRdStdDe", parquet_lib::DataType::FLOAT32},
        {"SnsrMtnData_CrvRdSt", parquet_lib::DataType::UINT8}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_trigger_process(void)
{
    add_message("TRIGGER_PROCESS", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("TRIGGER_PROCESS", {
        {"ActivateAlgoProcessing", parquet_lib::DataType::BOOL}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_init_trigger_cyclic(void)
{
    add_message("TRIGGER_CYCLIC", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("TRIGGER_CYCLIC", {
        {"Counter", parquet_lib::DataType::UINT64},
        {"TimerMs", parquet_lib::DataType::UINT16}
    });
}




/*----------------------------------------------------------------------------*/
/*  WRITE DATA INTO PARQUET                                                   */
/*----------------------------------------------------------------------------*/

void MERdrDataCubeMidW_Parquet_In::parquet_export_midw_all_int_data(msg_replay_radar::msg::MsgMidwIntAllDataType::UniquePtr msg)
{
    append_values("Midw_All_Int_Data", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"R_Header_Data_Valid", msg->r_header.data_valid},
        {"R_Header_Data_Busy", msg->r_header.data_busy},
        {"R_Header_Scan_Loop_Size", msg->r_header.scan_loop_size},
        {"R_Header_Header_Size", msg->r_header.header_size},
        {"R_Header_Main_Data_Size", msg->r_header.main_data_size},
        {"R_Header_Aux_Data_Size", msg->r_header.aux_data_size},
        {"Aux_Data_Aux", msg->aux_data.aux},
    });

    std::string prefix{""};
    parquet_lib::SignalValuesListType list_signal_values;
    for (uint16_t idx = 0; idx < 4; idx++)
    {
        prefix = "_#_" + std::to_string(idx) + "_";
        for(uint16_t idy = 0; idy < 2; idy++)
        {
            list_signal_values["Scan_Info"+prefix+"Scan_Sequence_Numbers"].push_back(msg->scan_info.at(idx).scan_sequence_numbers.at(idy));
            list_signal_values["Scan_Info"+prefix+"Scan_Timestamps"].push_back(msg->scan_info.at(idx).scan_timestamps.at(idy));
            list_signal_values["Detection_List"+prefix+"Num_Elem_Per_Scan"].push_back(msg->detection_list.at(idx).num_elem_per_scan.at(idy));
        }

        append_values("Midw_All_Int_Data", list_signal_values);
        list_signal_values.clear();

        for(uint16_t idz = 0; idz < 512; idz++)
        {
            list_signal_values["Detection_List"+prefix+"Coor_Polar_Range"].push_back(msg->detection_list.at(idx).coor_polar.at(idz).range);
            list_signal_values["Detection_List"+prefix+"Coor_Polar_Azimuth"].push_back(msg->detection_list.at(idx).coor_polar.at(idz).azimuth);
            list_signal_values["Detection_List"+prefix+"Coor_Polar_Elevation"].push_back(msg->detection_list.at(idx).coor_polar.at(idz).elevation);
            list_signal_values["Detection_List"+prefix+"Doppler"].push_back(msg->detection_list.at(idx).doppler.at(idz));
            list_signal_values["Detection_List"+prefix+"Magnitude"].push_back(msg->detection_list.at(idx).magnitude.at(idz));
            list_signal_values["Detection_List"+prefix+"Sig_To_Noise_Rat"].push_back(msg->detection_list.at(idx).sig_to_noise_rat.at(idz));
            list_signal_values["Detection_List"+prefix+"Rdr_Cross_Sectn"].push_back(msg->detection_list.at(idx).rdr_cross_sectn.at(idz));
            list_signal_values["Detection_List"+prefix+"Flags"].push_back(msg->detection_list.at(idx).flags.at(idz));
            list_signal_values["Rdc2_Data_Rdc2_Arr_Data_"+prefix+"_I"].push_back(msg->rdc2_data.at(idx).rdc2_arr_data.at(idz).i);
            list_signal_values["Rdc2_Data_Rdc2_Arr_Data_"+prefix+"_Q"].push_back(msg->rdc2_data.at(idx).rdc2_arr_data.at(idz).q);
        }

        append_values("Midw_All_Int_Data", list_signal_values);
        list_signal_values.clear();

        for(uint16_t id = 0; id < 1024; id++)
        {
            list_signal_values["Conv_Point_Cloud_list"+prefix+"Range"].push_back(msg->conv_point_cloud_list.at(idx).range.at(id));
            list_signal_values["Conv_Point_Cloud_list"+prefix+"Azimuth"].push_back(msg->conv_point_cloud_list.at(idx).azimuth.at(id));
            list_signal_values["Conv_Point_Cloud_list"+prefix+"Elevation"].push_back(msg->conv_point_cloud_list.at(idx).elevation.at(id));
            list_signal_values["Conv_Point_Cloud_list"+prefix+"Doppler"].push_back(msg->conv_point_cloud_list.at(idx).doppler.at(id));
            list_signal_values["Conv_Point_Cloud_list"+prefix+"Snr_Db"].push_back(msg->conv_point_cloud_list.at(idx).snr_db.at(id));
            list_signal_values["Conv_Point_Cloud_list"+prefix+"Flags"].push_back(msg->conv_point_cloud_list.at(idx).flags.at(id));
            list_signal_values["Raw_Point_Cloud_list"+prefix+"Range"].push_back(msg->raw_point_cloud_list.at(idx).range.at(id));
            list_signal_values["Raw_Point_Cloud_list"+prefix+"Azimuth_Fbin"].push_back(msg->raw_point_cloud_list.at(idx).azimuth_fbin.at(id));
            list_signal_values["Raw_Point_Cloud_list"+prefix+"Elevation_Fbin"].push_back(msg->raw_point_cloud_list.at(idx).elevation_fbin.at(id));
            list_signal_values["Raw_Point_Cloud_list"+prefix+"Doppler_bin"].push_back(msg->raw_point_cloud_list.at(idx).doppler_bin.at(id));
        }

        append_values("Midw_All_Int_Data", list_signal_values);
        list_signal_values.clear();

        append_values("Midw_All_Int_Data", {
            {"Scan_Info"+prefix+"Scan_Dimension", msg->scan_info.at(idx).scan_dimension},
            {"Scan_Info"+prefix+"Scan_Set", msg->scan_info.at(idx).scan_set},
            {"Scan_Info"+prefix+"Ego_Rdr_VX", msg->scan_info.at(idx).ego_rdr.vx},
            {"Scan_Info"+prefix+"Ego_Rdr_VY", msg->scan_info.at(idx).ego_rdr.vy},
            {"Scan_Info"+prefix+"Ego_Rdr_VZ", msg->scan_info.at(idx).ego_rdr.vz},
            {"Scan_Info"+prefix+"Ego_Rdr_Estimd_VX", msg->scan_info.at(idx).ego_rdr_estimd.vx},
            {"Scan_Info"+prefix+"Ego_Rdr_Estimd_VY", msg->scan_info.at(idx).ego_rdr_estimd.vy},
            {"Scan_Info"+prefix+"Ego_Rdr_Estimd_VZ", msg->scan_info.at(idx).ego_rdr_estimd.vz},
            {"Scan_Params"+prefix+"Scan_Time", msg->scan_params.at(idx).scan_time},
            {"Scan_Params"+prefix+"Pulse_Time", msg->scan_params.at(idx).pulse_time},
            {"Scan_Params"+prefix+"Chip_Time", msg->scan_params.at(idx).chip_time},
            {"Scan_Params"+prefix+"Doppler_Bin_Width", msg->scan_params.at(idx).doppler_bin_width},
            {"Scan_Params"+prefix+"Range_Bin_Width", msg->scan_params.at(idx).range_bin_width},
            {"Scan_Params"+prefix+"Pulses_Per_Scan", msg->scan_params.at(idx).pulses_per_scan},
            {"Scan_Params"+prefix+"Chips_Per_Pulse", msg->scan_params.at(idx).chips_per_pulse},
            {"Scan_Params"+prefix+"Code_Type", msg->scan_params.at(idx).code_type},
            {"Scan_Params"+prefix+"Num_Range_Bins", msg->scan_params.at(idx).num_range_bins},
            {"Scan_Params"+prefix+"Num_Azimuth_Bins", msg->scan_params.at(idx).num_azimuth_bins},
            {"Scan_Params"+prefix+"Num_Elevation_Bins", msg->scan_params.at(idx).num_elevation_bins},
            {"Scan_Params"+prefix+"Num_Vrx_Used", msg->scan_params.at(idx).num_vrx_used},
            {"Scan_Params"+prefix+"Wrap_Azimuth_Angles", msg->scan_params.at(idx).wrap_azimuth_angles},
            {"Scan_Params"+prefix+"Wrap_Elevation_Angles", msg->scan_params.at(idx).wrap_elevation_angles},
            {"Scan_Params"+prefix+"Scan_Lambda", msg->scan_params.at(idx).scan_lambda},
            {"Scan_Params"+prefix+"First_Range_Bin", msg->scan_params.at(idx).first_range_bin},
            {"Scan_Params"+prefix+"Azimuth_Sine_Bin_Size", msg->scan_params.at(idx).azimuth_sine_bin_size},
            {"Scan_Params"+prefix+"Azimuth_Sine_Zero_Location", msg->scan_params.at(idx).azimuth_sine_zero_location},
            {"Scan_Params"+prefix+"Elevation_Sine_Bin_Size", msg->scan_params.at(idx).elevation_sine_bin_size},
            {"Scan_Params"+prefix+"Elevation_Sine_Zero_Location", msg->scan_params.at(idx).elevation_sine_zero_location},
            {"Rdc2_Data_"+prefix+"_Num_Rd", msg->rdc2_data.at(idx).num_rd},
            {"Conv_Point_Cloud_list_"+prefix+"_Num_Elements", msg->conv_point_cloud_list.at(idx).num_elements},
            {"Raw_Point_Cloud_list_"+prefix+"_Num_Elements", msg->raw_point_cloud_list.at(idx).num_elements},
        });
    }
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_blkgroad(
    msg_swc_common::msg::MsgBlkgroadType::UniquePtr msg)
{
    append_values("BLKGROAD", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"RoadDetnEnblRq", msg->road_detn_enbl_rq},
        {"RoadDetnDist", msg->road_detn_dist}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_completetrigger(
    msg_swc_common::msg::MsgEventType::UniquePtr msg)
{
    append_values("COMPLETETRIGGER", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"ActivateAlgoProcessing", msg->event}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_diagscan(
    msg_swc_common::msg::MsgDiagscanType::UniquePtr msg)
{
    parquet_lib::SignalValuesListType list_signal_values;

    append_values("DIAGSCAN", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"DiagScanSet_ScanSetHeader_NumScans", msg->diag_scan_set.scan_set_header.num_scans},
        {"DiagScanSet_ScanSetHeader_ScanSetInterval", msg->diag_scan_set.scan_set_header.scan_set_interval},
        {"DiagnosticScanRq", msg->diagnostic_scan_rq}
    });

    for(uint i=0 ; i<5 ; i++)
    {
        list_signal_values["DiagScanSet_ScanParameterArr_ScanPreset"].push_back(msg->diag_scan_set.scan_parameter_arr[i].scan_preset);
        list_signal_values["DiagScanSet_ScanParameterArr_num_pi"].push_back(msg->diag_scan_set.scan_parameter_arr[i].numpi);
        list_signal_values["DiagScanSet_ScanParameterArr_num_si"].push_back(msg->diag_scan_set.scan_parameter_arr[i].numsi);
        list_signal_values["DiagScanSet_ScanParameterArr_ScanDimension"].push_back(msg->diag_scan_set.scan_parameter_arr[i].scan_dimension);
        list_signal_values["DiagScanSet_ScanParameterArr_ScanType"].push_back(msg->diag_scan_set.scan_parameter_arr[i].scan_type);
        list_signal_values["DiagScanSet_ScanParameterArr_detection_thresh_snr_dB"].push_back(msg->diag_scan_set.scan_parameter_arr[i].detectionthreshsnrd_b);
        list_signal_values["DiagScanSet_ScanParameterArr_clutter_image_thresh_snr_dB"].push_back(msg->diag_scan_set.scan_parameter_arr[i].clutterimagethreshsnrd_b);
        list_signal_values["DiagScanSet_ScanParameterArr_point_cloud_thresh_snr_dB"].push_back(msg->diag_scan_set.scan_parameter_arr[i].pointcloudthreshsnrd_b);
        list_signal_values["DiagScanSet_ScanParameterArr_scale_det_thresh_max_range"].push_back(msg->diag_scan_set.scan_parameter_arr[i].scaledetthreshmaxrange);
        list_signal_values["DiagScanSet_ScanParameterArr_scale_det_thresh_snr_adj"].push_back(msg->diag_scan_set.scan_parameter_arr[i].scaledetthreshsnradj);
        list_signal_values["DiagScanSet_ScanParameterArr_ego_zero_stationary_threshold_mps"].push_back(msg->diag_scan_set.scan_parameter_arr[i].egozerostationarythresholdmps);
        list_signal_values["DiagScanSet_ScanParameterArr_ego_nonz_stationary_threshold_mps"].push_back(msg->diag_scan_set.scan_parameter_arr[i].egononzstationarythresholdmps);
        list_signal_values["DiagScanSet_ScanParameterArr_notch_width_radians"].push_back(msg->diag_scan_set.scan_parameter_arr[i].notchwidthradians);
        list_signal_values["DiagScanSet_ScanParameterArr_notch_depth_dB"].push_back(msg->diag_scan_set.scan_parameter_arr[i].notchdepthd_b);
        list_signal_values["DiagScanSet_ScanParameterArr_outer_depth_dB"].push_back(msg->diag_scan_set.scan_parameter_arr[i].outerdepthd_b);
        list_signal_values["DiagScanSet_ScanParameterArr_ridge_extra_thresh_dB"].push_back(msg->diag_scan_set.scan_parameter_arr[i].ridgeextrathreshd_b);
        list_signal_values["DiagScanSet_ScanParameterArr_FlagsOverrideEnable1"].push_back(msg->diag_scan_set.scan_parameter_arr[i].flags_override_enable1);
        list_signal_values["DiagScanSet_ScanParameterArr_FlagsOverrideEnable2"].push_back(msg->diag_scan_set.scan_parameter_arr[i].flags_override_enable2);
        list_signal_values["DiagScanSet_ScanParameterArr_FlagsOverrideValue1"].push_back(msg->diag_scan_set.scan_parameter_arr[i].flags_override_value1);
        list_signal_values["DiagScanSet_ScanParameterArr_FlagsOverrideValue2"].push_back(msg->diag_scan_set.scan_parameter_arr[i].flags_override_value2);
    }
    append_values("DIAGSCAN", list_signal_values);
    list_signal_values.clear();
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_radarcfg(
    msg_swc_common::msg::MsgRadarcfgType::UniquePtr msg)
{
    append_values("RADARCFG", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"RadarRole", msg->radar_role},
        {"FuncArr", msg->func_arr}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_recordreplay(
    msg_swc_common::msg::MsgRecordreplayType::UniquePtr msg)
{
    append_values("RECORDREPLAY", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"RecordReplaySt", msg->record_replay_st}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_scan(
    msg_swc_common::msg::MsgScanType::UniquePtr msg)
{
    append_values("SCAN", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"ScanCfg", msg->scan_cfg}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_scanpara(
    msg_swc_common::msg::MsgScanparaType::UniquePtr msg)
{
    parquet_lib::SignalValuesListType list_signal_values;

    for(uint i=0 ; i<3 ; i++)
    {
        list_signal_values["ScanSets_ScanSetHeader_NumScans"].push_back(msg->scan_sets[i].scan_set_header.num_scans);
        list_signal_values["ScanSets_ScanSetHeader_ScanSetInterval"].push_back(msg->scan_sets[i].scan_set_header.scan_set_interval);
    }
    append_values("SCANPARA", list_signal_values);
    list_signal_values.clear();

    for(uint i=0 ; i<5 ; i++)
    {
        list_signal_values["ScanSets_ScanParameterArr_ScanPreset"].push_back(msg->scan_sets[i].scan_parameter_arr[i].scan_preset);
        list_signal_values["ScanSets_ScanParameterArr_num_pi"].push_back(msg->scan_sets[i].scan_parameter_arr[i].numpi);
        list_signal_values["ScanSets_ScanParameterArr_num_si"].push_back(msg->scan_sets[i].scan_parameter_arr[i].numsi);
        list_signal_values["ScanSets_ScanParameterArr_ScanDimension"].push_back(msg->scan_sets[i].scan_parameter_arr[i].scan_dimension);
        list_signal_values["ScanSets_ScanParameterArr_ScanType"].push_back(msg->scan_sets[i].scan_parameter_arr[i].scan_type);
        list_signal_values["ScanSets_ScanParameterArr_detection_thresh_snr_dB"].push_back(msg->scan_sets[i].scan_parameter_arr[i].detectionthreshsnrd_b);
        list_signal_values["ScanSets_ScanParameterArr_clutter_image_thresh_snr_dB"].push_back(msg->scan_sets[i].scan_parameter_arr[i].clutterimagethreshsnrd_b);
        list_signal_values["ScanSets_ScanParameterArr_point_cloud_thresh_snr_dB"].push_back(msg->scan_sets[i].scan_parameter_arr[i].pointcloudthreshsnrd_b);
        list_signal_values["ScanSets_ScanParameterArr_scale_det_thresh_max_range"].push_back(msg->scan_sets[i].scan_parameter_arr[i].scaledetthreshmaxrange);
        list_signal_values["ScanSets_ScanParameterArr_scale_det_thresh_snr_adj"].push_back(msg->scan_sets[i].scan_parameter_arr[i].scaledetthreshsnradj);
        list_signal_values["ScanSets_ScanParameterArr_ego_zero_stationary_threshold_mps"].push_back(msg->scan_sets[i].scan_parameter_arr[i].egozerostationarythresholdmps);
        list_signal_values["ScanSets_ScanParameterArr_ego_nonz_stationary_threshold_mps"].push_back(msg->scan_sets[i].scan_parameter_arr[i].egononzstationarythresholdmps);
        list_signal_values["ScanSets_ScanParameterArr_notch_width_radians"].push_back(msg->scan_sets[i].scan_parameter_arr[i].notchwidthradians);
        list_signal_values["ScanSets_ScanParameterArr_notch_depth_dB"].push_back(msg->scan_sets[i].scan_parameter_arr[i].notchdepthd_b);
        list_signal_values["ScanSets_ScanParameterArr_outer_depth_dB"].push_back(msg->scan_sets[i].scan_parameter_arr[i].outerdepthd_b);
        list_signal_values["ScanSets_ScanParameterArr_ridge_extra_thresh_dB"].push_back(msg->scan_sets[i].scan_parameter_arr[i].ridgeextrathreshd_b);
        list_signal_values["ScanSets_ScanParameterArr_FlagsOverrideEnable1"].push_back(msg->scan_sets[i].scan_parameter_arr[i].flags_override_enable1);
        list_signal_values["ScanSets_ScanParameterArr_FlagsOverrideEnable2"].push_back(msg->scan_sets[i].scan_parameter_arr[i].flags_override_enable2);
        list_signal_values["ScanSets_ScanParameterArr_FlagsOverrideValue1"].push_back(msg->scan_sets[i].scan_parameter_arr[i].flags_override_value1);
        list_signal_values["ScanSets_ScanParameterArr_FlagsOverrideValue2"].push_back(msg->scan_sets[i].scan_parameter_arr[i].flags_override_value2);
    }
    append_values("SCANPARA", list_signal_values);
    list_signal_values.clear();
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_scanready(
    msg_swc_common::msg::MsgEventType::UniquePtr msg)
{
    append_values("SCANREADY", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"ScanReady", msg->event}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_sensrmtn(
    msg_swc_common::msg::MsgSensrmtnType::UniquePtr msg)
{
    append_values("SENSRMTN", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"SnsrMtnData_V_VX", msg->snsr_mtn_data.v.vx},
        {"SnsrMtnData_V_VY", msg->snsr_mtn_data.v.vy},
        {"SnsrMtnData_V_VZ", msg->snsr_mtn_data.v.vz},
        {"SnsrMtnData_VStdDe_VX", msg->snsr_mtn_data.v_std_de.vx},
        {"SnsrMtnData_VStdDe_VY", msg->snsr_mtn_data.v_std_de.vy},
        {"SnsrMtnData_VStdDe_VZ", msg->snsr_mtn_data.v_std_de.vz},
        {"SnsrMtnData_VEstimnSt", msg->snsr_mtn_data.v_estimn_st},
        {"SnsrMtnData_A_AX", msg->snsr_mtn_data.a.ax},
        {"SnsrMtnData_A_AY", msg->snsr_mtn_data.a.ay},
        {"SnsrMtnData_A_AZ", msg->snsr_mtn_data.a.az},
        {"SnsrMtnData_AStdDe_AX", msg->snsr_mtn_data.a_std_de.ax},
        {"SnsrMtnData_AStdDe_AY", msg->snsr_mtn_data.a_std_de.ay},
        {"SnsrMtnData_AStdDe_AZ", msg->snsr_mtn_data.a_std_de.az},
        {"SnsrMtnData_AEstimnSt", msg->snsr_mtn_data.a_estimn_st},
        {"SnsrMtnData_YawRate", msg->snsr_mtn_data.yaw_rate},
        {"SnsrMtnData_YawRateStdDe", msg->snsr_mtn_data.yaw_rate_std_de},
        {"SnsrMtnData_YawRateSt", msg->snsr_mtn_data.yaw_rate_st},
        {"SnsrMtnData_CrvRd", msg->snsr_mtn_data.crv_rd},
        {"SnsrMtnData_CrvRdStdDe", msg->snsr_mtn_data.crv_rd_std_de},
        {"SnsrMtnData_CrvRdSt", msg->snsr_mtn_data.crv_rd_st}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_trigger_process(
    msg_swc_common::msg::MsgEventType::UniquePtr msg)
{
    append_values("TRIGGER_PROCESS", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"ActivateAlgoProcessing", msg->event}
    });
}


void MERdrDataCubeMidW_Parquet_In::parquet_export_trigger_cyclic(
    msg_swc_common::msg::MsgTriggerCyclicType::UniquePtr msg)
{
    append_values("TRIGGER_CYCLIC", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"Counter", msg->counter},
        {"TimerMs", msg->timer_ms}
    });
}
