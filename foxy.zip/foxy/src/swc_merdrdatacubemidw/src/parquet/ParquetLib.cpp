/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       ParquetLib.cpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */


#include "ParquetLib.hpp"
#include <iostream>
#include <algorithm>
#include <filesystem>

namespace fs = std::filesystem;

namespace parquet_lib
{

    SignalInfo::SignalInfo(const std::string name, const DataType dtype, const ValueType vtype)
        : name_(std::move(name)), dtype_(std::move(dtype)), vtype_(std::move(vtype))
    {
    }

    SignalData::SignalData(const SignalInfo& info) : info_(std::move(info))
    {
    }

    auto SignalData::append_value(const VariantValueType& value) -> bool
    {
        if(info_.vtype_ != ValueType::PRIMITIVE)
        {
            std::cout<<"Not Primitive!\n";
            return false;
        }

        if(value.index() != info_.dtype_)
        {
            std::cout<<"The data type of the given value doesn't match the data type this signal was initialized with."<<std::to_string(value.index())<<std::endl;
            return false;
        }
    
        values_.push_back(value);
        return true;

    }

    auto SignalData::append_value(const Variant1DVectorType& value_lsit) -> bool
    {
        if(info_.vtype_ != ValueType::LIST)
        {
            std::cout<<"Not a List!\n";
            return false;
        }

        if(std::any_of(value_lsit.begin(), value_lsit.end(), [&](const VariantValueType& value){return value.index() != info_.dtype_;}))
        {
            std::cout<<"The data type of the given value doesn't match the data type this signal was initialized with.\n";
            return false;
        }

        value_lists_.push_back(value_lsit);
        return true;
    }

    auto SignalData::get_arrow_type() -> std::shared_ptr<arrow::DataType>
    {
        std::shared_ptr<arrow::DataType> arrow_dtype;

        switch (info_.dtype_)
        {
            case DataType::BOOL:
                arrow_dtype = arrow::boolean();
                break;
            case DataType::UINT8:
            case DataType::UINT16:
            case DataType::UINT32:
            case DataType::INT8:
            case DataType::INT16:
            case DataType::INT32:
                arrow_dtype = arrow::int32();
                break;
            case DataType::UINT64:
            case DataType::INT64:
                arrow_dtype = arrow::int64();
                break;
            case DataType::FLOAT32:
                arrow_dtype = arrow::float32();
                break;
            case DataType::FLOAT64:
                arrow_dtype = arrow::float64();
                break;
            case DataType::STRING:
                arrow_dtype = arrow::utf8();
                break;
            
            default:
                std::cout<<"Unhandled Data type! "<<std::to_string(info_.dtype_)<<std::endl;
                break;
        }

        if(info_.vtype_ == ValueType::LIST)
        {
            return arrow::list(arrow_dtype);
        }
        else    //For ValueType::PRIMITIVE
        {
            return arrow_dtype;
        }        
    }

    MessageData::MessageData(const std::string key_column, const SignalInfoListType list) : key_column_(key_column)
    {
        add_signals(list); 
    }

    auto MessageData::append_values(const SignalValuesPrimitiveType values) -> bool
    { 
        for(const auto&[name, value]: values)
        {
            if(!signals_map_[name].append_value(value))
            {
                return false;
            }
        }
        return true;
    }

    auto MessageData::append_values(const SignalValuesListType value_lists) -> bool
    { 
        for(const auto&[name, value_list]: value_lists)
        {
            if(!signals_map_[name].append_value(value_list))
            {
                return false;
            }
        }
        return true;
    }

    auto MessageData::add_signals(const SignalInfoListType list) -> bool
    {
        for(const auto& signal_info : list)
        {
            const auto [signal_itr, result] = signals_map_.insert({signal_info.name_, SignalData(signal_info)});
            if(!result)
            {
                return false;
            }
        }
        return true;
    }

    ParquetWriter::~ParquetWriter()
    {
        messages_map_.clear();
        timestamp_locations_.clear();
    }

    auto ParquetWriter::add_message(const std::string msg_name, const std::string key_column, const SignalInfoListType list) -> bool
    {
        const auto [message_itr, result] = messages_map_.insert({msg_name, MessageData(key_column, list)});
        return result;
    }

    auto ParquetWriter::add_signals(const std::string msg_name, const SignalInfoListType list) -> bool
    {
        return messages_map_[msg_name].add_signals(list);
    }

    auto ParquetWriter::append_values(const std::string msg_name, const SignalValuesPrimitiveType values) -> bool
    {
        return messages_map_[msg_name].append_values(values);
    }

    auto ParquetWriter::append_values(const std::string msg_name, const SignalValuesListType value_lists) -> bool
    {
        return messages_map_[msg_name].append_values(value_lists);
    }

    auto ParquetWriter::save_to_disk(const std::string input_file_path, const std::string suffix, const std::string output_folder_path) -> bool
    {
        if(input_file_path.empty())
        {
            std::cout<<"Error - No input file path provided\n";
            return false;
        }

        if(messages_map_.size() == 0)
        {
            std::cout<<"Cache Empty - No Messages/Signals defined!\n";
            return false;
        }
        
        fs::path path_temp = input_file_path;

        input_filename_ = path_temp.stem();

        std::string output_file_name = !suffix.empty() ? input_filename_ + "_" + suffix + ".parquet" : input_filename_ + ".parquet" ;

        if(!output_folder_path.empty())
        {
            fs::create_directories(output_folder_path);
            output_file_path_ = fs::path(output_folder_path) / output_file_name;
        }
        else
        {
            output_file_path_ = path_temp.parent_path() / output_file_name;
        }
    
        return write_parquet().Equals(arrow::Status::OK());
    }

    auto ParquetWriter::get_value(const std::string& msg_name, const std::string& signal_name, const size_t vector_index) -> VariantValueType&
    {
        return messages_map_[msg_name].signals_map_[signal_name].values_[vector_index];
    }

    auto ParquetWriter::get_value_list(const std::string& msg_name, const std::string& signal_name, const size_t vector_index) -> Variant1DVectorType&
    {
        return messages_map_[msg_name].signals_map_[signal_name].value_lists_[vector_index];
    }

    auto ParquetWriter::get_value_type(const std::string& msg_name, const std::string& signal_name) -> ValueType&
    {
        return messages_map_[msg_name].signals_map_[signal_name].info_.vtype_;
    }

    auto ParquetWriter::write_parquet() -> arrow::Status
    {
        for(auto&[msg_name, msg_data] : messages_map_)
        {
            const auto& key_column = msg_data.signals_map_.at(msg_data.key_column_);

            for(size_t idx = 0; idx < key_column.values_.size(); idx++)
            {
                int64_t value;
                std::visit(overload{
                                    [&value](const std::monostate& variant_value){std::cout<<"Uninitialized value in timestamps.\n";},
                                    [&value](const std::string& variant_value){value = std::stoll(variant_value.c_str());},
                                    [&value](const auto& variant_value){value = static_cast<int64_t>(variant_value);}
                }, key_column.values_.at(idx));
            
                timestamp_locations_[value].push_back(LocationData{msg_name, idx});
            }
            msg_data.signals_map_.erase(msg_data.key_column_);
        }

        int64_t ts_size = timestamp_locations_.size();
        
        arrow::FieldVector table_fields;
        table_fields.push_back(arrow::field("Timestamp_ns", arrow::int64()));
        table_fields.push_back(arrow::field("Messages_Present", arrow::utf8()));
        table_fields.push_back(arrow::field("Input_Filename", arrow::utf8()));

        for(auto& [msg_name, msg_data] : messages_map_)
        {
            for(auto& [signal_name, signal_data] : msg_data.signals_map_)
            {
                std::string field_name = msg_name+"__"+signal_name;
                table_fields.push_back(arrow::field(field_name, signal_data.get_arrow_type()));
            }
        }

        auto table_schema = arrow::schema(table_fields);
        std::unique_ptr<arrow::RecordBatchBuilder> batch_builder;
        ARROW_ASSIGN_OR_RAISE(batch_builder, arrow::RecordBatchBuilder::Make(table_schema, arrow::default_memory_pool(), ts_size)); 
        
        // build timestamp, message_name and filename columns
        arrow::Int64Builder* ts_builder = static_cast<arrow::Int64Builder*>(batch_builder->GetField(0));
        arrow::StringBuilder* msg_name_builder = static_cast<arrow::StringBuilder*>(batch_builder->GetField(1));
        arrow::StringBuilder* input_filename_builder = static_cast<arrow::StringBuilder*>(batch_builder->GetField(2));
    	
        for(const auto& [timestamp, locations] : timestamp_locations_)
        {
            ts_builder->UnsafeAppend(timestamp);

            std::string msg_names;
            for(const auto& [msg_name, vec_idx] : locations)
            {
                msg_names += msg_name + " ";
            }
            ARROW_RETURN_NOT_OK(msg_name_builder->Append(msg_names));

            ARROW_RETURN_NOT_OK(input_filename_builder->Append(input_filename_));
        }

        for(size_t idx = 3; idx < batch_builder->num_fields(); ++idx)
        {
            arrow::ArrayBuilder* builder = batch_builder->GetField(idx);
            
            auto field = table_schema->field(idx);
            
            const std::string field_name = field->name();
            size_t sep_pos = field_name.find("__");
            const std::string msg_name = field_name.substr(0, sep_pos);
            const std::string signal_name = field_name.substr(sep_pos + 2);
            
            auto field_type = field->type();
                        
            auto msg_exists = [&msg_name](const LocationData& location){return msg_name == location.msg_name_;};
            
            auto values_visitor = ValuesVisitor(builder, field_type.get());

            for(const auto& [timestamp, locations] : timestamp_locations_)
            {
                auto location_iter = std::find_if(locations.begin(), locations.end(), msg_exists);
            
                bool is_message_present = location_iter != locations.end();

                auto& value_type = get_value_type(msg_name, signal_name);

                if(value_type == ValueType::PRIMITIVE)
                {
                    auto value = is_message_present ? get_value(msg_name, signal_name, location_iter->vector_index_) : std::monostate{};
                    
                    ARROW_RETURN_NOT_OK(values_visitor.append_value(value));
                }
                else if(value_type == ValueType::LIST)
                {
                    auto value_list = is_message_present ? get_value_list(msg_name, signal_name, location_iter->vector_index_) : Variant1DVectorType{};
                    
                    ARROW_RETURN_NOT_OK(values_visitor.append_value(value_list));
                }    
            }
        }

        std::shared_ptr<arrow::RecordBatch> record_batch;
        ARROW_ASSIGN_OR_RAISE(record_batch, batch_builder->Flush());
    
        std::shared_ptr<arrow::Table> arrow_table;
        ARROW_ASSIGN_OR_RAISE(arrow_table, arrow::Table::FromRecordBatches({record_batch}));
        
        std::shared_ptr<arrow::io::FileOutputStream> output_parquet;

        // Parquet Viewer can't open RLE_DICTIONARY encoded parquet files as it is not supported by parquet-dotnet as of now
        // Therefore, switching to PLAIN encoding till issue is resolved (https://github.com/aloneguid/parquet-dotnet/issues/107)
        parquet::WriterProperties::Builder parquet_builder;
        parquet_builder.encoding(parquet::Encoding::PLAIN);
        parquet_builder.disable_dictionary();
        auto writer_properties = parquet_builder.build();

        PARQUET_ASSIGN_OR_THROW(output_parquet, arrow::io::FileOutputStream::Open(output_file_path_));
        PARQUET_THROW_NOT_OK(parquet::arrow::WriteTable(*arrow_table,
                                arrow::default_memory_pool(),
                                output_parquet,
                                arrow_table->num_rows(),
                                writer_properties));

        std::cout<<"'" + output_file_path_ + "' written to disk.\n";

        // Memory clean-up in case destructor doesn't get called properly.
        messages_map_.clear();
        timestamp_locations_.clear();


        return arrow::Status::OK();
    }

    ValuesVisitor::ValuesVisitor(arrow::ArrayBuilder* builder, arrow::DataType* type) : builder_(builder), type_(type)
    {
    }
    
    auto ValuesVisitor::append_value(const VariantValueType& value) -> arrow::Status
    {
        value_ = value;
        ARROW_RETURN_NOT_OK(arrow::VisitTypeInline(*type_, this));
        return arrow::Status::OK();
    }

    auto ValuesVisitor::append_value(const Variant1DVectorType& values_list) -> arrow::Status
    {
        values_list_ = values_list;
        ARROW_RETURN_NOT_OK(arrow::VisitTypeInline(*type_, this));
        return arrow::Status::OK();
    }

    // Default case for un-matched Arrow Type
    auto ValuesVisitor::Visit(const arrow::DataType& type) -> arrow::Status
    {
        return arrow::Status::NotImplemented("Implementation doesn't exist for Arrow Type -> ", type.ToString());
    }

    auto ValuesVisitor::Visit(const arrow::BooleanType& type) -> arrow::Status
    {
        arrow::BooleanBuilder* builder = static_cast<arrow::BooleanBuilder*>(builder_);
      
        std::visit(overload{
            [&](const bool& value){builder->UnsafeAppend(value);},
            [&](std::monostate&){builder->UnsafeAppendNull();},
            [&](auto){std::cout<<"Invalid value type!\n";}
        }, value_);
        
        return arrow::Status::OK();
    }

    auto ValuesVisitor::Visit(const arrow::Int32Type& type) -> arrow::Status
    {
        arrow::Int32Builder* builder = static_cast<arrow::Int32Builder*>(builder_);
      
        std::visit(overload{
            [&](const auto& value){builder->UnsafeAppend(static_cast<int32_t>(value));},
            [&](const std::string&){},  // Only added as static_cast complains about no implicit conversion from string to int
            [&](std::monostate&){builder->UnsafeAppendNull();}
        }, value_);
        
        return arrow::Status::OK();
    }

    auto ValuesVisitor::Visit(const arrow::Int64Type& type) -> arrow::Status
    {
        arrow::Int64Builder* builder = static_cast<arrow::Int64Builder*>(builder_);
      
        std::visit(overload{
            [&](const auto& value){builder->UnsafeAppend(static_cast<int64_t>(value));},
            [&](const std::string&){},  // Only added as static_cast complains about no implicit conversion from string to int
            [&](std::monostate&){builder->UnsafeAppendNull();}
        }, value_);
        
        return arrow::Status::OK();
    }

    auto ValuesVisitor::Visit(const arrow::FloatType& type) -> arrow::Status
    {
        arrow::FloatBuilder* builder = static_cast<arrow::FloatBuilder*>(builder_);
      
        std::visit(overload{
            [&](const float& value){builder->UnsafeAppend(value);},
            [&](std::monostate&){builder->UnsafeAppendNull();},
            [&](auto){std::cout<<"Invalid value type!\n";}
        }, value_);
        
        return arrow::Status::OK();
    }

    auto ValuesVisitor::Visit(const arrow::DoubleType& type) -> arrow::Status
    {
        arrow::DoubleBuilder* builder = static_cast<arrow::DoubleBuilder*>(builder_);
      
        std::visit(overload{
            [&](const double& value){builder->UnsafeAppend(value);},
            [&](std::monostate&){builder->UnsafeAppendNull();},
            [&](auto){std::cout<<"Invalid value type!\n";}
        }, value_);
        
        return arrow::Status::OK();
    }

    auto ValuesVisitor::Visit(const arrow::StringType& type) -> arrow::Status
    {
        arrow::StringBuilder* builder = static_cast<arrow::StringBuilder*>(builder_);
      
        std::visit(overload{
            [&](const std::string& value){builder->Append(value);},
            [&](std::monostate&){builder->AppendNull();},
            [&](auto){std::cout<<"Invalid value type!\n";}
        }, value_);
        
        return arrow::Status::OK();
    }

    auto ValuesVisitor::Visit(const arrow::ListType& type) -> arrow::Status
    {
        arrow::ListBuilder* builder = static_cast<arrow::ListBuilder*>(builder_);
        arrow::ArrayBuilder* value_builder = builder->value_builder();

        ARROW_RETURN_NOT_OK(builder->Append(!values_list_.empty()));

        if(!values_list_.empty())
        {
            size_t values_list_size = values_list_.size();
            
            std::unique_ptr<arrow::ArrayBuilder> temp_value_builder;
            ARROW_ASSIGN_OR_RAISE(temp_value_builder, arrow::MakeBuilder(value_builder->type()));

            ARROW_RETURN_NOT_OK(temp_value_builder->Reserve(values_list_size));
            auto temp_values_visitor = ValuesVisitor(temp_value_builder.get(), type.value_type().get());

            for (const auto& value : values_list_)
            {
                ARROW_RETURN_NOT_OK(temp_values_visitor.append_value(value));
            }

            std::shared_ptr<arrow::Array> values_array;
            ARROW_RETURN_NOT_OK(temp_value_builder->Finish(&values_array));
            auto values_data = values_array->data();

            ARROW_RETURN_NOT_OK(value_builder->AppendArraySlice(*values_data.get(), 0, values_list_size));
        }

        return arrow::Status::OK();
    }

} // namespace parquet_lib
