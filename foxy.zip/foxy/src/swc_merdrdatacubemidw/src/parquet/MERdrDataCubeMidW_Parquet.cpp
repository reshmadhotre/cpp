/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_Parquet.cpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */


#include "MERdrDataCubeMidW_Parquet.hpp"

#include <thread>
#include <iostream>
#include "rclcpp/rclcpp.hpp"



MERdrDataCubeMidW_Parquet::MERdrDataCubeMidW_Parquet()
{
}


MERdrDataCubeMidW_Parquet::~MERdrDataCubeMidW_Parquet()
{
}


void MERdrDataCubeMidW_Parquet::set_filename_in(const std::string filename)
{
    size_t path_len = filename.find_last_of('/') + 1;
    std::string file_path = filename.substr(0,path_len);
    std::string file_name = filename.substr(path_len, filename.length());
    parquet_file_name_ = file_path+"_i_"+file_name;
}


void MERdrDataCubeMidW_Parquet::set_filename_out(const std::string filename)
{
    parquet_file_name_ = filename;
}


const std::string MERdrDataCubeMidW_Parquet::get_file_suffix() const
{
    return filename_prefix_;
}


const std::string MERdrDataCubeMidW_Parquet::get_filename() const
{
    return parquet_file_name_;
}


bool MERdrDataCubeMidW_Parquet::is_parquet_file_written()
{
    return parquet_file_completion_flag_;
}


void MERdrDataCubeMidW_Parquet::set_parquet_file_completion_flag(const bool status)
{
    parquet_file_completion_flag_ = status;
}


void MERdrDataCubeMidW_Parquet::write_parquet()
{
    std::thread thrd(std::bind(&MERdrDataCubeMidW_Parquet::write_parquet_file, this));
    thrd.detach();
}


void MERdrDataCubeMidW_Parquet::write_parquet_file()
{
    auto file_name = get_filename();
    auto file_suffix = get_file_suffix();
    save_to_disk(file_name, file_suffix);
    set_parquet_file_completion_flag(true);
}
