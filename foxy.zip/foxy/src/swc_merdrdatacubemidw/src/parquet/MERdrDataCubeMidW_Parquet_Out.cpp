/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_Parquet_Out.cpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */


#include "MERdrDataCubeMidW_Parquet_Out.hpp"

#include <thread>
#include <iostream>
#include "rclcpp/rclcpp.hpp"



MERdrDataCubeMidW_Parquet_Out::MERdrDataCubeMidW_Parquet_Out() : MERdrDataCubeMidW_Parquet()
{
    init_parquet_headers();
}


MERdrDataCubeMidW_Parquet_Out::~MERdrDataCubeMidW_Parquet_Out()
{
}


void MERdrDataCubeMidW_Parquet_Out::init_parquet_headers()
{
    parquet_init_detn_getmidwdata();
    parquet_init_detn_getrdc2data();
    parquet_init_rdcst();
    parquet_init_scaninfo();
    parquet_init_version_merdrdatacubemidw_getversioninfo();
}


/*----------------------------------------------------------------------------*/
/*  INITIALIZE DATA FOR PARQUET                                               */
/*----------------------------------------------------------------------------*/

void MERdrDataCubeMidW_Parquet_Out::parquet_init_detn_getmidwdata(void)
{
    add_message("DETN_GetMidWData", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("DETN_GetMidWData", {
        {"OneDPtr_ScanInfo_ScanSet", parquet_lib::DataType::UINT8},
        {"OneDPtr_ScanInfo_ScanDimension", parquet_lib::DataType::UINT8},
        {"OneDPtr_ScanInfo_EgoRdr_VX", parquet_lib::DataType::FLOAT32},
        {"OneDPtr_ScanInfo_EgoRdr_VY", parquet_lib::DataType::FLOAT32},
        {"OneDPtr_ScanInfo_EgoRdr_VZ", parquet_lib::DataType::FLOAT32},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VX", parquet_lib::DataType::FLOAT32},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VY", parquet_lib::DataType::FLOAT32},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VZ", parquet_lib::DataType::FLOAT32},
        {"OneDPtr_ClusterData_NumClusters", parquet_lib::DataType::UINT16},
        {"OneDPtr_ClusterData_NumExpandedClusters", parquet_lib::DataType::UINT16},
        {"TwoDPtr_ScanInfo_ScanSet", parquet_lib::DataType::UINT8},
        {"TwoDPtr_ScanInfo_ScanDimension", parquet_lib::DataType::UINT8},
        {"TwoDPtr_ScanInfo_EgoRdr_VX", parquet_lib::DataType::FLOAT32},
        {"TwoDPtr_ScanInfo_EgoRdr_VY", parquet_lib::DataType::FLOAT32},
        {"TwoDPtr_ScanInfo_EgoRdr_VZ", parquet_lib::DataType::FLOAT32},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VX", parquet_lib::DataType::FLOAT32},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VY", parquet_lib::DataType::FLOAT32},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VZ", parquet_lib::DataType::FLOAT32},
        {"TwoDPtr_ClusterData_NumClusters", parquet_lib::DataType::UINT16},
        {"TwoDPtr_ClusterData_NumExpandedClusters", parquet_lib::DataType::UINT16}
    });

    for(uint i=0 ; i<2 ; i++)
    {
        add_signals("DETN_GetMidWData", {
            {"OneDPtr_ScanInfo_ScanSequenceNumbers", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanInfo_ScanTimestamps", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_StaticDetns_NumElemPerScan", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_DynamicDetns_NumElemPerScan", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_PointCloudList_NumElemPerScan", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_ScanTime", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_PulseTime", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_ChipTime", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_DopplerBinWidth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_RangeBinWidth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_PulsesPerScan", parquet_lib::DataType::INT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_ChipsPerPulse", parquet_lib::DataType::INT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_CodeType", parquet_lib::DataType::INT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_NumRangeBins", parquet_lib::DataType::INT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_NumAzimuthBins", parquet_lib::DataType::INT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_NumElevationBins", parquet_lib::DataType::INT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_NumVRXUsed", parquet_lib::DataType::INT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_WrapAzimuthAngles", parquet_lib::DataType::BOOL, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_WrapElevationAngles", parquet_lib::DataType::BOOL, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_ScanLambda", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_FirstRangeBin", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_AzimuthSineBinSize", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_AzimuthSineZeroLocation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_ElevationSineBinSize", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ScanParams_ElevationSineZeroLocation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanInfo_ScanSequenceNumbers", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanInfo_ScanTimestamps", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_StaticDetns_NumElemPerScan", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_DynamicDetns_NumElemPerScan", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_PointCloudList_NumElemPerScan", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_ScanTime", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_PulseTime", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_ChipTime", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_DopplerBinWidth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_RangeBinWidth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_PulsesPerScan", parquet_lib::DataType::INT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_ChipsPerPulse", parquet_lib::DataType::INT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_CodeType", parquet_lib::DataType::INT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_NumRangeBins", parquet_lib::DataType::INT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_NumAzimuthBins", parquet_lib::DataType::INT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_NumElevationBins", parquet_lib::DataType::INT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_NumVRXUsed", parquet_lib::DataType::INT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_WrapAzimuthAngles", parquet_lib::DataType::BOOL, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_WrapElevationAngles", parquet_lib::DataType::BOOL, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_ScanLambda", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_FirstRangeBin", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_AzimuthSineBinSize", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_AzimuthSineZeroLocation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_ElevationSineBinSize", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ScanParams_ElevationSineZeroLocation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST}
        });
    }

    for(uint i=0 ; i<128 ; i++)
    {
        add_signals("DETN_GetMidWData", {
            {"OneDPtr_ClusterData_ClusterInfo_maxSNRIndx", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_ClusterData_ClusterInfo_ClusterSize", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_ClusterData_ClusterInfo_MinRangeIndx", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_ClusterData_ClusterInfo_StartingPointIndx", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ClusterData_ClusterInfo_maxSNRIndx", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ClusterData_ClusterInfo_ClusterSize", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ClusterData_ClusterInfo_MinRangeIndx", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ClusterData_ClusterInfo_StartingPointIndx", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST}
        });
    }

    for(uint i=0 ; i<512 ; i++)
    {
        add_signals("DETN_GetMidWData", {
            {"OneDPtr_DetectionList_StaticDetns_CoorPolar_Range", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_StaticDetns_CoorPolar_Azimuth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_StaticDetns_CoorPolar_Elevation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_StaticDetns_Doppler", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_StaticDetns_Magnitude", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_StaticDetns_SigToNoiseRat", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_StaticDetns_RdrCrossSectn", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_StaticDetns_Flags", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_DynamicDetns_CoorPolar_Range", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_DynamicDetns_CoorPolar_Azimuth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_DynamicDetns_CoorPolar_Elevation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_DynamicDetns_Doppler", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_DynamicDetns_Magnitude", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_DynamicDetns_SigToNoiseRat", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_DynamicDetns_RdrCrossSectn", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_DetectionList_DynamicDetns_Flags", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_StaticDetns_CoorPolar_Range", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_StaticDetns_CoorPolar_Azimuth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_StaticDetns_CoorPolar_Elevation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_StaticDetns_Doppler", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_StaticDetns_Magnitude", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_StaticDetns_SigToNoiseRat", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_StaticDetns_RdrCrossSectn", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_StaticDetns_Flags", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Range", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Azimuth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Elevation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_DynamicDetns_Doppler", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_DynamicDetns_Magnitude", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_DynamicDetns_SigToNoiseRat", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_DynamicDetns_RdrCrossSectn", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_DetectionList_DynamicDetns_Flags", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST}
        });
    }

    for(uint i=0 ; i<2048 ; i++)
    {
        add_signals("DETN_GetMidWData", {
            {"OneDPtr_PointCloudList_range", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_PointCloudList_azimuth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_PointCloudList_elevation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_PointCloudList_doppler", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_PointCloudList_snr_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_PointCloudList_flags", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_PointCloudList_mag_i", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_PointCloudList_mag_q", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_PointCloudList_rcs", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"OneDPtr_ClusterData_Indices", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"OneDPtr_ClusterData_ClusterIDs", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_PointCloudList_range", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_PointCloudList_azimuth", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_PointCloudList_elevation", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_PointCloudList_doppler", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_PointCloudList_snr_dB", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_PointCloudList_flags", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_PointCloudList_mag_i", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_PointCloudList_mag_q", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_PointCloudList_rcs", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ClusterData_Indices", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST},
            {"TwoDPtr_ClusterData_ClusterIDs", parquet_lib::DataType::UINT16, parquet_lib::ValueType::LIST}
        });
    }
}


void MERdrDataCubeMidW_Parquet_Out::parquet_init_detn_getrdc2data(void)
{
    add_message("DETN_GetRDC2Data", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("DETN_GetRDC2Data", {
        {"NumRD", parquet_lib::DataType::UINT8},
        {"RDC2Status", parquet_lib::DataType::UINT8}
    });

    for(uint i=0 ; i<512 ; i++)
    {
        add_signals("DETN_GetRDC2Data", {
            {"RDC2MatrixPtr_I", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST},
            {"RDC2MatrixPtr_Q", parquet_lib::DataType::FLOAT32, parquet_lib::ValueType::LIST}
        });
    }
}


void MERdrDataCubeMidW_Parquet_Out::parquet_init_rdcst(void)
{
    add_message("RDCST", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("RDCST", {
        {"RDCSt", parquet_lib::DataType::UINT8}
    });
}


void MERdrDataCubeMidW_Parquet_Out::parquet_init_scaninfo(void)
{
    add_message("SCANINFO", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("SCANINFO", {
        {"ProcessingPrio", parquet_lib::DataType::UINT8},
        {"ScanInfo_ScanSet", parquet_lib::DataType::UINT8},
        {"ScanInfo_ScanDimension", parquet_lib::DataType::UINT8},
        {"ScanInfo_EgoRdr_VX", parquet_lib::DataType::FLOAT32},
        {"ScanInfo_EgoRdr_VY", parquet_lib::DataType::FLOAT32},
        {"ScanInfo_EgoRdr_VZ", parquet_lib::DataType::FLOAT32},
        {"ScanInfo_EgoRdrEstimd_VX", parquet_lib::DataType::FLOAT32},
        {"ScanInfo_EgoRdrEstimd_VY", parquet_lib::DataType::FLOAT32},
        {"ScanInfo_EgoRdrEstimd_VZ", parquet_lib::DataType::FLOAT32}
    });

    for(uint i=0 ; i<2 ; i++)
    {
        add_signals("SCANINFO", {
            {"ScanInfo_ScanSequenceNumbers", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST},
            {"ScanInfo_ScanTimestamps", parquet_lib::DataType::UINT32, parquet_lib::ValueType::LIST}
        });
    }
}


void MERdrDataCubeMidW_Parquet_Out::parquet_init_version_merdrdatacubemidw_getversioninfo(void)
{
    add_message("VERSION_MERdrDataCubeMidW_GetVersionInfo", "timestamp", {{"timestamp", parquet_lib::DataType::INT64}});

    add_signals("VERSION_MERdrDataCubeMidW_GetVersionInfo", {
        {"Sw_Major", parquet_lib::DataType::UINT8},
        {"Sw_Minor", parquet_lib::DataType::UINT8},
        {"Sw_Patch", parquet_lib::DataType::UINT8},
        {"If_Major", parquet_lib::DataType::UINT8},
        {"If_Minor", parquet_lib::DataType::UINT8},
        {"If_Patch", parquet_lib::DataType::UINT8},
        {"Cmp_VendorId", parquet_lib::DataType::UINT16},
        {"Cmp_ModuleId", parquet_lib::DataType::UINT16}
    });

    for(uint i=0 ; i<20 ; i++)
    {
        add_signals("VERSION_MERdrDataCubeMidW_GetVersionInfo", {
            {"Cmp_BuildNoSwc", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST},
            {"Cmp_BuildNoSwcIf", parquet_lib::DataType::UINT8, parquet_lib::ValueType::LIST}
        });
    }
}




/*----------------------------------------------------------------------------*/
/*  WRITE DATA INTO PARQUET                                                   */
/*----------------------------------------------------------------------------*/

void MERdrDataCubeMidW_Parquet_Out::parquet_export_detn_getmidwdata(
    msg_swc_common::msg::MsgDetnGetMidWDataType *msg)
{
    parquet_lib::SignalValuesListType list_signal_values;

    append_values("DETN_GetMidWData", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"OneDPtr_ScanInfo_ScanSet", msg->one_d_ptr.scan_info.scan_set},
        {"OneDPtr_ScanInfo_ScanDimension", msg->one_d_ptr.scan_info.scan_dimension},
        {"OneDPtr_ScanInfo_EgoRdr_VX", msg->one_d_ptr.scan_info.ego_rdr.vx},
        {"OneDPtr_ScanInfo_EgoRdr_VY", msg->one_d_ptr.scan_info.ego_rdr.vy},
        {"OneDPtr_ScanInfo_EgoRdr_VZ", msg->one_d_ptr.scan_info.ego_rdr.vz},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VX", msg->one_d_ptr.scan_info.ego_rdr_estimd.vx},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VY", msg->one_d_ptr.scan_info.ego_rdr_estimd.vy},
        {"OneDPtr_ScanInfo_EgoRdrEstimd_VZ", msg->one_d_ptr.scan_info.ego_rdr_estimd.vz},
        {"OneDPtr_ClusterData_NumClusters", msg->one_d_ptr.cluster_data.num_clusters},
        {"OneDPtr_ClusterData_NumExpandedClusters", msg->one_d_ptr.cluster_data.num_expanded_clusters},
        {"TwoDPtr_ScanInfo_ScanSet", msg->two_d_ptr.scan_info.scan_set},
        {"TwoDPtr_ScanInfo_ScanDimension", msg->two_d_ptr.scan_info.scan_dimension},
        {"TwoDPtr_ScanInfo_EgoRdr_VX", msg->two_d_ptr.scan_info.ego_rdr.vx},
        {"TwoDPtr_ScanInfo_EgoRdr_VY", msg->two_d_ptr.scan_info.ego_rdr.vy},
        {"TwoDPtr_ScanInfo_EgoRdr_VZ", msg->two_d_ptr.scan_info.ego_rdr.vz},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VX", msg->two_d_ptr.scan_info.ego_rdr_estimd.vx},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VY", msg->two_d_ptr.scan_info.ego_rdr_estimd.vy},
        {"TwoDPtr_ScanInfo_EgoRdrEstimd_VZ", msg->two_d_ptr.scan_info.ego_rdr_estimd.vz},
        {"TwoDPtr_ClusterData_NumClusters", msg->two_d_ptr.cluster_data.num_clusters},
        {"TwoDPtr_ClusterData_NumExpandedClusters", msg->two_d_ptr.cluster_data.num_expanded_clusters}
    });

    for(uint i=0 ; i<2 ; i++)
    {
        list_signal_values["OneDPtr_ScanInfo_ScanSequenceNumbers"].push_back(msg->one_d_ptr.scan_info.scan_sequence_numbers[i]);
        list_signal_values["OneDPtr_ScanInfo_ScanTimestamps"].push_back(msg->one_d_ptr.scan_info.scan_timestamps[i]);
        list_signal_values["OneDPtr_DetectionList_StaticDetns_NumElemPerScan"].push_back(msg->one_d_ptr.detection_list.static_detns.num_elem_per_scan[i]);
        list_signal_values["OneDPtr_DetectionList_DynamicDetns_NumElemPerScan"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.num_elem_per_scan[i]);
        list_signal_values["OneDPtr_PointCloudList_NumElemPerScan"].push_back(msg->one_d_ptr.point_cloud_list.num_elem_per_scan[i]);
        list_signal_values["OneDPtr_ScanParams_ScanTime"].push_back(msg->one_d_ptr.scan_params[i].scan_time);
        list_signal_values["OneDPtr_ScanParams_PulseTime"].push_back(msg->one_d_ptr.scan_params[i].pulse_time);
        list_signal_values["OneDPtr_ScanParams_ChipTime"].push_back(msg->one_d_ptr.scan_params[i].chip_time);
        list_signal_values["OneDPtr_ScanParams_DopplerBinWidth"].push_back(msg->one_d_ptr.scan_params[i].doppler_bin_width);
        list_signal_values["OneDPtr_ScanParams_RangeBinWidth"].push_back(msg->one_d_ptr.scan_params[i].range_bin_width);
        list_signal_values["OneDPtr_ScanParams_PulsesPerScan"].push_back(msg->one_d_ptr.scan_params[i].pulses_per_scan);
        list_signal_values["OneDPtr_ScanParams_ChipsPerPulse"].push_back(msg->one_d_ptr.scan_params[i].chips_per_pulse);
        list_signal_values["OneDPtr_ScanParams_CodeType"].push_back(msg->one_d_ptr.scan_params[i].code_type);
        list_signal_values["OneDPtr_ScanParams_NumRangeBins"].push_back(msg->one_d_ptr.scan_params[i].num_range_bins);
        list_signal_values["OneDPtr_ScanParams_NumAzimuthBins"].push_back(msg->one_d_ptr.scan_params[i].num_azimuth_bins);
        list_signal_values["OneDPtr_ScanParams_NumElevationBins"].push_back(msg->one_d_ptr.scan_params[i].num_elevation_bins);
        list_signal_values["OneDPtr_ScanParams_NumVRXUsed"].push_back(msg->one_d_ptr.scan_params[i].num_vrx_used);
        list_signal_values["OneDPtr_ScanParams_WrapAzimuthAngles"].push_back(msg->one_d_ptr.scan_params[i].wrap_azimuth_angles);
        list_signal_values["OneDPtr_ScanParams_WrapElevationAngles"].push_back(msg->one_d_ptr.scan_params[i].wrap_elevation_angles);
        list_signal_values["OneDPtr_ScanParams_ScanLambda"].push_back(msg->one_d_ptr.scan_params[i].scan_lambda);
        list_signal_values["OneDPtr_ScanParams_FirstRangeBin"].push_back(msg->one_d_ptr.scan_params[i].first_range_bin);
        list_signal_values["OneDPtr_ScanParams_AzimuthSineBinSize"].push_back(msg->one_d_ptr.scan_params[i].azimuth_sine_bin_size);
        list_signal_values["OneDPtr_ScanParams_AzimuthSineZeroLocation"].push_back(msg->one_d_ptr.scan_params[i].azimuth_sine_zero_location);
        list_signal_values["OneDPtr_ScanParams_ElevationSineBinSize"].push_back(msg->one_d_ptr.scan_params[i].elevation_sine_bin_size);
        list_signal_values["OneDPtr_ScanParams_ElevationSineZeroLocation"].push_back(msg->one_d_ptr.scan_params[i].elevation_sine_zero_location);
        list_signal_values["TwoDPtr_ScanInfo_ScanSequenceNumbers"].push_back(msg->two_d_ptr.scan_info.scan_sequence_numbers[i]);
        list_signal_values["TwoDPtr_ScanInfo_ScanTimestamps"].push_back(msg->two_d_ptr.scan_info.scan_timestamps[i]);
        list_signal_values["TwoDPtr_DetectionList_StaticDetns_NumElemPerScan"].push_back(msg->two_d_ptr.detection_list.static_detns.num_elem_per_scan[i]);
        list_signal_values["TwoDPtr_DetectionList_DynamicDetns_NumElemPerScan"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.num_elem_per_scan[i]);
        list_signal_values["TwoDPtr_PointCloudList_NumElemPerScan"].push_back(msg->two_d_ptr.point_cloud_list.num_elem_per_scan[i]);
        list_signal_values["TwoDPtr_ScanParams_ScanTime"].push_back(msg->two_d_ptr.scan_params[i].scan_time);
        list_signal_values["TwoDPtr_ScanParams_PulseTime"].push_back(msg->two_d_ptr.scan_params[i].pulse_time);
        list_signal_values["TwoDPtr_ScanParams_ChipTime"].push_back(msg->two_d_ptr.scan_params[i].chip_time);
        list_signal_values["TwoDPtr_ScanParams_DopplerBinWidth"].push_back(msg->two_d_ptr.scan_params[i].doppler_bin_width);
        list_signal_values["TwoDPtr_ScanParams_RangeBinWidth"].push_back(msg->two_d_ptr.scan_params[i].range_bin_width);
        list_signal_values["TwoDPtr_ScanParams_PulsesPerScan"].push_back(msg->two_d_ptr.scan_params[i].pulses_per_scan);
        list_signal_values["TwoDPtr_ScanParams_ChipsPerPulse"].push_back(msg->two_d_ptr.scan_params[i].chips_per_pulse);
        list_signal_values["TwoDPtr_ScanParams_CodeType"].push_back(msg->two_d_ptr.scan_params[i].code_type);
        list_signal_values["TwoDPtr_ScanParams_NumRangeBins"].push_back(msg->two_d_ptr.scan_params[i].num_range_bins);
        list_signal_values["TwoDPtr_ScanParams_NumAzimuthBins"].push_back(msg->two_d_ptr.scan_params[i].num_azimuth_bins);
        list_signal_values["TwoDPtr_ScanParams_NumElevationBins"].push_back(msg->two_d_ptr.scan_params[i].num_elevation_bins);
        list_signal_values["TwoDPtr_ScanParams_NumVRXUsed"].push_back(msg->two_d_ptr.scan_params[i].num_vrx_used);
        list_signal_values["TwoDPtr_ScanParams_WrapAzimuthAngles"].push_back(msg->two_d_ptr.scan_params[i].wrap_azimuth_angles);
        list_signal_values["TwoDPtr_ScanParams_WrapElevationAngles"].push_back(msg->two_d_ptr.scan_params[i].wrap_elevation_angles);
        list_signal_values["TwoDPtr_ScanParams_ScanLambda"].push_back(msg->two_d_ptr.scan_params[i].scan_lambda);
        list_signal_values["TwoDPtr_ScanParams_FirstRangeBin"].push_back(msg->two_d_ptr.scan_params[i].first_range_bin);
        list_signal_values["TwoDPtr_ScanParams_AzimuthSineBinSize"].push_back(msg->two_d_ptr.scan_params[i].azimuth_sine_bin_size);
        list_signal_values["TwoDPtr_ScanParams_AzimuthSineZeroLocation"].push_back(msg->two_d_ptr.scan_params[i].azimuth_sine_zero_location);
        list_signal_values["TwoDPtr_ScanParams_ElevationSineBinSize"].push_back(msg->two_d_ptr.scan_params[i].elevation_sine_bin_size);
        list_signal_values["TwoDPtr_ScanParams_ElevationSineZeroLocation"].push_back(msg->two_d_ptr.scan_params[i].elevation_sine_zero_location);
    }
    append_values("DETN_GetMidWData", list_signal_values);
    list_signal_values.clear();

    for(uint i=0 ; i<128 ; i++)
    {
        list_signal_values["OneDPtr_ClusterData_ClusterInfo_maxSNRIndx"].push_back(msg->one_d_ptr.cluster_data.cluster_info[i].max_snr_indx);
        list_signal_values["OneDPtr_ClusterData_ClusterInfo_ClusterSize"].push_back(msg->one_d_ptr.cluster_data.cluster_info[i].cluster_size);
        list_signal_values["OneDPtr_ClusterData_ClusterInfo_MinRangeIndx"].push_back(msg->one_d_ptr.cluster_data.cluster_info[i].min_range_indx);
        list_signal_values["OneDPtr_ClusterData_ClusterInfo_StartingPointIndx"].push_back(msg->one_d_ptr.cluster_data.cluster_info[i].starting_point_indx);
        list_signal_values["TwoDPtr_ClusterData_ClusterInfo_maxSNRIndx"].push_back(msg->two_d_ptr.cluster_data.cluster_info[i].max_snr_indx);
        list_signal_values["TwoDPtr_ClusterData_ClusterInfo_ClusterSize"].push_back(msg->two_d_ptr.cluster_data.cluster_info[i].cluster_size);
        list_signal_values["TwoDPtr_ClusterData_ClusterInfo_MinRangeIndx"].push_back(msg->two_d_ptr.cluster_data.cluster_info[i].min_range_indx);
        list_signal_values["TwoDPtr_ClusterData_ClusterInfo_StartingPointIndx"].push_back(msg->two_d_ptr.cluster_data.cluster_info[i].starting_point_indx);
    }
    append_values("DETN_GetMidWData", list_signal_values);
    list_signal_values.clear();

    for(uint i=0 ; i<512 ; i++)
    {
        list_signal_values["OneDPtr_DetectionList_StaticDetns_CoorPolar_Range"].push_back(msg->one_d_ptr.detection_list.static_detns.coor_polar[i].range);
        list_signal_values["OneDPtr_DetectionList_StaticDetns_CoorPolar_Azimuth"].push_back(msg->one_d_ptr.detection_list.static_detns.coor_polar[i].azimuth);
        list_signal_values["OneDPtr_DetectionList_StaticDetns_CoorPolar_Elevation"].push_back(msg->one_d_ptr.detection_list.static_detns.coor_polar[i].elevation);
        list_signal_values["OneDPtr_DetectionList_StaticDetns_Doppler"].push_back(msg->one_d_ptr.detection_list.static_detns.doppler[i]);
        list_signal_values["OneDPtr_DetectionList_StaticDetns_Magnitude"].push_back(msg->one_d_ptr.detection_list.static_detns.magnitude[i]);
        list_signal_values["OneDPtr_DetectionList_StaticDetns_SigToNoiseRat"].push_back(msg->one_d_ptr.detection_list.static_detns.sig_to_noise_rat[i]);
        list_signal_values["OneDPtr_DetectionList_StaticDetns_RdrCrossSectn"].push_back(msg->one_d_ptr.detection_list.static_detns.rdr_cross_sectn[i]);
        list_signal_values["OneDPtr_DetectionList_StaticDetns_Flags"].push_back(msg->one_d_ptr.detection_list.static_detns.flags[i]);
        list_signal_values["OneDPtr_DetectionList_DynamicDetns_CoorPolar_Range"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.coor_polar[i].range);
        list_signal_values["OneDPtr_DetectionList_DynamicDetns_CoorPolar_Azimuth"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.coor_polar[i].azimuth);
        list_signal_values["OneDPtr_DetectionList_DynamicDetns_CoorPolar_Elevation"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.coor_polar[i].elevation);
        list_signal_values["OneDPtr_DetectionList_DynamicDetns_Doppler"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.doppler[i]);
        list_signal_values["OneDPtr_DetectionList_DynamicDetns_Magnitude"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.magnitude[i]);
        list_signal_values["OneDPtr_DetectionList_DynamicDetns_SigToNoiseRat"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.sig_to_noise_rat[i]);
        list_signal_values["OneDPtr_DetectionList_DynamicDetns_RdrCrossSectn"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.rdr_cross_sectn[i]);
        list_signal_values["OneDPtr_DetectionList_DynamicDetns_Flags"].push_back(msg->one_d_ptr.detection_list.dynamic_detns.flags[i]);
        list_signal_values["TwoDPtr_DetectionList_StaticDetns_CoorPolar_Range"].push_back(msg->two_d_ptr.detection_list.static_detns.coor_polar[i].range);
        list_signal_values["TwoDPtr_DetectionList_StaticDetns_CoorPolar_Azimuth"].push_back(msg->two_d_ptr.detection_list.static_detns.coor_polar[i].azimuth);
        list_signal_values["TwoDPtr_DetectionList_StaticDetns_CoorPolar_Elevation"].push_back(msg->two_d_ptr.detection_list.static_detns.coor_polar[i].elevation);
        list_signal_values["TwoDPtr_DetectionList_StaticDetns_Doppler"].push_back(msg->two_d_ptr.detection_list.static_detns.doppler[i]);
        list_signal_values["TwoDPtr_DetectionList_StaticDetns_Magnitude"].push_back(msg->two_d_ptr.detection_list.static_detns.magnitude[i]);
        list_signal_values["TwoDPtr_DetectionList_StaticDetns_SigToNoiseRat"].push_back(msg->two_d_ptr.detection_list.static_detns.sig_to_noise_rat[i]);
        list_signal_values["TwoDPtr_DetectionList_StaticDetns_RdrCrossSectn"].push_back(msg->two_d_ptr.detection_list.static_detns.rdr_cross_sectn[i]);
        list_signal_values["TwoDPtr_DetectionList_StaticDetns_Flags"].push_back(msg->two_d_ptr.detection_list.static_detns.flags[i]);
        list_signal_values["TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Range"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.coor_polar[i].range);
        list_signal_values["TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Azimuth"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.coor_polar[i].azimuth);
        list_signal_values["TwoDPtr_DetectionList_DynamicDetns_CoorPolar_Elevation"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.coor_polar[i].elevation);
        list_signal_values["TwoDPtr_DetectionList_DynamicDetns_Doppler"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.doppler[i]);
        list_signal_values["TwoDPtr_DetectionList_DynamicDetns_Magnitude"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.magnitude[i]);
        list_signal_values["TwoDPtr_DetectionList_DynamicDetns_SigToNoiseRat"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.sig_to_noise_rat[i]);
        list_signal_values["TwoDPtr_DetectionList_DynamicDetns_RdrCrossSectn"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.rdr_cross_sectn[i]);
        list_signal_values["TwoDPtr_DetectionList_DynamicDetns_Flags"].push_back(msg->two_d_ptr.detection_list.dynamic_detns.flags[i]);
    }
    append_values("DETN_GetMidWData", list_signal_values);
    list_signal_values.clear();

    for(uint i=0 ; i<2048 ; i++)
    {
        list_signal_values["OneDPtr_PointCloudList_range"].push_back(msg->one_d_ptr.point_cloud_list.range[i]);
        list_signal_values["OneDPtr_PointCloudList_azimuth"].push_back(msg->one_d_ptr.point_cloud_list.azimuth[i]);
        list_signal_values["OneDPtr_PointCloudList_elevation"].push_back(msg->one_d_ptr.point_cloud_list.elevation[i]);
        list_signal_values["OneDPtr_PointCloudList_doppler"].push_back(msg->one_d_ptr.point_cloud_list.doppler[i]);
        list_signal_values["OneDPtr_PointCloudList_snr_dB"].push_back(msg->one_d_ptr.point_cloud_list.snrd_b[i]);
        list_signal_values["OneDPtr_PointCloudList_flags"].push_back(msg->one_d_ptr.point_cloud_list.flags[i]);
        list_signal_values["OneDPtr_PointCloudList_mag_i"].push_back(msg->one_d_ptr.point_cloud_list.magi[i]);
        list_signal_values["OneDPtr_PointCloudList_mag_q"].push_back(msg->one_d_ptr.point_cloud_list.magq[i]);
        list_signal_values["OneDPtr_PointCloudList_rcs"].push_back(msg->one_d_ptr.point_cloud_list.rcs[i]);
        list_signal_values["OneDPtr_ClusterData_Indices"].push_back(msg->one_d_ptr.cluster_data.indices[i]);
        list_signal_values["OneDPtr_ClusterData_ClusterIDs"].push_back(msg->one_d_ptr.cluster_data.cluster_i_ds[i]);
        list_signal_values["TwoDPtr_PointCloudList_range"].push_back(msg->two_d_ptr.point_cloud_list.range[i]);
        list_signal_values["TwoDPtr_PointCloudList_azimuth"].push_back(msg->two_d_ptr.point_cloud_list.azimuth[i]);
        list_signal_values["TwoDPtr_PointCloudList_elevation"].push_back(msg->two_d_ptr.point_cloud_list.elevation[i]);
        list_signal_values["TwoDPtr_PointCloudList_doppler"].push_back(msg->two_d_ptr.point_cloud_list.doppler[i]);
        list_signal_values["TwoDPtr_PointCloudList_snr_dB"].push_back(msg->two_d_ptr.point_cloud_list.snrd_b[i]);
        list_signal_values["TwoDPtr_PointCloudList_flags"].push_back(msg->two_d_ptr.point_cloud_list.flags[i]);
        list_signal_values["TwoDPtr_PointCloudList_mag_i"].push_back(msg->two_d_ptr.point_cloud_list.magi[i]);
        list_signal_values["TwoDPtr_PointCloudList_mag_q"].push_back(msg->two_d_ptr.point_cloud_list.magq[i]);
        list_signal_values["TwoDPtr_PointCloudList_rcs"].push_back(msg->two_d_ptr.point_cloud_list.rcs[i]);
        list_signal_values["TwoDPtr_ClusterData_Indices"].push_back(msg->two_d_ptr.cluster_data.indices[i]);
        list_signal_values["TwoDPtr_ClusterData_ClusterIDs"].push_back(msg->two_d_ptr.cluster_data.cluster_i_ds[i]);
    }
    append_values("DETN_GetMidWData", list_signal_values);
    list_signal_values.clear();
}


void MERdrDataCubeMidW_Parquet_Out::parquet_export_detn_getrdc2data(
    msg_swc_common::msg::MsgDetnGetRdc2DataTypeArr *msg)
{
    parquet_lib::SignalValuesListType list_signal_values;

    append_values("DETN_GetRDC2Data", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"NumRD", msg->msg_detn_get_rdc2_data_type.at(0).num_rd},
        {"RDC2Status", msg->msg_detn_get_rdc2_data_type.at(0).rdc2_status}
    });

    for(uint i=0 ; i<512 ; i++)
    {
        list_signal_values["RDC2MatrixPtr_I"].push_back(msg->msg_detn_get_rdc2_data_type.at(0).rdc2_matrix_ptr[i].i);
        list_signal_values["RDC2MatrixPtr_Q"].push_back(msg->msg_detn_get_rdc2_data_type.at(0).rdc2_matrix_ptr[i].q);
    }
    append_values("DETN_GetRDC2Data", list_signal_values);
    list_signal_values.clear();
}


void MERdrDataCubeMidW_Parquet_Out::parquet_export_rdcst(
    msg_swc_common::msg::MsgRdcstType *msg)
{
    append_values("RDCST", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"RDCSt", msg->rdc_st}
    });
}


void MERdrDataCubeMidW_Parquet_Out::parquet_export_scaninfo(
    msg_swc_common::msg::MsgScaninfoType *msg)
{
    parquet_lib::SignalValuesListType list_signal_values;

    append_values("SCANINFO", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"ProcessingPrio", msg->processing_prio},
        {"ScanInfo_ScanSet", msg->scan_info.scan_set},
        {"ScanInfo_ScanDimension", msg->scan_info.scan_dimension},
        {"ScanInfo_EgoRdr_VX", msg->scan_info.ego_rdr.vx},
        {"ScanInfo_EgoRdr_VY", msg->scan_info.ego_rdr.vy},
        {"ScanInfo_EgoRdr_VZ", msg->scan_info.ego_rdr.vz},
        {"ScanInfo_EgoRdrEstimd_VX", msg->scan_info.ego_rdr_estimd.vx},
        {"ScanInfo_EgoRdrEstimd_VY", msg->scan_info.ego_rdr_estimd.vy},
        {"ScanInfo_EgoRdrEstimd_VZ", msg->scan_info.ego_rdr_estimd.vz}
    });

    for(uint i=0 ; i<2 ; i++)
    {
        list_signal_values["ScanInfo_ScanSequenceNumbers"].push_back(msg->scan_info.scan_sequence_numbers[i]);
        list_signal_values["ScanInfo_ScanTimestamps"].push_back(msg->scan_info.scan_timestamps[i]);
    }
    append_values("SCANINFO", list_signal_values);
    list_signal_values.clear();
}


void MERdrDataCubeMidW_Parquet_Out::parquet_export_version_merdrdatacubemidw_getversioninfo(
    msg_swc_common::msg::MsgVersionMeRdrDataCubeMidWGetVersionInfoType *msg)
{
    parquet_lib::SignalValuesListType list_signal_values;

    append_values("VERSION_MERdrDataCubeMidW_GetVersionInfo", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"Sw_Major", msg->sw.r_major},
        {"Sw_Minor", msg->sw.r_minor},
        {"Sw_Patch", msg->sw.patch},
        {"If_Major", msg->r_if.r_major},
        {"If_Minor", msg->r_if.r_minor},
        {"If_Patch", msg->r_if.patch},
        {"Cmp_VendorId", msg->cmp.vendor_id},
        {"Cmp_ModuleId", msg->cmp.module_id}
    });

    for(uint i=0 ; i<20 ; i++)
    {
        list_signal_values["Cmp_BuildNoSwc"].push_back(msg->cmp.build_no_swc[i]);
        list_signal_values["Cmp_BuildNoSwcIf"].push_back(msg->cmp.build_no_swc_if[i]);
    }
    append_values("VERSION_MERdrDataCubeMidW_GetVersionInfo", list_signal_values);
    list_signal_values.clear();
}
