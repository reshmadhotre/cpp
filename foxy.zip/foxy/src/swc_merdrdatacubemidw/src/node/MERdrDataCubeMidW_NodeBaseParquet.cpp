/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_NodeBaseParquet.cpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */


#include "MERdrDataCubeMidW_NodeBaseParquet.hpp"


MERdrDataCubeMidW_NodeBaseParquet::MERdrDataCubeMidW_NodeBaseParquet(std::shared_ptr<rclcpp::Node> node): node_{node}
{
    InitSubscriber();
    InitParameter();
    InitParquetExporter();
}


void MERdrDataCubeMidW_NodeBaseParquet::InitSubscriber()
{
    sub_node_feedback_ =
        node_->create_subscription<msg_swc_common::msg::MsgNodeFeedbackType>(
            "topic_node_feedback", QUEUE_SIZE_SUBSCRIBER_PARQUET,
            std::bind(&MERdrDataCubeMidW_NodeBaseParquet::callback_node_feedback,
                this, std::placeholders::_1)); 
}


void MERdrDataCubeMidW_NodeBaseParquet::InitParameter()
{
    const std::string PARAM_RECORD_PARQUET_IN{"param_record_input_parquets"};
    const std::string PARAM_RECORD_PARQUET_OUT{"param_record_output_parquets"};
    
    node_->declare_parameter(PARAM_RECORD_PARQUET_OUT, false);
    rclcpp::Parameter param_record_parquets = node_->get_parameter(PARAM_RECORD_PARQUET_OUT);
    param_record_parquets_out_ = param_record_parquets.as_bool();
    RCLCPP_INFO(node_->get_logger(), "Enable output parquet = %d ", param_record_parquets_out_);

    node_->declare_parameter(PARAM_RECORD_PARQUET_IN, false);
    param_record_parquets = node_->get_parameter(PARAM_RECORD_PARQUET_IN);
    param_record_parquets_in_ = param_record_parquets.as_bool();
    RCLCPP_INFO(node_->get_logger(), "Enable input parquet = %d ", param_record_parquets_in_);
}


void MERdrDataCubeMidW_NodeBaseParquet::InitParquetExporter()
{
    if(param_record_parquets_out_)
        queue_parquet_out_.push(std::make_unique<MERdrDataCubeMidW_Parquet_Out>());
    
    if(param_record_parquets_in_)
        queue_parquet_in_.push(std::make_unique<MERdrDataCubeMidW_Parquet_In>());
}


void MERdrDataCubeMidW_NodeBaseParquet::WriteParquetFile()
{
    if(!queue_parquet_out_.empty())
        queue_parquet_out_.back()->write_parquet();
    
    if(!queue_parquet_in_.empty())
        queue_parquet_in_.back()->write_parquet();

    if(!is_end_of_parquet_file_)
    {
        InitParquetExporter();
        is_parquet_file_name_set_ = false;
        has_file_changed_ = false;
    }
    else
    {
        is_parquet_file_name_set_ = true;
    }
    
    if (!queue_parquet_out_.empty())
    {
        if (queue_parquet_out_.front()->is_parquet_file_written())
            queue_parquet_out_.pop();
    }

    if (!queue_parquet_in_.empty())
    {
        if (queue_parquet_in_.front()->is_parquet_file_written())
            queue_parquet_in_.pop();
    }
}


bool MERdrDataCubeMidW_NodeBaseParquet::file_changed() const
{
    return has_file_changed_;
}


bool MERdrDataCubeMidW_NodeBaseParquet::enable_parquet_in() const
{
    return param_record_parquets_in_;
}


bool MERdrDataCubeMidW_NodeBaseParquet::enable_parquet_out() const
{
    return param_record_parquets_out_;
}


void MERdrDataCubeMidW_NodeBaseParquet::incr_cntr()
{
    msg_cntr_ += 1;
}


void MERdrDataCubeMidW_NodeBaseParquet::reset_cntr()
{
    msg_cntr_ = 1;
}


bool MERdrDataCubeMidW_NodeBaseParquet::write_data() const
{
    return (msg_cntr_ % 4 == 0);
}


void MERdrDataCubeMidW_NodeBaseParquet::callback_node_feedback(msg_swc_common::msg::MsgNodeFeedbackType::UniquePtr msg)
{
    if (param_record_parquets_out_ || param_record_parquets_in_)
    {	
        if ((!is_parquet_file_name_set_))
        {
            if(!queue_parquet_out_.empty())
            {
                queue_parquet_out_.back()->set_filename_out(msg->file_under_process);
            }
            if(!queue_parquet_in_.empty())
            {
                queue_parquet_in_.back()->set_filename_in(msg->file_under_process);
            }
            is_parquet_file_name_set_ = true;
        }

        if (msg->num_files_processed > counter_)
        {
            has_file_changed_ = true;
            if((param_record_parquets_out_ == false) && (param_record_parquets_in_ == true))
            {
                WriteParquetFile();
            }
            counter_ += 1;
        }

        if ((msg->status == msg->FINISHED))
        {
            is_end_of_parquet_file_ = true;
            WriteParquetFile();
            param_record_parquets_out_ = false;
            param_record_parquets_in_ = false;
        }
    }
}
