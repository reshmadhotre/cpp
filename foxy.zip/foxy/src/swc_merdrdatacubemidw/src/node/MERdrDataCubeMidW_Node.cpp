/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_Node.cpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */


#include "MERdrDataCubeMidW_Node.hpp"



MERdrDataCubeMidW_Node::MERdrDataCubeMidW_Node(std::shared_ptr<rclcpp::Node> node) : MERdrDataCubeMidW_NodeBaseTrigger(node), node_(node)
{
    if (node_base_init) {
        RCLCPP_DEBUG(node_->get_logger(), "Initializing node master...");
        
        /*--------------------------------*/
        // Start of SW developer free zone
        /*--------------------------------*/
        
        // Do here what you want

        /*--------------------------------*/
        // End of SW developer free zone
        /*--------------------------------*/
        init_subscriber();
        init_synchronizer();

        RCLCPP_DEBUG(node_->get_logger(), "");
        RCLCPP_INFO(node_->get_logger(), ">> Ready for take off");
        RCLCPP_DEBUG(node_->get_logger(), "---------------------------------------");
    }
}


MERdrDataCubeMidW_Node::~MERdrDataCubeMidW_Node()
{
}


void MERdrDataCubeMidW_Node::init_subscriber(void)
{
    sub_midw_int_all_data_ =
        node_->create_subscription<msg_replay_radar::msg::MsgMidwIntAllDataType>(
            "topic_rra_data", QUEUE_SIZE_SUBSCRIBER,
                std::bind(&MERdrDataCubeMidW_Node::callback_midw_int_all_data,
                this, std::placeholders::_1));
    
    sub_radarcfg_type_ =
        node_->create_subscription<msg_can_addon::msg::MsgRadarcfgType>(
            "topic_can_radarcfg", QUEUE_SIZE_SUBSCRIBER,
                std::bind(&MERdrDataCubeMidW_Node::callback_radarcfg,
                this, std::placeholders::_1));
}


void MERdrDataCubeMidW_Node::init_synchronizer(void)
{
    //map_sync_[Synchronization_Index_List::SYNC_ID_RADAR_DATA_UHDP] = std::make_unique<Synchronizer<msg_replay_radar::msg::MsgRraData>> (std::bind(&MERdrDataCubeMidW_Node::sync_callback_radar_data_uhdp, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_RADAR_DATA_UHDP] = std::make_unique<Synchronizer<msg_replay_radar::msg::MsgMidwIntAllDataType>> (std::bind(&MERdrDataCubeMidW_Node::sync_callback_midw_int_all_data, this, std::placeholders::_1));
}


void MERdrDataCubeMidW_Node::callback_midw_int_all_data(msg_replay_radar::msg::MsgMidwIntAllDataType::UniquePtr msg)
{
    if (0 == map_sync_.count(MERdrDataCubeMidW_Node::Synchronization_Index_List::SYNC_ID_RADAR_DATA_UHDP))
        return;
    auto p = std::dynamic_pointer_cast<Synchronizer<msg_replay_radar::msg::MsgMidwIntAllDataType>>(map_sync_.at(MERdrDataCubeMidW_Node::Synchronization_Index_List::SYNC_ID_RADAR_DATA_UHDP));
    p->setMsg(std::move(msg));
    MERdrDataCubeMidW_NodeBase::check_and_process(MERdrDataCubeMidW_Node::Synchronization_Index_List::SYNC_ID_RADAR_DATA_UHDP);
}


void MERdrDataCubeMidW_Node::callback_radarcfg(msg_can_addon::msg::MsgRadarcfgType::UniquePtr msg)
{
    auto out_msg = std::make_unique<msg_swc_common::msg::MsgRadarcfgType>();
    out_msg->header.stamp = msg->header.stamp;
    out_msg->radar_role = msg->radar_role;
    out_msg->func_arr = msg->func_arr;
    RCLCPP_DEBUG(node_->get_logger(), "radar_role = %d", static_cast<uint16_t>(msg->radar_role));
    if ((msg->radar_role > RADARROLE_NOT_CONFIGURED) && (msg->radar_role != RADARROLE_SNA) && (m_pCoreEnv != nullptr))
    {
        m_pCoreEnv->GetDataSetBasePtr()->MEAPPMOD = RTE_MODE_MEAppMod_APPMOD_RUN;
    }
    MERdrDataCubeMidW_NodeBase::callback_radarcfg(std::move(out_msg));
}


void MERdrDataCubeMidW_Node::sync_callback_midw_int_all_data(msg_replay_radar::msg::MsgMidwIntAllDataType::UniquePtr msg)
{
    if (m_pCoreEnv != nullptr) 
    {
        MidwInt_AllData_Type midw_all_int_data{};
        for (size_t idx = 0; idx < MIDW_ADPR_NUM_SCAN_SETS; idx++)
        {
            memcpy(&midw_all_int_data.auxData, &(msg->aux_data), sizeof(MidwInt_AppendixData_Type));
            memcpy(&midw_all_int_data.header, &(msg->r_header), sizeof(MidwInt_DataHeader_Type));
            memcpy(&midw_all_int_data.scanInfo[idx], &(msg->scan_info.at(idx)), sizeof(Rdc_ScanInfoType));
            memcpy(&midw_all_int_data.scanParams[idx], &(msg->scan_params.at(idx)), sizeof(Rdc_ScanParamsType));
            memcpy(&midw_all_int_data.rdc2Data[idx], &(msg->rdc2_data.at(idx)), sizeof(MidwInt_Rdc2Data_Type));
            memcpy(&midw_all_int_data.rawPointCloudList[idx], &(msg->raw_point_cloud_list.at(idx)), sizeof(MidwInt_RawPointCloudList_Type));

            memcpy(&midw_all_int_data.convPointCloudList[idx].NumElements, &(msg->conv_point_cloud_list.at(idx).num_elements), sizeof(uint16));
            memcpy(&midw_all_int_data.convPointCloudList[idx].range, &(msg->conv_point_cloud_list.at(idx).range), sizeof(float32)*MAX_UHNDER_POINTCLOUD_ELEMENTS);
            memcpy(&midw_all_int_data.convPointCloudList[idx].azimuth, &(msg->conv_point_cloud_list.at(idx).azimuth), sizeof(float32)*MAX_UHNDER_POINTCLOUD_ELEMENTS);
            memcpy(&midw_all_int_data.convPointCloudList[idx].elevation, &(msg->conv_point_cloud_list.at(idx).elevation), sizeof(float32)*MAX_UHNDER_POINTCLOUD_ELEMENTS);
            memcpy(&midw_all_int_data.convPointCloudList[idx].doppler, &(msg->conv_point_cloud_list.at(idx).doppler), sizeof(float32)*MAX_UHNDER_POINTCLOUD_ELEMENTS);
            memcpy(&midw_all_int_data.convPointCloudList[idx].snr_dB, &(msg->conv_point_cloud_list.at(idx).snr_db), sizeof(float32)*MAX_UHNDER_POINTCLOUD_ELEMENTS);
            memcpy(&midw_all_int_data.convPointCloudList[idx].flags, &(msg->conv_point_cloud_list.at(idx).flags), sizeof(uint32)*MAX_UHNDER_POINTCLOUD_ELEMENTS);

            memcpy(&midw_all_int_data.detectionList[idx].NumElemPerScan, &(msg->detection_list.at(idx).num_elem_per_scan), sizeof(Rdc_NumElemPerScanArrType));
            memcpy(&midw_all_int_data.detectionList[idx].CoorPolar, &(msg->detection_list.at(idx).coor_polar), sizeof(DetnCoorPolarArrType));
            memcpy(&midw_all_int_data.detectionList[idx].Doppler, &(msg->detection_list.at(idx).doppler), sizeof(DetnFloat32ArrType));
            memcpy(&midw_all_int_data.detectionList[idx].Magnitude, &(msg->detection_list.at(idx).magnitude), sizeof(DetnFloat32ArrType));
            memcpy(&midw_all_int_data.detectionList[idx].SigToNoiseRat, &(msg->detection_list.at(idx).sig_to_noise_rat), sizeof(DetnFloat32ArrType));
            memcpy(&midw_all_int_data.detectionList[idx].RdrCrossSectn, &(msg->detection_list.at(idx).rdr_cross_sectn), sizeof(DetnFloat32ArrType));
            memcpy(&midw_all_int_data.detectionList[idx].Flags, &(msg->detection_list.at(idx).flags), sizeof(DetnUInt32ArrType));
        }

        m_pCoreEnv->Set_MidwIntAllDataBuffer(&midw_all_int_data);
        if(parquet_handler_.enable_parquet_in())
            parquet_handler_.queue_parquet_in_.back()->parquet_export_midw_all_int_data(std::move(msg));
    }
    else
    {
        RCLCPP_ERROR(node_->get_logger(),
	             "m_pCoreEnv == Null  -- Library correctly loaded?");
    }
}
