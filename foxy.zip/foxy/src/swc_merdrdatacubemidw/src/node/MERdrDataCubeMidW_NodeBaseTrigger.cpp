/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_NodeBaseTrigger.cpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */


#include "MERdrDataCubeMidW_NodeBaseTrigger.hpp"



MERdrDataCubeMidW_NodeBaseTrigger::MERdrDataCubeMidW_NodeBaseTrigger(std::shared_ptr<rclcpp::Node> node) : MERdrDataCubeMidW_NodeBase(node), node_(node)
{
    if (node_base_init) 
    {
        RCLCPP_DEBUG(node_->get_logger(), "Initializing node base trigger...");
        init_subscriber();
        init_publisher();
        init_parameter();
        init_synchronizer();

        if(param_previous_node_.empty())
            RCLCPP_INFO(node_->get_logger(), "Triggered by: Not defined");
        else
            RCLCPP_INFO(node_->get_logger(), "Triggered by: '%s'", param_previous_node_.c_str());
    }
}


MERdrDataCubeMidW_NodeBaseTrigger::~MERdrDataCubeMidW_NodeBaseTrigger()
{
}


void MERdrDataCubeMidW_NodeBaseTrigger::init_publisher()
{
    pub_trigger_init_ =
        node_->create_publisher<msg_swc_common::msg::MsgTriggerInitType>(
            "topic_swc_merdrdatacubemidw_trigger_init", QUEUE_SIZE_PUBLISHER);
    pub_trigger_cyclic_ =
        node_->create_publisher<msg_swc_common::msg::MsgTriggerCyclicType>(
            "topic_swc_merdrdatacubemidw_trigger_cyclic", QUEUE_SIZE_PUBLISHER);
}


void MERdrDataCubeMidW_NodeBaseTrigger::init_subscriber()
{
    sub_trigger_init_ =
        node_->create_subscription<msg_swc_common::msg::MsgTriggerInitType>(
            "topic_trigger_init", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBaseTrigger::callback_trigger_init,
                this, std::placeholders::_1)); 
    sub_trigger_cyclic_ =
        node_->create_subscription<msg_swc_common::msg::MsgTriggerCyclicType>(
            "topic_trigger_cyclic", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBaseTrigger::callback_trigger_cyclic,
                this, std::placeholders::_1)); 
}


void MERdrDataCubeMidW_NodeBaseTrigger::init_parameter()
{
    node_->declare_parameter("param_trigger_cyclic_immediate", true);
    rclcpp::Parameter param_trigger_cyclic_immediate =
        node_->get_parameter("param_trigger_cyclic_immediate");
    param_trigger_cyclic_immediate_ = param_trigger_cyclic_immediate.as_bool();

    rclcpp::Parameter param_previous_node =
        node_->get_parameter("param_previous_node");
    param_previous_node_ = param_previous_node.as_string();

    param_callback_handle_  = node_->add_on_set_parameters_callback(
        std::bind(&MERdrDataCubeMidW_NodeBaseTrigger::callback_parameters, this,
            std::placeholders::_1));

    set_subscriber(param_previous_node_);
}


void MERdrDataCubeMidW_NodeBaseTrigger::init_synchronizer()
{
    map_sync_[Synchronization_Index_List::SYNC_ID_TRIGGER_INIT] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgTriggerInitType>> (
            std::bind(&MERdrDataCubeMidW_NodeBaseTrigger::sync_callback_trigger_init, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_TRIGGER_CYCLIC] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgTriggerCyclicType>> (
            std::bind(&MERdrDataCubeMidW_NodeBaseTrigger::sync_callback_trigger_cyclic, this, std::placeholders::_1));
}


void MERdrDataCubeMidW_NodeBaseTrigger::set_subscriber(std::string trigger_node)
{
    sub_trigger_init_ =
        node_->create_subscription<msg_swc_common::msg::MsgTriggerInitType>(
            "topic_" + trigger_node + "_trigger_init", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBaseTrigger::callback_trigger_init,
                this, std::placeholders::_1)); 
    sub_trigger_cyclic_ =
        node_->create_subscription<msg_swc_common::msg::MsgTriggerCyclicType>(
            "topic_" + trigger_node + "_trigger_cyclic", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBaseTrigger::callback_trigger_cyclic,
                this, std::placeholders::_1)); 
}


rcl_interfaces::msg::SetParametersResult MERdrDataCubeMidW_NodeBaseTrigger::callback_parameters(
    const std::vector<rclcpp::Parameter>& parameters) 
{
    rcl_interfaces::msg::SetParametersResult result;
    result.successful = true;
    result.reason = "success";

    for (const auto& parameter : parameters) 
    {
       if (parameter.get_name() == "param_trigger_cyclic_immediate" &&
            parameter.get_type() == rclcpp::ParameterType::PARAMETER_BOOL) 
        {
            param_trigger_cyclic_immediate_ = parameter.as_bool();
            RCLCPP_INFO(node_->get_logger(),
                "Parameter 'param_trigger_cyclic_immediate' changed: %d",
                param_trigger_cyclic_immediate_);
        }
        else if (parameter.get_name() == "param_previous_node" &&
            parameter.get_type() == rclcpp::ParameterType::PARAMETER_STRING) 
        {
            param_previous_node_ = parameter.as_string();
            RCLCPP_INFO(node_->get_logger(),
                "Parameter 'param_previous_node' changed: %s",
                param_previous_node_.c_str());
        }
        else 
        {
            // result.successful = false;
            // result.reason = "Unable to set the parameter " + parameter.get_name();
        }

        if (result.successful && parameter.get_name() == "param_previous_node")
        {
            set_subscriber(parameter.get_name());
        }
    }
    return result;
} 


void MERdrDataCubeMidW_NodeBaseTrigger::callback_trigger_init(
    msg_swc_common::msg::MsgTriggerInitType::UniquePtr msg)
{
    if (0 == map_sync_.count(MERdrDataCubeMidW_NodeBaseTrigger::Synchronization_Index_List::SYNC_ID_TRIGGER_INIT))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgTriggerInitType>>(map_sync_.at(MERdrDataCubeMidW_NodeBaseTrigger::Synchronization_Index_List::SYNC_ID_TRIGGER_INIT));
    p->setMsg(std::move(msg));

    MERdrDataCubeMidW_NodeBase::check_and_process(MERdrDataCubeMidW_NodeBaseTrigger::Synchronization_Index_List::SYNC_ID_TRIGGER_INIT);
}

void MERdrDataCubeMidW_NodeBaseTrigger::callback_trigger_cyclic(
    msg_swc_common::msg::MsgTriggerCyclicType::UniquePtr msg)
{
    if (0 == map_sync_.count(MERdrDataCubeMidW_NodeBaseTrigger::Synchronization_Index_List::SYNC_ID_TRIGGER_CYCLIC))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgTriggerCyclicType>>(map_sync_.at(MERdrDataCubeMidW_NodeBaseTrigger::Synchronization_Index_List::SYNC_ID_TRIGGER_CYCLIC));
    p->setMsg(std::move(msg));

    MERdrDataCubeMidW_NodeBase::check_and_process(MERdrDataCubeMidW_NodeBaseTrigger::Synchronization_Index_List::SYNC_ID_TRIGGER_CYCLIC);
} 
void MERdrDataCubeMidW_NodeBaseTrigger::sync_callback_trigger_init(
    msg_swc_common::msg::MsgTriggerInitType::UniquePtr msg)
{
    if (m_pCoreEnv)
        m_pCoreEnv->Init();
    
    // Daisy chain -> Forward the trigger signal
    pub_trigger_init_->publish(std::move(msg));
}


void MERdrDataCubeMidW_NodeBaseTrigger::sync_callback_trigger_cyclic(
    msg_swc_common::msg::MsgTriggerCyclicType::UniquePtr msg)
{
//    bool trigger = false;
    rclcpp::Time time(msg->header.stamp);
    m_timestamp = time;
//
//    if (param_trigger_cyclic_immediate_)
//        trigger = true;
//
//    else if (msg->counter % param_trigger_cyclic_counter_ == 0)
//        trigger = true;
//
//    if (trigger) 
//    {
//        if (m_pCoreEnv)
//        {
//            m_pCoreEnv->Cyclic();
//            publish_data();
//        }
//    }

    if (m_pCoreEnv)
    {
        m_pCoreEnv->Cyclic();
        publish_data_with_parquet();
    }

    // Daisy chain -> Forward the trigger signal
    auto msg_trigger_out = std::make_unique<msg_swc_common::msg::MsgTriggerCyclicType>();
    msg_trigger_out->counter = msg->counter;
    msg_trigger_out->header.stamp = m_timestamp;
    pub_trigger_cyclic_->publish(std::move(msg_trigger_out));
    
    // Parquet input files
    if(parquet_handler_.enable_parquet_in())
        parquet_handler_.queue_parquet_in_.back()->parquet_export_trigger_cyclic(std::move(msg));
}


