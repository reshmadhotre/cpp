/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_NodeBase.cpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */

#include <ament_index_cpp/get_package_share_directory.hpp>
#include "MERdrDataCubeMidW_NodeBase.hpp"




MERdrDataCubeMidW_NodeBase::MERdrDataCubeMidW_NodeBase(std::shared_ptr<rclcpp::Node> node) : node_(node), parquet_handler_(node)
{
    RCLCPP_DEBUG(node_->get_logger(), "---------------------------------------"); 
    RCLCPP_DEBUG(node_->get_logger(), "Loading library...");

    if ((node_base_init = load_lib())) 
    {
        /* Library initialization  */
        RCLCPP_DEBUG(node_->get_logger(), "");
        RCLCPP_DEBUG(node_->get_logger(), "Initializing core...");
        m_pCoreEnv->Init();

        /* Version info */
        display_versions();

        /* Pub/Sub initialization  */
        RCLCPP_DEBUG(node_->get_logger(), "Initializing node base...");
        init_namespace();
        init_subscriber();
        init_publisher();

        /* Parameters initialization  */
        init_parameter();
        init_synchronizer();
        sync_setup_validation();
        // RCLCPP_INFO(node_->get_logger(), "Event (\"completetrigger_node\") from: %s", param_completetrigger_node_.c_str());
        // RCLCPP_INFO(node_->get_logger(), "Event (\"scanready_node\") from: %s", param_scanready_node_.c_str());
        // RCLCPP_INFO(node_->get_logger(), "Event (\"previous_node\") from: %s", param_previous_node_.c_str());
    }

    else 
    {
        RCLCPP_ERROR(node_->get_logger(), "Failed to load library %s", libName.c_str());
        RCLCPP_DEBUG(node_->get_logger(), "");
        RCLCPP_INFO(node_->get_logger(), "----< Shutting down >----");
        rclcpp::shutdown();
    }
}


MERdrDataCubeMidW_NodeBase::~MERdrDataCubeMidW_NodeBase()
{
    m_CoreLibrary.Unload();
    if (m_pCoreEnv)
    {
        delete m_pCoreEnv;
        m_pCoreEnv = nullptr;
    }
}

void MERdrDataCubeMidW_NodeBase::display_versions(void)
{
    VersionInfoType data = m_pCoreEnv->Get_VERSION_MERdrDataCubeMidW_GetVersionInfo();
    RCLCPP_INFO(node_->get_logger(), "Interface version: %d.%d.%d", data.If.Major, data.If.Minor, data.If.Patch);
    RCLCPP_INFO(node_->get_logger(), "Core version: %d.%d.%d", data.Sw.Major, data.Sw.Minor, data.Sw.Patch);
    RCLCPP_DEBUG(node_->get_logger(), "");
}


void MERdrDataCubeMidW_NodeBase::init_namespace(void)
{
    node_namespace_ = node_->get_namespace();
    if(node_namespace_.length() <= 1)
        node_namespace_ = "/map";
}


void MERdrDataCubeMidW_NodeBase::init_subscriber(void)
{
    sub_blkgroad_ =
        node_->create_subscription<msg_swc_common::msg::MsgBlkgroadType>(
            "topic_blkgroad", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_blkgroad,
                this, std::placeholders::_1)); 
    sub_completetrigger_ =
        node_->create_subscription<msg_swc_common::msg::MsgEventType>(
            "topic_completetrigger", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_completetrigger,
                this, std::placeholders::_1)); 
    sub_diagscan_ =
        node_->create_subscription<msg_swc_common::msg::MsgDiagscanType>(
            "topic_diagscan", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_diagscan,
                this, std::placeholders::_1)); 
    sub_radarcfg_ =
        node_->create_subscription<msg_swc_common::msg::MsgRadarcfgType>(
            "topic_radarcfg", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_radarcfg,
                this, std::placeholders::_1)); 
    sub_recordreplay_ =
        node_->create_subscription<msg_swc_common::msg::MsgRecordreplayType>(
            "topic_recordreplay", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_recordreplay,
                this, std::placeholders::_1)); 
    sub_scan_ =
        node_->create_subscription<msg_swc_common::msg::MsgScanType>(
            "topic_scan", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_scan,
                this, std::placeholders::_1)); 
    sub_scanpara_ =
        node_->create_subscription<msg_swc_common::msg::MsgScanparaType>(
            "topic_scanpara", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_scanpara,
                this, std::placeholders::_1)); 
    sub_scanready_ =
        node_->create_subscription<msg_swc_common::msg::MsgEventType>(
            "topic_scanready", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_scanready,
                this, std::placeholders::_1)); 
    sub_sensrmtn_ =
        node_->create_subscription<msg_swc_common::msg::MsgSensrmtnType>(
            "topic_sensrmtn", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_sensrmtn,
                this, std::placeholders::_1)); 
    sub_trigger_process_ =
        node_->create_subscription<msg_swc_common::msg::MsgEventType>(
            "topic_trigger_process", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_trigger_process,
                this, std::placeholders::_1)); 
}


void MERdrDataCubeMidW_NodeBase::init_publisher(void)
{
    pub_detn_getmidwdata_ =
        node_->create_publisher<msg_swc_common::msg::MsgDetnGetMidWDataType>(
            "topic_detn_getmidwdata", QUEUE_SIZE_PUBLISHER);
    pub_detn_getrdc2data_ =
        node_->create_publisher<msg_swc_common::msg::MsgDetnGetRdc2DataTypeArr>(
            "topic_detn_getrdc2data", QUEUE_SIZE_PUBLISHER);
    pub_rdcst_ =
        node_->create_publisher<msg_swc_common::msg::MsgRdcstType>(
            "topic_rdcst", QUEUE_SIZE_PUBLISHER);
    pub_scaninfo_ =
        node_->create_publisher<msg_swc_common::msg::MsgScaninfoType>(
            "topic_scaninfo", QUEUE_SIZE_PUBLISHER);
    pub_trigger_ =
        node_->create_publisher<msg_swc_common::msg::MsgEventType>(
            "topic_swc_merdrdatacubemidw_trigger", QUEUE_SIZE_PUBLISHER);
    pub_version_merdrdatacubemidw_getversioninfo_ =
        node_->create_publisher<msg_swc_common::msg::MsgVersionMeRdrDataCubeMidWGetVersionInfoType>(
            "topic_version_merdrdatacubemidw_getversioninfo", QUEUE_SIZE_PUBLISHER);
    fwd_completetrigger_ =
        node_->create_publisher<msg_swc_common::msg::MsgEventType>(
            "topic_swc_merdrdatacubemidw_completetrigger", QUEUE_SIZE_PUBLISHER);
    fwd_scanready_ =
        node_->create_publisher<msg_swc_common::msg::MsgEventType>(
            "topic_swc_merdrdatacubemidw_scanready", QUEUE_SIZE_PUBLISHER);
    fwd_trigger_process_ =
        node_->create_publisher<msg_swc_common::msg::MsgEventType>(
            "topic_swc_merdrdatacubemidw_trigger_process", QUEUE_SIZE_PUBLISHER);
}


void MERdrDataCubeMidW_NodeBase::init_parameter()
{
    node_->declare_parameter("param_previous_node", "swc_merdrdatacubemidw");
    param_previous_node_ = node_->get_parameter("param_previous_node").as_string();
    sub_completetrigger_ =
        node_->create_subscription<msg_swc_common::msg::MsgEventType>(
            "topic_" + param_previous_node_ + "_completetrigger", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_completetrigger,
                this, std::placeholders::_1)); 
    sub_scanready_ =
        node_->create_subscription<msg_swc_common::msg::MsgEventType>(
            "topic_" + param_previous_node_ + "_scanready", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_scanready,
                this, std::placeholders::_1)); 
    sub_trigger_process_ =
        node_->create_subscription<msg_swc_common::msg::MsgEventType>(
            "topic_" + param_previous_node_ + "_trigger_process", QUEUE_SIZE_SUBSCRIBER,
            std::bind(&MERdrDataCubeMidW_NodeBase::callback_trigger_process,
                this, std::placeholders::_1)); 

    node_->declare_parameter("param_sync_subscriber_list", param_sync_subscriber_list_);
    param_sync_subscriber_list_ = node_->get_parameter("param_sync_subscriber_list").as_string_array();
}


void MERdrDataCubeMidW_NodeBase::init_synchronizer()
{
    map_sync_[Synchronization_Index_List::SYNC_ID_BLKGROAD] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgBlkgroadType>> (
            std::bind(&MERdrDataCubeMidW_NodeBase::sync_callback_blkgroad, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_COMPLETETRIGGER] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgEventType>> (
            std::bind(&MERdrDataCubeMidW_NodeBase::sync_callback_completetrigger, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_DIAGSCAN] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgDiagscanType>> (
            std::bind(&MERdrDataCubeMidW_NodeBase::sync_callback_diagscan, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_RADARCFG] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgRadarcfgType>> (
            std::bind(&MERdrDataCubeMidW_NodeBase::sync_callback_radarcfg, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_RECORDREPLAY] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgRecordreplayType>> (
            std::bind(&MERdrDataCubeMidW_NodeBase::sync_callback_recordreplay, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_SCAN] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgScanType>> (
            std::bind(&MERdrDataCubeMidW_NodeBase::sync_callback_scan, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_SCANPARA] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgScanparaType>> (
            std::bind(&MERdrDataCubeMidW_NodeBase::sync_callback_scanpara, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_SCANREADY] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgEventType>> (
            std::bind(&MERdrDataCubeMidW_NodeBase::sync_callback_scanready, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_SENSRMTN] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgSensrmtnType>> (
            std::bind(&MERdrDataCubeMidW_NodeBase::sync_callback_sensrmtn, this, std::placeholders::_1));
    map_sync_[Synchronization_Index_List::SYNC_ID_TRIGGER_PROCESS] = 
        std::make_unique<Synchronizer<msg_swc_common::msg::MsgEventType>> (
            std::bind(&MERdrDataCubeMidW_NodeBase::sync_callback_trigger_process, this, std::placeholders::_1));
}


void MERdrDataCubeMidW_NodeBase::sync_setup_validation()
{
     // Be sure the map is valid
    if (map_sync_.empty())
    {
        RCLCPP_ERROR(node_->get_logger(), "Synchronization: \"map_sync_\" is empty");
    }

    // Be sure the parameters list is valid
    if (param_sync_subscriber_list_.empty())
    {
        RCLCPP_WARN(node_->get_logger(), "No Subscribers to Synchronize");
    }

    // Be sure the subscribers to sync are valid and initialize the variable map_sync_msg_controller_ 
    int16_t idx{0};
    RCLCPP_INFO(node_->get_logger(), "Subscribers to synchronize ->");
    for(const auto sync_sub : param_sync_subscriber_list_)
    {
        if(map_sync_subscriber_to_index_.find(sync_sub) == map_sync_subscriber_to_index_.end())
        {
            RCLCPP_WARN(node_->get_logger(), "Unable to find the sync topic %s provided in the \"param_sync_subscriber_list_\", \
                           this will be removed", sync_sub.c_str());
            param_sync_subscriber_list_.erase(param_sync_subscriber_list_.begin()+idx);
        }
        else
        {
           RCLCPP_INFO(node_->get_logger(), "%s", sync_sub.c_str());
           map_sync_msg_controller_[map_sync_subscriber_to_index_[sync_sub]] = 0;
        }
        idx++;   
    }
    // Reverse lookup to retrieve subscriber name from Index_List enum
    std::for_each(map_sync_subscriber_to_index_.begin(), map_sync_subscriber_to_index_.end(), 
                       [this](const auto& val){map_sync_index_to_subscriber_[val.second] = val.first;});
}


bool MERdrDataCubeMidW_NodeBase::load_lib(void)
{
    bool no_error = false;
    bool is_param_found = false;
    std::string fpath = "";
    std::string custom_lib_path = "";

    // Check if custom lib path is provided as ros param
    is_param_found = get_ros_param(libPathRosParamName, custom_lib_path);
    
    if(is_param_found && file_exists(custom_lib_path))
    {
        fpath = custom_lib_path;
    }
    else
    {
        // RCLCPP_DEBUG(node_->get_logger(), "Using default %s file.", libName.c_str());
        std::string path = ament_index_cpp::get_package_share_directory("swc_merdrdatacubemidw");
        //fpath = path + "/lib/" + libName;
        fpath = path + "/lib/";
    }

    RCLCPP_INFO(node_->get_logger(), "Library name: %s", libName.c_str());
    RCLCPP_INFO(node_->get_logger(), "Library path: %s", fpath.c_str());

    if (m_CoreLibrary.Load(fpath + libName, true) == 0)
    {
        m_pCoreEnv = new CoreEnv(m_CoreLibrary.GetFunctionPtr("CoreBase_Rte_MockUp_Init"));
        m_pCoreEnv->SetOtherPtr(m_CoreLibrary.GetFunctionPtr("Core_GetFuncList"));
        m_pCoreEnv->SetCyclicPtr(m_CoreLibrary.GetFunctionPtr("CoreBase_Cyclic"));
        m_pCoreEnv->SetInitPtr(m_CoreLibrary.GetFunctionPtr("CoreBase_Init"));
        m_pCoreEnv->SetOnAlgoProcessingCompletePtr(m_CoreLibrary.GetFunctionPtr("CoreBase_OnAlgoProcessingComplete"));
        m_pCoreEnv->SetProcessPtr(m_CoreLibrary.GetFunctionPtr("CoreBase_Process"));
        m_pCoreEnv->SetUhCyclicPtr(m_CoreLibrary.GetFunctionPtr("CoreBase_UhCyclic"));
        no_error = true;
    }
    else 
    {
        no_error = false;
    }

    return no_error;
}


void MERdrDataCubeMidW_NodeBase::callback_blkgroad(
    msg_swc_common::msg::MsgBlkgroadType::UniquePtr msg)
{
    if (0 == map_sync_.count(Synchronization_Index_List::SYNC_ID_BLKGROAD))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgBlkgroadType>>(map_sync_.at(MERdrDataCubeMidW_NodeBase::Synchronization_Index_List::SYNC_ID_BLKGROAD));
    p->setMsg(std::move(msg));

    check_and_process(Synchronization_Index_List::SYNC_ID_BLKGROAD);
}


void MERdrDataCubeMidW_NodeBase::callback_completetrigger(
    msg_swc_common::msg::MsgEventType::UniquePtr msg)
{
    if (0 == map_sync_.count(Synchronization_Index_List::SYNC_ID_COMPLETETRIGGER))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgEventType>>(map_sync_.at(MERdrDataCubeMidW_NodeBase::Synchronization_Index_List::SYNC_ID_COMPLETETRIGGER));
    p->setMsg(std::move(msg));

    check_and_process(Synchronization_Index_List::SYNC_ID_COMPLETETRIGGER);
}


void MERdrDataCubeMidW_NodeBase::callback_diagscan(
    msg_swc_common::msg::MsgDiagscanType::UniquePtr msg)
{
    if (0 == map_sync_.count(Synchronization_Index_List::SYNC_ID_DIAGSCAN))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgDiagscanType>>(map_sync_.at(MERdrDataCubeMidW_NodeBase::Synchronization_Index_List::SYNC_ID_DIAGSCAN));
    p->setMsg(std::move(msg));

    check_and_process(Synchronization_Index_List::SYNC_ID_DIAGSCAN);
}


void MERdrDataCubeMidW_NodeBase::callback_radarcfg(
    msg_swc_common::msg::MsgRadarcfgType::UniquePtr msg)
{
    if (0 == map_sync_.count(Synchronization_Index_List::SYNC_ID_RADARCFG))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgRadarcfgType>>(map_sync_.at(MERdrDataCubeMidW_NodeBase::Synchronization_Index_List::SYNC_ID_RADARCFG));
    p->setMsg(std::move(msg));

    check_and_process(Synchronization_Index_List::SYNC_ID_RADARCFG);
}


void MERdrDataCubeMidW_NodeBase::callback_recordreplay(
    msg_swc_common::msg::MsgRecordreplayType::UniquePtr msg)
{
    if (0 == map_sync_.count(Synchronization_Index_List::SYNC_ID_RECORDREPLAY))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgRecordreplayType>>(map_sync_.at(MERdrDataCubeMidW_NodeBase::Synchronization_Index_List::SYNC_ID_RECORDREPLAY));
    p->setMsg(std::move(msg));

    check_and_process(Synchronization_Index_List::SYNC_ID_RECORDREPLAY);
}


void MERdrDataCubeMidW_NodeBase::callback_scan(
    msg_swc_common::msg::MsgScanType::UniquePtr msg)
{
    if (0 == map_sync_.count(Synchronization_Index_List::SYNC_ID_SCAN))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgScanType>>(map_sync_.at(MERdrDataCubeMidW_NodeBase::Synchronization_Index_List::SYNC_ID_SCAN));
    p->setMsg(std::move(msg));

    check_and_process(Synchronization_Index_List::SYNC_ID_SCAN);
}


void MERdrDataCubeMidW_NodeBase::callback_scanpara(
    msg_swc_common::msg::MsgScanparaType::UniquePtr msg)
{
    if (0 == map_sync_.count(Synchronization_Index_List::SYNC_ID_SCANPARA))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgScanparaType>>(map_sync_.at(MERdrDataCubeMidW_NodeBase::Synchronization_Index_List::SYNC_ID_SCANPARA));
    p->setMsg(std::move(msg));

    check_and_process(Synchronization_Index_List::SYNC_ID_SCANPARA);
}


void MERdrDataCubeMidW_NodeBase::callback_scanready(
    msg_swc_common::msg::MsgEventType::UniquePtr msg)
{
    if (0 == map_sync_.count(Synchronization_Index_List::SYNC_ID_SCANREADY))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgEventType>>(map_sync_.at(MERdrDataCubeMidW_NodeBase::Synchronization_Index_List::SYNC_ID_SCANREADY));
    p->setMsg(std::move(msg));

    check_and_process(Synchronization_Index_List::SYNC_ID_SCANREADY);
}


void MERdrDataCubeMidW_NodeBase::callback_sensrmtn(
    msg_swc_common::msg::MsgSensrmtnType::UniquePtr msg)
{
    if (0 == map_sync_.count(Synchronization_Index_List::SYNC_ID_SENSRMTN))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgSensrmtnType>>(map_sync_.at(MERdrDataCubeMidW_NodeBase::Synchronization_Index_List::SYNC_ID_SENSRMTN));
    p->setMsg(std::move(msg));

    check_and_process(Synchronization_Index_List::SYNC_ID_SENSRMTN);
}


void MERdrDataCubeMidW_NodeBase::callback_trigger_process(
    msg_swc_common::msg::MsgEventType::UniquePtr msg)
{
    if (0 == map_sync_.count(Synchronization_Index_List::SYNC_ID_TRIGGER_PROCESS))
        return;

    auto p = std::dynamic_pointer_cast<Synchronizer<msg_swc_common::msg::MsgEventType>>(map_sync_.at(MERdrDataCubeMidW_NodeBase::Synchronization_Index_List::SYNC_ID_TRIGGER_PROCESS));
    p->setMsg(std::move(msg));

    check_and_process(Synchronization_Index_List::SYNC_ID_TRIGGER_PROCESS);
}


void MERdrDataCubeMidW_NodeBase::sync_callback_blkgroad(
    msg_swc_common::msg::MsgBlkgroadType::UniquePtr msg)
{
    // Create a variable in the same way as ADTF
    static Blkgroad_Type data;

    // Copy the content of the message into this variable
    data.RoadDetnEnblRq = msg->road_detn_enbl_rq;
    data.RoadDetnDist = msg->road_detn_dist;

    // Call the set function from the core
    if(m_pCoreEnv)
        m_pCoreEnv->Set_BLKGROAD(&data);
    
    // Parquet input data
    if(parquet_handler_.enable_parquet_in())
    {
        parquet_handler_.queue_parquet_in_.back()->parquet_export_blkgroad(std::move(msg));
    }
}


void MERdrDataCubeMidW_NodeBase::sync_callback_diagscan(
    msg_swc_common::msg::MsgDiagscanType::UniquePtr msg)
{
    // Create a variable in the same way as ADTF
    static Diagscan_Type data;

    // Copy the content of the message into this variable
    memcpy(&(data.DiagScanSet), &(msg->diag_scan_set), sizeof(ScanSetParameterType));
    data.DiagnosticScanRq = msg->diagnostic_scan_rq;

    // Call the set function from the core
    if(m_pCoreEnv)
        m_pCoreEnv->Set_DIAGSCAN(&data);
    
    // Parquet input data
    if(parquet_handler_.enable_parquet_in())
    {
        parquet_handler_.queue_parquet_in_.back()->parquet_export_diagscan(std::move(msg));
    }
}


void MERdrDataCubeMidW_NodeBase::sync_callback_radarcfg(
    msg_swc_common::msg::MsgRadarcfgType::UniquePtr msg)
{
    // Create a variable in the same way as ADTF
    static Radarcfg_Type data;

    // Copy the content of the message into this variable
    data.RadarRole = msg->radar_role;
    data.FuncArr = msg->func_arr;

    // Call the set function from the core
    if(m_pCoreEnv)
        m_pCoreEnv->Set_RADARCFG(&data);
    
    // Parquet input data
    if(parquet_handler_.enable_parquet_in())
    {
        parquet_handler_.queue_parquet_in_.back()->parquet_export_radarcfg(std::move(msg));
    }
}


void MERdrDataCubeMidW_NodeBase::sync_callback_recordreplay(
    msg_swc_common::msg::MsgRecordreplayType::UniquePtr msg)
{
    // Create a variable in the same way as ADTF
    static Recordreplay_Type data;

    // Copy the content of the message into this variable
    data.RecordReplaySt = msg->record_replay_st;

    // Call the set function from the core
    if(m_pCoreEnv)
        m_pCoreEnv->Set_RECORDREPLAY(&data);
    
    // Parquet input data
    if(parquet_handler_.enable_parquet_in())
    {
        parquet_handler_.queue_parquet_in_.back()->parquet_export_recordreplay(std::move(msg));
    }
}


void MERdrDataCubeMidW_NodeBase::sync_callback_scan(
    msg_swc_common::msg::MsgScanType::UniquePtr msg)
{
    // Create a variable in the same way as ADTF
    static Scan_Type data;

    // Copy the content of the message into this variable
    data.ScanCfg = msg->scan_cfg;

    // Call the set function from the core
    if(m_pCoreEnv)
        m_pCoreEnv->Set_SCAN(&data);
    
    // Parquet input data
    if(parquet_handler_.enable_parquet_in())
    {
        parquet_handler_.queue_parquet_in_.back()->parquet_export_scan(std::move(msg));
    }
}


void MERdrDataCubeMidW_NodeBase::sync_callback_scanpara(
    msg_swc_common::msg::MsgScanparaType::UniquePtr msg)
{
    // Create a variable in the same way as ADTF
    static Scanpara_Type data;

    // Copy the content of the message into this variable
    memcpy(&(data.ScanSets[0]), &(msg->scan_sets[0]), sizeof(ScanSetsType));

    // Call the set function from the core
    if(m_pCoreEnv)
        m_pCoreEnv->Set_SCANPARA(&data);
    
    // Parquet input data
    if(parquet_handler_.enable_parquet_in())
    {
        parquet_handler_.queue_parquet_in_.back()->parquet_export_scanpara(std::move(msg));
    }
}


void MERdrDataCubeMidW_NodeBase::sync_callback_sensrmtn(
    msg_swc_common::msg::MsgSensrmtnType::UniquePtr msg)
{
    // Create a variable in the same way as ADTF
    static Sensrmtn_Type data;

    // Copy the content of the message into this variable
    memcpy(&(data.SnsrMtnData), &(msg->snsr_mtn_data), sizeof(MtnDataType));

    // Call the set function from the core
    if(m_pCoreEnv)
        m_pCoreEnv->Set_SENSRMTN(&data);
    
    // Parquet input data
    if(parquet_handler_.enable_parquet_in())
    {
        parquet_handler_.queue_parquet_in_.back()->parquet_export_sensrmtn(std::move(msg));
    }
}


void MERdrDataCubeMidW_NodeBase::sync_callback_completetrigger(
    msg_swc_common::msg::MsgEventType::UniquePtr msg)
{
    m_pCoreEnv->OnAlgoProcessingComplete();
    fwd_cnt_completetrigger_++;
    
    // Parquet input data
    if(parquet_handler_.enable_parquet_in())
    {
        parquet_handler_.queue_parquet_in_.back()->parquet_export_completetrigger(std::move(msg));
    }
}


void MERdrDataCubeMidW_NodeBase::sync_callback_scanready(
    msg_swc_common::msg::MsgEventType::UniquePtr msg)
{
    m_pCoreEnv->UhCyclic();
    fwd_cnt_scanready_++;
    
    // Parquet input data
    if(parquet_handler_.enable_parquet_in())
    {
        parquet_handler_.queue_parquet_in_.back()->parquet_export_scanready(std::move(msg));
    }
}


void MERdrDataCubeMidW_NodeBase::sync_callback_trigger_process(
    msg_swc_common::msg::MsgEventType::UniquePtr msg)
{
    m_pCoreEnv->Process();
    fwd_cnt_trigger_process_++;
    
    // Parquet input data
    if(parquet_handler_.enable_parquet_in())
    {
        parquet_handler_.queue_parquet_in_.back()->parquet_export_trigger_process(std::move(msg));
    }
}


void MERdrDataCubeMidW_NodeBase::publish_data_with_parquet(void)
{
    if(parquet_handler_.file_changed() && parquet_handler_.enable_parquet_out())
    {
        parquet_handler_.WriteParquetFile();
    }
    publish_data();
}


void MERdrDataCubeMidW_NodeBase::publish_data(void)
{
    publish_detn_getmidwdata();
    publish_detn_getrdc2data();
    publish_rdcst();
    publish_scaninfo();
    publish_trigger();
    publish_version_merdrdatacubemidw_getversioninfo();
    forward_completetrigger();
    forward_scanready();
    forward_trigger_process();
}


void MERdrDataCubeMidW_NodeBase::publish_detn_getmidwdata(void)
{
    // Message to publish
    auto msg = std::make_unique<msg_swc_common::msg::MsgDetnGetMidWDataType>();
    // Data to send
    Rdc_MidWData1D2DType data = m_pCoreEnv->Get_DETN_GetMidWData();

    // Set the header
    msg->header.frame_id = node_namespace_;
    msg->header.stamp = m_timestamp;

    // Copy the content from the core to the message
    memcpy(&(msg->one_d_ptr), data.OneDPtr, sizeof(Rdc_MidWDataType));
    memcpy(&(msg->two_d_ptr), data.TwoDPtr, sizeof(Rdc_MidWDataType));

    // parquet check
    if(parquet_handler_.enable_parquet_out())
    {
        parquet_handler_.queue_parquet_out_.back()->parquet_export_detn_getmidwdata(msg.get());
    }

    // Publish the message
    pub_detn_getmidwdata_->publish(std::move(msg));
}


void MERdrDataCubeMidW_NodeBase::publish_detn_getrdc2data(void)
{
    // Message to publish
    auto msg = std::make_unique<msg_swc_common::msg::MsgDetnGetRdc2DataTypeArr>();
    // Data to send
    RDC2DataPtrType data = m_pCoreEnv->Get_DETN_GetRDC2Data();

    // Set the header
    msg->header.frame_id = node_namespace_;
    msg->header.stamp = m_timestamp;

    // Copy the content from the core to the message
    if(data)
    {
        for(uint16_t idx = 0; idx < MIDW_ADPR_NUM_SCAN_SETS; idx++)
        {
            memcpy(&(msg->msg_detn_get_rdc2_data_type.at(idx).rdc2_matrix_ptr), data[idx].RDC2MatrixPtr, sizeof(RDC2ArrDataType));
            msg->msg_detn_get_rdc2_data_type.at(idx).num_rd = data[idx].NumRD;
            msg->msg_detn_get_rdc2_data_type.at(idx).rdc2_status = data[idx].RDC2Status;
        }
    }

    // parquet check
    if(parquet_handler_.enable_parquet_out())
    {
        parquet_handler_.queue_parquet_out_.back()->parquet_export_detn_getrdc2data(msg.get());
    }

    // Publish the message
    pub_detn_getrdc2data_->publish(std::move(msg));
}


void MERdrDataCubeMidW_NodeBase::publish_rdcst(void)
{
    // Message to publish
    auto msg = std::make_unique<msg_swc_common::msg::MsgRdcstType>();
    // Data to send
    Rdcst_Type data = m_pCoreEnv->Get_RDCST();

    // Set the header
    msg->header.frame_id = node_namespace_;
    msg->header.stamp = m_timestamp;

    // Copy the content from the core to the message
    msg->rdc_st = data.RDCSt;

    // parquet check
    if(parquet_handler_.enable_parquet_out())
    {
        parquet_handler_.queue_parquet_out_.back()->parquet_export_rdcst(msg.get());
    }

    // Publish the message
    pub_rdcst_->publish(std::move(msg));
}


void MERdrDataCubeMidW_NodeBase::publish_scaninfo(void)
{
    // Message to publish
    auto msg = std::make_unique<msg_swc_common::msg::MsgScaninfoType>();
    // Data to send
    Scaninfo_Type data = m_pCoreEnv->Get_SCANINFO();

    // Set the header
    msg->header.frame_id = node_namespace_;
    msg->header.stamp = m_timestamp;

    // Copy the content from the core to the message
    msg->processing_prio = data.ProcessingPrio;
    memcpy(&(msg->scan_info), &(data.ScanInfo), sizeof(Rdc_ScanInfoType));

    // parquet check
    if(parquet_handler_.enable_parquet_out())
    {
        parquet_handler_.queue_parquet_out_.back()->parquet_export_scaninfo(msg.get());
    }

    // Publish the message
    pub_scaninfo_->publish(std::move(msg));
}


void MERdrDataCubeMidW_NodeBase::publish_trigger(void)
{
    // Message to publish
    auto msg = std::make_unique<msg_swc_common::msg::MsgEventType>();
    msg->header.stamp = m_timestamp;
    msg->event = (m_pCoreEnv->GetDataSetBasePtr()->TriggerActivateAlgoProcessingCnt == 0);
    
    pub_trigger_->publish(std::move(msg));  
    if(m_pCoreEnv->GetDataSetBasePtr()->TriggerActivateAlgoProcessingCnt > 0)
    {
        m_pCoreEnv->GetDataSetBasePtr()->TriggerActivateAlgoProcessingCnt--;
    }
}


void MERdrDataCubeMidW_NodeBase::publish_version_merdrdatacubemidw_getversioninfo(void)
{
    // Message to publish
    auto msg = std::make_unique<msg_swc_common::msg::MsgVersionMeRdrDataCubeMidWGetVersionInfoType>();
    // Data to send
    VersionInfoType data = m_pCoreEnv->Get_VERSION_MERdrDataCubeMidW_GetVersionInfo();

    // Set the header
    msg->header.frame_id = node_namespace_;
    msg->header.stamp = m_timestamp;

    // Copy the content from the core to the message
    memcpy(&(msg->sw), &(data.Sw), sizeof(BaseVersionInfoType));
    memcpy(&(msg->r_if), &(data.If), sizeof(BaseVersionInfoType));
    memcpy(&(msg->cmp), &(data.Cmp), sizeof(VersionInfoCmpType));

    // parquet check
    if(parquet_handler_.enable_parquet_out())
    {
        parquet_handler_.queue_parquet_out_.back()->parquet_export_version_merdrdatacubemidw_getversioninfo(msg.get());
    }

    // Publish the message
    pub_version_merdrdatacubemidw_getversioninfo_->publish(std::move(msg));
}


void MERdrDataCubeMidW_NodeBase::forward_completetrigger(void)
{
    auto msg = std::make_unique<msg_swc_common::msg::MsgEventType>();
    msg->header.stamp = m_timestamp;
    msg->event = (fwd_cnt_completetrigger_ >= 1);
    fwd_completetrigger_->publish(std::move(msg));

    if (fwd_cnt_completetrigger_ >= 1)
    {
        fwd_cnt_completetrigger_--;
    }
}


void MERdrDataCubeMidW_NodeBase::forward_scanready(void)
{
    auto msg = std::make_unique<msg_swc_common::msg::MsgEventType>();
    msg->header.stamp = m_timestamp;
    msg->event = (fwd_cnt_scanready_ >= 1);
    fwd_scanready_->publish(std::move(msg));

    if (fwd_cnt_scanready_ >= 1)
    {
        fwd_cnt_scanready_--;
    }
}


void MERdrDataCubeMidW_NodeBase::forward_trigger_process(void)
{
    auto msg = std::make_unique<msg_swc_common::msg::MsgEventType>();
    msg->header.stamp = m_timestamp;
    msg->event = (fwd_cnt_trigger_process_ >= 1);
    fwd_trigger_process_->publish(std::move(msg));

    if (fwd_cnt_trigger_process_ >= 1)
    {
        fwd_cnt_trigger_process_--;
    }
}


bool MERdrDataCubeMidW_NodeBase::is_part_of_sync_subscriber(enum Synchronization_Index_List index)
{
    bool status = false;
    if(map_sync_index_to_subscriber_.find(index) != map_sync_index_to_subscriber_.end())
    {
        auto pos = std::find(param_sync_subscriber_list_.begin(), param_sync_subscriber_list_.end(), map_sync_index_to_subscriber_[index]);
        if(pos != param_sync_subscriber_list_.end())
            status = true;
    }

    return status;
}


void MERdrDataCubeMidW_NodeBase::check_and_process(enum Synchronization_Index_List index)
{
    // Be sure the index is valid
    if (map_sync_.find(index) == map_sync_.end())
    {
        RCLCPP_ERROR(node_->get_logger(), "Synchronization: index %d not in \"map_sync_\"", index);
    }

    // All errors covered, here we go
    else 
    {
        if(is_part_of_sync_subscriber(index))
        {
            map_sync_msg_controller_.at(index)++;
        }
        else
        {
            map_sync_.at(static_cast<enum Synchronization_Index_List>(index))->cb();   
        }
        
        bool sub_sync_status{false};
        if(!map_sync_msg_controller_.empty())
        {
            sub_sync_status = std::all_of(map_sync_msg_controller_.begin(), map_sync_msg_controller_.end(), 
                                        [](const auto &val){return val.second > 0;});
        }
        
        if(sub_sync_status)
        {
            for (const auto &subscriber :  param_sync_subscriber_list_)
            {
                auto idx = map_sync_subscriber_to_index_[subscriber];
                map_sync_.at(idx)->cb();
                map_sync_msg_controller_[idx]--;
            }
        }
    }
}


bool MERdrDataCubeMidW_NodeBase::get_ros_param(const std::string& param_name, std::string& param_value)
{
    std::string param_name_abs;

    bool param_found = node_->get_parameter(param_name, param_name_abs);

    if (param_found)
    {
        RCLCPP_DEBUG(node_->get_logger(), "Setting %s : %s", param_name_abs.c_str(), param_value.c_str());
        param_value = param_name_abs;
    }
    else
    {
        RCLCPP_WARN(node_->get_logger(), "Could not retrieve %s param", param_name.c_str());
    }

    return param_found;
}


bool MERdrDataCubeMidW_NodeBase::file_exists(const std::string& file_path)
{
    struct stat buffer;
    return (stat (file_path.c_str(), &buffer)==0);
}



