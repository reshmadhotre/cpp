/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_Parquet_In.hpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */
 
#ifndef MERDRDATACUBEMIDW_PARQUET_IN_HPP_
#define MERDRDATACUBEMIDW_PARQUET_IN_HPP_


#include "ParquetLib.hpp"
#include "MERdrDataCubeMidW_Parquet.hpp"

#include "msg_replay_radar/msg/msg_midw_int_all_data_type.hpp"
#include "msg_swc_common/msg/msg_blkgroad_type.hpp"
#include "msg_swc_common/msg/msg_event_type.hpp"
#include "msg_swc_common/msg/msg_diagscan_type.hpp"
#include "msg_swc_common/msg/msg_radarcfg_type.hpp"
#include "msg_swc_common/msg/msg_recordreplay_type.hpp"
#include "msg_swc_common/msg/msg_scan_type.hpp"
#include "msg_swc_common/msg/msg_scanpara_type.hpp"
#include "msg_swc_common/msg/msg_event_type.hpp"
#include "msg_swc_common/msg/msg_sensrmtn_type.hpp"
#include "msg_swc_common/msg/msg_trigger_cyclic_type.hpp"


using namespace parquet_lib;


class MERdrDataCubeMidW_Parquet_In : public MERdrDataCubeMidW_Parquet
{
public:
	explicit MERdrDataCubeMidW_Parquet_In();
	virtual ~MERdrDataCubeMidW_Parquet_In();

    virtual void init_parquet_headers();

    virtual void parquet_init_midw_all_int_data(void);
    virtual void parquet_init_blkgroad(void);
    virtual void parquet_init_completetrigger(void);
    virtual void parquet_init_diagscan(void);
    virtual void parquet_init_radarcfg(void);
    virtual void parquet_init_recordreplay(void);
    virtual void parquet_init_scan(void);
    virtual void parquet_init_scanpara(void);
    virtual void parquet_init_scanready(void);
    virtual void parquet_init_sensrmtn(void);
    virtual void parquet_init_trigger_process(void);
    virtual void parquet_init_trigger_cyclic(void);
    

    virtual void parquet_export_midw_all_int_data(msg_replay_radar::msg::MsgMidwIntAllDataType::UniquePtr msg);
    virtual void parquet_export_blkgroad(msg_swc_common::msg::MsgBlkgroadType::UniquePtr msg);
    virtual void parquet_export_completetrigger(msg_swc_common::msg::MsgEventType::UniquePtr msg);
    virtual void parquet_export_diagscan(msg_swc_common::msg::MsgDiagscanType::UniquePtr msg);
    virtual void parquet_export_radarcfg(msg_swc_common::msg::MsgRadarcfgType::UniquePtr msg);
    virtual void parquet_export_recordreplay(msg_swc_common::msg::MsgRecordreplayType::UniquePtr msg);
    virtual void parquet_export_scan(msg_swc_common::msg::MsgScanType::UniquePtr msg);
    virtual void parquet_export_scanpara(msg_swc_common::msg::MsgScanparaType::UniquePtr msg);
    virtual void parquet_export_scanready(msg_swc_common::msg::MsgEventType::UniquePtr msg);
    virtual void parquet_export_sensrmtn(msg_swc_common::msg::MsgSensrmtnType::UniquePtr msg);
    virtual void parquet_export_trigger_process(msg_swc_common::msg::MsgEventType::UniquePtr msg);
    virtual void parquet_export_trigger_cyclic(msg_swc_common::msg::MsgTriggerCyclicType::UniquePtr msg);

};	// MERdrDataCubeMidW_Parquet_In


#endif // MERDRDATACUBEMIDW_PARQUET_IN_HPP_
