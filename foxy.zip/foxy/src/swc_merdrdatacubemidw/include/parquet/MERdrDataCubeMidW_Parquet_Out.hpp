/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_Parquet_Out.hpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */
 
#ifndef MERDRDATACUBEMIDW_PARQUET_OUT_HPP_
#define MERDRDATACUBEMIDW_PARQUET_OUT_HPP_


#include "ParquetLib.hpp"
#include "MERdrDataCubeMidW_Parquet.hpp"

#include "msg_swc_common/msg/msg_detn_get_mid_w_data_type.hpp"
#include "msg_swc_common/msg/msg_detn_get_rdc2_data_type_arr.hpp"
#include "msg_swc_common/msg/msg_rdcst_type.hpp"
#include "msg_swc_common/msg/msg_scaninfo_type.hpp"
#include "msg_swc_common/msg/msg_version_me_rdr_data_cube_mid_w_get_version_info_type.hpp"
#include "msg_swc_common/msg/msg_node_feedback_type.hpp"


using namespace parquet_lib;


class MERdrDataCubeMidW_Parquet_Out : public MERdrDataCubeMidW_Parquet
{
public:
	explicit MERdrDataCubeMidW_Parquet_Out();
	virtual ~MERdrDataCubeMidW_Parquet_Out();

    virtual void init_parquet_headers();

    virtual void parquet_init_detn_getmidwdata(void);
    virtual void parquet_init_detn_getrdc2data(void);
    virtual void parquet_init_rdcst(void);
    virtual void parquet_init_scaninfo(void);
    virtual void parquet_init_version_merdrdatacubemidw_getversioninfo(void);

    virtual void parquet_export_detn_getmidwdata(msg_swc_common::msg::MsgDetnGetMidWDataType *msg);
    virtual void parquet_export_detn_getrdc2data(msg_swc_common::msg::MsgDetnGetRdc2DataTypeArr *msg);
    virtual void parquet_export_rdcst(msg_swc_common::msg::MsgRdcstType *msg);
    virtual void parquet_export_scaninfo(msg_swc_common::msg::MsgScaninfoType *msg);
    virtual void parquet_export_version_merdrdatacubemidw_getversioninfo(msg_swc_common::msg::MsgVersionMeRdrDataCubeMidWGetVersionInfoType *msg);

};	// MERdrDataCubeMidW_Parquet_Out


#endif // MERDRDATACUBEMIDW_PARQUET_OUT_HPP_
