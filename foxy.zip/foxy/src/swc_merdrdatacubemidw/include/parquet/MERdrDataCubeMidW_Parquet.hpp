/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_Parquet.hpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */
 
#ifndef MERDRDATACUBEMIDW_PARQUET_HPP_
#define MERDRDATACUBEMIDW_PARQUET_HPP_


#include "ParquetLib.hpp"


using namespace parquet_lib;


class MERdrDataCubeMidW_Parquet : public ParquetWriter
{
public:
	explicit MERdrDataCubeMidW_Parquet();
	virtual ~MERdrDataCubeMidW_Parquet();

    void set_filename_in(const std::string filename);
    void set_filename_out(const std::string filename);
    const std::string get_file_suffix() const;
    const std::string get_filename() const;      
    bool is_parquet_file_written();
    void set_parquet_file_completion_flag(const bool status);
    void write_parquet_file();
    void write_parquet();

private:
    std::string filename_prefix_{"MIDW"}; //component name
    std::string parquet_extn_{".parquet"};
    std::string parquet_file_name_{""};
    bool parquet_file_completion_flag_{false};

};	// MERdrDataCubeMidW_Parquet


#endif // MERDRDATACUBEMIDW_PARQUET_HPP_
