/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_NodeBaseTrigger.hpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */
 
#ifndef MERDRDATACUBEMIDW_NODEBASETRIGGER_HPP_
#define MERDRDATACUBEMIDW_NODEBASETRIGGER_HPP_



#include "MERdrDataCubeMidW_NodeBase.hpp"
#include "msg_swc_common/msg/msg_trigger_init_type.hpp"
#include "msg_swc_common/msg/msg_trigger_cyclic_type.hpp"


class MERdrDataCubeMidW_NodeBaseTrigger : public MERdrDataCubeMidW_NodeBase
{
public:
	// Constructors
    explicit MERdrDataCubeMidW_NodeBaseTrigger(std::shared_ptr<rclcpp::Node> node);
    virtual ~MERdrDataCubeMidW_NodeBaseTrigger();    


private:
	// Node pointer
	std::shared_ptr<rclcpp::Node> node_;

	// Input
    rclcpp::Subscription<msg_swc_common::msg::MsgTriggerInitType>::SharedPtr sub_trigger_init_;
    rclcpp::Subscription<msg_swc_common::msg::MsgTriggerCyclicType>::SharedPtr sub_trigger_cyclic_;
    void callback_trigger_init(msg_swc_common::msg::MsgTriggerInitType::UniquePtr msg);
    void callback_trigger_cyclic(msg_swc_common::msg::MsgTriggerCyclicType::UniquePtr msg);
    void sync_callback_trigger_init(msg_swc_common::msg::MsgTriggerInitType::UniquePtr msg);
    void sync_callback_trigger_cyclic(msg_swc_common::msg::MsgTriggerCyclicType::UniquePtr msg);
	
	// Output
    rclcpp::Publisher<msg_swc_common::msg::MsgTriggerInitType>::SharedPtr pub_trigger_init_;
    rclcpp::Publisher<msg_swc_common::msg::MsgTriggerCyclicType>::SharedPtr pub_trigger_cyclic_;
    void publish_trigger_init(void);
    void publish_trigger_cyclic(void);

    // Functions
    void init_subscriber(void);
    void init_publisher(void);
    void init_parameter(void);
    void init_synchronizer(void);
    void set_subscriber(std::string trigger_node);

	// Parameters
    bool param_trigger_cyclic_immediate_;
    std::string param_previous_node_;
    rcl_interfaces::msg::SetParametersResult
        callback_parameters(const std::vector<rclcpp::Parameter>& parameters);
    rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr
        param_callback_handle_;


};	// class MERdrDataCubeMidW_NodeBaseTrigger

#endif // MERDRDATACUBEMIDW_NODEBASETRIGGER_HPP_
