/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_NodeBase.hpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */
 
#ifndef MERDRDATACUBEMIDW_NODEBASE_HPP_
#define MERDRDATACUBEMIDW_NODEBASE_HPP_


#include "MERdrDataCubeMidW_CoreEnv.hpp"
#include "MERdrDataCubeMidW_Types.h"
#include "MERdrDataCubeMidW_NodeBaseParquet.hpp"

#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <cmath>
#include <sys/stat.h>

#include "MERdrDataCubeMidW_Visibility.hpp"
#include "rclcpp/rclcpp.hpp"
#include "CLibLoader.h"
#include "Synchronizer.hpp"

#include "msg_swc_common/msg/msg_blkgroad_type.hpp"
#include "msg_swc_common/msg/msg_event_type.hpp"
#include "msg_swc_common/msg/msg_event_type.hpp"
#include "msg_swc_common/msg/msg_diagscan_type.hpp"
#include "msg_swc_common/msg/msg_radarcfg_type.hpp"
#include "msg_swc_common/msg/msg_recordreplay_type.hpp"
#include "msg_swc_common/msg/msg_scan_type.hpp"
#include "msg_swc_common/msg/msg_scanpara_type.hpp"
#include "msg_swc_common/msg/msg_event_type.hpp"
#include "msg_swc_common/msg/msg_event_type.hpp"
#include "msg_swc_common/msg/msg_sensrmtn_type.hpp"
#include "msg_swc_common/msg/msg_detn_get_mid_w_data_type.hpp"
#include "msg_swc_common/msg/msg_detn_get_rdc2_data_type_arr.hpp"
#include "msg_swc_common/msg/msg_rdcst_type.hpp"
#include "msg_swc_common/msg/msg_scaninfo_type.hpp"
#include "msg_swc_common/msg/msg_event_type.hpp"
#include "msg_swc_common/msg/msg_version_me_rdr_data_cube_mid_w_get_version_info_type.hpp"



const constexpr int QUEUE_SIZE_SUBSCRIBER = 100;
const constexpr int QUEUE_SIZE_PUBLISHER = 100;


class MERdrDataCubeMidW_NodeBase
{

public:
    explicit MERdrDataCubeMidW_NodeBase(std::shared_ptr<rclcpp::Node> node);
    virtual ~MERdrDataCubeMidW_NodeBase();
    MERdrDataCubeMidW_NodeBase(const MERdrDataCubeMidW_NodeBase &other) = delete;
    MERdrDataCubeMidW_NodeBase & operator=(const MERdrDataCubeMidW_NodeBase &other) = delete;
    
    virtual void publish_data_with_parquet(void);
    virtual void publish_data(void);
    MERdrDataCubeMidW_NodeBaseParquet parquet_handler_;


protected:
    void display_versions(void);
    void init_namespace(void);
    void init_subscriber(void);
    void init_publisher(void);
    void init_parameter(void);
    bool node_base_init = false;

    // Synchronization
    enum  Synchronization_Index_List {
        SYNC_ID_BLKGROAD,
        SYNC_ID_COMPLETETRIGGER,
        SYNC_ID_DIAGSCAN,
        SYNC_ID_RADARCFG,
        SYNC_ID_RECORDREPLAY,
        SYNC_ID_SCAN,
        SYNC_ID_SCANPARA,
        SYNC_ID_SCANREADY,
        SYNC_ID_SENSRMTN,
        SYNC_ID_TRIGGER_PROCESS,
        SYNC_ID_TRIGGER_INIT,
        SYNC_ID_TRIGGER_CYCLIC,
        SYNC_ID_NODE_FEEDBACK,
        SYNC_ID_RADAR_DATA_UHDP,
        SYNC_ID_END
    };
    
    void init_synchronizer(void);
    void check_and_process(enum Synchronization_Index_List id);
    std::map<enum Synchronization_Index_List, std::shared_ptr<SynchronizerBase>> map_sync_;

    // Callbacks
    void callback_blkgroad(msg_swc_common::msg::MsgBlkgroadType::UniquePtr msg);
    void callback_completetrigger(msg_swc_common::msg::MsgEventType::UniquePtr msg);
    void callback_diagscan(msg_swc_common::msg::MsgDiagscanType::UniquePtr msg);
    void callback_radarcfg(msg_swc_common::msg::MsgRadarcfgType::UniquePtr msg);
    void callback_recordreplay(msg_swc_common::msg::MsgRecordreplayType::UniquePtr msg);
    void callback_scan(msg_swc_common::msg::MsgScanType::UniquePtr msg);
    void callback_scanpara(msg_swc_common::msg::MsgScanparaType::UniquePtr msg);
    void callback_scanready(msg_swc_common::msg::MsgEventType::UniquePtr msg);
    void callback_sensrmtn(msg_swc_common::msg::MsgSensrmtnType::UniquePtr msg);
    void callback_trigger_process(msg_swc_common::msg::MsgEventType::UniquePtr msg);
    
    // Core
    bool load_lib(void);
    CoreEnv *m_pCoreEnv;
    CLibLoader m_CoreLibrary;
#if defined(ME_PLATFORM_WIN)
    std::string libName = "MERdrDataCubeMidW_Algo.dll";
#else
    std::string libName = "MERdrDataCubeMidW_Algo.so";
#endif
    std::string libPathRosParamName = "merdrdatacubemidw_lib_path";
    rclcpp::Time m_timestamp;


private:
    // Node namespace
    std::string node_namespace_;

    // Node pointer
    std::shared_ptr<rclcpp::Node> node_;
    bool get_ros_param(const std::string& param_name, std::string& param_value);
    bool file_exists(const std::string& file_path);


    // Input
    rclcpp::Subscription<msg_swc_common::msg::MsgBlkgroadType>::SharedPtr sub_blkgroad_;
    rclcpp::Subscription<msg_swc_common::msg::MsgEventType>::SharedPtr sub_completetrigger_;
    rclcpp::Subscription<msg_swc_common::msg::MsgDiagscanType>::SharedPtr sub_diagscan_;
    rclcpp::Subscription<msg_swc_common::msg::MsgRadarcfgType>::SharedPtr sub_radarcfg_;
    rclcpp::Subscription<msg_swc_common::msg::MsgRecordreplayType>::SharedPtr sub_recordreplay_;
    rclcpp::Subscription<msg_swc_common::msg::MsgScanType>::SharedPtr sub_scan_;
    rclcpp::Subscription<msg_swc_common::msg::MsgScanparaType>::SharedPtr sub_scanpara_;
    rclcpp::Subscription<msg_swc_common::msg::MsgEventType>::SharedPtr sub_scanready_;
    rclcpp::Subscription<msg_swc_common::msg::MsgSensrmtnType>::SharedPtr sub_sensrmtn_;
    rclcpp::Subscription<msg_swc_common::msg::MsgEventType>::SharedPtr sub_trigger_process_;

    void sync_callback_blkgroad(msg_swc_common::msg::MsgBlkgroadType::UniquePtr msg);
    void sync_callback_completetrigger(msg_swc_common::msg::MsgEventType::UniquePtr msg);
    void sync_callback_diagscan(msg_swc_common::msg::MsgDiagscanType::UniquePtr msg);
    void sync_callback_radarcfg(msg_swc_common::msg::MsgRadarcfgType::UniquePtr msg);
    void sync_callback_recordreplay(msg_swc_common::msg::MsgRecordreplayType::UniquePtr msg);
    void sync_callback_scan(msg_swc_common::msg::MsgScanType::UniquePtr msg);
    void sync_callback_scanpara(msg_swc_common::msg::MsgScanparaType::UniquePtr msg);
    void sync_callback_scanready(msg_swc_common::msg::MsgEventType::UniquePtr msg);
    void sync_callback_sensrmtn(msg_swc_common::msg::MsgSensrmtnType::UniquePtr msg);
    void sync_callback_trigger_process(msg_swc_common::msg::MsgEventType::UniquePtr msg);


    // Output
    rclcpp::Publisher<msg_swc_common::msg::MsgDetnGetMidWDataType>::SharedPtr pub_detn_getmidwdata_;
    rclcpp::Publisher<msg_swc_common::msg::MsgDetnGetRdc2DataTypeArr>::SharedPtr pub_detn_getrdc2data_;
    rclcpp::Publisher<msg_swc_common::msg::MsgRdcstType>::SharedPtr pub_rdcst_;
    rclcpp::Publisher<msg_swc_common::msg::MsgScaninfoType>::SharedPtr pub_scaninfo_;
    rclcpp::Publisher<msg_swc_common::msg::MsgEventType>::SharedPtr pub_trigger_;
    rclcpp::Publisher<msg_swc_common::msg::MsgVersionMeRdrDataCubeMidWGetVersionInfoType>::SharedPtr pub_version_merdrdatacubemidw_getversioninfo_;

    void publish_detn_getmidwdata(void);
    void publish_detn_getrdc2data(void);
    void publish_rdcst(void);
    void publish_scaninfo(void);
    void publish_trigger(void);
    void publish_version_merdrdatacubemidw_getversioninfo(void);


    // Forward
    rclcpp::Publisher<msg_swc_common::msg::MsgEventType>::SharedPtr fwd_completetrigger_;
    rclcpp::Publisher<msg_swc_common::msg::MsgEventType>::SharedPtr fwd_scanready_;
    rclcpp::Publisher<msg_swc_common::msg::MsgEventType>::SharedPtr fwd_trigger_process_;

    void forward_completetrigger(void);
    void forward_scanready(void);
    void forward_trigger_process(void);

    // Synchronization settings
    std::map<std::string, Synchronization_Index_List> map_sync_subscriber_to_index_ 
    {
        {"sub_blkgroad_", Synchronization_Index_List::SYNC_ID_BLKGROAD},
        {"sub_completetrigger_", Synchronization_Index_List::SYNC_ID_COMPLETETRIGGER},
        {"sub_diagscan_", Synchronization_Index_List::SYNC_ID_DIAGSCAN},
        {"sub_radarcfg_", Synchronization_Index_List::SYNC_ID_RADARCFG},
        {"sub_recordreplay_", Synchronization_Index_List::SYNC_ID_RECORDREPLAY},
        {"sub_scan_", Synchronization_Index_List::SYNC_ID_SCAN},
        {"sub_scanpara_", Synchronization_Index_List::SYNC_ID_SCANPARA},
        {"sub_scanready_", Synchronization_Index_List::SYNC_ID_SCANREADY},
        {"sub_sensrmtn_", Synchronization_Index_List::SYNC_ID_SENSRMTN},
        {"sub_trigger_process_", Synchronization_Index_List::SYNC_ID_TRIGGER_PROCESS},
        {"sub_trigger_init_", Synchronization_Index_List::SYNC_ID_TRIGGER_INIT},
        {"sub_trigger_cyclic_", Synchronization_Index_List::SYNC_ID_TRIGGER_CYCLIC},
        {"sub_node_feedback_", Synchronization_Index_List::SYNC_ID_NODE_FEEDBACK},
        {"sub_midw_int_all_data_", Synchronization_Index_List::SYNC_ID_RADAR_DATA_UHDP}
    };
    std::map<Synchronization_Index_List, std::string> map_sync_index_to_subscriber_;
    std::map<Synchronization_Index_List, int> map_sync_msg_controller_{};

    // Synchronization parameters
    std::vector<std::string>param_sync_subscriber_list_{};
    void sync_setup_validation(void);
    bool is_part_of_sync_subscriber(enum Synchronization_Index_List index);

    // Parameters
    std::string param_previous_node_ = "";

    // Counter(s) for port forwarding
    uint8 fwd_cnt_completetrigger_{0};
    uint8 fwd_cnt_scanready_{0};
    uint8 fwd_cnt_trigger_process_{0};

};	// class MERdrDataCubeMidW_NodeBase


#endif // MERDRDATACUBEMIDW_NODEBASE_HPP_
