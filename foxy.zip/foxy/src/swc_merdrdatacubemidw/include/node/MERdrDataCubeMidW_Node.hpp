/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_Node.hpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */

#ifndef MERDRDATACUBEMIDW_NODE_HPP_
#define MERDRDATACUBEMIDW_NODE_HPP_

#include "MERdrDataCubeMidW_NodeBaseTrigger.hpp"
#include "msg_replay_radar/msg/msg_rra_data.hpp"
#include "msg_can_addon/msg/msg_radarcfg_type.hpp"
#include "msg_replay_radar/msg/msg_midw_int_all_data_type.hpp"

class MERdrDataCubeMidW_Node : public MERdrDataCubeMidW_NodeBaseTrigger
{
public:
    explicit MERdrDataCubeMidW_Node(std::shared_ptr<rclcpp::Node> node);
    virtual ~MERdrDataCubeMidW_Node();

private:
	// Node pointer
	std::shared_ptr<rclcpp::Node> node_;
	rclcpp::Subscription<msg_replay_radar::msg::MsgMidwIntAllDataType>::SharedPtr sub_midw_int_all_data_;
	rclcpp::Subscription<msg_can_addon::msg::MsgRadarcfgType>::SharedPtr sub_radarcfg_type_;

	void callback_midw_int_all_data(msg_replay_radar::msg::MsgMidwIntAllDataType::UniquePtr msg);
	void callback_radarcfg(msg_can_addon::msg::MsgRadarcfgType::UniquePtr msg);

	void sync_callback_midw_int_all_data(msg_replay_radar::msg::MsgMidwIntAllDataType::UniquePtr msg);

    void init_subscriber(void);
    void init_synchronizer(void);

};	// MERdrDataCubeMidW_Node


#endif // MERDRDATACUBEMIDW_NODE_HPP_
