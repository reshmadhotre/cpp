/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       MERdrDataCubeMidW_NodeBaseParquet.hpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */
 
#ifndef MERDRDATACUBEMIDW_NODEBASEPARQUET_HPP_
#define MERDRDATACUBEMIDW_NODEBASEPARQUET_HPP_



#include "rclcpp/rclcpp.hpp"
#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <cmath>
#include <queue>
#include <sys/stat.h>

#include "MERdrDataCubeMidW_Parquet_Out.hpp"
#include "MERdrDataCubeMidW_Parquet_In.hpp"
#include "msg_swc_common/msg/msg_node_feedback_type.hpp"


const constexpr int QUEUE_SIZE_SUBSCRIBER_PARQUET = 100;


class MERdrDataCubeMidW_NodeBaseParquet
{
public:
    explicit MERdrDataCubeMidW_NodeBaseParquet(std::shared_ptr<rclcpp::Node> node);
    ~MERdrDataCubeMidW_NodeBaseParquet() = default;
    MERdrDataCubeMidW_NodeBaseParquet(const MERdrDataCubeMidW_NodeBaseParquet &other) = delete;
    MERdrDataCubeMidW_NodeBaseParquet & operator=(const MERdrDataCubeMidW_NodeBaseParquet &other) = delete;

    bool file_changed() const;
    bool enable_parquet_out() const;
    bool enable_parquet_in() const;
    void WriteParquetFile();
    void incr_cntr();
    void reset_cntr();
    bool write_data() const;

    std::queue<std::unique_ptr<MERdrDataCubeMidW_Parquet_In>> queue_parquet_in_;
    std::queue<std::unique_ptr<MERdrDataCubeMidW_Parquet_Out>> queue_parquet_out_;
    
private:
    void InitParameter();
    void InitSubscriber();
    void InitParquetExporter();
    void UpdateParquetDataMap();
    void callback_node_feedback(msg_swc_common::msg::MsgNodeFeedbackType::UniquePtr msg);

    uint32_t counter_{1};
    int64_t msg_cntr_{1};
    bool param_record_parquets_in_{false};
    bool param_record_parquets_out_{false};
    bool is_parquet_file_name_set_{false};
    bool has_file_changed_{false};
    bool is_end_of_parquet_file_{false};
    std::shared_ptr<rclcpp::Node> node_;
    rclcpp::Subscription<msg_swc_common::msg::MsgNodeFeedbackType>::SharedPtr sub_node_feedback_;

};	// class MERdrDataCubeMidW_NodeBaseParquet

#endif // MERDRDATACUBEMIDW_NODEBASEPARQUET_HPP_
