/*
 * Copyright 2019 - 2023 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       Synchronizer.hpp
 * \version    5.0.0 - Release
 * \date       Aug-18-2023 - 06:49:41
 *
 * \author     Magna Electronics Europe GmbH and Co. OHG 
 *             D-63877 Sailauf
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 */
 
#ifndef SYNCHRONIZER_HPP_
#define SYNCHRONIZER_HPP_


#include "SynchronizerBase.hpp"
#include <queue>



template<typename T>
class Synchronizer : public SynchronizerBase
{
public:
    typedef std::unique_ptr<T> msg_ptr_t;
	typedef std::function<void(msg_ptr_t)> cb_t;

private:
	cb_t _cb;
	std::queue<msg_ptr_t> msg_queue;

public:
	Synchronizer(cb_t cb);
	bool cb() override;
	void setMsg(msg_ptr_t msg);

};	// Synchronizer


template<typename T>
Synchronizer<T>::Synchronizer(cb_t cb)
:_cb(cb)
{

}


template<typename T>
bool Synchronizer<T>::cb()
{
    if (nullptr != _cb)
    {
        _cb(std::move(msg_queue.front()));
        msg_queue.pop();
        return true;
    }

    return false;
}


template<typename T>
void Synchronizer<T>::setMsg(msg_ptr_t msg)
{
    msg_queue.push(std::move(msg));
}


#endif // SYNCHRONIZER_HPP_
