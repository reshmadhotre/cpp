#include "RosbagUtil.h"

RosbagUtil::RosbagUtil(std::string rosbag_path, std::shared_ptr<rclcpp::Node> node,
                       rclcpp::node_interfaces::NodeBaseInterface::SharedPtr node_base_interface)
{
    rosbag_path_ = rosbag_path;
    node_ = node;
    node_base_interface_ = node_base_interface;
    rosbag_reader_ = std::make_unique<rosbag2_cpp::readers::SequentialReader>();
    prev_published_time_ = 0;
    PublishStaticTransformsFromBag();
}

void RosbagUtil::PublishStaticTransformsFromBag()
{
    auto rosbag_reader_tf = std::make_unique<rosbag2_cpp::readers::SequentialReader>();
    rosbag2_cpp::StorageOptions storage_options{};
    storage_options.uri = rosbag_path_;
    storage_options.storage_id = "sqlite3";

    rosbag2_cpp::ConverterOptions converter_options{};
    converter_options.input_serialization_format = rmw_get_serialization_format(); // "cdr"
    converter_options.output_serialization_format = rmw_get_serialization_format();

    std::vector<std::string> topics_to_publish{"/tf_static"};
    rosbag2_storage::StorageFilter storage_filter;
    storage_filter.topics = topics_to_publish;

    rosbag_reader_tf->open(storage_options, converter_options);
    rosbag_reader_tf->set_filter(storage_filter);

    if (rosbag_reader_tf->has_next())
    {
        static_transform_broadcaster_ = std::make_shared<tf2_ros::StaticTransformBroadcaster>(node_);
    }

    while (rosbag_reader_tf->has_next())
    {
        auto tf_msg = rosbag_reader_tf->read_next();

        auto transform = geometry_msgs::msg::TransformStamped();
        auto type_support =
            rosidl_typesupport_cpp::get_message_type_support_handle<geometry_msgs::msg::TransformStamped>();

        auto rmw_serialized_msg = static_cast<std::shared_ptr<rmw_serialized_message_t>>(tf_msg->serialized_data);
        auto ret = rmw_deserialize(rmw_serialized_msg.get(), type_support, &transform);

        if (ret == RMW_RET_OK)
        {
            RCLCPP_INFO(node_->get_logger(), "Publishing static transform from rosbag...");
            static_transform_broadcaster_->sendTransform(transform);
        }
    }
}

bool RosbagUtil::OpenBag(const std::vector<std::string>& msg_types_to_publish)
{
    rosbag2_cpp::StorageOptions storage_options{};
    storage_options.uri = rosbag_path_;
    storage_options.storage_id = "sqlite3";

    rosbag2_cpp::ConverterOptions converter_options{};
    converter_options.input_serialization_format = rmw_get_serialization_format(); // "cdr"
    converter_options.output_serialization_format = rmw_get_serialization_format();

    try
    {
        rosbag_reader_->open(storage_options, converter_options);
        auto topics_to_publish = GetTopicsToPublishFromTypes(msg_types_to_publish);

        if (msg_types_to_publish.empty())
        {
            RCLCPP_WARN(node_->get_logger(), "No topic types provided to filter. Publishing all topics from Rosbag.");
        }

        else
        {

            rosbag2_storage::StorageFilter storage_filter;
            storage_filter.topics = topics_to_publish;
            rosbag_reader_->set_filter(storage_filter);
        }

        PreparePublishers(topics_to_publish);

        auto rosbag_metadata = rosbag_reader_->get_metadata();
        bag_duration_ns_ = rosbag_metadata.duration;
        bag_start_time_ns_ = rosbag_metadata.starting_time.time_since_epoch().count();
        return true;
    }
    catch (const std::exception& e)
    {
        RCLCPP_ERROR(node_->get_logger(), "Error opening rosbag at path : %s", rosbag_path_.c_str());
        std::cerr << e.what() << '\n';
        return false;
    }
}

std::vector<std::string> RosbagUtil::GetTopicsToPublishFromTypes(const std::vector<std::string>& msg_types)
{
    std::vector<std::string> topics_to_publish;
    bool publish_all_topics = msg_types.empty();

    auto all_topics_rosbag = rosbag_reader_->get_all_topics_and_types();
    for (const auto& topic : all_topics_rosbag)
    {
        const auto& type = topic.type;

        if (publish_all_topics)
        {
            topics_to_publish.push_back(topic.name);
        }

        else if (std::find(msg_types.begin(), msg_types.end(), type) != msg_types.end())
        {
            topics_to_publish.push_back(topic.name);
        }
    }

    return topics_to_publish;
}

void RosbagUtil::PreparePublishers(const std::vector<std::string>& topics_to_publish)
{
    auto all_topics_rosbag = rosbag_reader_->get_all_topics_and_types();

    for (const auto& topic : all_topics_rosbag)
    {
        // Filter topics of interest.
        if (!topics_to_publish.empty())
        {
            auto iter = std::find(topics_to_publish.begin(), topics_to_publish.end(), topic.name);
            if (iter == topics_to_publish.end())
            {
                continue;
            }

            auto topic_qos = rclcpp::QoS(rmw_qos_profile_default.depth);

            try
            {
                RCLCPP_INFO(node_->get_logger(), "Creating publisher for type : %s", topic.type.c_str());
                publishers_.insert(
                    std::make_pair(topic.name, CreateGenericPublisher(topic.name, topic.type, topic_qos)));
            }
            catch (const std::exception& e)
            {
                RCLCPP_ERROR(node_->get_logger(), "Ignoring topic : %s for replay.", topic.name.c_str());
                std::cerr << e.what() << '\n';
            }
        }
    }
}

std::shared_ptr<GenericPublisher> RosbagUtil::CreateGenericPublisher(const std::string& topic, const std::string& type,
                                                                     const rclcpp::QoS& qos)
{
    std::shared_ptr<rcpputils::SharedLibrary> library_generic_publisher =
        rosbag2_cpp::get_typesupport_library(type, "rosidl_typesupport_cpp");

    auto type_support = rosbag2_cpp::get_typesupport_handle(type, "rosidl_typesupport_cpp", library_generic_publisher);

    return std::make_shared<GenericPublisher>(node_base_interface_.get(), *type_support, topic, qos);
}

bool RosbagUtil::HasNext()
{
    return rosbag_reader_->has_next();
}

std::shared_ptr<rosbag2_storage::SerializedBagMessage> RosbagUtil::GetNextMessage()
{
    if (HasNext())
    {
        return rosbag_reader_->read_next();
    }

    return nullptr;
}

void RosbagUtil::PublishMessage(std::shared_ptr<rosbag2_storage::SerializedBagMessage> bag_msg)
{
    auto topic_name = bag_msg->topic_name;

    auto publisher_iter = publishers_.find(topic_name);
    if (publisher_iter != publishers_.end())
    {
        publisher_iter->second->Publish(bag_msg->serialized_data);
        prev_published_time_ = bag_msg->time_stamp;
    }
}

float RosbagUtil::GetDurationPlayed()
{
    return (prev_published_time_ - bag_start_time_ns_) * 1e-9;
}

float RosbagUtil::GetRosbagDuration()
{
    return bag_duration_ns_.count() * 1e-9;
}

rcutils_time_point_value_t RosbagUtil::GetPrevPublishedTimestamp()
{
    return prev_published_time_;
}
