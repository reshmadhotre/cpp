
#include "RosParams.h"

namespace ROS_PARAM_NAMES
{

const std::string ROSBAG_FOLDER_PATH = "rosbag_folder_path";
const std::string ROSBAG_TYPE = "rosbag_type";

} // namespace ROS_PARAM_NAMES

namespace ROS_PARAM_VALUES
{
const std::string ROSBAG_TYPE_RDC3 = "RDC3";
const std::string ROSBAG_TYPE_MIDW = "MIDW";
const std::string ROSBAG_TYPE_VIDEO = "VIDEO";
const std::string ROSBAG_TYPE_CAN = "CAN";
const std::string ROSBAG_TYPE_ALL = "ALL";

} // namespace ROS_PARAM_VALUES