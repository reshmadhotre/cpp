#include "ServerReplayRosbagNode.h"
#include "RosbagUtil.h"
int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);

    auto node = std::make_shared<rclcpp::Node>("server_replay_rosbag_node");

    auto server_replay_rosbag_node = std::make_shared<ServerReplayRosbagNode>(node);
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}