#include "RosTypes.h"

namespace ROSBAG_PLAY_MESSAGE_TYPES
{
const std::vector<std::string> RDC3_MSG_TYPES{"msg_replay_radar/msg/MsgRraDetectionDataList",
                                              "msg_replay_radar/msg/MsgRraData",
                                              "msg_replay_radar/msg/MsgRraPointCloudDataFloatList",
                                              "msg_swc_common/msg/MsgTriggerCyclicType",
                                              "msg_swc_common/msg/MsgEventType",
                                              "msg_swc_common/msg/MsgNodeFeedbackType"};

const std::vector<std::string> MIDW_MSG_TYPES{
    "msg_swc_common/msg/MsgDetnGetMidWDataType", "msg_swc_common/msg/MsgScaninfoType",
    "msg_swc_common/msg/MsgTriggerInitType",     "msg_swc_common/msg/MsgTriggerCyclicType",
    "msg_swc_common/msg/MsgEventType",           "msg_swc_common/msg/MsgNodeFeedbackType",
    "msg_live_addon/msg/MsgObjdataType"};

const std::vector<std::string> VIDEO_MSG_TYPES{"sensor_msgs/msg/Image"};

const std::vector<std::string> CAN_MSG_TYPES{
    "msg_can_addon/msg/MsgCanRadarCalDataType", "msg_can_addon/msg/MsgRadarcfgType",
    "msg_can_addon/msg/MsgCanRadarInfoType",    "msg_can_addon/msg/MsgCanTsyncType",
    "msg_can_addon/msg/MsgVehdynType",          "msg_live_addon/msg/MsgCanObjListType",
    "msg_live_addon/msg/MsgRoadborderType"};

} // namespace ROSBAG_PLAY_MESSAGE_TYPES