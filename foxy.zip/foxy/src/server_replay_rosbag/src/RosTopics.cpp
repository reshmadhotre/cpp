#include "RosTopics.h"

namespace ROS_PUBLISHER_TOPICS
{
const std::string TOPIC_ROSBAG_PLAY_STATUS = "topic_rosbag_play_status";

} // namespace ROS_PUBLISHER_TOPICS

namespace ROS_SUBSCRIBER_TOPICS
{

const std::string TOPIC_TRIGGER_ROSBAG_PLAY_NEXT_FRAME = "topic_trigger_rosbag_play_next_frame";
const std::string TOPIC_SET_ROSBAG_PLAY_PAUSE_MODE = "topic_set_rosbag_play_pause_mode";

} // namespace ROS_SUBSCRIBER_TOPICS
