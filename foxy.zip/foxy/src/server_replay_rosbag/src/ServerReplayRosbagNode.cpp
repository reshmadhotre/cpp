#include "ServerReplayRosbagNode.h"
#include "RosParams.h"
#include "RosTopics.h"
#include "RosTypes.h"

ServerReplayRosbagNode::ServerReplayRosbagNode(std::shared_ptr<rclcpp::Node> node)
{
    node_ = node;
    ros_param_util_ = std::make_shared<RosParamUtil>(node_);

    InitROSParams();
    InitPublishers();
    InitSubscribers();
    InitTimers();
}

void ServerReplayRosbagNode::InitROSParams()
{
    using namespace ROS_PARAM_NAMES;
    using namespace ROS_PARAM_VALUES;
    ros_param_util_->DeclareParameter(ROSBAG_FOLDER_PATH, "");
    ros_param_util_->DeclareParameter(ROSBAG_TYPE, ROSBAG_TYPE_ALL);

    rosbag_folder_path_ = ros_param_util_->GetParameter(ROSBAG_FOLDER_PATH).as_string();
    rosbag_type_ = ros_param_util_->GetParameter(ROSBAG_TYPE).as_string();
}

void ServerReplayRosbagNode::InitPublishers()
{
    using namespace ROS_PUBLISHER_TOPICS;
    status_publisher_ =
        node_->create_publisher<server_replay_rosbag::msg::MsgRosbagPlayStatus>(TOPIC_ROSBAG_PLAY_STATUS, 10);
}

void ServerReplayRosbagNode::InitSubscribers()
{
    using namespace ROS_SUBSCRIBER_TOPICS;
    trigger_single_frame_subscriber_ = node_->create_subscription<server_replay_rosbag::msg::MsgTriggerSingleFrame>(
        TOPIC_TRIGGER_ROSBAG_PLAY_NEXT_FRAME, 10,
        std::bind(&ServerReplayRosbagNode::TriggerNextFrameCB, this, std::placeholders::_1));

    set_pause_mode_subscriber_ = node_->create_subscription<server_replay_rosbag::msg::MsgSetPauseMode>(
        TOPIC_SET_ROSBAG_PLAY_PAUSE_MODE, 10,
        std::bind(&ServerReplayRosbagNode::SetPauseModeCB, this, std::placeholders::_1));
}

void ServerReplayRosbagNode::InitTimers()
{
    data_publish_timer_ = node_->create_wall_timer(std::chrono::milliseconds(1),
                                                   std::bind(&ServerReplayRosbagNode::DataPublishTimerCB, this));
}

void ServerReplayRosbagNode::DataPublishTimerCB()
{

    if (rosbag_util_ == nullptr)
    {
        InitRosbagUtil();
    }

    if (!rosbag_opened_)
    {
        RCLCPP_INFO(node_->get_logger(), "Couldn't open rosbag at : %s", rosbag_folder_path_.c_str());
        return;
    }

    if (pause_playback_)
    {
        // Reset the prev message timestamp to continue the timepoint from now.
        prev_message_timestamp_ = 0;
        return;
    }

    PublishNextFrame();
}

void ServerReplayRosbagNode::PublishNextFrame()
{
    auto bag_msg = rosbag_util_->GetNextMessage();

    if (bag_msg)
    {
        int64_t next_timestamp = bag_msg->time_stamp;
        if (prev_message_timestamp_ == 0)
        {
            prev_message_timestamp_ = next_timestamp;
            prev_publish_system_time_ = std::chrono::system_clock::now();
        }

        auto time_delta = next_timestamp - prev_message_timestamp_;
        auto time_delta_ns = std::chrono::nanoseconds(time_delta);
        if (time_delta > 5e9)
        {
            RCLCPP_WARN(node_->get_logger(), "Time difference of more than 5sec. Publishinbg without a wait!");
            time_delta_ns = std::chrono::nanoseconds(0);
        }
        std::this_thread::sleep_until(prev_publish_system_time_ +
                                      std::chrono::duration_cast<std::chrono::nanoseconds>(time_delta_ns));

        rosbag_util_->PublishMessage(bag_msg);

        auto status_msg = std::make_shared<server_replay_rosbag::msg::MsgRosbagPlayStatus>();
        status_msg->current_published_time = next_timestamp;
        status_msg->bag_duration_sec = rosbag_duration_;
        status_msg->duration_played_sec = rosbag_util_->GetDurationPlayed();
        status_msg->status = server_replay_rosbag::msg::MsgRosbagPlayStatus::IN_PROGRESS;
        status_publisher_->publish(*status_msg.get());

        prev_publish_system_time_ = std::chrono::system_clock::now();
        prev_message_timestamp_ = next_timestamp;
    }

    else
    {
        auto status_msg = std::make_shared<server_replay_rosbag::msg::MsgRosbagPlayStatus>();
        status_msg->current_published_time = prev_message_timestamp_;
        status_msg->bag_duration_sec = rosbag_duration_;
        status_msg->duration_played_sec = rosbag_util_->GetDurationPlayed();
        status_msg->status = server_replay_rosbag::msg::MsgRosbagPlayStatus::FINISHED;
        status_publisher_->publish(*status_msg.get());
    }
}

void ServerReplayRosbagNode::SetPauseModeCB(server_replay_rosbag::msg::MsgSetPauseMode::UniquePtr msg)
{
    pause_playback_ = msg->pause_playback;
}

void ServerReplayRosbagNode::TriggerNextFrameCB([[maybe_unused]] server_replay_rosbag::msg::MsgTriggerSingleFrame::UniquePtr msg)
{
    // Only in pause mode.
    if (pause_playback_)
    {
        PublishNextFrame();
    }
}

void ServerReplayRosbagNode::InitRosbagUtil()
{
    rosbag_util_ = std::make_shared<RosbagUtil>(rosbag_folder_path_, node_, node_->get_node_base_interface());
    auto msg_types_to_publish = GetRosTopicTypes(rosbag_type_);
    rosbag_opened_ = rosbag_util_->OpenBag(msg_types_to_publish);
    if (rosbag_opened_)
    {
        rosbag_duration_ = rosbag_util_->GetRosbagDuration();
    }
}

std::vector<std::string> ServerReplayRosbagNode::GetRosTopicTypes(const std::string& rosbag_type)
{
    using namespace ROS_PARAM_VALUES;
    using namespace ROSBAG_PLAY_MESSAGE_TYPES;

    if (rosbag_type == ROSBAG_TYPE_RDC3)
    {
        return RDC3_MSG_TYPES;
    }

    if (rosbag_type == ROSBAG_TYPE_MIDW)
    {
        return MIDW_MSG_TYPES;
    }

    if (rosbag_type == ROSBAG_TYPE_VIDEO)
    {
        return VIDEO_MSG_TYPES;
    }

    if (rosbag_type == ROSBAG_TYPE_CAN)
    {
        return CAN_MSG_TYPES;
    }

    return std::vector<std::string>{};
}
