#ifndef ROS_TOPICS_H
#define ROS_TOPICS_H

#include <string>

namespace ROS_PUBLISHER_TOPICS
{

extern const std::string TOPIC_ROSBAG_PLAY_STATUS;

} // namespace ROS_PUBLISHER_TOPICS

namespace ROS_SUBSCRIBER_TOPICS
{

extern const std::string TOPIC_TRIGGER_ROSBAG_PLAY_NEXT_FRAME;
extern const std::string TOPIC_SET_ROSBAG_PLAY_PAUSE_MODE;

} // namespace ROS_SUBSCRIBER_TOPICS
#endif