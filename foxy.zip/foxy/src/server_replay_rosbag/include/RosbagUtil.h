#ifndef ROSBAG_UTIL_HPP
#define ROSBAG_UTIL_HPP

#include "GenericPublisher.h"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rosbag2_compression/sequential_compression_reader.hpp"
#include "rosbag2_cpp/readers/sequential_reader.hpp"
#include "rosbag2_cpp/typesupport_helpers.hpp"
#include <tf2_ros/static_transform_broadcaster.h>

class RosbagUtil
{
  public:
    explicit RosbagUtil(std::string rosbag_path, std::shared_ptr<rclcpp::Node> node,
                        rclcpp::node_interfaces::NodeBaseInterface::SharedPtr node_base_interface);
    bool OpenBag(const std::vector<std::string>& msg_types_to_publish);
    bool HasNext();
    std::shared_ptr<rosbag2_storage::SerializedBagMessage> GetNextMessage();
    void PublishMessage(std::shared_ptr<rosbag2_storage::SerializedBagMessage> bag_msg);
    float GetDurationPlayed();
    float GetRosbagDuration();
    rcutils_time_point_value_t GetPrevPublishedTimestamp();

  private:
    void PublishStaticTransformsFromBag();
    std::vector<std::string> GetTopicsToPublishFromTypes(const std::vector<std::string>& msg_types);
    void PreparePublishers(const std::vector<std::string>& topics_to_publish);
    std::shared_ptr<GenericPublisher> CreateGenericPublisher(const std::string& topic, const std::string& type,
                                                             const rclcpp::QoS& qos);

    std::string rosbag_path_;
    std::chrono::nanoseconds bag_duration_ns_;
    rcutils_time_point_value_t bag_start_time_ns_;
    rcutils_time_point_value_t prev_published_time_;
    std::shared_ptr<rclcpp::Node> node_;
    rclcpp::node_interfaces::NodeBaseInterface::SharedPtr node_base_interface_;
    std::unique_ptr<rosbag2_cpp::readers::SequentialReader> rosbag_reader_;
    std::unordered_map<std::string, std::shared_ptr<GenericPublisher>> publishers_;
    std::shared_ptr<tf2_ros::StaticTransformBroadcaster> static_transform_broadcaster_;
};

#endif