#ifndef ROS_PARAMS_H
#define ROS_PARAMS_H

#include <string>

namespace ROS_PARAM_NAMES
{

extern const std::string ROSBAG_FOLDER_PATH;
extern const std::string ROSBAG_TYPE;

} // namespace ROS_PARAM_NAMES

namespace ROS_PARAM_VALUES
{
extern const std::string ROSBAG_TYPE_RDC3;
extern const std::string ROSBAG_TYPE_MIDW;
extern const std::string ROSBAG_TYPE_VIDEO;
extern const std::string ROSBAG_TYPE_CAN;
extern const std::string ROSBAG_TYPE_ALL;

} // namespace ROS_PARAM_VALUES

#endif