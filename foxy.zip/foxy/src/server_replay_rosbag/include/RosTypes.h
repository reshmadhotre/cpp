#ifndef ROS_TYPES_H
#define ROS_TYPES_H

#include <string>
#include <vector>

namespace ROSBAG_PLAY_MESSAGE_TYPES
{
extern const std::vector<std::string> RDC3_MSG_TYPES;
extern const std::vector<std::string> MIDW_MSG_TYPES;
extern const std::vector<std::string> VIDEO_MSG_TYPES;
extern const std::vector<std::string> CAN_MSG_TYPES;
} // namespace ROSBAG_PLAY_MESSAGE_TYPES
#endif