#ifndef GENERIC_PUBLISHER_HPP
#define GENERIC_PUBLISHER_HPP

#include "rclcpp/rclcpp.hpp"

class GenericPublisher : public rclcpp::PublisherBase
{
  public:
    GenericPublisher(rclcpp::node_interfaces::NodeBaseInterface* node_base,
                     const rosidl_message_type_support_t& type_support, const std::string& topic_name,
                     const rclcpp::QoS& qos);

    virtual ~GenericPublisher() = default;

    void Publish(std::shared_ptr<rmw_serialized_message_t> message);

  private:
    rcl_publisher_options_t GetPublisherOptions(const rclcpp::QoS& qos);
};

#endif