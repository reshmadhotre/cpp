#ifndef SERVER_REPLAY_ROSBAG_NODE_HPP
#define SERVER_REPLAY_ROSBAG_NODE_HPP

#include "RosParamUtil.hpp"
#include "RosbagUtil.h"
#include "rclcpp/rclcpp.hpp"
#include "server_replay_rosbag/msg/msg_rosbag_play_status.hpp"
#include "server_replay_rosbag/msg/msg_set_pause_mode.hpp"
#include "server_replay_rosbag/msg/msg_trigger_single_frame.hpp"

class ServerReplayRosbagNode
{
  public:
    explicit ServerReplayRosbagNode(std::shared_ptr<rclcpp::Node> node);

  private:
    void InitROSParams();
    void InitTimers();
    void InitPublishers();
    void InitSubscribers();
    void InitRosbagUtil();
    std::vector<std::string> GetRosTopicTypes(const std::string& rosbag_type);
    void PublishNextFrame();

    void DataPublishTimerCB();
    void TriggerNextFrameCB(server_replay_rosbag::msg::MsgTriggerSingleFrame::UniquePtr msg);
    void SetPauseModeCB(server_replay_rosbag::msg::MsgSetPauseMode::UniquePtr msg);

    std::string rosbag_folder_path_{""};
    std::string rosbag_type_{""};

    bool rosbag_opened_{false};
    float rosbag_duration_;

    bool pause_playback_{false};

    std::chrono::time_point<std::chrono::system_clock> prev_publish_system_time_;
    int64_t prev_message_timestamp_{0};

    rclcpp::TimerBase::SharedPtr data_publish_timer_;

    std::shared_ptr<rclcpp::Node> node_;
    std::shared_ptr<RosbagUtil> rosbag_util_;
    std::shared_ptr<RosParamUtil> ros_param_util_;

    rclcpp::Publisher<server_replay_rosbag::msg::MsgRosbagPlayStatus>::SharedPtr status_publisher_;
    rclcpp::Subscription<server_replay_rosbag::msg::MsgTriggerSingleFrame>::SharedPtr trigger_single_frame_subscriber_;
    rclcpp::Subscription<server_replay_rosbag::msg::MsgSetPauseMode>::SharedPtr set_pause_mode_subscriber_;
};

#endif