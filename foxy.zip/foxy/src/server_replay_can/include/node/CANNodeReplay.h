
#ifndef CAN_NODE_REPLAY_H
#define CAN_NODE_REPLAY_H

#include "CANNode.h"
#include "RosPublisher.hpp"
#include "server_replay_can/msg/msg_set_pause_mode.hpp"
#include "server_replay_can/msg/msg_trigger_single_frame.hpp"
#include "msg_swc_common/msg/msg_node_feedback_type.hpp"

class CANNodeReplay : public CANNode
{
  public:
    CANNodeReplay(std::shared_ptr<rclcpp::Node> node);
    void SetParquetExporter(std::unique_ptr<ParquetExportSkelgen> parquet_exporter) override;
    void CloseFileHandles() override;

    void AddFeedbackMessage(std::shared_ptr<msg_swc_common::msg::MsgNodeFeedbackType> feedback_msg,
                            const int64_t timestamp) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_can_addon::msg::MsgCanRadarCalDataType> ros_cal_data) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_can_addon::msg::MsgRadarcfgType> ros_radar_cfg) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_can_addon::msg::MsgCanRadarInfoType> ros_radar_info) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_can_addon::msg::MsgCanTsyncType> ros_tsync) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_can_addon::msg::MsgVehdynType> ros_veh_dyn) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_live_addon::msg::MsgCanObjType> ros_can_obj_data) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_live_addon::msg::MsgRoadborderType> road_border) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_live_addon::msg::MsgVehmtnType> veh_mtn) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_live_addon::msg::MsgSensrmtnType> snsr_mtn) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_live_addon::msg::MsgBlkgdebugType> blkg_data) override;

  private:
    void InitROSParams() override;
    void InitPublishers() override;
    void InitSubscribers() override;
    void InitTimers() override;

    void RadarNodeFeedbackCB(msg_swc_common::msg::MsgNodeFeedbackType::UniquePtr msg);
    void TriggerNextFrameCB(server_replay_can::msg::MsgTriggerSingleFrame::UniquePtr msg);
    void SetPauseModeCB(server_replay_can::msg::MsgSetPauseMode::UniquePtr msg);
    void PublishTimerCB();

    void PublishCANFramesUntil(const int64_t timestamp);
    void PublishNextCANFrame();
    void UpdateParquet(std::shared_ptr<msg_can_addon::msg::MsgCanRadarCalDataType> radar_cal_data);
    void UpdateParquet(std::shared_ptr<msg_can_addon::msg::MsgRadarcfgType> radar_cfg);
    void UpdateParquet(std::shared_ptr<msg_live_addon::msg::MsgRoadborderType> road_brd);
    void UpdateParquet(std::shared_ptr<msg_live_addon::msg::MsgCanObjListType> can_obj_list);
    void UpdateParquet(std::shared_ptr<msg_can_addon::msg::MsgVehdynType> veh_dyn);
    void UpdateParquet(std::shared_ptr<msg_live_addon::msg::MsgVehmtnType> veh_mtn);
    void UpdateParquet(std::shared_ptr<msg_live_addon::msg::MsgSensrmtnType> snsr_mtn);
    void UpdateParquet(std::shared_ptr<msg_live_addon::msg::MsgBlkgdebugType> blkg_data);
    void UpdateParquet(std::shared_ptr<msg_can_addon::msg::MsgCanRadarInfoType> radar_info);

    const static uint8_t DEFAULT_HISTORY_DEPTH;
    const static uint32_t OBJ_DATA_FRAME_ID_START;
    const static uint32_t OBJ_DATA_FRAME_ID_END;

    bool standalone_mode_;
    bool pause_playback_{false};

    std::queue<std::unique_ptr<ParquetExportSkelgen>> parquet_queue_;

    std::shared_ptr<msg_can_addon::msg::MsgCanRadarInfoType> current_radar_info_;


    std::shared_ptr<RosPublisher<msg_swc_common::msg::MsgNodeFeedbackType>> feedback_publisher_;
    std::shared_ptr<RosPublisher<msg_can_addon::msg::MsgCanRadarCalDataType>> radar_cal_data_publisher_;
    std::shared_ptr<RosPublisher<msg_can_addon::msg::MsgRadarcfgType>> radar_cfg_publisher_;
    std::shared_ptr<RosPublisher<msg_can_addon::msg::MsgCanRadarInfoType>> radar_info_publisher_;
    std::shared_ptr<RosPublisher<msg_can_addon::msg::MsgCanTsyncType>> tsync_publisher_;
    std::shared_ptr<RosPublisher<msg_can_addon::msg::MsgVehdynType>> veh_dyn_publisher_;
    std::shared_ptr<RosPublisher<msg_live_addon::msg::MsgCanObjListType>> can_object_list_publisher_;
    std::shared_ptr<RosPublisher<msg_live_addon::msg::MsgRoadborderType>> can_road_border_publisher_;
    std::shared_ptr<RosPublisher<msg_live_addon::msg::MsgVehmtnType>> veh_mtn_publisher_;
    std::shared_ptr<RosPublisher<msg_live_addon::msg::MsgSensrmtnType>> snsr_mtn_publisher_;
    std::shared_ptr<RosPublisher<msg_live_addon::msg::MsgBlkgdebugType>> blkg_data_publisher_;

    rclcpp::Subscription<msg_swc_common::msg::MsgNodeFeedbackType>::SharedPtr radar_node_feedback_subscriber_;
    rclcpp::Subscription<server_replay_can::msg::MsgTriggerSingleFrame>::SharedPtr trigger_single_frame_subscriber_;
    rclcpp::Subscription<server_replay_can::msg::MsgSetPauseMode>::SharedPtr set_pause_mode_subscriber_;

    rclcpp::TimerBase::SharedPtr publish_timer_;
};
#endif
