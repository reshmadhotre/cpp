#ifndef ROS_PARAMS_H
#define ROS_PARAMS_H

#include <string>

namespace ROS_PARAM_NAMES
{

extern const std::string SENSOR_MOUNT_POS_X_PARAM;
extern const std::string SENSOR_MOUNT_POS_Y_PARAM;
extern const std::string SENSOR_MOUNT_POS_Z_PARAM;
extern const std::string SENSOR_MOUNT_YAW_PARAM;
extern const std::string SENSOR_MOUNT_PITCH_PARAM;
extern const std::string SENSOR_MOUNT_ROLL_PARAM;

} // namespace ROS_PARAM_NAMES

namespace ROS_PARAM_NAMES_REPLAY_MODE
{

extern const std::string REPLAY_MF4_CAN_FILEPATHS;
extern const std::string DBC_FILEPATH;
extern const std::string RECORD_ROSBAGS;
extern const std::string PARAM_RECORD_PARQUETS;
extern const std::string PUBLISH_CAN_OBJECT_LIST;
extern const std::string PUBLISH_ROAD_BORDER_DATA;
extern const std::string STANDALONE_MODE;

} // namespace ROS_PARAM_NAMES_REPLAY_MODE

namespace ROS_PARAM_NAMES_LIVE_MODE
{

extern const std::string CAN_CHANNEL;
extern const std::string DBC_FILEPATH;
extern const std::string RECORD_ROSBAGS;
extern const std::string ROSBAG_PATH;
extern const std::string RADAR_RUN;
extern const std::string RADAR_SYNC;

} // namespace ROS_PARAM_NAMES_LIVE_MODE
#endif