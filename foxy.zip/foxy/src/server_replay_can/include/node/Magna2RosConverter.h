#ifndef MAGNA_2_ROS_CONVERTER_H
#define MAGNA_2_ROS_CONVERTER_H

#include "CANNode.h"

class CalDataParser;
class RadarInfoParser;
class TSyncParser;
class RadarCfgParser;
class ObjectDataParser;
class VehicleStateDataParser;
class WheelStateDataParser;
class RoadBorderParser;
class EgoMotionParser;
class BlockageParser;

class Magna2RosConverter
{
  public:
    Magna2RosConverter();
    void SetCANNode(std::shared_ptr<CANNode> can_node);
    void Convert(const CalDataParser& cal_data_parser, const int64_t timestamp) const;
    void Convert(const ObjectDataParser& object_data_parser, const int64_t timestamp) const;
    void Convert(const RadarCfgParser& radar_cfg_parser, const int64_t timestamp) const;
    void Convert(const RadarInfoParser& radar_info_parser, const int64_t timestamp) const;
    void Convert(const TSyncParser& tsync_parser, const int64_t timestamp) const;
    void Convert(const VehicleStateDataParser& vehicle_state_data_parser, const int64_t timestamp) const;
    void Convert(const WheelStateDataParser& wheel_state_data_parser, const int64_t timestamp) const;
    void Convert(const RoadBorderParser& road_border_parser, const int64_t timestamp) const;
    void Convert(const EgoMotionParser& ego_motion_parser, const int64_t timestamp) const;
    void Convert(const BlockageParser& blkg_parser, const int64_t timestamp) const;

  private:
    std::shared_ptr<CANNode> can_node_;
    const static float G_MPS2;
    const static float DEG_TO_RAD;
    const static float KMPH_TO_MPS;
};
#endif