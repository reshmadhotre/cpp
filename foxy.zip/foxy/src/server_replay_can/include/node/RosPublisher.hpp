#ifndef ROS_PUBLISHER_H
#define ROS_PUBLISHER_H

#include "ConcurrentQueue.hpp"
#include "rclcpp/rclcpp.hpp"

template <typename T> struct RosCANMsg
{
    int64_t timestamp;
    std::shared_ptr<T> msg;
};

template <typename T> class RosPublisher
{
  public:
    RosPublisher(std::shared_ptr<rclcpp::Node> node, const std::string& topic, const uint8_t history_depth_size)
    {
        publisher_ = node->create_publisher<T>(topic, rclcpp::QoS(history_depth_size));
    }

    void AddMessage(std::shared_ptr<T> msg, const int64_t timestamp)
    {
        RosCANMsg<T> ros_can_msg;
        ros_can_msg.timestamp = timestamp;
        ros_can_msg.msg = std::move(msg);
        data_queue_.Push(std::move(ros_can_msg));
    }

    void PublishMessage(std::shared_ptr<T> msg)
    {
        publisher_->publish(*msg.get());
    }

    void PublishMessagesUntil(uint64_t timestamp)
    {
        auto ros_can_msgs = data_queue_.PopUntilTime(timestamp);
        for (auto& ros_can_msg : ros_can_msgs)
        {
            publisher_->publish(*ros_can_msg.msg.get());
        }
    }

    void PublishNextMessage()
    {
        if (!data_queue_.Empty())
        {
            auto ros_can_msg = data_queue_.Pop();
            publisher_->publish(*ros_can_msg.msg.get());
        }
    }

    int64_t GetNextTimestamp()
    {
        if (!data_queue_.Empty())
        {
            return data_queue_.Front().timestamp;
        }

        return 0;
    }

  private:
    typename rclcpp::Publisher<T>::SharedPtr publisher_;
    ConcurrentQueue<RosCANMsg<T>> data_queue_;
};
#endif