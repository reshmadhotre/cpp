#ifndef MDF_UTIL_H
#define MDF_UTIL_H

#include "MDFPlayer.h"
#include "ReplayLibrary.h"
#include "rclcpp/rclcpp.hpp"
class MDFUtil
{
  public:
    MDFUtil(std::shared_ptr<rclcpp::Node> node);
    ~MDFUtil();
    void OpenMf4File(const std::string& file_path);
    std::vector<mdfp::CanFDData_s> ReadFile();
    void CloseMf4File();

  private:
    mdfp::MDFPlayer mdf_player_;
    ReplayLibrary replay_lib_;

    bool mf4_file_opened_{false};

    std::shared_ptr<rclcpp::Node> node_;
};
#endif