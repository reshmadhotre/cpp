#ifndef CAN_NODE_LIVE_H
#define CAN_NODE_LIVE_H

#include "CANNode.h"
#include "RosPublisher.hpp"
#include "msg_can_addon/msg/msg_can_radar_info_type.hpp"
#include "msg_live_addon/msg/msg_can_obj_list_type.hpp"

class CANNodeLive : public CANNode
{
  public:
    CANNodeLive(std::shared_ptr<rclcpp::Node> node);
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_can_addon::msg::MsgCanRadarInfoType> ros_radar_info) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_live_addon::msg::MsgCanObjType> ros_can_obj_data) override;
    void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                       std::shared_ptr<msg_live_addon::msg::MsgRoadborderType> road_border) override;

  private:
    void InitROSParams() override;
    void InitPublishers() override;
    void InitSubscribers() override;
    void InitTimers() override;
    void InitRosbagWriter();
    std::string GetRosbagName();

    const static uint8_t DEFAULT_HISTORY_DEPTH;
    const static uint32_t OBJ_DATA_FRAME_ID_START;
    const static uint32_t OBJ_DATA_FRAME_ID_END;
    std::string rosbag_path_;
    bool record_rosbags_{false};

    std::shared_ptr<msg_can_addon::msg::MsgCanRadarInfoType> current_radar_info_;
    std::shared_ptr<RosPublisher<msg_live_addon::msg::MsgCanObjListType>> can_object_list_publisher_;
    std::shared_ptr<RosPublisher<msg_can_addon::msg::MsgCanRadarInfoType>> can_radar_info_publisher_;
    std::shared_ptr<RosPublisher<msg_live_addon::msg::MsgRoadborderType>> road_border_publisher_;
};
#endif