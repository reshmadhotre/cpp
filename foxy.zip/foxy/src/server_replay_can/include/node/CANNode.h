#ifndef CAN_NODE_H
#define CAN_NODE_H

#include "ParquetExporterSkelgen.hpp"
#include "RosParamUtil.hpp"
#include "RosbagWriter.hpp"
#include "TfFramesTransformUtil.h"
#include "msg_can_addon/msg/msg_can_radar_cal_data_type.hpp"
#include "msg_can_addon/msg/msg_can_radar_info_type.hpp"
#include "msg_can_addon/msg/msg_can_tsync_type.hpp"
#include "msg_can_addon/msg/msg_radarcfg_type.hpp"
#include "msg_can_addon/msg/msg_vehdyn_type.hpp"
#include "msg_live_addon/msg/msg_can_obj_list_type.hpp"
#include "msg_live_addon/msg/msg_roadborder_type.hpp"
#include "msg_live_addon/msg/msg_sensrmtn_type.hpp"
#include "msg_live_addon/msg/msg_vehmtn_type.hpp"
#include "msg_live_addon/msg/msg_blkgdebug_type.hpp"
#include "msg_swc_common/msg/msg_node_feedback_type.hpp"

#include "rclcpp/rclcpp.hpp"
#include <tf2_ros/static_transform_broadcaster.h>

class CANNode
{
  public:
    CANNode(std::shared_ptr<rclcpp::Node> node);
    void SetRosbagWriter(std::shared_ptr<RosbagWriter> rosbag_writer);
    virtual void SetParquetExporter(std::unique_ptr<ParquetExportSkelgen> parquet_exporter);
    virtual void CloseFileHandles();

    virtual void AddFeedbackMessage(std::shared_ptr<msg_swc_common::msg::MsgNodeFeedbackType> feedback_msg,
                                    const int64_t timestamp);

    virtual void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                               std::shared_ptr<msg_can_addon::msg::MsgCanRadarCalDataType> ros_cal_data);
    virtual void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                               std::shared_ptr<msg_can_addon::msg::MsgRadarcfgType> ros_radar_cfg);
    virtual void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                               std::shared_ptr<msg_can_addon::msg::MsgCanRadarInfoType> ros_radar_info);
    virtual void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                               std::shared_ptr<msg_can_addon::msg::MsgCanTsyncType> ros_tsync);
    virtual void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                               std::shared_ptr<msg_can_addon::msg::MsgVehdynType> ros_veh_dyn);
    virtual void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                               std::shared_ptr<msg_live_addon::msg::MsgCanObjType> ros_can_obj_data);
    virtual void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                               std::shared_ptr<msg_live_addon::msg::MsgRoadborderType> road_border);
    virtual void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                               std::shared_ptr<msg_live_addon::msg::MsgVehmtnType> veh_mtn);
    virtual void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                               std::shared_ptr<msg_live_addon::msg::MsgSensrmtnType> snsr_mtn);
    virtual void AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                               std::shared_ptr<msg_live_addon::msg::MsgBlkgdebugType> blkg_data);

  protected:
    std::shared_ptr<rclcpp::Node> node_;
    std::shared_ptr<RosbagWriter> rosbag_writer_;
    std::string node_namespace_;
    std::shared_ptr<RosParamUtil> ros_param_util_;

  private:
    virtual void InitPublishers() = 0;
    virtual void InitSubscribers() = 0;
    virtual void InitROSParams() = 0;
    virtual void InitTimers() = 0;

    void PublishStaticTransform();
    void GetNodeNamespace();

    std::shared_ptr<tf2_ros::StaticTransformBroadcaster> static_transform_broadcaster_;
    std::shared_ptr<TfFramesTransformUtil> tf_frames_transform_util_;
};
#endif