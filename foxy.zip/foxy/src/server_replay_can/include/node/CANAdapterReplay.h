#ifndef CAN_ADAPTER_REPLAY_H
#define CAN_ADAPTER_REPLAY_H

#include "CANAdapter.h"
#include "MDFUtil.h"
#include <queue>

class CANAdapterReplay : public CANAdapter
{
  public:
    CANAdapterReplay(std::shared_ptr<rclcpp::Node> node);
    ~CANAdapterReplay();
    void StartReaderThread();
    void StopReaderThread();
    void CloseFileHandles();
    void ReadNextFile();

  private:
    void InitROSParams();
    void ReadWorker();
    void ProcessCANFrame(const mdfp::CanFDData_s& can_data, bool end_of_replay);
    void InitFrameIDsToProcess() override;
    void SendNodeFeedbackMsg(int64_t timestamp, bool end_of_replay);

    // TODO : Enable when CAN message comparison is required
    // void CompareCANFrame(msg_can_fd::msg::Frame::UniquePtr msg);
    // void CANVehAdapterOutputCB(msg_can_fd::msg::Frame::UniquePtr msg);

    std::shared_ptr<MDFUtil> mdf_util_;

    bool publish_can_obj_list_;
    bool publish_road_border_data_;

    std::thread reader_thread_;
    std::atomic<bool> continue_reading_;
    std::queue<std::string> mf4_files_queue_;
    bool end_of_mf4_files_{false};

    std::string opened_mf4_file_path_{""};
    uint8_t num_files_to_process_{0};
    uint8_t num_files_processed_{0};

    bool record_parquets_;
    // TODO : Enable when CAN message comparison is required
    // rclcpp::Subscription<msg_can_fd::msg::Frame>::SharedPtr sub_can_veh_adapter_output_;
};
#endif