#ifndef CAN_ADAPTER_H
#define CAN_ADAPTER_H

#include "CANNode.h"
#include "ParquetExporterSkelgen.hpp"
#include "ParserFactory.h"
#include "RosParamUtil.hpp"
#include "RosbagWriter.hpp"

class CANAdapter
{
  public:
    CANAdapter(std::shared_ptr<rclcpp::Node> node);
    void SetMagna2RosConverter(std::shared_ptr<Magna2RosConverter> converter);
    void SetCANNode(std::shared_ptr<CANNode> can_node);

  protected:
    void InitCANParser();
    bool ProcessFrameID(const uint32_t frame_id);
    bool FileExists(const std::string& file_path);
    std::string RemoveExtensionFromFilePath(const std::string& file_path);

    std::vector<uint32_t> frame_ids_to_process_;

    std::shared_ptr<ParserFactory> parser_factory_;
    bool can_parser_initialized_{false};
    std::string dbc_filepath_{""};

    std::shared_ptr<Magna2RosConverter> magna_ros_converter_;

    bool record_rosbags_;
    std::shared_ptr<RosbagWriter> rosbag_writer_;

    std::shared_ptr<rclcpp::Node> node_;
    std::shared_ptr<CANNode> can_node_;

    std::shared_ptr<RosParamUtil> ros_param_util_;

  private:
    virtual void InitFrameIDsToProcess() = 0;
};
#endif