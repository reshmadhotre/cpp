#ifndef ROS_TOPICS_H
#define ROS_TOPICS_H

#include <string>
namespace ROS_PUBLISHER_TOPICS_LIVE_MODE
{
extern const std::string TOPIC_CAN_OBJ_DATA;
extern const std::string TOPIC_CAN_RADAR_INFO;
extern const std::string TOPIC_CAN_ROADBORDER;
} // namespace ROS_PUBLISHER_TOPICS_LIVE_MODE

namespace ROS_PUBLIHSER_TOPICS_REPLAY_MODE
{
extern const std::string TOPIC_CAN_RADAR_CAL_DATA;
extern const std::string TOPIC_CAN_RADARCFG;
extern const std::string TOPIC_CAN_RADAR_INFO;
extern const std::string TOPIC_CAN_TSYNC;
extern const std::string TOPIC_CAN_VEHDYN;
extern const std::string TOPIC_CAN_OBJ_DATA;
extern const std::string TOPIC_NODE_FEEDBACK;
extern const std::string TOPIC_CAN_ROAD_BORDER;
extern const std::string TOPIC_CAN_SNSR_MTN;
extern const std::string TOPIC_CAN_VEH_MTN;
extern const std::string TOPIC_BLKG_DEBUG;

} // namespace ROS_PUBLIHSER_TOPICS_REPLAY_MODE

namespace ROS_SUBSCRIBER_TOPICS_REPLAY_MODE
{
extern const std::string TOPIC_NODE_FEEDBACK;
extern const std::string TOPIC_TRIGGER_CAN_NEXT_FRAME;
extern const std::string TOPIC_SET_CAN_PAUSE_MODE;
} // namespace ROS_SUBSCRIBER_TOPICS_REPLAY_MODE
#endif
