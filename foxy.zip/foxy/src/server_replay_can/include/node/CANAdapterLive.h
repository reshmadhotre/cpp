#ifndef CAN_ADAPTER_LIVE_H
#define CAN_ADAPTER_LIVE_H

#include "CANAdapter.h"
#include "can_iface.h"
#include "rcl_interfaces/msg/set_parameters_result.hpp"
#include "VehicleStateDefs.h"
#include "TSyncDefs.h"

class CANAdapterLive : public CANAdapter
{
  public:
    CANAdapterLive(std::shared_ptr<rclcpp::Node> node);
    void ReadNextMessage();

  private:
    void InitROSParams();
    void InitCANInterface();
    void InitFrameIDsToProcess() override;
    void InitTimers();
    rcl_interfaces::msg::SetParametersResult ParametersUpdateCB(const std::vector<rclcpp::Parameter>& parameters);
    void StartStopRadar();
    void SynchronizeRadar(bool reset);
    void SendNextMessage_20ms(void);
    void SendNextMessage_100ms(void);
    void SendNextMessage(uint16_t frame_id);

    uint8_t can_channel_;
    bool radar_run_;
    bool radar_sync_;
    std::shared_ptr<CanIface> can_interface_;
    uint8_t num_available_can_channels_{0};
    rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr param_callback_handle_;
    rclcpp::TimerBase::SharedPtr data_publish_timer_20ms_;
    rclcpp::TimerBase::SharedPtr data_publish_timer_100ms_;

    std::vector<uint32_t> list_frame_id_20ms{RADAR_HYDRA3_PRIVATE_VEH_STATE_FRAME_ID};
    std::vector<uint32_t> list_frame_id_100ms{RADAR_HYDRA3_PRIVATE_TSYNC_FRAME_ID};
};
#endif