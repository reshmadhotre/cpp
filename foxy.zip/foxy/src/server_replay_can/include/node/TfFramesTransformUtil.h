#ifndef TF_FRAMES_TRANSFORM_UTIL_H
#define TF_FRAMES_TRANSFORM_UTIL_H

#include "RosParamUtil.hpp"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "rclcpp/rclcpp.hpp"
#include "tf2/LinearMath/Quaternion.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

class TfFramesTransformUtil final
{
  public:
    TfFramesTransformUtil(rclcpp::Node::SharedPtr node) noexcept;
    geometry_msgs::msg::TransformStamped GetFrameTransform() noexcept;

  private:
    void InitRosParams();
    void UpdateTranslationMatrix() noexcept;
    void UpdateRotationalMatrix() noexcept;
    double DegreesToRadians(const double& degree) noexcept;
    double GetROSParam(const std::string& param_name) const;

    geometry_msgs::msg::TransformStamped static_transformStamped_;
    std::shared_ptr<rclcpp::Node> node_;

    std::shared_ptr<RosParamUtil> ros_param_util_;
    // static const std::vector<std::string> ROS_PARAM_NAMES;

    static const double DEGREES_TO_RADIANS;
    // static const std::string SENSOR_MOUNT_POS_X_PARAM;
    // static const std::string SENSOR_MOUNT_POS_Y_PARAM;
    // static const std::string SENSOR_MOUNT_POS_Z_PARAM;
    // static const std::string SENSOR_MOUNT_YAW_PARAM;
    // static const std::string SENSOR_MOUNT_PITCH_PARAM;
    // static const std::string SENSOR_MOUNT_ROLL_PARAM;
};

#endif // TF_FRAMES_TRANSFORM_UTIL_H
