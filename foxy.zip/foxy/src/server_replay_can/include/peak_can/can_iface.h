/**
* @file            can_iface.h
* @brief           
*
* @author          giovcand
* @date            08/30/22 14:15:11
* @version         1.0
*/

/*
*	@copyright MAGNA Electronics - C O N F I D E N T I A L <br>
*	
*	This is an unpublished work of authorship, which contains
*	trade secrets, created in 2014.  Magna Electronics owns all
*	rights to this work and intends to maintain it in confidence
*	to preserve its trade secret status.  Magna Electronics
*	reserves the right, under the copyright laws of the United
*	States or those of any other country that may have jurisdiction,
*	to protect this work as an unpublished work, in the event of
*	an inadvertent or deliberate unauthorized publication.
*	Magna Electronics also reserves its rights under all copyright
*	laws to protect this work as a published work, when appropriate.
*	Those having access to this work may not copy it, use it,
*	modify it, or disclose the information contained in it without
*	the written authorization of Magna Electronics.
*/
#pragma once
#include <stdint.h>
#include <vector>


#ifndef MACRO_IS_IN_RANGE
#define MACRO_IS_IN_RANGE

#endif

class CanIface
{
public:
	struct message
	{
		uint32_t id;
		uint64_t timestamp_us;
		std::vector<uint8_t> data;
	};

	enum class CanFDCfg
	{
		SAEJ2284_4_500k_2M
	};

	CanIface();
	virtual ~CanIface();
	virtual bool init(uint8_t ch, uint32_t baud) = 0;
	virtual bool initFD(uint8_t ch, uint32_t baud, uint32_t brs = 0) = 0;
	virtual bool initFD(uint8_t ch, CanFDCfg cfg) = 0;
	virtual bool deinit(uint8_t ch) = 0;
	virtual bool read(message& data, uint8_t ch) = 0;
	virtual bool write(uint8_t ch, uint32_t id, bool extended, const std::vector<uint8_t>& data) = 0;
	virtual bool filterID(uint8_t ch, uint32_t from, uint32_t to, bool extendedID = false) = 0;
	virtual bool countAvailableChannels() = 0;
	virtual bool setListenOnly(uint8_t ch, bool val) = 0;

	uint8_t availableChannels() const;
	bool isFD(bool &v, uint8_t ch) const;

protected:
	uint8_t _availableChannels;
	std::vector<bool> _fd;

	bool setCANFDChannel(uint8_t ch);
	bool setCANChannel(uint8_t ch);
	uint8_t getSizeFromDLC(uint8_t dlc) const;
	uint8_t getDLCFromSize(uint8_t size) const;

private:
	bool _setChannelCanType(uint8_t ch, bool isFD);
};


