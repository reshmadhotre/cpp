#ifndef WHEEL_STATE_DATA_PARSER_H
#define WHEEL_STATE_DATA_PARSER_H

#include "ParserBase.h"
#include "WheelStateDefs.h"
#include <memory>

class WheelStateDataParser : public ParserBase
{
  public:
    WheelStateDataParser(const std::string& dbc_file, const uint32_t frame_id);
    void Decode(const std::vector<unsigned char>& payload) override;
    void AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const override;
    std::shared_ptr<radar_hydra3_private_whl_state_t> GetDecodedData() const;

  private:
    std::shared_ptr<radar_hydra3_private_whl_state_t> wheel_state_data_;
};
#endif