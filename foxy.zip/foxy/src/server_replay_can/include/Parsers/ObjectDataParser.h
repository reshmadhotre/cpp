#ifndef OBJECT_DATA_PARSER_H
#define OBJECT_DATA_PARSER_H

#include "ObjectDataDefs.h"
#include "ParserBase.h"
#include <memory>

class Magna2RosConverter;

class ObjectDataParser : public ParserBase
{
  public:
    ObjectDataParser(const std::string& dbc_file, const uint32_t frame_id);
    void Decode(const std::vector<unsigned char>& payload) override;
    void AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const override;
    std::shared_ptr<radar_hydra3_private_obj_data_t> GetDecodedData() const;

  private:
    int8_t GetObjIndexFromFrameID(uint32_t frame_id);
    std::string GenerateSuffixFromObjIndex(uint8_t obj_index);
    std::shared_ptr<radar_hydra3_private_obj_data_t> object_data_;
};

#endif