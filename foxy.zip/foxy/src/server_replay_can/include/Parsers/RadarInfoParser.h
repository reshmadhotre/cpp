#ifndef RADAR_INFO_PARSER_H
#define RADAR_INFO_PARSER_H

#include "ParserBase.h"
#include "RadarInfoDefs.h"
#include <memory>

class RadarInfoParser : public ParserBase
{
  public:
    RadarInfoParser(const std::string& dbc_file, const uint32_t frame_id);
    void Decode(const std::vector<unsigned char>& payload) override;
    void AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const override;
    std::shared_ptr<radar_hydra3_private_radar_info_t> GetDecodedData() const;

  private:
    std::shared_ptr<radar_hydra3_private_radar_info_t> radar_info_;
};
#endif