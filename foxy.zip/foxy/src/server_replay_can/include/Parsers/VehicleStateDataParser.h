#ifndef VEHICLE_STATE_DATA_PARSER_H
#define VEHICLE_STATE_DATA_PARSER_H

#include "ParserBase.h"
#include "VehicleStateDefs.h"
#include "memory"

class VehicleStateDataParser : public ParserBase
{
  public:
    VehicleStateDataParser(const std::string& dbc_file, const uint32_t frame_id);
    void Decode(const std::vector<unsigned char>& payload) override;
    void AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const override;
    std::shared_ptr<radar_hydra3_private_veh_state_t> GetDecodedData() const;
    void SetValue(std::string signal_name, double value) override;
    void Update(void) override;

  private:
    std::shared_ptr<radar_hydra3_private_veh_state_t> veh_state_data_;

    void UpdateMC(void);
    void UpdateCRC(size_t cmac_size);
    void UpdateMAC(size_t cmac_size);

    const std::vector<uint8_t> veh_state_data_id{0x40}; // magic_number!
};
#endif