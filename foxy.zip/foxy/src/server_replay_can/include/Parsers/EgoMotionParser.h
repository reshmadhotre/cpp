#ifndef EGO_MOTION_PARSER_H
#define EGO_MOTION_PARSER_H

#include "EgoMotionDefs.h"
#include "ParserBase.h"
#include "memory"

class Magna2RosConverter;

class EgoMotionParser : public ParserBase
{
  public:
    EgoMotionParser(const std::string& dbc_file, const uint32_t frame_id);
    void Decode(const std::vector<unsigned char>& payload) override;
    std::shared_ptr<radar_hydra3_private_egomotion_t> GetDecodedData() const;
    void AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const override;

  private:
    std::shared_ptr<radar_hydra3_private_egomotion_t> ego_motion_data_;
};
#endif