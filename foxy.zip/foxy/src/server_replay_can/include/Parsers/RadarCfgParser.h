#ifndef RADAR_CFG_PARSER_H
#define RADAR_CFG_PARSER_H

#include "ParserBase.h"
#include "RadarCfgDefs.h"
#include <memory>

class Magna2RosConverter;

class RadarCfgParser : public ParserBase
{
  public:
    RadarCfgParser(const std::string& dbc_file, const uint32_t frame_id);
    void Decode(const std::vector<unsigned char>& payload) override;
    void AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const override;
    std::shared_ptr<radar_hydra3_private_radar_cfg_t> GetDecodedData() const;

  private:
    bool IfSignalGroupHasSignalName(const Vector::DBC::Message& dbc_message, const std::string& signal_name);
    float GetDefaultRadarRoll(uint8_t radar_role_config);
    std::shared_ptr<radar_hydra3_private_radar_cfg_t> radar_cfg_;

    const static float DEFAULT_RADAR_ORIENTATION_ROLL_DEG;
    const static float RIGHT_RADAR_ORIENTATION_ROLL_DEG;
};
#endif