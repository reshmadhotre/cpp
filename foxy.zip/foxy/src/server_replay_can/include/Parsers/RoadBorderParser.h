#ifndef ROAD_BORDER_PARSER_H
#define ROAD_BORDER_PARSER_H

#include "ParserBase.h"
#include "RoadBorderDefs.h"
#include "memory"

class Magna2RosConverter;

class RoadBorderParser : public ParserBase
{
  public:
    RoadBorderParser(const std::string& dbc_file, const uint32_t frame_id);
    void Decode(const std::vector<unsigned char>& payload) override;
    std::shared_ptr<radar_hydra3_private_road_border_t> GetDecodedData() const;
    void AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const override;

  private:
    std::shared_ptr<radar_hydra3_private_road_border_t> road_border_data_;
};
#endif