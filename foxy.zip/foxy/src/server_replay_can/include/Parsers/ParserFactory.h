#ifndef PARSER_FACTORY_H
#define PARSER_FACTORY_H

#include "ParserBase.h"
#include <memory>

class ParserFactory
{
  public:
    ParserFactory(const std::string& dbc_file);
    std::shared_ptr<ParserBase> GetParser(const uint32_t frame_id);

    const uint8_t CODE_RADAR_START{1};
    const uint8_t CODE_RADAR_STOP{2};

  private:
    std::map<uint32_t, std::shared_ptr<ParserBase>> frameID_parser_map_;
    const static uint32_t OBJ_DATA_FRAME_ID_START;
    const static uint32_t OBJ_DATA_FRAME_ID_END;
};
#endif