#ifndef TSYNC_PARSER_H
#define TSYNC_PARSER_H

#include "ParserBase.h"
#include "TSyncDefs.h"
#include <memory>

class Magna2RosConverter;

class TSyncParser : public ParserBase
{
  public:
    TSyncParser(const std::string& dbc_file, const uint32_t frame_id);
    void Decode(const std::vector<unsigned char>& payload) override;
    void AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const override;
    std::shared_ptr<radar_hydra3_private_tsync_t> GetDecodedData() const;
    void SetValue(std::string signal_name, double value) override;
    void Update(void) override;

  private:
    std::shared_ptr<radar_hydra3_private_tsync_t> tsync_;

    void UpdateSC(void);
    void UpdateCRC(void);

    bool toggle_mux_{true};
    std::chrono::_V2::system_clock::time_point time_sync_offset_;
    std::vector<uint8_t> encoded_data_mux_1_;  // in multiplex case, we need 2 encoded data
    std::vector<uint8_t> encoded_data_mux_2_;  // in multiplex case, we need 2 encoded data

};
#endif