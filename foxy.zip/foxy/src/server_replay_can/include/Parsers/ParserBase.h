#ifndef PARSER_BASE_H
#define PARSER_BASE_H

#include "DBC.h"
#include <fstream>
#include <openssl/cmac.h>
#include <chrono>



#define CRC8_START_VALUE 0xFFU
#define CRC8_XOR 0xFFU
#define CRC8_POLYNOMIAL 0x1DU
#define CRC8H2F_POLYNOMIAL 0x2FU



class Magna2RosConverter;

class ParserBase
{
  public:
    ParserBase(const std::string& dbc_file, const uint32_t frame_id);
    void SetNetwork(const std::string& dbc_file);
    uint32_t GetFrameID() const;
    static bool IsNetworkInitialized();
    virtual void Decode(const std::vector<unsigned char>& payload) = 0;
    virtual void AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const = 0;
    virtual void SetValue(std::string signal_name, double value);
    virtual void Update(void){};

    uint8_t CalculateCRC8(const uint8_t *message, uint32_t nBytes, uint8_t start, uint8_t poly);
    uint8_t Crc_CalculateCRC8(const uint8_t *Crc_DataPtr, uint32_t Crc_Length, uint8_t Crc_StartValue8, bool Crc_IsFirstCall);
    uint8_t Crc_CalculateCRC8H2F(const uint8_t *Crc_DataPtr, uint32_t Crc_Length, uint8_t Crc_StartValue8, bool Crc_IsFirstCall);
    void CalculateMAC(uint8_t *cmac, size_t cmac_size, uint16_t magic_number);

    std::vector<uint8_t> encoded_data_;

  protected:
    Vector::DBC::Message GetDBCMessage();
    double DecodeMessage(const Vector::DBC::Message& dbc_msg, const std::string& signal_name,
                         std::vector<uint8_t>& data);
    void EncodeMessage(const Vector::DBC::Message& dbc_msg, const std::string& signal_name,
                         std::vector<uint8_t>& data, double physical_value);
    
  private:
    uint32_t frame_id_;
    static Vector::DBC::Network dbc_network_;
};

#endif