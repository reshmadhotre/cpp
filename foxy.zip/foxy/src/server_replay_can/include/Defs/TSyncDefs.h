#ifndef RADAR_HYDRA3_PRIVATE_TSYNC_DEFS_H
#define RADAR_HYDRA3_PRIVATE_TSYNC_DEFS_H

#include <iostream>
#include <stdint.h>

/* Signal choices. */
#define RADAR_HYDRA3_PRIVATE_TSYNC_CAN_T_SYN_TYPE_CAN_T_SYN_TYPE_SYNC_NO_CRC_CHOICE (16u)
#define RADAR_HYDRA3_PRIVATE_TSYNC_CAN_T_SYN_TYPE_CAN_T_SYN_TYPE_FUP_NO_CRC_CHOICE (24u)
#define RADAR_HYDRA3_PRIVATE_TSYNC_CAN_T_SYN_TYPE_CAN_T_SYN_TYPE_SYNC_CRC_CHOICE (32u)
#define RADAR_HYDRA3_PRIVATE_TSYNC_CAN_T_SYN_TYPE_CAN_T_SYN_TYPE_FUP_CRC_CHOICE (40u)
#define RADAR_HYDRA3_PRIVATE_TSYNC_CAN_T_SYN_TYPE_CAN_T_SYN_TYPE_OFS_CRC_CANFD_CHOICE (100u)

/* Frame ids. */
#define RADAR_HYDRA3_PRIVATE_TSYNC_FRAME_ID (0x100u)

/* Frame lengths in bytes. */
#define RADAR_HYDRA3_PRIVATE_TSYNC_LENGTH (16u)



/**
 * Signals in message TSYNC.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */

struct radar_hydra3_private_tsync_t
{
    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t can_t_syn_type;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t can_t_syn_crc;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t can_t_syn_d;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t can_t_syn_sc;

    /**
     * Range: 0..31 (0..31 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t can_t_syn_rsvrd0;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t can_t_syn_usb0;

    /**
     * Range: 0..1 (0..1 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t can_t_syn_fup_sgw;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t can_t_syn_ovs;

    /**
     * Range: 0..4294967295 (0..4294967295 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint32_t can_t_syn_sync_time_n_sec;

    /**
     * Range: 0..4294967295 (0..4294967295 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint32_t can_t_syn_sync_time_sec;

    friend std::ostream& operator<<(std::ostream& os, const radar_hydra3_private_tsync_t& tsync)
    {
        return os << "can_t_syn_type : " << unsigned(tsync.can_t_syn_type) << std::endl
                  << "can_t_syn_crc : " << unsigned(tsync.can_t_syn_crc) << std::endl
                  << "can_t_syn_d : " << unsigned(tsync.can_t_syn_d) << std::endl
                  << "can_t_syn_sc : " << unsigned(tsync.can_t_syn_sc) << std::endl
                  << "can_t_syn_rsvrd0 : " << unsigned(tsync.can_t_syn_rsvrd0) << std::endl
                  << "can_t_syn_usb0 : " << unsigned(tsync.can_t_syn_usb0) << std::endl
                  << "can_t_syn_fup_sgw : " << unsigned(tsync.can_t_syn_fup_sgw) << std::endl
                  << "can_t_syn_ovs : " << unsigned(tsync.can_t_syn_ovs) << std::endl
                  << "can_t_syn_sync_time_n_sec : " << tsync.can_t_syn_sync_time_n_sec << std::endl
                  << "can_t_syn_sync_time_sec : " << tsync.can_t_syn_sync_time_sec << std::endl;
    }
};

#endif