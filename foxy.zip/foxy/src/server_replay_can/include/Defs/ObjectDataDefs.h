#ifndef RADAR_HYDRA3_PRIVATE_OBJECT_DATA_DEFS_H
#define RADAR_HYDRA3_PRIVATE_OBJECT_DATA_DEFS_H

#include <iostream>
#include <stdint.h>

#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_FU_SA_LEVEL_OBJECT_FU_SA_LEVEL_FUSA_QM_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_FU_SA_LEVEL_OBJECT_FU_SA_LEVEL_FUSA_ASIL_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_FU_SA_LEVEL_OBJECT_FU_SA_LEVEL_FUSA_SNA_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_0_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_0_30_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_30_40_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_40_50_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_50_60_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_60_70_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_70_80_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_80_85_CHOICE (7u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_85_90_CHOICE (8u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_90_95_CHOICE (9u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_95_98_CHOICE (10u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_98_99_CHOICE (11u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_99_100_CHOICE (12u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CONFIDENCE_OBJECT_CONFIDENCE_OBJ_CONF_PROB_100_CHOICE (13u)

#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_MOTION_ST_OBJECT_MOTION_ST_OBJ_MTN_UNKNOWN_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_MOTION_ST_OBJECT_MOTION_ST_OBJ_MTN_MOVING_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_MOTION_ST_OBJECT_MOTION_ST_OBJ_MTN_ONCOMING_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_MOTION_ST_OBJECT_MOTION_ST_OBJ_MTN_CROSSING_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_MOTION_ST_OBJECT_MOTION_ST_OBJ_MTN_STOPPED_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_MOTION_ST_OBJECT_MOTION_ST_OBJ_MTN_STOPPED_ONCOMING_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_MOTION_ST_OBJECT_MOTION_ST_OBJ_MTN_STOPPED_CROSSING_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_MOTION_ST_OBJECT_MOTION_ST_OBJ_MTN_STATIONARY_CHOICE (7u)

#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_REF_POINT_OBJECT_REF_POINT_OBJ_REF_PT_UNKNOWN_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_REF_POINT_OBJECT_REF_POINT_OBJ_REF_PT_REARLEFT_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_REF_POINT_OBJECT_REF_POINT_OBJ_REF_PT_REARMID_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_REF_POINT_OBJECT_REF_POINT_OBJ_REF_PT_REARRIGHT_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_REF_POINT_OBJECT_REF_POINT_OBJ_REF_PT_FRONTLEFT_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_REF_POINT_OBJECT_REF_POINT_OBJ_REF_PT_FRONTMID_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_REF_POINT_OBJECT_REF_POINT_OBJ_REF_PT_FRONTRIGHT_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_REF_POINT_OBJECT_REF_POINT_OBJ_REF_PT_SIDELEFT_CHOICE (7u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_REF_POINT_OBJECT_REF_POINT_OBJ_REF_PT_SIDERIGHT_CHOICE (8u)

#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_WIDTH_ST_OBJECT_WIDTH_ST_NOT_OBSCURED_DEFAULT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_WIDTH_ST_OBJECT_WIDTH_ST_PARTIALLY_OBSCURED_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_WIDTH_ST_OBJECT_WIDTH_ST_COMPLETELY_OBSCURED_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_WIDTH_ST_OBJECT_WIDTH_ST_LENGTH_WIDTH_NOT_AVAILABLE_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_LENGTH_ST_OBJECT_LENGTH_ST_NOT_OBSCURED_DEFAULT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_LENGTH_ST_OBJECT_LENGTH_ST_PARTIALLY_OBSCURED_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_LENGTH_ST_OBJECT_LENGTH_ST_COMPLETELY_OBSCURED_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_LENGTH_ST_OBJECT_LENGTH_ST_LENGTH_WIDTH_NOT_AVAILABLE_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_UNKNOWN_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_CAR_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_TRUCK_SMALL_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_TRUCK_MEDIUM_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_TRUCK_BIG_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_MOTORBIKE_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_BICYCLE_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_BICYCLE_GROUP_CHOICE (7u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_PEDESTRIAN_CHOICE (8u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_PEDESTRIAN_GROUP_CHOICE (9u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_UNDERDRIVABLE_CHOICE (10u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_OVERDRIVABLE_CHOICE (11u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_OBSTACLE_SMALL_CHOICE (12u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_OBSTACLE_MEDIUM_CHOICE (13u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_OBSTACLE_BIG_CHOICE (14u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_OBJECT_CLASS_OBJ_CLASSN_ANIMAL_CHOICE (15u)

#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_0_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_0_30_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_30_40_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_40_50_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_50_60_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_60_70_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_70_80_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_80_85_CHOICE (7u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_85_90_CHOICE (8u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_90_95_CHOICE (9u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_95_98_CHOICE (10u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_98_99_CHOICE (11u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_99_100_CHOICE    \
    (12u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_100_CHOICE (13u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_UNKNOWN_CHOICE   \
    (14u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_CLASS_CONFIDENCE_OBJECT_CLASS_CONFIDENCE_OBJ_CLASSN_CONF_SNA_CHOICE (15u)

#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVABLE_OBJECT_OVER_UNDER_DRIVABLE_OBJ_IS_OBSTACLE_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVABLE_OBJECT_OVER_UNDER_DRIVABLE_OBJ_UNDERDRIVABLE_CHOICE   \
    (1u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVABLE_OBJECT_OVER_UNDER_DRIVABLE_OBJ_OVERDRIVABLE_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVABLE_OBJECT_OVER_UNDER_DRIVABLE_OBJ_UNDER_AND_OVERDRIVABLE_CHOICE \
    (3u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVABLE_OBJECT_OVER_UNDER_DRIVABLE_OBJ_UNDER_OVERDRIVABLE_UNKNOWN_CHOICE \
    (7u)

#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_0_CHOICE \
    (0u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_0_30_CHOICE \
    (1u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_30_40_CHOICE \
    (2u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_40_50_CHOICE \
    (3u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_50_60_CHOICE \
    (4u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_60_70_CHOICE \
    (5u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_70_80_CHOICE \
    (6u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_80_85_CHOICE \
    (7u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_85_90_CHOICE \
    (8u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_90_95_CHOICE \
    (9u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_95_98_CHOICE \
    (10u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_98_99_CHOICE \
    (11u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_99_100_CHOICE \
    (12u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_100_CHOICE \
    (13u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_UNKNOWN_CHOICE \
    (14u)
#define RADAR_HYDRA3_PRIVATE_OBJ_DATA_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OBJECT_OVER_UNDER_DRIVEABLE_CONF_OUD_CONF_SNA_CHOICE \
    (15u)

/**
 * Signals in message OBJ_DATA_XX.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */
struct radar_hydra3_private_obj_data_t
{
    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t crc_obj_data;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t mc_obj_data;

    /**
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t object_id;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t object_fu_sa_level;

    /**
     * Rolling buffer for measured flags, e.g.:
     * 00000001: New object
     * 00000101: object measured in this scan and 2 scans before, but not on the last scan (thus predicted in the last
     * scan) 11111111: object always measured
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t object_meas_status;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t object_confidence;

    /**
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t object_age;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t object_motion_st;

    /**
     * Range: 0..8191 (0..409.55 m)
     * Scale: 0.05
     * Offset: 0
     */
    double object_distance_x;

    /**
     * Range: 0..63 (0..7.875 m)
     * Scale: 0.125
     * Offset: 0
     */
    double object_distance_std_dev_x;

    /**
     * Range: 0..8191 (-204.775..204.775 m)
     * Scale: 0.05
     * Offset: -204.775
     */
    double object_distance_y;

    /**
     * Range: 0..63 (0..7.875 m)
     * Scale: 0.125
     * Offset: 0
     */
    double object_distance_std_dev_y;

    /**
     * Range: 0..60 (-90..90 degrees)
     * Scale: 3
     * Offset: -90
     */
    int8_t object_distance_cov_xy;

    /**
     * Range: 0..4095 (-127.96875..127.96875 m_per_s)
     * Scale: 0.0625
     * Offset: -127.96875
     */
    double object_rel_velocity_x;

    /**
     * Range: 0..63 (0..3.9375 m_per_s)
     * Scale: 0.0625
     * Offset: 0
     */
    double object_rel_velocity_std_dev_x;

    /**
     * Range: 0..4095 (-127.96875..127.96875 m_per_s)
     * Scale: 0.0625
     * Offset: -127.96875
     */
    double object_rel_velocity_y;

    /**
     * Range: 0..63 (0..3.9375 m_per_s)
     * Scale: 0.0625
     * Offset: 0
     */
    double object_rel_velocity_std_dev_y;

    /**
     * Range: 0..63 (-90..99 degrees)
     * Scale: 3
     * Offset: -90
     */
    int8_t object_rel_velocity_cov_xy;

    /**
     * Range: 0..2047 (-31.984375..31.984375 m_per_s²)
     * Scale: 0.03125
     * Offset: -31.984375
     */
    double object_rel_acceleration_x;

    /**
     * Range: 0..63 (0..3.9375 m_per_s²)
     * Scale: 0.0625
     * Offset: 0
     */
    double object_rel_acceleration_std_dev_x;

    /**
     * Range: 0..2047 (-31.984375..31.984375 m_per_s²)
     * Scale: 0.03125
     * Offset: -31.984375
     */
    double object_rel_acceleration_y;

    /**
     * Range: 0..63 (0..3.9375 m_per_s²)
     * Scale: 0.0625
     * Offset: 0
     */
    double object_rel_acceleration_std_dev_y;

    /**
     * Range: 0..63 (-90..99 degrees)
     * Scale: 3
     * Offset: -90
     */
    int8_t object_rel_acceleration_cov_xy;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t object_ref_point;

    /**
     * Range: 0..255.0000000000001217536343062 (-3.14159..3.14158999999999 rad)
     * Scale: 0.0246399215686274
     * Offset: -3.14159
     */
    double object_yaw_angle;

    /**
     * Range: 0..63 (0..0.4921875 rad)
     * Scale: 0.0078125
     * Offset: 0
     */
    double object_yaw_angle_std_dev;

    /**
     * Range: 0..254.9999999999999188309790231 (-0.7854..0.785396326794895 rad_per_s)
     * Scale: 0.0061599855952741
     * Offset: -0.7854
     */
    double object_yaw_rate;

    /**
     * Range: 0..255 (0..0.498046875 rad_per_s)
     * Scale: 0.001953125
     * Offset: 0
     */
    double object_yaw_rate_std_dev;

    /**
     * Range: 0..255 (0..31.875 m)
     * Scale: 0.125
     * Offset: 0
     */
    double object_width;

    /**
     * Range: 0..63 (0..7.875 m)
     * Scale: 0.125
     * Offset: 0
     */
    double object_width_std_dev;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t object_width_st;

    /**
     * Range: 0..255 (0..31.875 m)
     * Scale: 0.125
     * Offset: 0
     */
    double object_length;

    /**
     * Range: 0..63 (0..7.875 m)
     * Scale: 0.125
     * Offset: 0
     */
    double object_length_std_dev;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t object_length_st;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t object_class;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t object_class_confidence;

    /**
     * Range: 0..63 (-20..43 dBm2)
     * Scale: 1
     * Offset: -20
     */
    double object_rcs;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t object_over_under_drivable;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t object_over_under_driveable_conf;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t scan_id;

    /**
     * Range: 0..16777215 (0..16777215 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint32_t mac_object_data;

    friend std::ostream& operator<<(std::ostream& os, const radar_hydra3_private_obj_data_t& radar_obj_data)
    {
        return os << "crc_obj_data : " << radar_obj_data.crc_obj_data << std::endl
                  << "mc_obj_data : " << radar_obj_data.mc_obj_data << std::endl
                  << "object_id : " << radar_obj_data.object_id << std::endl
                  << "object_fu_sa_level : " << radar_obj_data.object_fu_sa_level << std::endl
                  << "object_meas_status : " << radar_obj_data.object_meas_status << std::endl
                  << "object_confidence : " << radar_obj_data.object_confidence << std::endl
                  << "object_age : " << radar_obj_data.object_age << std::endl
                  << "object_motion_st : " << radar_obj_data.object_motion_st << std::endl
                  << "object_distance_x : " << radar_obj_data.object_distance_x << std::endl
                  << "object_distance_std_dev_x : " << radar_obj_data.object_distance_std_dev_x << std::endl
                  << "object_distance_y : " << radar_obj_data.object_distance_y << std::endl
                  << "object_distance_std_dev_y : " << radar_obj_data.object_distance_std_dev_y << std::endl
                  << "object_distance_cov_xy : " << radar_obj_data.object_distance_cov_xy << std::endl
                  << "object_rel_velocity_x : " << radar_obj_data.object_rel_velocity_x << std::endl
                  << "object_rel_velocity_std_dev_x : " << radar_obj_data.object_rel_velocity_std_dev_x << std::endl
                  << "object_rel_velocity_y : " << radar_obj_data.object_rel_velocity_y << std::endl
                  << "object_rel_velocity_std_dev_y : " << radar_obj_data.object_rel_velocity_std_dev_y << std::endl
                  << "object_rel_velocity_cov_xy : " << radar_obj_data.object_rel_velocity_cov_xy << std::endl
                  << "object_rel_acceleration_x : " << radar_obj_data.object_rel_acceleration_x << std::endl
                  << "object_rel_acceleration_std_dev_x : " << radar_obj_data.object_rel_acceleration_std_dev_x
                  << std::endl
                  << "object_rel_acceleration_y : " << radar_obj_data.object_rel_acceleration_y << std::endl
                  << "object_rel_acceleration_std_dev_y : " << radar_obj_data.object_rel_acceleration_std_dev_y
                  << std::endl
                  << "object_rel_acceleration_cov_xy : " << radar_obj_data.object_rel_acceleration_cov_xy << std::endl
                  << "object_ref_point : " << radar_obj_data.object_ref_point << std::endl
                  << "object_yaw_angle : " << radar_obj_data.object_yaw_angle << std::endl
                  << "object_yaw_angle_std_dev : " << radar_obj_data.object_yaw_angle_std_dev << std::endl
                  << "object_yaw_rate : " << radar_obj_data.object_yaw_rate << std::endl
                  << "object_yaw_rate_std_dev : " << radar_obj_data.object_yaw_rate_std_dev << std::endl
                  << "object_width : " << radar_obj_data.object_width << std::endl
                  << "object_width_std_dev : " << radar_obj_data.object_width_std_dev << std::endl
                  << "object_width_st : " << radar_obj_data.object_width_st << std::endl
                  << "object_length : " << radar_obj_data.object_length << std::endl
                  << "object_length_std_dev : " << radar_obj_data.object_length_std_dev << std::endl
                  << "object_length_st : " << radar_obj_data.object_length_st << std::endl
                  << "object_class : " << radar_obj_data.object_class << std::endl
                  << "object_class_confidence : " << radar_obj_data.object_class_confidence << std::endl
                  << "object_rcs : " << radar_obj_data.object_rcs << std::endl
                  << "object_over_under_drivable : " << radar_obj_data.object_over_under_drivable << std::endl
                  << "object_over_under_driveable_conf : " << radar_obj_data.object_over_under_driveable_conf
                  << std::endl
                  << "scan_id : " << radar_obj_data.scan_id << std::endl
                  << "mac_object_data : " << radar_obj_data.mac_object_data << std::endl;
    }
};

#endif