#ifndef RADAR_HYDRA3_PRIVATE_ROAD_BORDER_DEFS_H
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_DEFS_H

#include <iostream>
#include <stdint.h>

#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_ST_LT_ROAD_BORDER_ST_LT_ROADBORDER_NOT_AVAILABLE_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_ST_LT_ROAD_BORDER_ST_LT_ROADBORDER_AVAILABLE_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_ST_LT_ROAD_BORDER_ST_LT_ROADBORDER_SNA_CHOICE (7u)

#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_0_CHOICE \
    (0u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_0_30_CHOICE \
    (1u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_30_40_CHOICE \
    (2u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_40_50_CHOICE \
    (3u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_50_60_CHOICE \
    (4u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_60_70_CHOICE \
    (5u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_70_80_CHOICE \
    (6u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_80_85_CHOICE \
    (7u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_85_90_CHOICE \
    (8u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_90_95_CHOICE \
    (9u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_95_98_CHOICE \
    (10u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_98_99_CHOICE \
    (11u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_99_100_CHOICE \
    (12u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_100_CHOICE \
    (13u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_LT_ROAD_BORDER_CONFIDENCE_LT_ROADBORDER_CONF_PROB_SNA_CHOICE \
    (15u)

#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_ST_RT_ROAD_BORDER_ST_RT_ROADBORDER_NOT_AVAILABLE_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_ST_RT_ROAD_BORDER_ST_RT_ROADBORDER_AVAILABLE_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_ST_RT_ROAD_BORDER_ST_RT_ROADBORDER_SNA_CHOICE (7u)

#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_0_CHOICE \
    (0u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_0_30_CHOICE \
    (1u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_30_40_CHOICE \
    (2u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_40_50_CHOICE \
    (3u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_50_60_CHOICE \
    (4u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_60_70_CHOICE \
    (5u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_70_80_CHOICE \
    (6u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_80_85_CHOICE \
    (7u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_85_90_CHOICE \
    (8u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_90_95_CHOICE \
    (9u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_95_98_CHOICE \
    (10u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_98_99_CHOICE \
    (11u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_99_100_CHOICE \
    (12u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_100_CHOICE \
    (13u)
#define RADAR_HYDRA3_PRIVATE_ROAD_BORDER_ROAD_BORDER_CONFIDENCE_RT_ROAD_BORDER_CONFIDENCE_RT_ROADBORDER_CONF_PROB_SNA_CHOICE \
    (15u)

/**
 * Signals in message ROAD_BORDER.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */

struct radar_hydra3_private_road_border_t
{
    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t crc_road_border;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t mc_road_border;

    /**
     * Range: 0..65535 (0..65535 s)
     * Scale: 1
     * Offset: 0
     */
    uint16_t road_border_timestamp_sec;

    /**
     * Range: 0..4095 (0..1000732005 No_Unit)
     * Scale: 244379
     * Offset: 0
     */
    uint16_t road_border_timestamp_n_sec;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t road_border_st_lt;

    /**
     * Range: 256.5..766.5 (-12.75..12.75 m)
     * Scale: 0.05
     * Offset: -25.575
     */
    double road_border_offset_y_lt;

    /**
     * Range: 0..4094.999999999999478608406431 (-0.7853982..0.785398126794895 rad)
     * Scale: 0.00038358884659216
     * Offset: -0.7853982
     */
    uint16_t road_border_angle_lt;

    /**
     * Range: 0..16777215 (-0.52..16.257215 x_over_meter)
     * Scale: 1e-06
     * Offset: -0.52
     */
    double road_border_initial_curvature_lt;

    /**
     * Range: 0..16777215 (-0.0419430375..0.0419430375 x_over_m2)
     * Scale: 5e-09
     * Offset: -0.0419430375
     */
    double road_border_initial_curvature_grad_lt;

    /**
     * Range: 0..16777215 (-0.0419430375..0.0419430375 x_over_m2)
     * Scale: 5e-09
     * Offset: -0.0419430375
     */
    double road_border_second_curvature_grad_lt;

    /**
     * Range: 0..4095 (0..1023.75 m)
     * Scale: 0.25
     * Offset: 0
     */
    double road_border_transition_point_lt;

    /**
     * Range: 0..4095 (0..1023.75 m)
     * Scale: 0.25
     * Offset: 0
     */
    double road_border_max_range_lt;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t road_border_confidence_lt;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t road_border_st_rt;

    /**
     * Range: 256.5..766.5 (-12.75..12.75 m)
     * Scale: 0.05
     * Offset: -25.575
     */
    double road_border_offset_y_rt;

    /**
     * Range: 0..4094.999999999999478608406431 (-0.7853982..0.785398126794895 rad)
     * Scale: 0.00038358884659216
     * Offset: -0.7853982
     */
    double road_border_angle_rt;

    /**
     * Range: 0..16777215 (-0.52..16.257215 x_over_meter)
     * Scale: 1e-06
     * Offset: -0.52
     */
    double road_border_initial_curvature_rt;

    /**
     * Range: 0..16777215 (-0.0419430375..0.0419430375 x_over_m2)
     * Scale: 5e-09
     * Offset: -0.0419430375
     */
    double road_border_initial_curvature_grad_rt;

    /**
     * Range: 0..16777215 (-0.0419430375..0.0419430375 x_over_m2)
     * Scale: 5e-09
     * Offset: -0.0419430375
     */
    double road_border_second_curvature_grad_rt;

    /**
     * Range: 0..4095 (0..1023.75 m)
     * Scale: 0.25
     * Offset: 0
     */
    double road_border_transition_point_rt;

    /**
     * Range: 0..4095 (0..1023.75 m)
     * Scale: 0.25
     * Offset: 0
     */
    double road_border_max_range_rt;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t road_border_confidence_rt;

    /**
     * Range: 127.5..383.25 (0..25.575 m)
     * Scale: 0.1
     * Offset: -12.75
     */
    double road_border_offset_x_lt;

    /**
     * Range: 127.5..383.25 (0..25.575 m)
     * Scale: 0.1
     * Offset: -12.75
     */
    double road_border_offset_x_rt;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t road_border_scan_id;

    /**
     * Range: 0..16777215 (0..16777215 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint32_t mac_road_border;

    friend std::ostream& operator<<(std::ostream& os, const radar_hydra3_private_road_border_t& road_border)
    {
        return os << "crc_road_border : " << road_border.crc_road_border << std::endl
                  << "mc_road_border : " << road_border.mc_road_border << std::endl
                  << "road_border_timestamp_sec : " << road_border.road_border_timestamp_sec << std::endl
                  << "road_border_timestamp_n_sec : " << road_border.road_border_timestamp_n_sec << std::endl
                  << "road_border_st_lt : " << road_border.road_border_st_lt << std::endl
                  << "road_border_offset_y_lt : " << road_border.road_border_offset_y_lt << std::endl
                  << "road_border_angle_lt : " << road_border.road_border_angle_lt << std::endl
                  << "road_border_initial_curvature_lt : " << road_border.road_border_initial_curvature_lt << std::endl
                  << "road_border_initial_curvature_grad_lt : " << road_border.road_border_initial_curvature_grad_lt
                  << std::endl
                  << "road_border_second_curvature_grad_lt : " << road_border.road_border_second_curvature_grad_lt
                  << std::endl
                  << "road_border_transition_point_lt : " << road_border.road_border_transition_point_lt << std::endl
                  << "road_border_max_range_lt : " << road_border.road_border_max_range_lt << std::endl
                  << "road_border_confidence_lt : " << road_border.road_border_confidence_lt << std::endl
                  << "road_border_st_rt : " << road_border.road_border_st_rt << std::endl
                  << "road_border_offset_y_rt : " << road_border.road_border_offset_y_rt << std::endl
                  << "road_border_angle_rt : " << road_border.road_border_angle_rt << std::endl
                  << "road_border_initial_curvature_rt : " << road_border.road_border_initial_curvature_rt << std::endl
                  << "road_border_initial_curvature_grad_rt : " << road_border.road_border_initial_curvature_grad_rt
                  << std::endl
                  << "road_border_second_curvature_grad_rt : " << road_border.road_border_second_curvature_grad_rt
                  << std::endl
                  << "road_border_transition_point_rt : " << road_border.road_border_transition_point_rt << std::endl
                  << "road_border_max_range_rt : " << road_border.road_border_max_range_rt << std::endl
                  << "road_border_confidence_rt : " << road_border.road_border_confidence_rt << std::endl
                  << "road_border_offset_x_lt : " << road_border.road_border_offset_x_lt << std::endl
                  << "road_border_offset_x_rt : " << road_border.road_border_offset_x_rt << std::endl
                  << "road_border_scan_id : " << road_border.road_border_scan_id << std::endl
                  << "mac_road_border : " << road_border.mac_road_border << std::endl;
    }
};

#endif