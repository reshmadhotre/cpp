#ifndef RADAR_HYDRA3_PRIVATE_RADAR_INFO_DEFS_H
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_DEFS_H

#include <iostream>
#include <stdint.h>

#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_MRR_TIMESYNC_STATUS_MRR_TIMESYNC_STATUS_TSYNC_NOT_SYNCED_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_MRR_TIMESYNC_STATUS_MRR_TIMESYNC_STATUS_TSYNC_SYNCED_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_MRR_TIMESYNC_STATUS_MRR_TIMESYNC_STATUS_TSYNC_SNA_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_STATUS_BLOCKAGE_STATUS_BLKG_NO_DAMPING_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_STATUS_BLOCKAGE_STATUS_BLKG_INC_DAMPING_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_STATUS_BLOCKAGE_STATUS_BLKG_FULL_DAMPING_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_STATUS_BLOCKAGE_STATUS_BLKG_DEC_DAMPING_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_STATUS_BLOCKAGE_STATUS_BLKG_UNKNOWN_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_STATUS_BLOCKAGE_STATUS_BLKG_SNA_CHOICE (7u)

#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_0_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_0_30_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_30_40_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_40_50_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_50_60_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_60_70_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_70_80_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_80_85_CHOICE (7u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_85_90_CHOICE (8u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_90_95_CHOICE (9u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_95_98_CHOICE (10u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_98_99_CHOICE (11u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_99_100_CHOICE (12u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_100_CHOICE (13u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_BLOCKAGE_PROB_BLOCKAGE_PROB_BLKG_PROB_UNKNOWN_CHOICE (14u)

#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PRESENCE_TUNNEL_PRESENCE_TUNNEL_PRES_NO_TUNNEL_DETECTED_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PRESENCE_TUNNEL_PRESENCE_TUNNEL_PRES_TUNNEL_DETECTED_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PRESENCE_TUNNEL_PRESENCE_TUNNEL_PRES_SNA_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_0_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_0_30_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_30_40_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_40_50_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_50_60_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_60_70_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_70_80_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_80_85_CHOICE (7u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_85_90_CHOICE (8u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_90_95_CHOICE (9u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_95_98_CHOICE (10u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_98_99_CHOICE (11u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_99_100_CHOICE (12u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_100_CHOICE (13u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_UNKNOWN_CHOICE (14u)
#define RADAR_HYDRA3_PRIVATE_RADAR_INFO_TUNNEL_PROB_TUNNEL_PROB_TUNNEL_PROB_SNA_CHOICE (15u)

/**
 * Signals in message RADAR_INFO.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */
struct radar_hydra3_private_radar_info_t
{
    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t crc_radar_info;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t mc_radar_info;

    /**
     * Range: 0..4294967295 (0..4294967295 s)
     * Scale: 1
     * Offset: 0
     */
    uint32_t mrr_timestamp_sec;

    /**
     * Range: 0..4294967295 (0..4294967295 ns)
     * Scale: 1
     * Offset: 0
     */
    uint32_t mrr_timestamp_n_sec;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t mrr_timesync_status;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blockage_status;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blockage_prob;

    /**
     * Range: 0..255 (0..255 m)
     * Scale: 1
     * Offset: 0
     */
    uint8_t safety_distance;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t tunnel_presence;

    /**
     * Range: 0..255 (0..255 m)
     * Scale: 1
     * Offset: 0
     */
    uint8_t tunnel_distance;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t tunnel_prob;

    /**
     * Range: 0..65535 (0..65535 s)
     * Scale: 1
     * Offset: 0
     */
    uint16_t object_timestamp_sec;

    /**
     * Range: 0..4294967295 (0..4294967295 ns)
     * Scale: 1
     * Offset: 0
     */
    uint32_t object_timestamp_n_sec;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t radar_scan_id;

    /**
     * Range: 0..63 (0..63 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t number_of_objects;

    /**
     * Range: 0..16777215 (0..16777215 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint32_t mac_radar_info;

    friend std::ostream& operator<<(std::ostream& os, const radar_hydra3_private_radar_info_t& radar_info)
    {
        return os << "crc_radar_info : " << unsigned(radar_info.crc_radar_info) << std::endl
                  << "mc_radar_info : " << unsigned(radar_info.mc_radar_info) << std::endl
                  << "mrr_timestamp_sec : " << radar_info.mrr_timestamp_sec << std::endl
                  << "mrr_timestamp_n_sec : " << radar_info.mrr_timestamp_n_sec << std::endl

                  << "mrr_timesync_status : " << unsigned(radar_info.mrr_timesync_status) << std::endl
                  << "blockage_status : " << unsigned(radar_info.blockage_status) << std::endl

                  << "blockage_prob : " << unsigned(radar_info.blockage_prob) << std::endl
                  << "safety_distance : " << unsigned(radar_info.safety_distance) << std::endl

                  << "tunnel_presence : " << unsigned(radar_info.tunnel_presence) << std::endl
                  << "tunnel_distance : " << unsigned(radar_info.tunnel_distance) << std::endl

                  << "tunnel_prob : " << unsigned(radar_info.tunnel_prob) << std::endl
                  << "object_timestamp_sec : " << radar_info.object_timestamp_sec << std::endl
                  << "object_timestamp_n_sec : " << radar_info.object_timestamp_n_sec << std::endl
                  << "radar_scan_id : " << unsigned(radar_info.radar_scan_id) << std::endl

                  << "number_of_objects : " << unsigned(radar_info.number_of_objects) << std::endl
                  << "mac_radar_info : " << radar_info.mac_radar_info << std::endl;
    }
};

#endif