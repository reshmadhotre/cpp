#ifndef RADAR_HYDRA3_PRIVATE_WHL_STATE_DEFS_H
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_DEFS_H

#include <iostream>
#include <stdint.h>

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_FL_WHL_SPD_VLD_FL_INIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_FL_WHL_SPD_VLD_FL_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_FL_WHL_SPD_VLD_FL_INVALID_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_FL_WHL_SPD_VLD_FL_RESERVED_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_FR_WHL_SPD_VLD_FR_INIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_FR_WHL_SPD_VLD_FR_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_FR_WHL_SPD_VLD_FR_INVALID_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_FR_WHL_SPD_VLD_FR_RESERVED_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_RL_WHL_SPD_VLD_RL_INIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_RL_WHL_SPD_VLD_RL_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_RL_WHL_SPD_VLD_RL_INVALID_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_RL_WHL_SPD_VLD_RL_RESERVED_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_RR_WHL_SPD_VLD_RR_INIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_RR_WHL_SPD_VLD_RR_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_RR_WHL_SPD_VLD_RR_INVALID_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_SPD_VLD_RR_WHL_SPD_VLD_RR_RESERVED_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_FL_WHL_DIR_FL_INIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_FL_WHL_DIR_FL_FORWARD_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_FL_WHL_DIR_FL_BACKWARD_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_FL_WHL_DIR_FL_STOP_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_FL_WHL_DIR_FL_INVALID_CHOICE (4u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_FR_WHL_DIR_FR_INIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_FR_WHL_DIR_FR_FORWARD_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_FR_WHL_DIR_FR_BACKWARD_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_FR_WHL_DIR_FR_STOP_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_FR_WHL_DIR_FR_INVALID_CHOICE (4u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_RL_WHL_DIR_RL_INIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_RL_WHL_DIR_RL_FORWARD_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_RL_WHL_DIR_RL_BACKWARD_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_RL_WHL_DIR_RL_STOP_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_RL_WHL_DIR_RL_INVALID_CHOICE (4u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_RR_WHL_DIR_RR_INIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_RR_WHL_DIR_RR_FORWARD_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_RR_WHL_DIR_RR_BACKWARD_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_RR_WHL_DIR_RR_STOP_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_DIR_RR_WHL_DIR_RR_INVALID_CHOICE (4u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_PLS_CNT_FL_WHL_PLS_CNT_FL_SNA_CHOICE (255u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_PLS_CNT_FR_WHL_PLS_CNT_FR_SNA_CHOICE (255u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_PLS_CNT_RL_WHL_PLS_CNT_RL_SNA_CHOICE (255u)

#define RADAR_HYDRA3_PRIVATE_WHL_STATE_WHL_PLS_CNT_RR_WHL_PLS_CNT_RR_SNA_CHOICE (255u)

/**
 * Signals in message WHL_STATE.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */
struct radar_hydra3_private_whl_state_t
{
    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t crc_whl_state;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t mc_whl_state;

    /**
     * Range: 0..16383 (0..1023.9375 km_per_h)
     * Scale: 0.0625
     * Offset: 0
     */
    double wheel_spd_fl;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_spd_vld_fl;

    /**
     * Range: 0..16383 (0..1023.9375 km_per_h)
     * Scale: 0.0625
     * Offset: 0
     */
    double wheel_spd_fr;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_spd_vld_fr;

    /**
     * Range: 0..16383 (0..1023.9375 km_per_h)
     * Scale: 0.0625
     * Offset: 0
     */
    double wheel_spd_rl;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_spd_vld_rl;

    /**
     * Range: 0..16383 (0..1023.9375 km_per_h)
     * Scale: 0.0625
     * Offset: 0
     */
    double wheel_spd_rr;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_spd_vld_rr;

    /**
     * Range: 0..4 (0..4 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_dir_fl;

    /**
     * Range: 0..4 (0..4 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_dir_fr;

    /**
     * Range: 0..4 (0..4 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_dir_rl;

    /**
     * Range: 0..4 (0..4 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_dir_rr;

    /**
     * Range: 0..255 (0..255 Impulse)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_pls_cnt_fl;

    /**
     * Range: 0..255 (0..255 Impulse)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_pls_cnt_fr;

    /**
     * Range: 0..255 (0..255 Impulse)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_pls_cnt_rl;

    /**
     * Range: 0..255 (0..255 Impulse)
     * Scale: 1
     * Offset: 0
     */
    uint8_t whl_pls_cnt_rr;

    /**
     * Range: 0..16777215 (0..16777215 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint32_t mac_whl_state;

    friend std::ostream& operator<<(std::ostream& os, const radar_hydra3_private_whl_state_t& whl_state)
    {
        return os << "crc_whl_state : " << unsigned(whl_state.crc_whl_state) << std::endl
                  << "mc_whl_state : " << unsigned(whl_state.mc_whl_state) << std::endl
                  << "wheel_spd_fl : " << whl_state.wheel_spd_fl << std::endl
                  << "whl_spd_vld_fl : " << unsigned(whl_state.whl_spd_vld_fl) << std::endl

                  << "wheel_spd_fr : " << whl_state.wheel_spd_fr << std::endl
                  << "whl_spd_vld_fr : " << unsigned(whl_state.whl_spd_vld_fr) << std::endl

                  << "wheel_spd_rl : " << whl_state.wheel_spd_rl << std::endl
                  << "whl_spd_vld_rl : " << unsigned(whl_state.whl_spd_vld_rl) << std::endl

                  << "wheel_spd_rr : " << whl_state.wheel_spd_rr << std::endl
                  << "whl_spd_vld_rr : " << unsigned(whl_state.whl_spd_vld_rr) << std::endl

                  << "whl_dir_fl : " << unsigned(whl_state.whl_dir_fl) << std::endl
                  << "whl_dir_fr : " << unsigned(whl_state.whl_dir_fr) << std::endl
                  << "whl_dir_rl : " << unsigned(whl_state.whl_dir_rl) << std::endl
                  << "whl_dir_rr : " << unsigned(whl_state.whl_dir_rr) << std::endl

                  << "whl_pls_cnt_fl : " << unsigned(whl_state.whl_pls_cnt_fl) << std::endl
                  << "whl_pls_cnt_rl : " << unsigned(whl_state.whl_pls_cnt_rl) << std::endl
                  << "whl_pls_cnt_fr : " << unsigned(whl_state.whl_pls_cnt_fr) << std::endl
                  << "whl_pls_cnt_rr : " << unsigned(whl_state.whl_pls_cnt_rr) << std::endl

                  << "mac_whl_state : " << whl_state.mac_whl_state << std::endl;
    }
};

#endif