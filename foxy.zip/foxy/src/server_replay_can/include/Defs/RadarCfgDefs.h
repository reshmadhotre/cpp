#ifndef RADAR_HYDRA3_PRIVATE_RADAR_CFG_DEFS_H
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_DEFS_H

#include <iostream>
#include <stdint.h>

#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_POS_X_ST_RADAR_POS_X_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_POS_X_ST_RADAR_POS_X_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_POS_X_ST_RADAR_POS_X_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_POS_Y_ST_RADAR_POS_Y_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_POS_Y_ST_RADAR_POS_Y_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_POS_Y_ST_RADAR_POS_Y_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_POS_Z_ST_RADAR_POS_Z_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_POS_Z_ST_RADAR_POS_Z_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_POS_Z_ST_RADAR_POS_Z_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ANGL_AZIMUTH_ST_RADAR_ANGL_AZIMUTH_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ANGL_AZIMUTH_ST_RADAR_ANGL_AZIMUTH_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ANGL_AZIMUTH_ST_RADAR_ANGL_AZIMUTH_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_NOT_CONFIGURED_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_FRONT_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_CORNER_FL_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_CORNER_FR_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_CORNER_RL_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_CORNER_RR_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_BACK_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_SNA_CHOICE (7u)

#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_FUNC_CFG_RADAR_FUNC_CFG_FUNC_NOT_CONFIGURED_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_FUNC_CFG_RADAR_FUNC_CFG_FUNC_BLOCKAGE_CONFIGURED_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_FUNC_CFG_RADAR_FUNC_CFG_FUNC_TUNNEL_CONFIGURED_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_FUNC_CFG_RADAR_FUNC_CFG_FUNC_EGOMOTION_CONFIGURED_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_FUNC_CFG_RADAR_FUNC_CFG_FUNC_MPLOBJTRACKER_CONFIGURED_CHOICE (8u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_FUNC_CFG_RADAR_FUNC_CFG_FUNC_NDEF_CHOICE (22u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_FUNC_CFG_RADAR_FUNC_CFG_FUNC_ROADBORDER_CONFIGURED_CHOICE (50u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_FUNC_CFG_RADAR_FUNC_CFG_FUNC_FREESPACE_CONFIGURED_CHOICE (100u)

#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ANGL_ELEVATION_ST_RADAR_ANGL_ELEVATION_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ANGL_ELEVATION_ST_RADAR_ANGL_ELEVATION_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ANGL_ELEVATION_ST_RADAR_ANGL_ELEVATION_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ANGL_ROLL_ST_RADAR_ANGL_ROLL_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ANGL_ROLL_ST_RADAR_ANGL_ROLL_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ANGL_ROLL_ST_RADAR_ANGL_ROLL_ST_ERROR_CHOICE (3u)

/**
 * Signals in message RADAR_CFG.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */
struct radar_hydra3_private_radar_cfg_t
{
    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t crc_radar_cfg;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t mc_radar_cfg;

    /**
     * Range: 0..16383 (-16.383..16.383 m)
     * Scale: 0.002
     * Offset: -16.383
     */
    double radar_pos_x;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t radar_pos_x_st;

    /**
     * Range: 0..4095 (-4.095..4.095 m)
     * Scale: 0.002
     * Offset: -4.095
     */
    double radar_pos_y;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t radar_pos_y_st;

    /**
     * Range: 0..4095 (0..8.19 m)
     * Scale: 0.002
     * Offset: 0
     */
    double radar_pos_z;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t radar_pos_z_st;

    /**
     * Range: 0..65535.00000000002187230625000 (-180..180 degrees)
     * Scale: 0.00549324788281071
     * Offset: -180
     */
    double radar_angl_azimuth;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t radar_angl_azimuth_st;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t radar_role_config;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t radar_func_cfg;

    /**
     * Range: 0..65535.00000000002187230625000 (-180..180 degrees)
     * Scale: 0.00549324788281071
     * Offset: -180
     */
    double radar_angl_elevation;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t radar_angl_elevation_st;

    /**
     * Range: 0..65535.00000000002187230625000 (-180..180 degrees)
     * Scale: 0.00549324788281071
     * Offset: -180
     */
    double radar_angl_roll;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t radar_angl_roll_st;

    /**
     * Range: 0..16777215 (0..16777215 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint32_t mac_radar_cfg;

    friend std::ostream& operator<<(std::ostream& os, const radar_hydra3_private_radar_cfg_t& radar_cfg)
    {
        return os << "crc_radar_cfg : " << unsigned(radar_cfg.crc_radar_cfg) << std::endl
                  << "mc_radar_cfg : " << unsigned(radar_cfg.mc_radar_cfg) << std::endl
                  << "radar_pos_x : " << radar_cfg.radar_pos_x << std::endl
                  << "radar_pos_x_st : " << unsigned(radar_cfg.radar_pos_x_st) << std::endl

                  << "radar_pos_y : " << radar_cfg.radar_pos_y << std::endl
                  << "radar_pos_y_st : " << unsigned(radar_cfg.radar_pos_y_st) << std::endl

                  << "radar_pos_z : " << radar_cfg.radar_pos_z << std::endl
                  << "radar_pos_z_st : " << unsigned(radar_cfg.radar_pos_z_st) << std::endl

                  << "radar_angl_azimuth : " << radar_cfg.radar_angl_azimuth << std::endl
                  << "radar_angl_azimuth_st : " << unsigned(radar_cfg.radar_angl_azimuth_st) << std::endl

                  << "radar_role_config : " << unsigned(radar_cfg.radar_role_config) << std::endl
                  << "radar_func_cfg : " << unsigned(radar_cfg.radar_func_cfg) << std::endl
                  << "radar_angl_elevation : " << radar_cfg.radar_angl_elevation << std::endl
                  << "radar_angl_elevation_st : " << unsigned(radar_cfg.radar_angl_elevation_st) << std::endl
                  << "radar_angl_roll : " << unsigned(radar_cfg.radar_angl_roll) << std::endl
                  << "radar_angl_roll_st : " << unsigned(radar_cfg.radar_angl_roll_st) << std::endl

                  << "mac_radar_cfg : " << radar_cfg.mac_radar_cfg << std::endl;
    }
};
#endif