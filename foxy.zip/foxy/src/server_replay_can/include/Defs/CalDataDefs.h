#ifndef RADAR_HYDRA3_PRIVATE_RADAR_CAL_DATA_DEFS_H
#define RADAR_HYDRA3_PRIVATE_RADAR_CAL_DATA_DEFS_H

#include <iostream>
#include <stdint.h>

/**
 * Signals in message RADAR_CAL_DATA.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */
struct radar_hydra3_private_radar_cal_data_t
{
    /**
     * Range: 0..65535 (-180..179.78715 degrees)
     * Scale: 0.00549
     * Offset: -180
     */
    double ocal_rotation_matrix_roll_ag;

    /**
     * Range: 0..65535 (-180..179.78715 degrees)
     * Scale: 0.00549
     * Offset: -180
     */
    double ocal_rotation_matrix_pitch_ag;

    /**
     * Range: 0..65535 (-180..179.78715 degrees)
     * Scale: 0.00549
     * Offset: -180
     */
    double ocal_rotation_matrix_yaw_ag;

    /**
     * Range: 0..65535 (-180..179.78715 degrees)
     * Scale: 0.00549
     * Offset: -180
     */
    double ocal_rotation_matrix_pitch_ag_std_dev;

    /**
     * Range: 0..65535 (-180..179.78715 degrees)
     * Scale: 0.00549
     * Offset: -180
     */
    double ocal_rotation_matrix_roll_ag_std_dev;

    /**
     * Range: 0..65535 (-180..179.78715 degrees)
     * Scale: 0.00549
     * Offset: -180
     */
    double ocal_rotation_matrix_yaw_ag_std_dev;

    friend std::ostream& operator<<(std::ostream& os, const radar_hydra3_private_radar_cal_data_t& radar_cal_data)
    {
        return os << "ocal_rotation_matrix_roll_ag : " << radar_cal_data.ocal_rotation_matrix_roll_ag << std::endl
                  << "ocal_rotation_matrix_pitch_ag : " << radar_cal_data.ocal_rotation_matrix_pitch_ag << std::endl
                  << "ocal_rotation_matrix_yaw_ag : " << radar_cal_data.ocal_rotation_matrix_yaw_ag << std::endl
                  << "ocal_rotation_matrix_pitch_ag_std_dev : " << radar_cal_data.ocal_rotation_matrix_pitch_ag_std_dev
                  << std::endl
                  << "ocal_rotation_matrix_roll_ag_std_dev : " << radar_cal_data.ocal_rotation_matrix_roll_ag_std_dev
                  << std::endl
                  << "ocal_rotation_matrix_yaw_ag_std_dev : " << radar_cal_data.ocal_rotation_matrix_yaw_ag_std_dev
                  << std::endl;
    }
};

#endif