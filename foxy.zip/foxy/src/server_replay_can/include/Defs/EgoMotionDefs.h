#ifndef RADAR_HYDRA3_PRIVATE_EGO_MOTION_DEFS_H
#define RADAR_HYDRA3_PRIVATE_EGO_MOTION_DEFS_H

#include <iostream>
#include <stdint.h>

#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_V_ST_EGO_MOTION_V_ST_ESTIMN_ST_UNINIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_V_ST_EGO_MOTION_V_ST_ESTIMN_ST_INIT_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_V_ST_EGO_MOTION_V_ST_ESTIMN_ST_PENDING_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_V_ST_EGO_MOTION_V_ST_ESTIMN_ST_OK_SNSR_RAW_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_V_ST_EGO_MOTION_V_ST_ESTIMN_ST_OK_ODO_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_V_ST_EGO_MOTION_V_ST_ESTIMN_ST_OK_FUSED_1_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_V_ST_EGO_MOTION_V_ST_ESTIMN_ST_OK_FUSED_2_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_V_ST_EGO_MOTION_V_ST_ESTIMN_ST_SNA_CHOICE (254u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_V_ST_EGO_MOTION_V_ST_ESTIMN_ST_ERR_CHOICE (255u)

#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_A_ST_EGO_MOTION_A_ST_ESTIMN_ST_UNINIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_A_ST_EGO_MOTION_A_ST_ESTIMN_ST_INIT_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_A_ST_EGO_MOTION_A_ST_ESTIMN_ST_PENDING_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_A_ST_EGO_MOTION_A_ST_ESTIMN_ST_OK_SNSR_RAW_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_A_ST_EGO_MOTION_A_ST_ESTIMN_ST_OK_ODO_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_A_ST_EGO_MOTION_A_ST_ESTIMN_ST_OK_FUSED_1_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_A_ST_EGO_MOTION_A_ST_ESTIMN_ST_OK_FUSED_2_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_A_ST_EGO_MOTION_A_ST_ESTIMN_ST_SNA_CHOICE (254u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_A_ST_EGO_MOTION_A_ST_ESTIMN_ST_ERR_CHOICE (255u)

#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_YAW_RATE_ST_EGO_MOTION_YAW_RATE_ST_ESTIMN_ST_UNINIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_YAW_RATE_ST_EGO_MOTION_YAW_RATE_ST_ESTIMN_ST_INIT_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_YAW_RATE_ST_EGO_MOTION_YAW_RATE_ST_ESTIMN_ST_PENDING_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_YAW_RATE_ST_EGO_MOTION_YAW_RATE_ST_ESTIMN_ST_OK_SNSR_RAW_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_YAW_RATE_ST_EGO_MOTION_YAW_RATE_ST_ESTIMN_ST_OK_ODO_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_YAW_RATE_ST_EGO_MOTION_YAW_RATE_ST_ESTIMN_ST_OK_FUSED_1_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_YAW_RATE_ST_EGO_MOTION_YAW_RATE_ST_ESTIMN_ST_OK_FUSED_2_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_YAW_RATE_ST_EGO_MOTION_YAW_RATE_ST_ESTIMN_ST_SNA_CHOICE (254u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_YAW_RATE_ST_EGO_MOTION_YAW_RATE_ST_ESTIMN_ST_ERR_CHOICE (255u)

#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_CRV_RD_ST_EGO_MOTION_CRV_RD_ST_ESTIMN_ST_UNINIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_CRV_RD_ST_EGO_MOTION_CRV_RD_ST_ESTIMN_ST_INIT_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_CRV_RD_ST_EGO_MOTION_CRV_RD_ST_ESTIMN_ST_PENDING_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_CRV_RD_ST_EGO_MOTION_CRV_RD_ST_ESTIMN_ST_OK_SNSR_RAW_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_CRV_RD_ST_EGO_MOTION_CRV_RD_ST_ESTIMN_ST_OK_ODO_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_CRV_RD_ST_EGO_MOTION_CRV_RD_ST_ESTIMN_ST_OK_FUSED_1_CHOICE (5u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_CRV_RD_ST_EGO_MOTION_CRV_RD_ST_ESTIMN_ST_OK_FUSED_2_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_CRV_RD_ST_EGO_MOTION_CRV_RD_ST_ESTIMN_ST_SNA_CHOICE (254u)
#define RADAR_HYDRA3_PRIVATE_EGOMOTION_EGO_MOTION_CRV_RD_ST_EGO_MOTION_CRV_RD_ST_ESTIMN_ST_ERR_CHOICE (255u)

/**
 * Signals in message EGOMOTION.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */
struct radar_hydra3_private_egomotion_t
{
    /**
     * Range: 0..65534.99999999999515041000000 (-100..99.9999999999997 m_per_s)
     * Scale: 0.00305180437933928
     * Offset: -100
     */
    double ego_motion_vx;

    /**
     * Range: 0..1023 (0..10.23 m_per_s)
     * Scale: 0.01
     * Offset: 0
     */
    double ego_motion_vx_std_dev;

    /**
     * Range: 0..65534.99999999999515041000000 (-100..99.9999999999997 m_per_s)
     * Scale: 0.00305180437933928
     * Offset: -100
     */
    double ego_motion_vy;

    /**
     * Range: 0..1023 (0..10.23 m_per_s)
     * Scale: 0.01
     * Offset: 0
     */
    double ego_motion_vy_std_dev;

    /**
     * Range: 0..65534.99999999999515041000000 (-100..99.9999999999997 m_per_s)
     * Scale: 0.00305180437933928
     * Offset: -100
     */
    double ego_motion_vz;

    /**
     * Range: 0..1023 (0..10.23 m_per_s)
     * Scale: 0.01
     * Offset: 0
     */
    double ego_motion_vz_std_dev;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t ego_motion_v_st;

    /**
     * Range: 0..65535 (-16..15.9994298 m_per_s²)
     * Scale: 0.00048828
     * Offset: -16
     */
    double ego_motion_ax;

    /**
     * Range: 0..1023 (0..10.23 m_per_s²)
     * Scale: 0.01
     * Offset: 0
     */
    double ego_motion_ax_std_dev;

    /**
     * Range: 0..65535 (-16..15.9994298 m_per_s²)
     * Scale: 0.00048828
     * Offset: -16
     */
    double ego_motion_ay;

    /**
     * Range: 0..1023 (0..10.23 m_per_s²)
     * Scale: 0.01
     * Offset: 0
     */
    double ego_motion_ay_std_dev;

    /**
     * Range: 0..65535 (-16..15.9994298 m_per_s²)
     * Scale: 0.00048828
     * Offset: -16
     */
    double ego_motion_az;

    /**
     * Range: 0..1023 (0..10.23 m_per_s²)
     * Scale: 0.01
     * Offset: 0
     */
    double ego_motion_az_std_dev;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t ego_motion_a_st;

    /**
     * Range: 0..65534.99999999998848503800814 (-0.7854..0.785396326794894 rad_per_s)
     * Scale: 2.39688155458136e-05
     * Offset: -0.7854
     */
    double ego_motion_yaw_rate;

    /**
     * Range: 0..1023 (0..0.5115 rad_per_s)
     * Scale: 0.0005
     * Offset: 0
     */
    double ego_motion_yaw_rate_std_dev;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t ego_motion_yaw_rate_st;

    /**
     * Range: 0..65534.99999999999515041000000 (-0.1..0.0999999999999997 x_over_meter)
     * Scale: 3.05180437933928e-06
     * Offset: -0.1
     */
    double ego_motion_crv_rd;

    /**
     * Range: 0..4094.999999999999262900000000 (0..0.999999999999999 x_over_meter)
     * Scale: 0.000244200244200244
     * Offset: 0
     */
    double ego_motion_crv_rd_std_dev;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t ego_motion_crv_rd_st;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t ego_motion_scan_id;
};

#endif