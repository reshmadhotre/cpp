#ifndef RADAR_HYDRA3_PRIVATE_VEH_STATE_DEFS_H
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_DEFS_H

#include <iostream>
#include <stdint.h>

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_SPEED_ST_VEH_SPEED_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_SPEED_ST_VEH_SPEED_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_SPEED_ST_VEH_SPEED_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_ACCEL_ST_VEH_ACCEL_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_ACCEL_ST_VEH_ACCEL_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_ACCEL_ST_VEH_ACCEL_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_ACCEL_X_ST_VEH_ACCEL_X_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_ACCEL_X_ST_VEH_ACCEL_X_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_ACCEL_X_ST_VEH_ACCEL_X_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_ACCEL_Y_ST_VEH_ACCEL_Y_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_ACCEL_Y_ST_VEH_ACCEL_Y_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_ACCEL_Y_ST_VEH_ACCEL_Y_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_YAW_RATE_ST_VEH_YAW_RATE_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_YAW_RATE_ST_VEH_YAW_RATE_ST_ERROR_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_YAW_RATE_ST_VEH_YAW_RATE_ST_VALID_LQ_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_YAW_RATE_ST_VEH_YAW_RATE_ST_VALID_MQ_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_YAW_RATE_ST_VEH_YAW_RATE_ST_VALID_HQ_CHOICE (4u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_STEERING_ANGLE_ST_STEERING_ANGLE_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_STEERING_ANGLE_ST_STEERING_ANGLE_ST_ERROR_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_STEERING_ANGLE_ST_STEERING_ANGLE_ST_VALID_LQ_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_STEERING_ANGLE_ST_STEERING_ANGLE_ST_VALID_MQ_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_STEERING_ANGLE_ST_STEERING_ANGLE_ST_VALID_HQ_CHOICE (4u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_BRAKE_ST_BRAKE_ST_BRK_ST_NORMAL_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_BRAKE_ST_BRAKE_ST_BRK_ST_ABS_EVENT_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_BRAKE_ST_BRAKE_ST_BRK_ST_ASR_EVENT_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_BRAKE_ST_BRAKE_ST_BRK_ST_ESC_EVENT_CHOICE (4u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_BRAKE_ST_BRAKE_ST_BRK_ST_SNA_CHOICE (7u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_WIPER_ST_WIPER_ST_WIPER_OFF_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_WIPER_ST_WIPER_ST_WIPER_INTERVAL_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_WIPER_ST_WIPER_ST_WIPER_LOW_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_WIPER_ST_WIPER_ST_WIPER_HIGH_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_WIPER_ST_WIPER_ST_SNA_CHOICE (7u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_DC_ST_DC_ST_DC_ST_INIT_DEINIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_DC_ST_DC_ST_DC_ST_NORMAL_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_DC_ST_DC_ST_DC_ST_DIAG_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_DC_ST_DC_ST_DC_ST_ERROR_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_DC_ST_DC_ST_DC_ST_SNA_CHOICE (7u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_STEERING_ANGLE_SPD_ST_STEERING_ANGLE_SPD_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_STEERING_ANGLE_SPD_ST_STEERING_ANGLE_SPD_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_STEERING_ANGLE_SPD_ST_STEERING_ANGLE_SPD_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_OUTSIDE_TEMP_ST_OUTSIDE_TEMP_ST_INVALID_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_OUTSIDE_TEMP_ST_OUTSIDE_TEMP_ST_VALID_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_OUTSIDE_TEMP_ST_OUTSIDE_TEMP_ST_ERROR_CHOICE (3u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_MOTION_ST_VEH_MOTION_ST_STANDING_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_MOTION_ST_VEH_MOTION_ST_MOVING_FWD_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_MOTION_ST_VEH_MOTION_ST_MOVING_BWD_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_MOTION_ST_VEH_MOTION_ST_ERR_CHOICE (6u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_MOTION_ST_VEH_MOTION_ST_SNA_CHOICE (7u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_RADAR_CTRL_RADAR_CTRL_RADARCTRL_INIT_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_RADAR_CTRL_RADAR_CTRL_RADARCTRL_NORMAL_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_RADAR_CTRL_RADAR_CTRL_RADARCTRL_SCAN_DISABLED_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_RADAR_CTRL_RADAR_CTRL_RADARCTRL_LOW_POWER_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_RADAR_CTRL_RADAR_CTRL_RADARCTRL_PREOFFWARNING_CHOICE (4u)

#define RADAR_HYDRA3_PRIVATE_VEH_STATE_RAIN_SENSOR_ST_RAIN_SENSOR_ST_NO_RAIN_CHOICE (0u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_RAIN_SENSOR_ST_RAIN_SENSOR_ST_RAIN_LOW_CHOICE (1u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_RAIN_SENSOR_ST_RAIN_SENSOR_ST_RAIN_MID_CHOICE (2u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_RAIN_SENSOR_ST_RAIN_SENSOR_ST_RAIN_HIGH_CHOICE (3u)
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_RAIN_SENSOR_ST_RAIN_SENSOR_ST_SNA_CHOICE (7u)


/* Frame lengths in bytes. */
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_LENGTH (32u)

/* Frame ids. */
#define RADAR_HYDRA3_PRIVATE_VEH_STATE_FRAME_ID (0x200u)


/*
    Adapted from Rte_MEVehInpAdprScp_Type.h (Repository : L2H5008_Sabine_SA80NFE20T)
*/
#define VEHDYN_ST_STOPPED (2u)
#define VEHDYN_ST_DRVNG_FWD (4u)
#define VEHDYN_ST_DRVNG_BKWD (5u)
#define VEHDYN_ST_UNKNOWN (0u)

/**
 * Signals in message VEH_STATE.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */
struct radar_hydra3_private_veh_state_t
{
    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t crc_veh_state;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t mc_veh_state;

    /**
     * Range: 0..65535 (-100..555.35 km_per_h)
     * Scale: 0.01
     * Offset: -100
     */
    double veh_speed;

    /**
     * Range: 0..65535 (-40.96..40.95875 m_per_s²)
     * Scale: 0.00125
     * Offset: -40.96
     */
    double veh_accel;

    /**
     * Range: 0..65535 (-2..63.535 g)
     * Scale: 0.001
     * Offset: -2
     */
    double veh_accel_x;

    /**
     * Range: 0..65535 (-2..63.535 g)
     * Scale: 0.001
     * Offset: -2
     */
    double veh_accel_y;

    /**
     * Range: 0..65535 (-180..475.35 deg_per_sec)
     * Scale: 0.01
     * Offset: -180
     */
    double veh_yaw_rate;

    /**
     * Range: 0..65535 (-1.6384..1.63835 rad)
     * Scale: 5e-05
     * Offset: -1.6384
     */
    double steering_angle;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t veh_speed_st;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t veh_accel_st;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t veh_accel_x_st;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t veh_accel_y_st;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t veh_yaw_rate_st;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t steering_angle_st;

    /**
     * Range: 0..255 (-40..87.5 degrees_Celsius)
     * Scale: 0.5
     * Offset: -40
     */
    double outside_temp;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t brake_st;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t wiper_st;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t dc_st;

    /**
     * Range: 0..65535.00000000003698631562500 (-40..39.9999999999998 rad_per_s)
     * Scale: 0.00122072175173571
     * Offset: -40
     */
    double steering_angle_spd;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t steering_angle_spd_st;

    /**
     * Range: 0..3 (0..3 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t outside_temp_st;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t veh_motion_st;

    /**
     * Range: 0..15 (0..15 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t radar_ctrl;

    /**
     * Range: 0..7 (0..7 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t rain_sensor_st;

    /**
     * Range: 0..16777215 (0..16777215 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint32_t mac_veh_state;

    friend std::ostream& operator<<(std::ostream& os, const radar_hydra3_private_veh_state_t& veh_state)
    {
        return os << "crc_veh_state : " << unsigned(veh_state.crc_veh_state) << std::endl
                  << "mc_veh_state : " << unsigned(veh_state.mc_veh_state) << std::endl
                  << "veh_speed : " << veh_state.veh_speed << std::endl
                  << "veh_accel : " << veh_state.veh_accel << std::endl
                  << "veh_accel_x : " << veh_state.veh_accel_x << std::endl
                  << "veh_accel_y : " << veh_state.veh_accel_y << std::endl
                  << "veh_yaw_rate : " << veh_state.veh_yaw_rate << std::endl
                  << "steering_angle : " << veh_state.steering_angle << std::endl
                  << "veh_speed_st : " << unsigned(veh_state.veh_speed_st) << std::endl
                  << "veh_accel_st : " << unsigned(veh_state.veh_accel_st) << std::endl
                  << "veh_accel_x_st : " << unsigned(veh_state.veh_accel_x_st) << std::endl
                  << "veh_accel_y_st : " << unsigned(veh_state.veh_accel_y_st) << std::endl
                  << "veh_yaw_rate_st : " << unsigned(veh_state.veh_yaw_rate_st) << std::endl
                  << "steering_angle_st : " << unsigned(veh_state.steering_angle_st) << std::endl
                  << "outside_temp : " << veh_state.outside_temp << std::endl
                  << "brake_st : " << unsigned(veh_state.brake_st) << std::endl
                  << "wiper_st : " << unsigned(veh_state.wiper_st) << std::endl
                  << "dc_st : " << unsigned(veh_state.dc_st) << std::endl
                  << "steering_angle_spd : " << veh_state.steering_angle_spd << std::endl
                  << "steering_angle_spd_st : " << unsigned(veh_state.steering_angle_spd_st) << std::endl
                  << "outside_temp_st : " << unsigned(veh_state.outside_temp_st) << std::endl
                  << "veh_motion_st : " << unsigned(veh_state.veh_motion_st) << std::endl
                  << "radar_ctrl : " << unsigned(veh_state.radar_ctrl) << std::endl
                  << "rain_sensor_st : " << unsigned(veh_state.rain_sensor_st) << std::endl;
    }
};

#endif