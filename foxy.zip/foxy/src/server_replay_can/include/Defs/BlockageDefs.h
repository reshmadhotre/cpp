#ifndef RADAR_HYDRA3_PRIVATE_BLOCKAGE_DEFS_H
#define RADAR_HYDRA3_PRIVATE_BLOCKAGE_DEFS_H

#include <iostream>
#include <stdint.h>

/**
 * Signals in message BLKG_DEBUG.
 *
 * All signal values are as on the CAN bus.
 */
struct radar_hydra3_private_blkg_debug_t {
    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_conf;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_range_mean;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_range_max;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_range_conf;
    
    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_range_prob;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_obj_loss_prob;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_obj_loss_conf;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_time_count;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_dist_count;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_time_dist_count_prob;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_time_dist_count_conf;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_st_mean;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_st_mean_conf;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_st_max;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_mov_mean;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_mov_mean_conf;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_mov_max;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_fl_mean;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_fl_conf;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_deactivate_range;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_deactivate_time_count;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_deactivate_dist_count;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..65535 (0..65535 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint16_t blkg_deactivate_obj_loss;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_scan_id;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_detection_ratio_static;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_detection_ratio_mov;

    /**
     * Range: 0..255 (0..255 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_detection_ratio_mean;

    /**
     * ONLY FOR DEVELOPMENT! NOT FOR PRODUCTION!
     *
     * Range: 0..1 (0..1 No_Unit)
     * Scale: 1
     * Offset: 0
     */
    uint8_t blkg_active;
};

#endif