/*
 * \file ParquetExporterLib.hpp
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 * Name: SkelGen
 * Version: 3.2.0 (beta)
 * Internal version: 05.25 (Build: 20220427)
 * Time of generation: Aug-18-2022 - 10:26:01
 * Based on ARXML interface version: 1.0.0
 *
 * \author Magna Electronics Europe GmbH & Co. OHG, 
 *         63877 Sailauf, Germany
 *
 * Copyright 2019 - 2022 Magna Electronics Europe GmbH & Co. OHG
 * All rights exclusively reserved for Magna Electronics Europe GmbH & Co. OHG,
 * unless expressly agreed to otherwise.
 */
 
#ifndef PARQUETEXPORTERLIB_HPP_
#define PARQUETEXPORTERLIB_HPP_


#include <memory>
#include <string>
#include <map>
#include <variant>
#include <vector>
#include <set>

#include <arrow/api.h>
#include <arrow/io/api.h>
#include <arrow/visit_type_inline.h>
#include <parquet/arrow/writer.h>


namespace parquet_exporter
{
    enum DataType : size_t
    {
        MONOSTATE=0,
        BOOL,
        UINT8,
        UINT16,
        UINT32,     // unsigned data type only added for flexibility in input, they will be stored as signed integer in PARQUET. 
        UINT64,     // unsigned data type only added for flexibility in input, they will be stored as signed integer in PARQUET.
        INT8,
        INT16,
        INT32,
        INT64,
        FLOAT32,    // corresponds to float data type in C++
        FLOAT64,    // corresponds to double data type in C++
        STRING
    };
    
    enum ValueType : size_t
    {
        PRIMITIVE=0,
        LIST
    };
    
    using VariantValueType = std::variant<std::monostate,
                                   bool,
                                   uint8_t,
                                   uint16_t,
                                   uint32_t,
                                   uint64_t,
                                   int8_t,
                                   int16_t,
                                   int32_t,
                                   int64_t,
                                   float,
                                   double,
                                   std::string>;

    using Variant1DVectorType = std::vector<VariantValueType>;
    using Variant2DVectorType = std::vector<Variant1DVectorType>;

    using BuilderType = std::variant<arrow::BooleanBuilder,
                                     arrow::Int32Builder,
                                     arrow::Int64Builder,
                                     arrow::FloatBuilder,
                                     arrow::DoubleBuilder,
                                     arrow::StringBuilder>;
   
    template<class... Ts> struct overload : Ts... {using Ts::operator()...;};
    template<class... Ts> overload(Ts...) -> overload<Ts...>;

    struct SignalInfo
    {
        SignalInfo() = default;
        SignalInfo(const std::string name, const DataType dtype, const ValueType vtype = ValueType::PRIMITIVE);

        std::string name_;
        DataType dtype_;
        ValueType vtype_;
    };

    struct SignalData
    {
        SignalData() = default;
        SignalData(const SignalInfo& info);
        auto append_value(const VariantValueType& value) -> bool;
        auto append_value(const Variant1DVectorType& value_list) -> bool;
        auto get_arrow_type() -> std::shared_ptr<arrow::DataType>;

        SignalInfo info_;
        Variant1DVectorType values_;
        Variant2DVectorType value_lists_;
    };

     
    using SignalInfoListType = std::initializer_list<SignalInfo>;
    using SignalValuesPrimitiveType = std::map<std::string, VariantValueType>;
    using SignalValuesListType = std::map<std::string, Variant1DVectorType>;
    using SignalDataMapType = std::map<std::string, SignalData>;
    
    struct MessageData
    {
        MessageData() = default;
        MessageData(const std::string key_column, const SignalInfoListType list);
        auto add_signals(const SignalInfoListType list) -> bool;
        auto append_values(const SignalValuesPrimitiveType values) -> bool;
        auto append_values(const SignalValuesListType value_lists) -> bool;

        std::string key_column_;
        SignalDataMapType signals_map_;        
    };

    using MessageDataMapType = std::map<std::string, MessageData>;

    struct LocationData
    {
        std::string msg_name_;
        size_t vector_index_;
    };
    
    using LocationsVectorType = std::vector<LocationData>;
    using TimestampLocationsMapType = std::map<int64_t, LocationsVectorType>;

    class ParquetWriter
    { 
    public:
        ParquetWriter() = default;
        ~ParquetWriter();
        auto add_message(const std::string msg_name, const std::string key_column, const SignalInfoListType list) -> bool;
        auto add_signals(const std::string msg_name, const SignalInfoListType list) -> bool;
        auto append_values(const std::string msg_name, const SignalValuesPrimitiveType values) -> bool;
        auto append_values(const std::string msg_name, const SignalValuesListType value_lists) -> bool;
        auto save_to_disk(const std::string input_file_path, const std::string suffix = "", const std::string output_folder_path = "") -> bool;
    
    private:
        auto get_value(const std::string& msg_name, const std::string& signal_name, const size_t vector_index) -> VariantValueType&;
        auto get_value_list(const std::string& msg_name, const std::string& signal_name, const size_t vector_index) -> Variant1DVectorType&;
        auto get_value_type(const std::string& msg_name, const std::string& signal_name) -> ValueType&;
        auto write_parquet() -> arrow::Status;

        std::string input_filename_;
        std::string output_file_path_;
        MessageDataMapType messages_map_;
        TimestampLocationsMapType timestamp_locations_;
    };

    class ValuesVisitor
    {
    public:
        ValuesVisitor(arrow::ArrayBuilder* builder, arrow::DataType* type);
        auto append_value(const VariantValueType& value) -> arrow::Status;
        auto append_value(const Variant1DVectorType& values_list) -> arrow::Status;
        auto Visit(const arrow::DataType& type) -> arrow::Status;
        auto Visit(const arrow::BooleanType& type) -> arrow::Status;
        auto Visit(const arrow::Int32Type& type) -> arrow::Status;
        auto Visit(const arrow::Int64Type& type) -> arrow::Status;
        auto Visit(const arrow::FloatType& type) -> arrow::Status;
        auto Visit(const arrow::DoubleType& type) -> arrow::Status;
        auto Visit(const arrow::StringType& type) -> arrow::Status;
        auto Visit(const arrow::ListType& type) -> arrow::Status;
    
    private:
        arrow::ArrayBuilder* builder_;
        VariantValueType value_;
        arrow::DataType* type_;
        
        // For List Type
        Variant1DVectorType values_list_;
    };
} // namespace parquet_exporter

#endif // PARQUETEXPORTERLIB_HPP_