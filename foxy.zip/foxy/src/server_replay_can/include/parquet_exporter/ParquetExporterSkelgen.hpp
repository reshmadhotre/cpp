/*
 * Copyright 2019 - 2022 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       ParquetExporterSkelgen.hpp
 * \version    3.3.0 (beta)
 * \date       Oct-25-2022 - 13:43:28
 *
 * \author     Magna Electronics Europe GmbH & Co. OHG, 
 *             63877 Sailauf, Germany
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 * Internal version: 05.35 (Build: 20221020)
 * Based on ARXML interface version: 1.0.0
 */
 
#ifndef PARQUETEXPORTERSKELGEN_HPP_
#define PARQUETEXPORTERSKELGEN_HPP_


#include "ParquetExporterLib.hpp"

#include "msg_can_addon/msg/msg_radarcfg_type.hpp"
#include "msg_can_addon/msg/msg_can_radar_cal_data_type.hpp"
#include "msg_swc_common/msg/msg_node_feedback_type.hpp"
#include "msg_live_addon/msg/msg_can_obj_list_type.hpp"
#include "msg_live_addon/msg/msg_roadborder_type.hpp"
#include "msg_live_addon/msg/msg_vehmtn_type.hpp"
#include "msg_live_addon/msg/msg_sensrmtn_type.hpp"
#include "msg_can_addon/msg/msg_vehdyn_type.hpp"
#include "msg_live_addon/msg/msg_blkgdebug_type.hpp"
#include "msg_can_addon/msg/msg_can_radar_info_type.hpp"

#include "rclcpp/rclcpp.hpp"
#include <map>
using namespace parquet_exporter;


class ParquetExportSkelgen : public ParquetWriter
{
public:
	explicit ParquetExportSkelgen();
	virtual ~ParquetExportSkelgen();

    void set_filename(const std::string filename);
    const std::string get_file_suffix() const;
    const std::string get_filename() const;      
    bool is_parquet_file_written();
    void set_parquet_file_completion_flag(const bool status);
    void init_parquet_headers();
    void write_parquet_file();

    enum class parquet_data_id
    {
        RADAR_CFG = 0,
        RADAR_CAL,
        RADAR_INFO,
        VEH_DYN,
        VEH_MTN,
        SNSR_MTN,
        OBJ_DATA,
        RBE_DATA,
        BLKG_DATA,
        DATA_UNKNOWN
    };

    std::map<parquet_data_id, bool> vistor_map{
        {parquet_data_id::RADAR_CFG, false},
        {parquet_data_id::RADAR_CAL, false},
        {parquet_data_id::RADAR_INFO, false},
        {parquet_data_id::VEH_DYN, false},
        {parquet_data_id::VEH_MTN, false},
        {parquet_data_id::SNSR_MTN, false},
        {parquet_data_id::OBJ_DATA, false},
        {parquet_data_id::RBE_DATA, false},
        {parquet_data_id::BLKG_DATA, false},
    };

    virtual void parquet_init_radarcfg(void);
    virtual void parquet_init_radarcal(void);
    virtual void parquet_init_roadborder(void);
    virtual void parquet_init_objdata(void);
    virtual void parquet_init_vehdyn(void);
    virtual void parquet_init_snsrmtn(void);
    virtual void parquet_init_vehmtn(void);
    virtual void parquet_init_blkgdata(void);
    virtual void parquet_init_radarinfo(void);
    virtual void parquet_init_node_feedback(void);

    virtual void parquet_export_radarcfg(msg_can_addon::msg::MsgRadarcfgType* msg);
    virtual void parquet_export_radarcal(msg_can_addon::msg::MsgCanRadarCalDataType* msg);
    virtual void parquet_export_roadborder(msg_live_addon::msg::MsgRoadborderType* msg);
    virtual void parquet_export_objdata(msg_live_addon::msg::MsgCanObjListType* msg);
    virtual void parquet_export_vehdyn(msg_can_addon::msg::MsgVehdynType* msg);
    virtual void parquet_export_snsrmtn(msg_live_addon::msg::MsgSensrmtnType* msg);
    virtual void parquet_export_vehmtn(msg_live_addon::msg::MsgVehmtnType* msg);
    virtual void parquet_export_node_feedback(msg_swc_common::msg::MsgNodeFeedbackType::UniquePtr msg);
    virtual void parquet_export_blkgdata(msg_live_addon::msg::MsgBlkgdebugType* msg);
    virtual void parquet_export_radarinfo(msg_can_addon::msg::MsgCanRadarInfoType* msg);

    void update_previous_data();

private:
    std::string filename_prefix_{"SRC"}; //component name
    std::string parquet_extn_{".parquet"};
    std::string node_ns_{""};
    std::string parquet_file_name_{""};
    bool parquet_file_completion_flag_{false};
    bool is_update_call_{false};
    msg_can_addon::msg::MsgRadarcfgType radar_cfg_data_{};
    msg_can_addon::msg::MsgCanRadarCalDataType radar_cal_data_{};
    msg_can_addon::msg::MsgVehdynType veh_dyn_data_{};
    msg_live_addon::msg::MsgCanObjListType can_obj_list_data_{};
    msg_live_addon::msg::MsgRoadborderType rbe_data_{};
    msg_live_addon::msg::MsgSensrmtnType snsr_mtn_data_{};
    msg_live_addon::msg::MsgVehmtnType veh_mtn_data_{};
    msg_live_addon::msg::MsgBlkgdebugType blkg_debug_data_{};
    msg_can_addon::msg::MsgCanRadarInfoType radar_info_data_{};

    void reset_data();
    void reset_visitor_map();

    rclcpp::Time m_timestamp_{};

};	// ParquetExportSkelgen


#endif // PARQUETEXPORTERSKELGEN_HPP_
