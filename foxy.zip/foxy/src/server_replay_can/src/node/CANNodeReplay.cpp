#include "CANNodeReplay.h"
#include "FrameIDDefs.h"
#include "RosParams.h"
#include "RosTopics.h"

const uint8_t CANNodeReplay::DEFAULT_HISTORY_DEPTH = 10;
const uint32_t CANNodeReplay::OBJ_DATA_FRAME_ID_START = RADAR_HYDRA3_PRIVATE_OBJ_DATA_00_FRAME_ID;
const uint32_t CANNodeReplay::OBJ_DATA_FRAME_ID_END = RADAR_HYDRA3_PRIVATE_OBJ_DATA_31_FRAME_ID;

CANNodeReplay::CANNodeReplay(std::shared_ptr<rclcpp::Node> node) : CANNode(node)
{
    InitROSParams();
    InitPublishers();
    InitSubscribers();
    InitTimers();
}

void CANNodeReplay::InitROSParams()
{
    using namespace ROS_PARAM_NAMES_REPLAY_MODE;
    ros_param_util_->DeclareParameter(STANDALONE_MODE, false);
    standalone_mode_ = ros_param_util_->GetParameter(STANDALONE_MODE).as_bool();
}

void CANNodeReplay::InitPublishers()
{
    using namespace ROS_PUBLIHSER_TOPICS_REPLAY_MODE;

    if (standalone_mode_)
    {
        feedback_publisher_ = std::make_shared<RosPublisher<msg_swc_common::msg::MsgNodeFeedbackType>>(
            node_, TOPIC_NODE_FEEDBACK, DEFAULT_HISTORY_DEPTH);
    }
    radar_cal_data_publisher_ = std::make_shared<RosPublisher<msg_can_addon::msg::MsgCanRadarCalDataType>>(
        node_, TOPIC_CAN_RADAR_CAL_DATA, DEFAULT_HISTORY_DEPTH);

    radar_cfg_publisher_ = std::make_shared<RosPublisher<msg_can_addon::msg::MsgRadarcfgType>>(
        node_, TOPIC_CAN_RADARCFG, DEFAULT_HISTORY_DEPTH);

    radar_info_publisher_ = std::make_shared<RosPublisher<msg_can_addon::msg::MsgCanRadarInfoType>>(
        node_, TOPIC_CAN_RADAR_INFO, DEFAULT_HISTORY_DEPTH);

    tsync_publisher_ = std::make_shared<RosPublisher<msg_can_addon::msg::MsgCanTsyncType>>(node_, TOPIC_CAN_TSYNC,
                                                                                           DEFAULT_HISTORY_DEPTH);

    veh_dyn_publisher_ = std::make_shared<RosPublisher<msg_can_addon::msg::MsgVehdynType>>(node_, TOPIC_CAN_VEHDYN,
                                                                                           DEFAULT_HISTORY_DEPTH);

    can_object_list_publisher_ = std::make_shared<RosPublisher<msg_live_addon::msg::MsgCanObjListType>>(
        node_, TOPIC_CAN_OBJ_DATA, DEFAULT_HISTORY_DEPTH);

    can_road_border_publisher_ = std::make_shared<RosPublisher<msg_live_addon::msg::MsgRoadborderType>>(
        node_, TOPIC_CAN_ROAD_BORDER, DEFAULT_HISTORY_DEPTH);

    veh_mtn_publisher_ = std::make_shared<RosPublisher<msg_live_addon::msg::MsgVehmtnType>>(node_, TOPIC_CAN_VEH_MTN,
                                                                                            DEFAULT_HISTORY_DEPTH);

    snsr_mtn_publisher_ = std::make_shared<RosPublisher<msg_live_addon::msg::MsgSensrmtnType>>(
        node_, TOPIC_CAN_SNSR_MTN, DEFAULT_HISTORY_DEPTH);

    blkg_data_publisher_ = std::make_shared<RosPublisher<msg_live_addon::msg::MsgBlkgdebugType>>(
        node_, TOPIC_BLKG_DEBUG, DEFAULT_HISTORY_DEPTH);
}

void CANNodeReplay::InitSubscribers()
{
    using namespace ROS_SUBSCRIBER_TOPICS_REPLAY_MODE;
    if (!standalone_mode_)
    {
        radar_node_feedback_subscriber_ = node_->create_subscription<msg_swc_common::msg::MsgNodeFeedbackType>(
            TOPIC_NODE_FEEDBACK, rclcpp::QoS(DEFAULT_HISTORY_DEPTH),
            std::bind(&CANNodeReplay::RadarNodeFeedbackCB, this, std::placeholders::_1));
        return;
    }

    trigger_single_frame_subscriber_ = node_->create_subscription<server_replay_can::msg::MsgTriggerSingleFrame>(
        TOPIC_TRIGGER_CAN_NEXT_FRAME, 10, std::bind(&CANNodeReplay::TriggerNextFrameCB, this, std::placeholders::_1));

    set_pause_mode_subscriber_ = node_->create_subscription<server_replay_can::msg::MsgSetPauseMode>(
        TOPIC_SET_CAN_PAUSE_MODE, 10, std::bind(&CANNodeReplay::SetPauseModeCB, this, std::placeholders::_1));
}

void CANNodeReplay::InitTimers()
{
    if (standalone_mode_)
    {
        publish_timer_ =
            node_->create_wall_timer(std::chrono::milliseconds(1), std::bind(&CANNodeReplay::PublishTimerCB, this));
    }
}

void CANNodeReplay::SetParquetExporter(std::unique_ptr<ParquetExportSkelgen> parquet_exporter)
{
    if (!parquet_queue_.empty())
    {
        parquet_queue_.back()->write_parquet_file();
        if (parquet_queue_.front()->is_parquet_file_written())
        {
            parquet_queue_.pop();
        }
    }
    parquet_queue_.push(std::move(parquet_exporter));
}

void CANNodeReplay::RadarNodeFeedbackCB(msg_swc_common::msg::MsgNodeFeedbackType::UniquePtr msg)
{
    auto radar_ts = msg->radar_timestamp;
    PublishCANFramesUntil(radar_ts);
}

void CANNodeReplay::TriggerNextFrameCB(server_replay_can::msg::MsgTriggerSingleFrame::UniquePtr msg)
{
    (void)msg;
    // Only in pause mode.
    if (pause_playback_)
    {
        PublishNextCANFrame();
    }
}

void CANNodeReplay::SetPauseModeCB(server_replay_can::msg::MsgSetPauseMode::UniquePtr msg)
{
    pause_playback_ = msg->pause_playback;
}

void CANNodeReplay::PublishNextCANFrame()
{
    if (pause_playback_)
    {
        int64_t next_timestamp = feedback_publisher_->GetNextTimestamp();
        radar_cal_data_publisher_->PublishMessagesUntil(next_timestamp);
        radar_cfg_publisher_->PublishMessagesUntil(next_timestamp);
        radar_info_publisher_->PublishMessagesUntil(next_timestamp);
        tsync_publisher_->PublishMessagesUntil(next_timestamp);
        veh_dyn_publisher_->PublishMessagesUntil(next_timestamp);
        can_object_list_publisher_->PublishMessagesUntil(next_timestamp);
        can_road_border_publisher_->PublishMessagesUntil(next_timestamp);
        feedback_publisher_->PublishMessagesUntil(next_timestamp);
        veh_mtn_publisher_->PublishMessagesUntil(next_timestamp);
        snsr_mtn_publisher_->PublishMessagesUntil(next_timestamp);
        blkg_data_publisher_->PublishMessagesUntil(next_timestamp);
    }
}

void CANNodeReplay::PublishTimerCB()
{
    static std::chrono::time_point<std::chrono::system_clock> start_time;
    static int64_t first_message_timestamp = 0;

    if (pause_playback_)
    {
        // Reset the first message timestamp to continue the timepoint from now.
        first_message_timestamp = 0;
        return;
    }
    int64_t next_timestamp = feedback_publisher_->GetNextTimestamp();

    if (next_timestamp > 0)
    {
        if (first_message_timestamp == 0)
        {
            first_message_timestamp = next_timestamp;
            start_time = std::chrono::system_clock::now();
        }

        auto time_delta = std::chrono::nanoseconds(next_timestamp - first_message_timestamp);
        std::this_thread::sleep_until(start_time + std::chrono::duration_cast<std::chrono::nanoseconds>(time_delta));

        radar_cal_data_publisher_->PublishMessagesUntil(next_timestamp);
        radar_cfg_publisher_->PublishMessagesUntil(next_timestamp);
        radar_info_publisher_->PublishMessagesUntil(next_timestamp);
        tsync_publisher_->PublishMessagesUntil(next_timestamp);
        veh_dyn_publisher_->PublishMessagesUntil(next_timestamp);
        can_object_list_publisher_->PublishMessagesUntil(next_timestamp);
        can_road_border_publisher_->PublishMessagesUntil(next_timestamp);
        veh_mtn_publisher_->PublishMessagesUntil(next_timestamp);
        snsr_mtn_publisher_->PublishMessagesUntil(next_timestamp);
        blkg_data_publisher_->PublishMessagesUntil(next_timestamp);
        feedback_publisher_->PublishMessagesUntil(next_timestamp);
    }
}

void CANNodeReplay::AddFeedbackMessage(std::shared_ptr<msg_swc_common::msg::MsgNodeFeedbackType> feedback_msg,
                                       const int64_t timestamp)
{
    if (standalone_mode_)
    {
        feedback_publisher_->AddMessage(feedback_msg, timestamp);
    }
}

void CANNodeReplay::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                  std::shared_ptr<msg_can_addon::msg::MsgCanRadarCalDataType> ros_cal_data)
{
    (void)frame_id;
    radar_cal_data_publisher_->AddMessage(ros_cal_data, timestamp);
    if (rosbag_writer_)
    {
        rosbag_writer_->Write(ros_cal_data.get(), rclcpp::Time(timestamp));
    }
    if (!parquet_queue_.empty())
    {
        UpdateParquet(ros_cal_data);
    }
}

void CANNodeReplay::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                  std::shared_ptr<msg_can_addon::msg::MsgRadarcfgType> ros_radar_cfg)
{
    (void)frame_id;
    radar_cfg_publisher_->AddMessage(ros_radar_cfg, timestamp);
    if (rosbag_writer_)
    {
        rosbag_writer_->Write(ros_radar_cfg.get(), rclcpp::Time(timestamp));
    }
    if (!parquet_queue_.empty())
    {
        UpdateParquet(ros_radar_cfg);
    }
}

void CANNodeReplay::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                  std::shared_ptr<msg_can_addon::msg::MsgCanRadarInfoType> ros_radar_info)
{
    (void)frame_id;
    current_radar_info_ = ros_radar_info;
    radar_info_publisher_->AddMessage(ros_radar_info, timestamp);
    if (rosbag_writer_)
    {
        rosbag_writer_->Write(ros_radar_info.get(), rclcpp::Time(timestamp));
    }
    if (!parquet_queue_.empty())
    {
        UpdateParquet(ros_radar_info);
    }
}

void CANNodeReplay::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                  std::shared_ptr<msg_can_addon::msg::MsgCanTsyncType> ros_tsync)
{
    (void)frame_id;
    tsync_publisher_->AddMessage(ros_tsync, timestamp);
    if (rosbag_writer_)
    {
        rosbag_writer_->Write(ros_tsync.get(), rclcpp::Time(timestamp));
    }
}

void CANNodeReplay::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                  std::shared_ptr<msg_can_addon::msg::MsgVehdynType> ros_veh_dyn)
{
    (void)frame_id;
    veh_dyn_publisher_->AddMessage(ros_veh_dyn, timestamp);
    if (rosbag_writer_)
    {
        rosbag_writer_->Write(ros_veh_dyn.get(), rclcpp::Time(timestamp));
    }
    if (!parquet_queue_.empty())
    {
        UpdateParquet(ros_veh_dyn);
    }
}

void CANNodeReplay::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                  std::shared_ptr<msg_live_addon::msg::MsgCanObjType> ros_can_obj_data)
{
    static std::shared_ptr<msg_live_addon::msg::MsgCanObjListType> can_obj_list;

    if (current_radar_info_ == nullptr)
    {
        RCLCPP_DEBUG(node_->get_logger(), "Waiting for Radar Info Can Message to update Object list header.");
        return;
    }

    if (frame_id == OBJ_DATA_FRAME_ID_START)
    {
        can_obj_list = std::make_shared<msg_live_addon::msg::MsgCanObjListType>();
    }

    if (can_obj_list == nullptr)
    {
        RCLCPP_DEBUG(node_->get_logger(), "Frame ID  : %f received before receiving ID : %f.", (float)frame_id,
                     (float)OBJ_DATA_FRAME_ID_START);
        return;
    }
    can_obj_list->obj_arr.at(frame_id - OBJ_DATA_FRAME_ID_START) = *ros_can_obj_data.get();

    if (frame_id == OBJ_DATA_FRAME_ID_END)
    {
        can_obj_list->header.stamp = rclcpp::Time(timestamp);
        can_obj_list->header.frame_id = "map";

        auto& r_header = can_obj_list->r_header;
        r_header.num_obj = current_radar_info_->number_of_objects;
        r_header.timestamp = current_radar_info_->object_timestamp_sec;
        r_header.timestamp_n_sec = current_radar_info_->object_timestamp_n_sec;
        r_header.scan_id = current_radar_info_->radar_scan_id;

        can_object_list_publisher_->AddMessage(can_obj_list, timestamp);

        if (rosbag_writer_)
        {
            rosbag_writer_->Write(can_obj_list.get(), rclcpp::Time(timestamp));
        }

        if (!parquet_queue_.empty())
        {
            UpdateParquet(can_obj_list);
        }

        can_obj_list.reset();
        current_radar_info_.reset();
    }
}

void CANNodeReplay::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                  std::shared_ptr<msg_live_addon::msg::MsgRoadborderType> road_border)
{
    (void)frame_id;
    can_road_border_publisher_->AddMessage(road_border, timestamp);
    if (rosbag_writer_)
    {
        rosbag_writer_->Write(road_border.get(), rclcpp::Time(timestamp));
    }
    if (!parquet_queue_.empty())
    {
        UpdateParquet(road_border);
    }
}

void CANNodeReplay::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                  std::shared_ptr<msg_live_addon::msg::MsgSensrmtnType> snsr_mtn)
{
    (void)frame_id;
    snsr_mtn_publisher_->AddMessage(snsr_mtn, timestamp);
    if (rosbag_writer_)
    {
        rosbag_writer_->Write(snsr_mtn.get(), rclcpp::Time(timestamp));
    }
    if (!parquet_queue_.empty())
    {
        UpdateParquet(snsr_mtn);
    }
}

void CANNodeReplay::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                  std::shared_ptr<msg_live_addon::msg::MsgVehmtnType> veh_mtn)
{
    (void)frame_id;
    veh_mtn_publisher_->AddMessage(veh_mtn, timestamp);
    if (rosbag_writer_)
    {
        rosbag_writer_->Write(veh_mtn.get(), rclcpp::Time(timestamp));
    }
    if (!parquet_queue_.empty())
    {
        UpdateParquet(veh_mtn);
    }
}

void CANNodeReplay::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                  std::shared_ptr<msg_live_addon::msg::MsgBlkgdebugType> blkg_data)
{
    (void)frame_id;
    blkg_data_publisher_->AddMessage(blkg_data, timestamp);
    if (rosbag_writer_)
    {
        rosbag_writer_->Write(blkg_data.get(), rclcpp::Time(timestamp));
    }
    if (!parquet_queue_.empty())
    {
        UpdateParquet(blkg_data);
    }
}

void CANNodeReplay::PublishCANFramesUntil(const int64_t timestamp)
{
    radar_cal_data_publisher_->PublishMessagesUntil(timestamp);
    radar_cfg_publisher_->PublishMessagesUntil(timestamp);
    radar_info_publisher_->PublishMessagesUntil(timestamp);
    tsync_publisher_->PublishMessagesUntil(timestamp);
    veh_dyn_publisher_->PublishMessagesUntil(timestamp);
    can_object_list_publisher_->PublishMessagesUntil(timestamp);
    can_road_border_publisher_->PublishMessagesUntil(timestamp);
    snsr_mtn_publisher_->PublishMessagesUntil(timestamp);
    veh_mtn_publisher_->PublishMessagesUntil(timestamp);
    blkg_data_publisher_->PublishMessagesUntil(timestamp);
}

void CANNodeReplay::UpdateParquet(std::shared_ptr<msg_can_addon::msg::MsgCanRadarCalDataType> radar_cal_data)
{
    parquet_queue_.back()->parquet_export_radarcal(radar_cal_data.get());
}

void CANNodeReplay::UpdateParquet(std::shared_ptr<msg_can_addon::msg::MsgRadarcfgType> radar_cfg)
{
    parquet_queue_.back()->parquet_export_radarcfg(radar_cfg.get());
}

void CANNodeReplay::UpdateParquet(std::shared_ptr<msg_live_addon::msg::MsgRoadborderType> road_brd)
{
    parquet_queue_.back()->parquet_export_roadborder(road_brd.get());
}

void CANNodeReplay::UpdateParquet(std::shared_ptr<msg_live_addon::msg::MsgCanObjListType> can_obj_list)
{
    parquet_queue_.back()->parquet_export_objdata(can_obj_list.get());
}

void CANNodeReplay::UpdateParquet(std::shared_ptr<msg_can_addon::msg::MsgVehdynType> veh_dyn)
{
    parquet_queue_.back()->parquet_export_vehdyn(veh_dyn.get());
}

void CANNodeReplay::UpdateParquet(std::shared_ptr<msg_live_addon::msg::MsgVehmtnType> veh_mtn)
{
    parquet_queue_.back()->parquet_export_vehmtn(veh_mtn.get());
}

void CANNodeReplay::UpdateParquet(std::shared_ptr<msg_live_addon::msg::MsgSensrmtnType> snsr_mtn)
{
    parquet_queue_.back()->parquet_export_snsrmtn(snsr_mtn.get());
}

void CANNodeReplay::UpdateParquet(std::shared_ptr<msg_live_addon::msg::MsgBlkgdebugType> blkg_data)
{
    parquet_queue_.back()->parquet_export_blkgdata(blkg_data.get());
}

void CANNodeReplay::UpdateParquet(std::shared_ptr<msg_can_addon::msg::MsgCanRadarInfoType> radar_info)
{
    parquet_queue_.back()->parquet_export_radarinfo(radar_info.get());
}

void CANNodeReplay::CloseFileHandles()
{
    if (rosbag_writer_)
    {
        rosbag_writer_->CloseFile();
    }

    while (!parquet_queue_.empty())
    {
        parquet_queue_.back()->write_parquet_file();
        if (parquet_queue_.front()->is_parquet_file_written())
        {
            parquet_queue_.pop();
        }
    }
}