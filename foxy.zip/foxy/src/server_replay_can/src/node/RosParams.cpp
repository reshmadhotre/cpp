
#include "RosParams.h"

namespace ROS_PARAM_NAMES
{

const std::string SENSOR_MOUNT_POS_X_PARAM = "sensor_position_x";
const std::string SENSOR_MOUNT_POS_Y_PARAM = "sensor_position_y";
const std::string SENSOR_MOUNT_POS_Z_PARAM = "sensor_position_z";
const std::string SENSOR_MOUNT_YAW_PARAM = "sensor_yaw";
const std::string SENSOR_MOUNT_PITCH_PARAM = "sensor_pitch";
const std::string SENSOR_MOUNT_ROLL_PARAM = "sensor_roll";

} // namespace ROS_PARAM_NAMES

namespace ROS_PARAM_NAMES_REPLAY_MODE
{
const std::string REPLAY_MF4_CAN_FILEPATHS = "replay_mf4_CAN_filepaths";
const std::string DBC_FILEPATH = "dbc_filepath";
const std::string RECORD_ROSBAGS = "record_rosbags";
const std::string PARAM_RECORD_PARQUETS = "param_record_output_parquets";
const std::string PUBLISH_CAN_OBJECT_LIST = "publish_can_obj_list";
const std::string PUBLISH_ROAD_BORDER_DATA = "publish_road_border_data";
const std::string STANDALONE_MODE = "standalone_mode";

} // namespace ROS_PARAM_NAMES_REPLAY_MODE

namespace ROS_PARAM_NAMES_LIVE_MODE
{

const std::string CAN_CHANNEL = "can_channel";
const std::string DBC_FILEPATH = "dbc_filepath";
const std::string RECORD_ROSBAGS = "record_rosbags";
const std::string ROSBAG_PATH = "rosbag_path";
const std::string RADAR_RUN = "radar_run";
const std::string RADAR_SYNC = "radar_sync";

} // namespace ROS_PARAM_NAMES_LIVE_MODE