#include "CANAdapter.h"

CANAdapter::CANAdapter(std::shared_ptr<rclcpp::Node> node) : node_(node)
{
    ros_param_util_ = std::make_shared<RosParamUtil>(node);
}

void CANAdapter::InitCANParser()
{
    if (FileExists(dbc_filepath_))
    {
        parser_factory_ = std::make_shared<ParserFactory>(dbc_filepath_);
        can_parser_initialized_ = true;
    }
}

void CANAdapter::SetMagna2RosConverter(std::shared_ptr<Magna2RosConverter> converter)
{
    magna_ros_converter_ = converter;
}

void CANAdapter::SetCANNode(std::shared_ptr<CANNode> can_node)
{
    can_node_ = can_node;
}

bool CANAdapter::ProcessFrameID(const uint32_t frame_id)
{
    return std::find(frame_ids_to_process_.begin(), frame_ids_to_process_.end(), frame_id) !=
           frame_ids_to_process_.end();
}

bool CANAdapter::FileExists(const std::string& file_path)
{
    struct stat buffer;
    return (stat(file_path.c_str(), &buffer) == 0);
}

std::string CANAdapter::RemoveExtensionFromFilePath(const std::string& file_path)
{
    size_t lastdot = file_path.find_last_of(".");
    if (lastdot == std::string::npos)
    {
        return file_path;
    }
    return file_path.substr(0, lastdot);
}