#include "RosTopics.h"

namespace ROS_PUBLISHER_TOPICS_LIVE_MODE
{
const std::string TOPIC_CAN_OBJ_DATA{"topic_can_objdata"};
const std::string TOPIC_CAN_RADAR_INFO{"topic_can_radar_info"};
const std::string TOPIC_CAN_ROADBORDER{"topic_can_road_border"};
} // namespace ROS_PUBLISHER_TOPICS_LIVE_MODE

namespace ROS_PUBLIHSER_TOPICS_REPLAY_MODE
{
const std::string TOPIC_CAN_RADAR_CAL_DATA{"topic_can_radar_cal_data"};
const std::string TOPIC_CAN_RADARCFG{"topic_can_radarcfg"};
const std::string TOPIC_CAN_RADAR_INFO{"topic_can_radarinfo"};
const std::string TOPIC_CAN_TSYNC{"topic_can_tsync"};
const std::string TOPIC_CAN_VEHDYN{"topic_can_vehdyn"};
const std::string TOPIC_CAN_OBJ_DATA{"topic_can_objdata"};
const std::string TOPIC_NODE_FEEDBACK{"topic_node_feedback"};
const std::string TOPIC_CAN_ROAD_BORDER{"topic_can_road_border"};
const std::string TOPIC_CAN_SNSR_MTN{"topic_can_snsr_mtn"};
const std::string TOPIC_CAN_VEH_MTN{"topic_can_veh_mtn"};
const std::string TOPIC_BLKG_DEBUG{"topic_can_blkgdebug"};

} // namespace ROS_PUBLIHSER_TOPICS_REPLAY_MODE

namespace ROS_SUBSCRIBER_TOPICS_REPLAY_MODE
{
const std::string TOPIC_NODE_FEEDBACK{"topic_node_feedback"};
const std::string TOPIC_TRIGGER_CAN_NEXT_FRAME{"topic_trigger_can_next_frame"};
const std::string TOPIC_SET_CAN_PAUSE_MODE{"topic_set_can_pause_mode"};
} // namespace ROS_SUBSCRIBER_TOPICS_REPLAY_MODE