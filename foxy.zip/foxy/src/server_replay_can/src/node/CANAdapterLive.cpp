#include "CANAdapterLive.h"
#include "FrameIDDefs.h"
#include "RosParams.h"
#include "can_peak.h"



#define delay_ms(x) std::this_thread::sleep_for(std::chrono::milliseconds(x));
#define delay_us(x) std::this_thread::sleep_for(std::chrono::microseconds(x));




CANAdapterLive::CANAdapterLive(std::shared_ptr<rclcpp::Node> node) : CANAdapter(node)
{
    InitROSParams();
    InitFrameIDsToProcess();
    InitCANParser();
    InitCANInterface();
    InitTimers();
}


void CANAdapterLive::ReadNextMessage()
{
    if (!can_parser_initialized_)
    {
        RCLCPP_INFO(node_->get_logger(), "CAN Parser is not initialized. Given DBC Path : %s", dbc_filepath_.c_str());
        return;
    }
    if (magna_ros_converter_ == nullptr)
    {
        RCLCPP_ERROR(node_->get_logger(), "Converter not set. Cannot publish ROS Messages after decode!!");
        return;
    }

    static CanIface::message can_msg;
    if (!can_interface_->read(can_msg, can_channel_))
    {
        return;
    }

    if (!can_msg.data.size())
    {
        RCLCPP_DEBUG(node_->get_logger(), "CAN data empty");
        return;
    }

    uint32_t frame_id = can_msg.id;
    if (!ProcessFrameID(frame_id))
    {
        RCLCPP_DEBUG(node_->get_logger(), "CAN frame ID not defined: %u", frame_id);
        return;
    }

    auto parser = parser_factory_->GetParser(frame_id);
    if (parser == nullptr)
    {
        RCLCPP_ERROR(node_->get_logger(), "Parser not available for CAN ID : %u", can_msg.id);
        return;
    }
    auto timestamp = node_->get_clock()->now();
    parser->Decode(can_msg.data);
    parser->AcceptROSConverter(*magna_ros_converter_.get(), timestamp.nanoseconds());
}


void CANAdapterLive::InitTimers()
{
    data_publish_timer_20ms_ =
        node_->create_wall_timer(std::chrono::milliseconds(20), std::bind(&CANAdapterLive::SendNextMessage_20ms, this));
    
    data_publish_timer_100ms_ =
        node_->create_wall_timer(std::chrono::milliseconds(100), std::bind(&CANAdapterLive::SendNextMessage_100ms, this));
}


void CANAdapterLive::SendNextMessage_20ms()
{
    if (can_interface_ != nullptr)
    {
        for(auto frame_id : list_frame_id_20ms)
            SendNextMessage(frame_id);
    }
}



void CANAdapterLive::SendNextMessage_100ms()
{
    if (can_interface_ != nullptr)
    {
        for(auto frame_id : list_frame_id_100ms)
            SendNextMessage(frame_id);
    }
}


void CANAdapterLive::SendNextMessage(uint16_t frame_id)
{
    if (!ProcessFrameID(frame_id))
    {
        RCLCPP_ERROR(node_->get_logger(), "Frame ID unknown: %u", frame_id);
        return;
    }

    auto parser = parser_factory_->GetParser(frame_id);

    // Be sure counter, crc and so on are updated
    parser->Update();

    // and publish
    can_interface_->write(can_channel_, frame_id, false, parser->encoded_data_); 

    /* ----------------------------------- */
    // std::string display{""};
    // char buffer[10];
    // static uint32_t cnt = 0;
    // if(cnt++ == 10)
    // {
    //     for(auto d : parser->encoded_data_)
    //     {
    //         sprintf(buffer, "%02x ", d);
    //         display += std::string(buffer);
    //     }
    //     RCLCPP_INFO(node_->get_logger(), "Encoded Tsync: %s", display.c_str());
    //     cnt = 0;
    // }
    /* ----------------------------------- */
}


void CANAdapterLive::InitROSParams()
{
    using namespace ROS_PARAM_NAMES_LIVE_MODE;

    param_callback_handle_ = node_->add_on_set_parameters_callback(
        std::bind(&CANAdapterLive::ParametersUpdateCB, this, std::placeholders::_1));

    ros_param_util_->DeclareParameter(CAN_CHANNEL, 0);
    ros_param_util_->DeclareParameter(DBC_FILEPATH, "");
    ros_param_util_->DeclareParameter(RADAR_RUN, false);
    ros_param_util_->DeclareParameter(RADAR_SYNC, false);

    can_channel_ = ros_param_util_->GetParameter(CAN_CHANNEL).as_int();
    dbc_filepath_ = ros_param_util_->GetParameter(DBC_FILEPATH).as_string();
    radar_run_ = ros_param_util_->GetParameter(RADAR_RUN).as_bool();
    radar_sync_ = ros_param_util_->GetParameter(RADAR_SYNC).as_bool();
}


rcl_interfaces::msg::SetParametersResult CANAdapterLive::ParametersUpdateCB(
    const std::vector<rclcpp::Parameter>& parameters)
{
    using namespace ROS_PARAM_NAMES_LIVE_MODE;

    rcl_interfaces::msg::SetParametersResult result;
    result.successful = true;
    result.reason = "success";

    for (const auto& parameter : parameters)
    {
        RCLCPP_INFO(node_->get_logger(), "Parameter name: %s", parameter.get_name().c_str());
        
        if (parameter.get_name() == RADAR_RUN)
        {
            if(parameter.get_type() == rclcpp::ParameterType::PARAMETER_BOOL)
            {
                radar_run_ = parameter.as_bool();
                if(radar_run_ )
                    RCLCPP_INFO(node_->get_logger(), "Parameter value: True");
                else
                    RCLCPP_INFO(node_->get_logger(), "Parameter value: False");
                StartStopRadar();
            }
            else
            {
                result.successful = false;
                result.reason = "Not defined as boolean";
            }
        }

        else if (parameter.get_name() == RADAR_SYNC)
        {
            if(parameter.get_type() == rclcpp::ParameterType::PARAMETER_BOOL)
            {
                radar_sync_ = parameter.as_bool();
                if(radar_sync_)
                    RCLCPP_INFO(node_->get_logger(), "Parameter value: True");
                else
                    RCLCPP_INFO(node_->get_logger(), "Parameter value: False");
                SynchronizeRadar(radar_sync_);
            }
            else
            {
                result.successful = false;
                result.reason = "Not defined as boolean";
            }
        }
    }

    return result;
}


void CANAdapterLive::StartStopRadar()
{
    if (can_interface_ != nullptr)
    {
        const uint32_t frame_id = RADAR_HYDRA3_PRIVATE_VEH_STATE_FRAME_ID;
        const std::string signal_name = "RadarCtrl";
        const uint8_t start = parser_factory_->CODE_RADAR_START;
        const uint8_t stop = parser_factory_->CODE_RADAR_STOP;
    
        if (!ProcessFrameID(frame_id))
        {
            RCLCPP_ERROR(node_->get_logger(), "Frame ID unknown: %u", frame_id);
            return;
        }

        // Set the value
        auto parser = parser_factory_->GetParser(frame_id);      
        if (radar_run_)
            parser->SetValue(signal_name, start);
        else
            parser->SetValue(signal_name, stop);
    }
}


void CANAdapterLive::SynchronizeRadar(bool reset)
{
    const uint32_t frame_id = RADAR_HYDRA3_PRIVATE_TSYNC_FRAME_ID;
        
    if (can_interface_ != nullptr)
    {
        if (!ProcessFrameID(frame_id))
        {
            RCLCPP_ERROR(node_->get_logger(), "Frame ID unknown: %u", frame_id);
            return;
        }

        // Set the value
        auto parser = parser_factory_->GetParser(frame_id);
        parser->SetValue("time_sync_reset", reset);
    }
}



void CANAdapterLive::InitFrameIDsToProcess()
{
    for (uint32_t frame_id = RADAR_HYDRA3_PRIVATE_OBJ_DATA_00_FRAME_ID;
         frame_id <= RADAR_HYDRA3_PRIVATE_OBJ_DATA_31_FRAME_ID; frame_id++)
    {
        frame_ids_to_process_.push_back(frame_id);
    }
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_RADAR_INFO_FRAME_ID);
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_ROAD_BORDER_FRAME_ID);
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_VEH_STATE_FRAME_ID);
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_TSYNC_FRAME_ID);

    std::sort(frame_ids_to_process_.begin(), frame_ids_to_process_.end());
}


void CANAdapterLive::InitCANInterface()
{
    can_interface_ = std::make_shared<CanPeak>();
    can_interface_->countAvailableChannels();
    num_available_can_channels_ = can_interface_->availableChannels();
    RCLCPP_INFO(node_->get_logger(), "Available channels: %u", num_available_can_channels_);
    RCLCPP_INFO(node_->get_logger(), "Selected channel: %u", can_channel_);

    auto frame_id_start = frame_ids_to_process_.front();
    auto frame_id_end = frame_ids_to_process_.back();

    can_interface_->initFD(can_channel_, CanIface::CanFDCfg::SAEJ2284_4_500k_2M);
    can_interface_->setListenOnly(can_channel_, true);
    can_interface_->filterID(can_channel_, frame_id_start, frame_id_end);
    delay_ms(100);

    // Init all available can channels
    // for (uint8_t channel_num = 0; channel_num < num_available_can_channels_; ++channel_num)
    // {
    //     can_interface_->initFD(channel_num, CanIface::CanFDCfg::SAEJ2284_4_500k_2M);
    //     can_interface_->setListenOnly(channel_num, true);
    //     can_interface_->filterID(channel_num, frame_id_start, frame_id_end);
    //     delay_ms(100);
    // }
}

