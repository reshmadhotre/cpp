#include "MDFUtil.h"

MDFUtil::MDFUtil(std::shared_ptr<rclcpp::Node> node) : node_(node)
{
    mdf_player_.RegisterListener(&replay_lib_);
}

MDFUtil::~MDFUtil()
{
    CloseMf4File();
}

void MDFUtil::OpenMf4File(const std::string& file_path)
{
    if (mf4_file_opened_)
    {
        CloseMf4File();
    }

    // replay_lib_.Reset();
    mf4_file_opened_ = mdf_player_.Open(file_path);
    if (mf4_file_opened_)
    {
        RCLCPP_INFO(node_->get_logger(), "Opened CAN mf4 file : %s", file_path.c_str());
    }
}

void MDFUtil::CloseMf4File()
{
    if (mf4_file_opened_)
    {
        mdf_player_.Close();
        mf4_file_opened_ = false;
    }
}

std::vector<mdfp::CanFDData_s> MDFUtil::ReadFile()
{
    std::vector<mdfp::CanFDData_s> can_data_list;

    while (mdf_player_.ReadNextMessage() != nullptr)
    {
        RCLCPP_DEBUG(node_->get_logger(), "Reading MF4 file ....");
    }

    std::queue<mdfp::CanFDData_s>& replay_can_data = replay_lib_.GetReplayCanData();

    if (replay_can_data.empty())
    {
        RCLCPP_INFO(node_->get_logger(), "No CAN messages present in the file!!!");
    }

    while(!replay_can_data.empty())
    {
        can_data_list.emplace_back(replay_can_data.front());
        replay_can_data.pop();
    }


    CloseMf4File();

    return can_data_list;
}