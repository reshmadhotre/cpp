#include "CANAdapterReplay.h"
#include "FrameIDDefs.h"
#include "RosParams.h"

CANAdapterReplay::CANAdapterReplay(std::shared_ptr<rclcpp::Node> node) : CANAdapter(node)
{
    InitROSParams();
    InitFrameIDsToProcess();
    InitCANParser();
    mdf_util_ = std::make_shared<MDFUtil>(node);

    /**
     * TODO : Enable when CAN message comparison is required
    sub_can_veh_adapter_output_ = node_->create_subscription<msg_can_fd::msg::Frame>(
        "topic_can", 10, std::bind(&CANAdapterReplay::CANVehAdapterOutputCB, this, std::placeholders::_1));
    **/
}

CANAdapterReplay::~CANAdapterReplay()
{
    CloseFileHandles();
}

void CANAdapterReplay::InitROSParams()
{
    using namespace ROS_PARAM_NAMES_REPLAY_MODE;
    std::vector<std::string> default_file_paths{};
    ros_param_util_->DeclareParameter(REPLAY_MF4_CAN_FILEPATHS, default_file_paths);
    ros_param_util_->DeclareParameter(DBC_FILEPATH, "");
    ros_param_util_->DeclareParameter(RECORD_ROSBAGS, false);
    ros_param_util_->DeclareParameter(PARAM_RECORD_PARQUETS, false);
    ros_param_util_->DeclareParameter(PUBLISH_CAN_OBJECT_LIST, false);
    ros_param_util_->DeclareParameter(PUBLISH_ROAD_BORDER_DATA, false);

    auto mf4_files_to_play = ros_param_util_->GetParameter(REPLAY_MF4_CAN_FILEPATHS).as_string_array();
    for (const auto& mf4_filepath : mf4_files_to_play)
    {
        mf4_files_queue_.push(mf4_filepath);
    }
    num_files_to_process_ = mf4_files_queue_.size();

    dbc_filepath_ = ros_param_util_->GetParameter(DBC_FILEPATH).as_string();
    record_rosbags_ = ros_param_util_->GetParameter(RECORD_ROSBAGS).as_bool();
    record_parquets_ = ros_param_util_->GetParameter(PARAM_RECORD_PARQUETS).as_bool();
    publish_can_obj_list_ = ros_param_util_->GetParameter(PUBLISH_CAN_OBJECT_LIST).as_bool();
    publish_road_border_data_ = ros_param_util_->GetParameter(PUBLISH_ROAD_BORDER_DATA).as_bool();
}

void CANAdapterReplay::InitFrameIDsToProcess()
{
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_RADAR_CAL_DATA_FRAME_ID);
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_RADAR_CFG_FRAME_ID);
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_RADAR_INFO_FRAME_ID);
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_TSYNC_FRAME_ID);
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_VEH_STATE_FRAME_ID);
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_WHL_STATE_FRAME_ID);
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_EGOMOTION_FRAME_ID);
    frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_BLOCKAGE_DEBUG_FRAME_ID);

    if (publish_can_obj_list_)
    {
        for (uint32_t frame_id = RADAR_HYDRA3_PRIVATE_OBJ_DATA_00_FRAME_ID;
             frame_id <= RADAR_HYDRA3_PRIVATE_OBJ_DATA_31_FRAME_ID; frame_id++)
        {
            frame_ids_to_process_.push_back(frame_id);
        }
    }

    if (publish_road_border_data_)
    {
        frame_ids_to_process_.push_back(RADAR_HYDRA3_PRIVATE_ROAD_BORDER_FRAME_ID);
    }
}

void CANAdapterReplay::StartReaderThread()
{
    continue_reading_.store(true);
    reader_thread_ = std::thread(&CANAdapterReplay::ReadWorker, this);
}

void CANAdapterReplay::StopReaderThread()
{
    continue_reading_.store(false);
    if (reader_thread_.joinable())
    {
        reader_thread_.join();
    }
}

void CANAdapterReplay::ReadWorker()
{
    while (!end_of_mf4_files_ && continue_reading_.load())
    {
        ReadNextFile();
    }
    can_node_->CloseFileHandles();
    return;
}

void CANAdapterReplay::ReadNextFile()
{

    if (mf4_files_queue_.empty())
    {
        end_of_mf4_files_ = true;
        can_node_->CloseFileHandles();
        return;
    }

    std::string next_mf4_file = mf4_files_queue_.front();
    mf4_files_queue_.pop();

    if (!FileExists(next_mf4_file))
    {
        RCLCPP_ERROR(node_->get_logger(), "File doesn't exist : %s", next_mf4_file.c_str());
        return;
    }

    mdf_util_->OpenMf4File(next_mf4_file);
    opened_mf4_file_path_ = next_mf4_file;
    num_files_processed_ = num_files_to_process_ - mf4_files_queue_.size();
    end_of_mf4_files_ = mf4_files_queue_.empty();

    if (record_rosbags_)
    {
        std::string rosbag_path = RemoveExtensionFromFilePath(next_mf4_file) + ".ros2bag";
        rosbag_writer_.reset();
        rosbag_writer_ = std::make_shared<RosbagWriter>(rosbag_path, "");

        if (rosbag_writer_->OpenFile())
        {
            can_node_->SetRosbagWriter(rosbag_writer_);
        }
    }

    if (record_parquets_)
    {
        auto parquet_exporter = std::make_unique<ParquetExportSkelgen>();
        parquet_exporter->set_filename(next_mf4_file);
        can_node_->SetParquetExporter(std::move(parquet_exporter));
    }

    std::vector<mdfp::CanFDData_s> replay_can_data = mdf_util_->ReadFile();

    if (replay_can_data.empty())
    {
        RCLCPP_INFO(node_->get_logger(), "No CAN messages present in the file!!!");
        return;
    }

    auto num_frames = replay_can_data.size();
    for (size_t index = 0; index < num_frames; index++)
    {
        bool end_of_replay = end_of_mf4_files_ && (index == num_frames - 1);
        ProcessCANFrame(replay_can_data.at(index), end_of_replay);
    }
}

void CANAdapterReplay::ProcessCANFrame(const mdfp::CanFDData_s& can_data, bool end_of_replay)
{
    if (!can_parser_initialized_)
    {
        RCLCPP_ERROR(node_->get_logger(), "CAN Parser is not initialized. Given DBC Path : %s", dbc_filepath_.c_str());
        return;
    }
    if (magna_ros_converter_ == nullptr)
    {
        RCLCPP_ERROR(node_->get_logger(), "Converter not set. Cannot publish ROS Messages after decode!!");
        return;
    }

    uint32_t frame_id = can_data.Id;

    if (!ProcessFrameID(frame_id))
    {
        return;
    }

    auto parser = parser_factory_->GetParser(frame_id);
    if (parser == nullptr)
    {
        RCLCPP_DEBUG(node_->get_logger(), "Parser not defined for Frame ID : %lu", (unsigned long)can_data.Id);
        return;
    }

    parser->Decode(can_data.Payload);
    parser->AcceptROSConverter(*magna_ros_converter_.get(), can_data.TimesStamp);
    SendNodeFeedbackMsg(can_data.TimesStamp, end_of_replay);
}

void CANAdapterReplay::SendNodeFeedbackMsg(int64_t timestamp, bool end_of_replay)
{
    auto feedback_msg = std::make_shared<msg_swc_common::msg::MsgNodeFeedbackType>();
    feedback_msg->header.stamp = rclcpp::Time(timestamp);
    feedback_msg->num_files_to_process = num_files_to_process_;
    feedback_msg->num_files_processed = num_files_processed_;
    feedback_msg->file_under_process = opened_mf4_file_path_;
    feedback_msg->radar_timestamp = timestamp;

    if (end_of_replay)
    {
        feedback_msg->status = msg_swc_common::msg::MsgNodeFeedbackType::FINISHED;
    }
    else
    {
        feedback_msg->status = msg_swc_common::msg::MsgNodeFeedbackType::IN_PROGRESS;
    }

    can_node_->AddFeedbackMessage(feedback_msg, timestamp);
}

void CANAdapterReplay::CloseFileHandles()
{
    mdf_util_->CloseMf4File();
    can_node_->CloseFileHandles();
    // if (rosbag_writer_)
    // {
    //     rosbag_writer_->CloseFile();
    // }
}

/**
 * TODO : Enable when CAN message comparison is required
void CANAdapterReplay::CANVehAdapterOutputCB(msg_can_fd::msg::Frame::UniquePtr msg)
{
    CompareCANFrame(std::move(msg));
}
**/

/**
 * TODO : Enable when CAN message comparison is required
void CANAdapterReplay::CompareCANFrame(msg_can_fd::msg::Frame::UniquePtr msg)
{
    auto timestamp = msg->header.stamp.nanosec;
    bool mdf_contains_timestamp = can_frames_map_.HasTimestamp(timestamp);

    if (!mdf_contains_timestamp)
    {
        RCLCPP_INFO(node_->get_logger(), "[CAN DATA COMPARE] Timestamp : %f not found in mdf data.", (double)timestamp);
        return;
    }

    auto mdf_can_data = can_frames_map_.GetCanData(timestamp);

    // Check if dlc is equal
    bool dlc_matches = msg->dlc == mdf_can_data.Length;
    if (!dlc_matches)
    {
        RCLCPP_INFO(node_->get_logger(), "[CAN DATA COMPARE] Timestamp : %f. DLC does not match with mdf data.",
                    (double)timestamp);
        return;
    }

    // Check if Frame ID is equal
    bool frameID_matches = msg->id == mdf_can_data.Id;
    if (!frameID_matches)
    {
        RCLCPP_INFO(node_->get_logger(), "[CAN DATA COMPARE] Timestamp : %f. Frame ID does not match with mdf data.",
                    (double)timestamp);
        return;
    }

    // Check if payload is equal
    bool payload_matches{true};
    for (int index = 0; index < mdf_can_data.Length; index++)
    {
        if (msg->data[index] != mdf_can_data.Payload[index])
        {
            payload_matches = false;
            break;
        }
    }

    if (!payload_matches)
    {
        RCLCPP_INFO(node_->get_logger(), "[CAN DATA COMPARE] Timestamp : %f. Payload does not match with mdf data.",
                    (double)timestamp);
        return;
    }

    RCLCPP_INFO(node_->get_logger(), "[CAN DATA COMPARE] Timestamp : %f. CAN data matches.", (double)timestamp);
    return;
}
**/