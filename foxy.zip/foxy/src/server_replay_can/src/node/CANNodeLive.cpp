#include "CANNodeLive.h"
#include "FrameIDDefs.h"
#include "RosParams.h"
#include "RosTopics.h"

const uint8_t CANNodeLive::DEFAULT_HISTORY_DEPTH = 10;
const uint32_t CANNodeLive::OBJ_DATA_FRAME_ID_START = RADAR_HYDRA3_PRIVATE_OBJ_DATA_00_FRAME_ID;
const uint32_t CANNodeLive::OBJ_DATA_FRAME_ID_END = RADAR_HYDRA3_PRIVATE_OBJ_DATA_31_FRAME_ID;

CANNodeLive::CANNodeLive(std::shared_ptr<rclcpp::Node> node) : CANNode(node)
{
    InitROSParams();
    InitPublishers();
    InitSubscribers();
    InitTimers();

    if (record_rosbags_)
    {
        InitRosbagWriter();
    }
}

void CANNodeLive::InitROSParams()
{
    using namespace ROS_PARAM_NAMES_LIVE_MODE;
    ros_param_util_->DeclareParameter(RECORD_ROSBAGS, false);
    ros_param_util_->DeclareParameter(ROSBAG_PATH, "");

    record_rosbags_ = ros_param_util_->GetParameter(RECORD_ROSBAGS).as_bool();
    if (record_rosbags_)
    {
        rosbag_path_ = ros_param_util_->GetParameter(ROSBAG_PATH).as_string();
    }
}

void CANNodeLive::InitPublishers()
{
    using namespace ROS_PUBLISHER_TOPICS_LIVE_MODE;
    can_object_list_publisher_ = std::make_shared<RosPublisher<msg_live_addon::msg::MsgCanObjListType>>(
        node_, TOPIC_CAN_OBJ_DATA, DEFAULT_HISTORY_DEPTH);

    can_radar_info_publisher_ = std::make_shared<RosPublisher<msg_can_addon::msg::MsgCanRadarInfoType>>(
        node_, TOPIC_CAN_RADAR_INFO, DEFAULT_HISTORY_DEPTH);

    road_border_publisher_ = std::make_shared<RosPublisher<msg_live_addon::msg::MsgRoadborderType>>(
        node_, TOPIC_CAN_ROADBORDER, DEFAULT_HISTORY_DEPTH);
}

void CANNodeLive::InitSubscribers()
{
}

void CANNodeLive::InitTimers()
{
}

void CANNodeLive::InitRosbagWriter()
{
    std::string full_rosbag_path = rosbag_path_ + "/" + GetRosbagName();
    rosbag_writer_.reset();
    rosbag_writer_ = std::make_shared<RosbagWriter>(full_rosbag_path, "");
    rosbag_writer_->OpenFile();
}

std::string CANNodeLive::GetRosbagName()
{
    using namespace std::chrono;
    auto now = system_clock::now();
    std::time_t now_c = system_clock::to_time_t(now);
    struct std::tm* parts = std::localtime(&now_c);

    std::stringstream rosbag_name;

    rosbag_name << "CAN"
                << "_";
    rosbag_name << (1900 + parts->tm_year) << (1 + parts->tm_mon) << parts->tm_mday << "_";
    rosbag_name << parts->tm_hour << parts->tm_min << parts->tm_sec << "_";
    rosbag_name << node_->get_namespace() << ".ros2bag";

    return rosbag_name.str();
}

void CANNodeLive::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                std::shared_ptr<msg_can_addon::msg::MsgCanRadarInfoType> ros_radar_info)
{
    current_radar_info_ = ros_radar_info;
    can_radar_info_publisher_->PublishMessage(ros_radar_info);

    if (rosbag_writer_)
    {
        rosbag_writer_->Write(ros_radar_info.get(), rclcpp::Time(timestamp));
    }
}

void CANNodeLive::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                std::shared_ptr<msg_live_addon::msg::MsgCanObjType> ros_can_obj_data)
{
    static std::shared_ptr<msg_live_addon::msg::MsgCanObjListType> can_obj_list;

    if (current_radar_info_ == nullptr)
    {
        RCLCPP_INFO(node_->get_logger(), "Waiting for Radar Info Can Message to update Object list header.");
        return;
    }

    if (frame_id == OBJ_DATA_FRAME_ID_START)
    {
        can_obj_list = std::make_shared<msg_live_addon::msg::MsgCanObjListType>();
    }

    if (can_obj_list != nullptr)
    {
        can_obj_list->obj_arr.at(frame_id - OBJ_DATA_FRAME_ID_START) = *ros_can_obj_data.get();

        if (frame_id == OBJ_DATA_FRAME_ID_END)
        {
            can_obj_list->header.stamp = rclcpp::Time(timestamp);
            can_obj_list->header.frame_id = node_namespace_;

            auto& r_header = can_obj_list->r_header;
            r_header.num_obj = current_radar_info_->number_of_objects;
            r_header.timestamp = current_radar_info_->object_timestamp_sec;
            r_header.timestamp_n_sec = current_radar_info_->object_timestamp_n_sec;
            r_header.scan_id = current_radar_info_->radar_scan_id;

            can_object_list_publisher_->PublishMessage(can_obj_list);

            if (rosbag_writer_)
            {
                rosbag_writer_->Write(can_obj_list.get(), rclcpp::Time(timestamp));
            }
        }
    }
}

void CANNodeLive::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                                std::shared_ptr<msg_live_addon::msg::MsgRoadborderType> road_border)
{
    road_border_publisher_->PublishMessage(road_border);

    if (rosbag_writer_)
    {
        rosbag_writer_->Write(road_border.get(), rclcpp::Time(timestamp));
    }
}