#include "Magna2RosConverter.h"
#include "BlockageParser.h"
#include "CalDataParser.h"
#include "EgoMotionParser.h"
#include "ObjectDataParser.h"
#include "RadarCfgParser.h"
#include "RadarInfoParser.h"
#include "RoadBorderParser.h"
#include "TSyncParser.h"
#include "VehicleStateDataParser.h"
#include "WheelStateDataParser.h"

const float Magna2RosConverter::G_MPS2 = 9.80665F;
const float Magna2RosConverter::DEG_TO_RAD = 0.0174532924F;
const float Magna2RosConverter::KMPH_TO_MPS = 0.277777791F;

Magna2RosConverter::Magna2RosConverter()
{
}

void Magna2RosConverter::SetCANNode(std::shared_ptr<CANNode> can_node)
{
    can_node_ = can_node;
}

void Magna2RosConverter::Convert(const CalDataParser& cal_data_parser, const int64_t timestamp) const
{
    auto decoded_data = cal_data_parser.GetDecodedData();
    auto frame_id = cal_data_parser.GetFrameID();

    auto radar_cal_data = std::make_shared<msg_can_addon::msg::MsgCanRadarCalDataType>();
    rclcpp::Time ros_time(timestamp);
    radar_cal_data->header.stamp = ros_time;
    radar_cal_data->ocal_rotation_matrix_roll_ag = decoded_data->ocal_rotation_matrix_roll_ag;
    radar_cal_data->ocal_rotation_matrix_pitch_ag = decoded_data->ocal_rotation_matrix_pitch_ag;
    radar_cal_data->ocal_rotation_matrix_yaw_ag = decoded_data->ocal_rotation_matrix_yaw_ag;
    radar_cal_data->ocal_rotation_matrix_pitch_ag_std_dev = decoded_data->ocal_rotation_matrix_pitch_ag_std_dev;
    radar_cal_data->ocal_rotation_matrix_roll_ag_std_dev = decoded_data->ocal_rotation_matrix_roll_ag_std_dev;
    radar_cal_data->ocal_rotation_matrix_yaw_ag_std_dev = decoded_data->ocal_rotation_matrix_yaw_ag_std_dev;

    if (can_node_)
    {
        can_node_->AddRosMessage(frame_id, timestamp, radar_cal_data);
    }
}

void Magna2RosConverter::Convert(const ObjectDataParser& object_data_parser, const int64_t timestamp) const
{
    auto decoded_data = object_data_parser.GetDecodedData();
    auto frame_id = object_data_parser.GetFrameID();

    auto can_obj_data = std::make_shared<msg_live_addon::msg::MsgCanObjType>();
    can_obj_data->crc_obj_data = decoded_data->crc_obj_data;
    can_obj_data->mc_obj_data = decoded_data->mc_obj_data;
    can_obj_data->object_id = decoded_data->object_id;
    can_obj_data->object_fu_sa_level = decoded_data->object_fu_sa_level;
    can_obj_data->object_meas_status = decoded_data->object_meas_status;
    can_obj_data->object_confidence = decoded_data->object_confidence;
    can_obj_data->object_age = decoded_data->object_age;
    can_obj_data->object_motion_st = decoded_data->object_motion_st;

    can_obj_data->object_distance_x = decoded_data->object_distance_x;
    can_obj_data->object_distance_std_dev_x = decoded_data->object_distance_std_dev_x;
    can_obj_data->object_distance_y = decoded_data->object_distance_y;
    can_obj_data->object_distance_std_dev_y = decoded_data->object_distance_std_dev_y;
    can_obj_data->object_distance_cov_xy = decoded_data->object_distance_cov_xy;

    can_obj_data->object_rel_velocity_x = decoded_data->object_rel_velocity_x;
    can_obj_data->object_rel_velocity_y = decoded_data->object_rel_velocity_y;
    can_obj_data->object_rel_velocity_std_dev_x = decoded_data->object_rel_velocity_std_dev_x;
    can_obj_data->object_rel_velocity_std_dev_y = decoded_data->object_rel_velocity_std_dev_y;
    can_obj_data->object_rel_velocity_cov_xy = decoded_data->object_rel_velocity_cov_xy;

    can_obj_data->object_rel_acceleration_x = decoded_data->object_rel_acceleration_x;
    can_obj_data->object_rel_acceleration_std_dev_x = decoded_data->object_rel_acceleration_std_dev_x;
    can_obj_data->object_rel_acceleration_y = decoded_data->object_rel_acceleration_y;
    can_obj_data->object_rel_acceleration_std_dev_y = decoded_data->object_rel_acceleration_std_dev_y;
    can_obj_data->object_rel_acceleration_cov_xy = decoded_data->object_rel_acceleration_cov_xy;

    can_obj_data->object_ref_point = decoded_data->object_ref_point;

    can_obj_data->object_yaw_angle = decoded_data->object_yaw_angle;
    can_obj_data->object_yaw_angle_std_dev = decoded_data->object_yaw_angle_std_dev;
    can_obj_data->object_yaw_rate = decoded_data->object_yaw_rate;
    can_obj_data->object_yaw_rate_std_dev = decoded_data->object_yaw_rate_std_dev;

    can_obj_data->object_width = decoded_data->object_width;
    can_obj_data->object_width_st = decoded_data->object_width_st;
    can_obj_data->object_width_std_dev = decoded_data->object_width_std_dev;

    can_obj_data->object_length = decoded_data->object_length;
    can_obj_data->object_length_st = decoded_data->object_length_st;
    can_obj_data->object_length_std_dev = decoded_data->object_length_std_dev;

    can_obj_data->object_class = decoded_data->object_class;
    can_obj_data->object_class_confidence = decoded_data->object_class_confidence;

    can_obj_data->object_rcs = decoded_data->object_rcs;

    can_obj_data->object_over_under_drivable = decoded_data->object_over_under_drivable;
    can_obj_data->object_over_under_driveable_conf = decoded_data->object_over_under_driveable_conf;

    can_obj_data->scan_id = decoded_data->scan_id;
    can_obj_data->mac_object_data = decoded_data->mac_object_data;

    if (can_node_)
    {
        can_node_->AddRosMessage(frame_id, timestamp, can_obj_data);
    }
}

void Magna2RosConverter::Convert(const RadarCfgParser& radar_cfg_parser, const int64_t timestamp) const
{
    auto decoded_data = radar_cfg_parser.GetDecodedData();
    auto frame_id = radar_cfg_parser.GetFrameID();

    auto radar_cfg = std::make_shared<msg_can_addon::msg::MsgRadarcfgType>();
    radar_cfg->header.stamp = rclcpp::Time(timestamp);
    msg_can_addon::msg::MsgGenCoor3dType radar_position;
    radar_position.x = decoded_data->radar_pos_x;
    radar_position.y = decoded_data->radar_pos_y;
    radar_position.z = decoded_data->radar_pos_z;

    msg_can_addon::msg::MsgGenRotationMatrixType radar_orientation;
    radar_orientation.yaw = decoded_data->radar_angl_azimuth;
    radar_orientation.pitch = decoded_data->radar_angl_elevation;
    radar_orientation.roll = decoded_data->radar_angl_roll;

    radar_cfg->act_position = radar_position;
    radar_cfg->nom_position = radar_position;

    radar_cfg->act_orientation = radar_orientation;
    radar_cfg->nom_orientation = radar_orientation;

    radar_cfg->radar_role = decoded_data->radar_role_config;
    radar_cfg->func_arr = decoded_data->radar_func_cfg;

    if (can_node_)
    {
        can_node_->AddRosMessage(frame_id, timestamp, radar_cfg);
    }
}

void Magna2RosConverter::Convert(const RadarInfoParser& radar_info_parser, const int64_t timestamp) const
{

    auto decoded_data = radar_info_parser.GetDecodedData();
    auto frame_id = radar_info_parser.GetFrameID();

    auto radar_info = std::make_shared<msg_can_addon::msg::MsgCanRadarInfoType>();
    radar_info->header.stamp = rclcpp::Time(timestamp);
    radar_info->crc_radar_info = decoded_data->crc_radar_info;
    radar_info->mc_radar_info = decoded_data->mc_radar_info;
    radar_info->mrr_timestamp_sec = decoded_data->mrr_timestamp_sec;
    radar_info->mrr_timestamp_n_sec = decoded_data->mrr_timestamp_n_sec;
    radar_info->mrr_timesync_status = decoded_data->mrr_timesync_status;
    radar_info->blockage_status = decoded_data->blockage_status;
    radar_info->blockage_prob = decoded_data->blockage_prob;
    radar_info->safety_distance = decoded_data->safety_distance;
    radar_info->tunnel_presence = decoded_data->tunnel_presence;
    radar_info->tunnel_distance = decoded_data->tunnel_distance;
    radar_info->tunnel_prob = decoded_data->tunnel_prob;
    radar_info->object_timestamp_sec = decoded_data->object_timestamp_sec;
    radar_info->object_timestamp_n_sec = decoded_data->object_timestamp_n_sec;
    radar_info->radar_scan_id = decoded_data->radar_scan_id;
    radar_info->number_of_objects = decoded_data->number_of_objects;
    radar_info->mac_radar_info = decoded_data->mac_radar_info;

    if (can_node_)
    {
        can_node_->AddRosMessage(frame_id, timestamp, radar_info);
    }
}

void Magna2RosConverter::Convert(const TSyncParser& tsync_parser, const int64_t timestamp) const
{

    auto decoded_data = tsync_parser.GetDecodedData();
    auto frame_id = tsync_parser.GetFrameID();

    auto tsync = std::make_shared<msg_can_addon::msg::MsgCanTsyncType>();
    tsync->header.stamp = rclcpp::Time(timestamp);

    tsync->can_t_syn_type = decoded_data->can_t_syn_type;
    tsync->can_t_syn_crc = decoded_data->can_t_syn_crc;
    tsync->can_t_syn_d = decoded_data->can_t_syn_d;
    tsync->can_t_syn_sc = decoded_data->can_t_syn_sc;
    tsync->can_t_syn_rsvrd0 = decoded_data->can_t_syn_rsvrd0;
    tsync->can_t_syn_usb0 = decoded_data->can_t_syn_usb0;
    tsync->can_t_syn_fup_sgw = decoded_data->can_t_syn_fup_sgw;
    tsync->can_t_syn_ovs = decoded_data->can_t_syn_ovs;
    tsync->can_t_syn_sync_time_n_sec = decoded_data->can_t_syn_sync_time_n_sec;
    tsync->can_t_syn_sync_time_sec = decoded_data->can_t_syn_sync_time_sec;

    if (can_node_)
    {
        can_node_->AddRosMessage(frame_id, timestamp, tsync);
    }
}

void Magna2RosConverter::Convert(const VehicleStateDataParser& vehicle_state_data_parser, const int64_t timestamp) const
{
    /*
        Adapted from MEVehInpAdprScp.c (Repository : L2H5008_Sabine_SA80NFE20T)
     */

    auto decoded_data = vehicle_state_data_parser.GetDecodedData();
    auto frame_id = vehicle_state_data_parser.GetFrameID();

    auto veh_dyn_data = std::make_shared<msg_can_addon::msg::MsgVehdynType>();
    veh_dyn_data->header.stamp = rclcpp::Time(timestamp);

    float veh_speed = decoded_data->veh_speed;
    uint8_t veh_mtn_st = decoded_data->veh_motion_st;

    // VEH_A_COOR
    veh_dyn_data->veh_a_coor.ax = decoded_data->veh_accel;
    veh_dyn_data->veh_a_coor.ay = 0.0F;
    veh_dyn_data->veh_a_coor.az = 0.0F;

    // GLB_A_COOR
    veh_dyn_data->glb_a_coor.ax = G_MPS2 * decoded_data->veh_accel_x;
    veh_dyn_data->glb_a_coor.ay = -1.0f * G_MPS2 * decoded_data->veh_accel_y;
    veh_dyn_data->glb_a_coor.ay = 0.0F;

    // YAW_RATE
    veh_dyn_data->yaw_rate = -1.0F * DEG_TO_RAD * decoded_data->veh_yaw_rate;

    // VEH_DYN_ST, VEH_SPD
    switch (veh_mtn_st)
    {
    case RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_MOTION_ST_VEH_MOTION_ST_STANDING_CHOICE:
        veh_dyn_data->veh_dyn_st = VEHDYN_ST_STOPPED;
        veh_speed = 0.0F;
        break;

    case RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_MOTION_ST_VEH_MOTION_ST_MOVING_FWD_CHOICE:
        veh_dyn_data->veh_dyn_st = VEHDYN_ST_DRVNG_FWD;
        veh_speed = KMPH_TO_MPS * veh_speed;
        break;

    case RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_MOTION_ST_VEH_MOTION_ST_MOVING_BWD_CHOICE:
        veh_dyn_data->veh_dyn_st = VEHDYN_ST_DRVNG_BKWD;
        veh_speed = -1.0F * KMPH_TO_MPS * veh_speed;
        break;

    case RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_MOTION_ST_VEH_MOTION_ST_ERR_CHOICE:
        veh_dyn_data->veh_dyn_st = VEHDYN_ST_UNKNOWN;
        veh_speed = 0.0F;
        break;

    case RADAR_HYDRA3_PRIVATE_VEH_STATE_VEH_MOTION_ST_VEH_MOTION_ST_SNA_CHOICE:
        veh_dyn_data->veh_dyn_st = VEHDYN_ST_UNKNOWN;
        veh_speed = 0.0F;
        break;

    default:
        veh_dyn_data->veh_dyn_st = VEHDYN_ST_UNKNOWN;
        veh_speed = 0.0F;
        break;
    }

    // VEH_V_COOR
    veh_dyn_data->veh_v_coor.vx = veh_speed;
    veh_dyn_data->veh_v_coor.vy = 0.0F;
    veh_dyn_data->veh_v_coor.vz = 0.0F;

    // GLB_V_COOR
    veh_dyn_data->glb_v_coor.vx = veh_speed;
    veh_dyn_data->glb_v_coor.vy = 0.0F;
    veh_dyn_data->glb_v_coor.vz = 0.0F;

    // TODO ROAD_GRDT
    veh_dyn_data->road_grdt = 0.0F;

    if (can_node_)
    {
        can_node_->AddRosMessage(frame_id, timestamp, veh_dyn_data);
    }
}

void Magna2RosConverter::Convert(const WheelStateDataParser& wheel_state_data_parser, const int64_t timestamp) const
{
    (void)wheel_state_data_parser;
    (void)timestamp;
}

void Magna2RosConverter::Convert(const RoadBorderParser& road_border_parser, const int64_t timestamp) const
{
    auto decoded_data = road_border_parser.GetDecodedData();
    auto frame_id = road_border_parser.GetFrameID();

    auto road_border_data = std::make_shared<msg_live_addon::msg::MsgRoadborderType>();
    road_border_data->header.stamp = rclcpp::Time(timestamp);
    road_border_data->header.frame_id = "map";

    auto& road_border_left = road_border_data->road_border_left;
    road_border_left.angle_tan = std::tan(decoded_data->road_border_angle_lt); // TODO : verify if this is true
    road_border_left.c0 = decoded_data->road_border_initial_curvature_lt;
    road_border_left.c10 = decoded_data->road_border_initial_curvature_grad_lt;
    road_border_left.c11 = decoded_data->road_border_second_curvature_grad_lt;
    road_border_left.confidence = decoded_data->road_border_confidence_lt;
    road_border_left.offset_x = decoded_data->road_border_offset_x_lt;
    road_border_left.offset_y = decoded_data->road_border_offset_y_lt;
    road_border_left.range0 = decoded_data->road_border_transition_point_lt;
    road_border_left.range_max = decoded_data->road_border_max_range_lt;
    road_border_left.status = decoded_data->road_border_st_lt;

    auto& road_border_right = road_border_data->road_border_right;
    road_border_right.angle_tan = std::tan(decoded_data->road_border_angle_rt); // TODO : verify if this is true
    road_border_right.c0 = decoded_data->road_border_initial_curvature_rt;
    road_border_right.c10 = decoded_data->road_border_initial_curvature_grad_rt;
    road_border_right.c11 = decoded_data->road_border_second_curvature_grad_rt;
    road_border_right.confidence = decoded_data->road_border_confidence_rt;
    road_border_right.offset_x = decoded_data->road_border_offset_x_rt;
    road_border_right.offset_y = decoded_data->road_border_offset_y_rt;
    road_border_right.range0 = decoded_data->road_border_transition_point_rt;
    road_border_right.range_max = decoded_data->road_border_max_range_rt;
    road_border_right.status = decoded_data->road_border_st_rt;

    if (can_node_)
    {
        can_node_->AddRosMessage(frame_id, timestamp, road_border_data);
    }
}

void Magna2RosConverter::Convert(const EgoMotionParser& ego_motion_parser, const int64_t timestamp) const
{
    auto decoded_data = ego_motion_parser.GetDecodedData();
    auto frame_id = ego_motion_parser.GetFrameID();

    auto ego_motion_data = std::make_shared<msg_live_addon::msg::MsgSensrmtnType>();
    ego_motion_data->header.stamp = rclcpp::Time(timestamp);
    ego_motion_data->header.frame_id = "map";

    ego_motion_data->snsr_mtn_data.a.ax = decoded_data->ego_motion_ax;
    ego_motion_data->snsr_mtn_data.a.ay = decoded_data->ego_motion_ay;
    ego_motion_data->snsr_mtn_data.a.az = decoded_data->ego_motion_az;

    ego_motion_data->snsr_mtn_data.a_estimn_st = decoded_data->ego_motion_a_st;

    ego_motion_data->snsr_mtn_data.a_std_de.ax = decoded_data->ego_motion_ax_std_dev;
    ego_motion_data->snsr_mtn_data.a_std_de.ay = decoded_data->ego_motion_ay_std_dev;
    ego_motion_data->snsr_mtn_data.a_std_de.az = decoded_data->ego_motion_az_std_dev;

    ego_motion_data->snsr_mtn_data.crv_rd = decoded_data->ego_motion_crv_rd;
    ego_motion_data->snsr_mtn_data.crv_rd_st = decoded_data->ego_motion_crv_rd_st;
    ego_motion_data->snsr_mtn_data.crv_rd_std_de = decoded_data->ego_motion_crv_rd_std_dev;

    ego_motion_data->snsr_mtn_data.v.vx = decoded_data->ego_motion_vx;
    ego_motion_data->snsr_mtn_data.v.vy = decoded_data->ego_motion_vy;
    ego_motion_data->snsr_mtn_data.v.vz = decoded_data->ego_motion_vz;

    ego_motion_data->snsr_mtn_data.v_estimn_st = decoded_data->ego_motion_v_st;

    ego_motion_data->snsr_mtn_data.v_std_de.vx = decoded_data->ego_motion_vx_std_dev;
    ego_motion_data->snsr_mtn_data.v_std_de.vy = decoded_data->ego_motion_vy_std_dev;
    ego_motion_data->snsr_mtn_data.v_std_de.vz = decoded_data->ego_motion_vz_std_dev;

    ego_motion_data->snsr_mtn_data.yaw_rate = decoded_data->ego_motion_yaw_rate;
    ego_motion_data->snsr_mtn_data.yaw_rate_st = decoded_data->ego_motion_yaw_rate_st;
    ego_motion_data->snsr_mtn_data.yaw_rate_std_de = decoded_data->ego_motion_yaw_rate_std_dev;

    if (can_node_)
    {
        can_node_->AddRosMessage(frame_id, timestamp, ego_motion_data);
    }
}

void Magna2RosConverter::Convert(const BlockageParser& blkg_parser, const int64_t timestamp) const
{
    auto decoded_msg = blkg_parser.GetDecodedData();
    auto frame_id = blkg_parser.GetFrameID();

    auto blkg_data = std::make_shared<msg_live_addon::msg::MsgBlkgdebugType>();
    blkg_data->header.stamp = rclcpp::Time(timestamp);
    blkg_data->header.frame_id = "map";

    blkg_data->blkg_active = decoded_msg->blkg_active;
    blkg_data->blkg_conf = decoded_msg->blkg_conf;
    blkg_data->blkg_deactivate_dist_count = decoded_msg->blkg_deactivate_dist_count;
    blkg_data->blkg_deactivate_obj_loss = decoded_msg->blkg_deactivate_obj_loss;
    blkg_data->blkg_deactivate_range = decoded_msg->blkg_deactivate_range;
    blkg_data->blkg_deactivate_time_count = decoded_msg->blkg_deactivate_time_count;
    blkg_data->blkg_detection_ratio_mean = decoded_msg->blkg_detection_ratio_mean;
    blkg_data->blkg_detection_ratio_mov = decoded_msg->blkg_detection_ratio_mov;
    blkg_data->blkg_detection_ratio_static = decoded_msg->blkg_detection_ratio_static;
    blkg_data->blkg_dist_count = decoded_msg->blkg_dist_count;
    blkg_data->blkg_fl_conf = decoded_msg->blkg_fl_conf;
    blkg_data->blkg_fl_mean = decoded_msg->blkg_fl_mean;
    blkg_data->blkg_mov_max = decoded_msg->blkg_mov_max;
    blkg_data->blkg_mov_mean = decoded_msg->blkg_mov_mean;
    blkg_data->blkg_mov_mean_conf = decoded_msg->blkg_mov_mean_conf;
    blkg_data->blkg_obj_loss_conf = decoded_msg->blkg_obj_loss_conf;
    blkg_data->blkg_obj_loss_prob = decoded_msg->blkg_obj_loss_prob;
    blkg_data->blkg_range_conf = decoded_msg->blkg_range_conf;
    blkg_data->blkg_range_max = decoded_msg->blkg_range_max;
    blkg_data->blkg_range_mean = decoded_msg->blkg_range_mean;
    blkg_data->blkg_range_prob = decoded_msg->blkg_range_prob;
    blkg_data->blkg_st_max = decoded_msg->blkg_st_max;
    blkg_data->blkg_st_mean = decoded_msg->blkg_st_mean;
    blkg_data->blkg_st_mean_conf = decoded_msg->blkg_st_mean_conf;
    blkg_data->blkg_time_count = decoded_msg->blkg_time_count;
    blkg_data->blkg_time_dist_count_conf = decoded_msg->blkg_time_dist_count_conf;
    blkg_data->blkg_time_dist_count_prob = decoded_msg->blkg_time_dist_count_prob;

    if (can_node_)
    {
        can_node_->AddRosMessage(frame_id, timestamp, blkg_data);
    }
}