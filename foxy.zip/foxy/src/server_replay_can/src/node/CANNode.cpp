#include "CANNode.h"

CANNode::CANNode(std::shared_ptr<rclcpp::Node> node)
{
    node_ = node;
    ros_param_util_ = std::make_shared<RosParamUtil>(node);
    tf_frames_transform_util_ = std::make_shared<TfFramesTransformUtil>(node_);
    static_transform_broadcaster_ = std::make_shared<tf2_ros::StaticTransformBroadcaster>(node);
    GetNodeNamespace();
    PublishStaticTransform();
}

void CANNode::PublishStaticTransform()
{
    geometry_msgs::msg::TransformStamped transform_stamped = tf_frames_transform_util_->GetFrameTransform();
    static_transform_broadcaster_->sendTransform(transform_stamped);
}

void CANNode::GetNodeNamespace()
{
    node_namespace_ = node_->get_namespace();
    if (node_namespace_.length() <= 1)
    {
        node_namespace_ = "/map";
    }
}

void CANNode::SetRosbagWriter(std::shared_ptr<RosbagWriter> rosbag_writer)
{
    rosbag_writer_ = rosbag_writer;
}

void CANNode::SetParquetExporter(std::unique_ptr<ParquetExportSkelgen> parquet_exporter)
{
    (void)parquet_exporter;
}

void CANNode::CloseFileHandles()
{
}

void CANNode::AddFeedbackMessage(std::shared_ptr<msg_swc_common::msg::MsgNodeFeedbackType> feedback_msg,
                                 const int64_t timestamp)
{
    (void)feedback_msg;
    (void)timestamp;
}

void CANNode::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                            std::shared_ptr<msg_can_addon::msg::MsgCanRadarCalDataType> ros_cal_data)
{
    (void)frame_id;
    (void)timestamp;
    (void)ros_cal_data;
}
void CANNode::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                            std::shared_ptr<msg_can_addon::msg::MsgRadarcfgType> ros_radar_cfg)
{
    (void)frame_id;
    (void)timestamp;
    (void)ros_radar_cfg;
}
void CANNode::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                            std::shared_ptr<msg_can_addon::msg::MsgCanRadarInfoType> ros_radar_info)
{
    (void)frame_id;
    (void)timestamp;
    (void)ros_radar_info;
}
void CANNode::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                            std::shared_ptr<msg_can_addon::msg::MsgCanTsyncType> ros_tsync)
{
    (void)frame_id;
    (void)timestamp;
    (void)ros_tsync;
}
void CANNode::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                            std::shared_ptr<msg_can_addon::msg::MsgVehdynType> ros_veh_dyn)
{
    (void)frame_id;
    (void)timestamp;
    (void)ros_veh_dyn;
}
void CANNode::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                            std::shared_ptr<msg_live_addon::msg::MsgCanObjType> ros_can_obj_data)
{
    (void)frame_id;
    (void)timestamp;
    (void)ros_can_obj_data;
}

void CANNode::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                            std::shared_ptr<msg_live_addon::msg::MsgRoadborderType> road_border)
{
    (void)frame_id;
    (void)timestamp;
    (void)road_border;
}

void CANNode::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                            std::shared_ptr<msg_live_addon::msg::MsgVehmtnType> veh_mtn)
{
    (void)frame_id;
    (void)timestamp;
    (void)veh_mtn;
}

void CANNode::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                            std::shared_ptr<msg_live_addon::msg::MsgSensrmtnType> snsr_mtn)
{
    (void)frame_id;
    (void)timestamp;
    (void)snsr_mtn;
}

void CANNode::AddRosMessage(uint32_t frame_id, const int64_t timestamp,
                            std::shared_ptr<msg_live_addon::msg::MsgBlkgdebugType> blkg_data)
{
    (void)frame_id;
    (void)timestamp;
    (void)blkg_data;
}