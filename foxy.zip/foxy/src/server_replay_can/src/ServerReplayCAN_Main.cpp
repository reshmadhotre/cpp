#include "CANAdapterReplay.h"
#include "CANNodeReplay.h"
#include "Magna2RosConverter.h"
#include "rclcpp/rclcpp.hpp"
#include <csignal>

std::shared_ptr<CANAdapterReplay> can_replay_adapter;
std::shared_ptr<Magna2RosConverter> magna_ros_converter;
std::shared_ptr<CANNode> can_replay_node;

void sigint_handler(int sig_num)
{
    if (can_replay_adapter != nullptr)
    {
        can_replay_adapter->CloseFileHandles();
    }
    rclcpp::shutdown();
    can_replay_adapter.reset();

    exit(sig_num);
}

int main(int argc, char* argv[])
{
    std::signal(SIGINT, sigint_handler);
    rclcpp::InitOptions options = rclcpp::InitOptions();
    options.shutdown_on_sigint = false;
    rclcpp::init(argc, argv, options);
    auto node = std::make_shared<rclcpp::Node>("server_replay_can_node");

    can_replay_node = std::make_shared<CANNodeReplay>(node);
    magna_ros_converter = std::make_shared<Magna2RosConverter>();
    magna_ros_converter->SetCANNode(can_replay_node);

    can_replay_adapter = std::make_shared<CANAdapterReplay>(node);
    can_replay_adapter->SetMagna2RosConverter(magna_ros_converter);
    can_replay_adapter->SetCANNode(can_replay_node);

    can_replay_adapter->StartReaderThread();

    rclcpp::spin(node);

    can_replay_adapter->StopReaderThread();
    can_replay_adapter->CloseFileHandles();
    can_replay_adapter.reset();
    rclcpp::shutdown();
    return 0;
}