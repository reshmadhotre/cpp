/**
* @file            can_peak.cpp
* @brief           
*
* @author          giovcand
* @date            08/30/22 14:31:34
* @version         1.0
*/

/*
*	@copyright MAGNA Electronics - C O N F I D E N T I A L <br>
*	
*	This is an unpublished work of authorship, which contains
*	trade secrets, created in 2014.  Magna Electronics owns all
*	rights to this work and intends to maintain it in confidence
*	to preserve its trade secret status.  Magna Electronics
*	reserves the right, under the copyright laws of the United
*	States or those of any other country that may have jurisdiction,
*	to protect this work as an unpublished work, in the event of
*	an inadvertent or deliberate unauthorized publication.
*	Magna Electronics also reserves its rights under all copyright
*	laws to protect this work as a published work, when appropriate.
*	Those having access to this work may not copy it, use it,
*	modify it, or disclose the information contained in it without
*	the written authorization of Magna Electronics.
*/
#include "can_peak.h"
#include <PCANBasic.h>
#include <stdio.h>
#include <memory.h>
#include <map>
#include <algorithm>

#define TOP_CAN_STANDARD_ID 0x7FF
#define TOP_CAN_EXTENDED_ID 0x1FFFFFFF

CanPeak::CanPeak()
{

}

CanPeak::~CanPeak()
{
    
}

bool CanPeak::init(uint8_t ch, uint32_t baud)
{
    uint16_t channel = 0;
    if (false == _getRealChannel(channel, ch))
        return false;

    setCANChannel(ch);


    return false;
}

bool CanPeak::initFD(uint8_t ch, uint32_t baud, uint32_t brs)
{
    //TODO implement calculation on the fly
    return false;
    uint16_t channel = 0;
    if (false == _getRealChannel(channel, ch))
        return false;

    setCANFDChannel(ch);

    // TODO: find a way to calculate this string according to baud and brs
    TPCANBitrateFD BitrateFD = const_cast<TPCANBitrateFD>("f_clock_mhz=80, nom_brp=2, nom_tseg1=63, nom_tseg2=16, nom_sjw=16, data_brp=2, data_tseg1=15, data_tseg2=4, data_sjw=4");
    TPCANStatus res = CAN_InitializeFD(channel, BitrateFD);
    return (PCAN_ERROR_OK == res);
}

bool CanPeak::initFD(uint8_t ch, CanFDCfg cfg)
{
    uint16_t channel = 0;
    if (false == _getRealChannel(channel, ch))
        return false;

    setCANFDChannel(ch);

    TPCANStatus res = CAN_InitializeFD(channel, (TPCANBitrateFD)_getConfig(cfg));
    return (PCAN_ERROR_OK == res);
}

bool CanPeak::deinit(uint8_t ch)
{
    uint16_t channel = 0;
    if (false == _getRealChannel(channel, ch))
        return false;

    TPCANStatus res = CAN_Uninitialize(channel);
    return (PCAN_ERROR_OK == res);
}

bool CanPeak::read(message &data, uint8_t ch)
{
    uint16_t channel = 0;
    bool fd = false;
    bool ret = false;
    data.data.clear();

    if (false
    || (false == _getRealChannel(channel, ch))
    || (false == isFD(fd, ch))
    )
    {
        return false;
    }

    if(false == fd)
    {
        TPCANMsg msg;
        TPCANTimestamp t;
        
        if(ret = (PCAN_ERROR_OK == CAN_Read(channel, &msg, &t)))
        {
            data.id = msg.ID;
            auto size = msg.LEN;
            data.timestamp_us = t.micros + 1000 * t.millis + 0x100000000 * 1000 * t.millis_overflow;
            data.data.insert(data.data.end(), msg.DATA, msg.DATA + size);
        }
    }
    else
    {
        TPCANMsgFD msg;
        TPCANTimestampFD t;
        
        if (ret = (PCAN_ERROR_OK == CAN_ReadFD(channel, &msg, &t)))
        {
            data.id = msg.ID;
            auto size = getSizeFromDLC(msg.DLC);
            data.timestamp_us = t;
            data.data.insert(data.data.end(), msg.DATA, msg.DATA + size);
        }
    }



    return ret;
}

bool CanPeak::write(uint8_t ch, uint32_t id, bool extended, const std::vector<uint8_t> &data)
{
    uint16_t channel = 0;
    bool fd = false;
    bool ret = false;
    int idType = -1;

    if (false == extended && id <= TOP_CAN_STANDARD_ID)
    {
        idType = PCAN_MESSAGE_STANDARD;
    }
    else if (extended && id <= TOP_CAN_EXTENDED_ID)
    {
        idType = PCAN_MESSAGE_EXTENDED;
    }
    else
    {
        return false;
    }

    if (false
    || (false == _getRealChannel(channel, ch))
    || (false == isFD(fd, ch))
    )
    {
        return false;
    }

    if (false == fd)
    {
        TPCANMsg msg;
        msg.ID = id;
        msg.LEN = data.size();
        msg.MSGTYPE = idType;
        memcpy((uint8_t*)&msg.DATA[0], (uint8_t*)data.data(), data.size());
        ret = (PCAN_ERROR_OK == CAN_Write(channel, &msg));
    }
    else
    {
        TPCANMsgFD msg;
        auto dlc = getDLCFromSize(data.size());
        msg.ID = id;
        msg.DLC = dlc;
        msg.MSGTYPE = idType | PCAN_MESSAGE_FD;
        memcpy((uint8_t*)&msg.DATA[0], (uint8_t*)data.data(), data.size());
        ret = (PCAN_ERROR_OK == CAN_WriteFD(channel, &msg));
    }

    return ret;
}

bool CanPeak::filterID(uint8_t ch, uint32_t from, uint32_t to, bool extendedID)
{
    uint16_t channel = 0;
    if(false == _getRealChannel(channel, ch))
        return false;

    auto idtype = extendedID ? PCAN_MESSAGE_EXTENDED : PCAN_MESSAGE_STANDARD;
    return (PCAN_ERROR_OK == CAN_FilterMessages(channel, from, to, idtype));
}

bool CanPeak::countAvailableChannels()
{
    bool ret = false;
    uint32_t channelsCount;
    if (PCAN_ERROR_OK == CAN_GetValue(PCAN_NONEBUS, PCAN_ATTACHED_CHANNELS_COUNT, &channelsCount, sizeof(channelsCount)))
    {
        // printf("Total of %d channels were found:\n", channelsCount);
        if (channelsCount > 0)
        {
            TPCANChannelInformation *channels = new TPCANChannelInformation[channelsCount];
            if (PCAN_ERROR_OK == CAN_GetValue(PCAN_NONEBUS, PCAN_ATTACHED_CHANNELS, channels, channelsCount * sizeof(TPCANChannelInformation)))
            {
                for (uint32_t i = 0; i < channelsCount; ++i)
                {
                    if (PCAN_CHANNEL_AVAILABLE == channels[i].channel_condition)
                        _channels.push_back(channels[i].channel_handle);
                        _fd.push_back(false);
                }
            }
            delete[] channels;
            ret = true;
        }
    }
    _availableChannels = _channels.size();
    return ret;
}

bool CanPeak::setListenOnly(uint8_t ch, bool val)
{
    uint16_t channel = 0;
    if (false == _getRealChannel(channel, ch))
        return false;

    uint32_t state = val ? PCAN_PARAMETER_ON : PCAN_PARAMETER_OFF;
    return (PCAN_ERROR_OK == CAN_SetValue(channel, PCAN_LISTEN_ONLY, &state, sizeof(state)));
}

bool CanPeak::_getRealChannel(uint16_t& val, uint8_t ch) const
{
    if(ch >= _channels.size())
        return false;
    
    val = _channels.at(ch);
    
    return true;
}

const char *CanPeak::_getConfig(CanFDCfg cfg) const
{
    static std::map<CanFDCfg, const char *> m =
        {
            {CanFDCfg::SAEJ2284_4_500k_2M, "f_clock_mhz=80, nom_brp=2, nom_tseg1=63, nom_tseg2=16, nom_sjw=16, data_brp=2, data_tseg1=15, data_tseg2=4, data_sjw=4"}
        };

    return m.at(cfg);
}
