/**
 * @file            can_iface.cpp
 * @brief
 *
 * @author          giovcand
 * @date            08/30/22 14:15:11
 * @version         1.0
 */

/*
 *	@copyright MAGNA Electronics - C O N F I D E N T I A L <br>
 *
 *	This is an unpublished work of authorship, which contains
 *	trade secrets, created in 2014.  Magna Electronics owns all
 *	rights to this work and intends to maintain it in confidence
 *	to preserve its trade secret status.  Magna Electronics
 *	reserves the right, under the copyright laws of the United
 *	States or those of any other country that may have jurisdiction,
 *	to protect this work as an unpublished work, in the event of
 *	an inadvertent or deliberate unauthorized publication.
 *	Magna Electronics also reserves its rights under all copyright
 *	laws to protect this work as a published work, when appropriate.
 *	Those having access to this work may not copy it, use it,
 *	modify it, or disclose the information contained in it without
 *	the written authorization of Magna Electronics.
 */
#include "can_iface.h"

#define IS_IN_RANGE(x, y, z) ((x >= y) && (x <= z))

CanIface::CanIface()
: _availableChannels(0)
{
}

CanIface::~CanIface()
{
}

uint8_t CanIface::availableChannels() const
{
    return _availableChannels;
}

bool CanIface::isFD(bool &v, uint8_t ch) const
{
    if (ch >= _fd.size())
        return false;

    v = _fd.at(ch);
    return true;
}

bool CanIface::setCANFDChannel(uint8_t ch)
{
    return _setChannelCanType(ch, true);
}

bool CanIface::setCANChannel(uint8_t ch)
{
    return _setChannelCanType(ch, false);
}

uint8_t CanIface::getSizeFromDLC(uint8_t dlc) const
{
    if (false == IS_IN_RANGE(dlc, 0, 15))
        return false;

    uint8_t dlc_table[] = {
        0, 1, 2, 3, 4, 5, 6, 7, 8,
        12, 16, 20, 24, 32, 48, 64};

    return dlc_table[dlc];
}

uint8_t CanIface::getDLCFromSize(uint8_t size) const
{
    uint8_t val = 0;
    switch (size)
    {
    case 0 ... 8:
        val = size;
        break;
    case 12:
        val = 9;
        break;
    case 16:
        val = 10;
        break;
    case 20:
        val = 11;
        break;
    case 24:
        val = 12;
        break;
    case 32:
        val = 13;
        break;
    case 48:
        val = 14;
        break;
    case 64:
        val = 15;
        break;
    default:
        val = 0;
        break;
    }

    return val;
}

bool CanIface::_setChannelCanType(uint8_t ch, bool isFD)
{
    if (ch >= _fd.size())
        return false;

    return _fd[ch] = isFD;
}