/*
 * Copyright 2019 - 2022 Magna Electronics Europe GmbH & Co. OHG
 *
 * This is an unpublished work of authorship, which contains trade secrets, 
 * created in 2019. 
 * 
 * Magna Electronics owns all rights to this work and intends 
 * to maintain it in confidence to preserve its trade secret status.
 * 
 * Magna Electronics reserves the right, under the copyright laws of the United
 * States or those of any other country that may have jurisdiction, to protect 
 * this work as an unpublished work, in the event of an inadvertent or deliberate
 * unauthorized publication.
 * 
 * Magna Electronics also reserves its rights under all copyright laws to protect
 * this work as a published work, when appropriate. Those having access to this
 * work may not copy it, use it, modify it, or disclose the information contained
 * in it without the written authorization of Magna Electronics.
 *
 *
 * \file       ParquetExporterSkelgen.cpp
 * \version    3.3.0 (beta)
 * \date       Oct-25-2022 - 13:43:28
 *
 * \author     Magna Electronics Europe GmbH & Co. OHG, 
 *             63877 Sailauf, Germany
 *
 * This file is auto generated! DO NOT MODIFY!
 *
 * Generated with: Radar Skeleton Generator
 * Internal version: 05.35 (Build: 20221020)
 * Based on ARXML interface version: 1.0.0
 */


#include "ParquetExporterSkelgen.hpp"

#include <thread>
#include <iostream>



ParquetExportSkelgen::ParquetExportSkelgen()
{
    init_parquet_headers();
}


ParquetExportSkelgen::~ParquetExportSkelgen()
{
}


void ParquetExportSkelgen::set_filename(const std::string filename)
{
	parquet_file_name_ = filename;
}

const std::string ParquetExportSkelgen::get_file_suffix() const
{
    return filename_prefix_;
}


const std::string ParquetExportSkelgen::get_filename() const
{
	return parquet_file_name_;
}


bool ParquetExportSkelgen::is_parquet_file_written()
{
	return parquet_file_completion_flag_;
}


void ParquetExportSkelgen::set_parquet_file_completion_flag(const bool status)
{
	parquet_file_completion_flag_ = status;
}


void ParquetExportSkelgen::write_parquet_file()
{
	auto file_name = get_filename();
    auto file_suffix = get_file_suffix();
    reset_data();
	save_to_disk(file_name, file_suffix);
	set_parquet_file_completion_flag(true);
}


void ParquetExportSkelgen::init_parquet_headers()
{
	parquet_init_radarcfg();
    parquet_init_radarcal();
    parquet_init_radarinfo();
    parquet_init_vehdyn();
    parquet_init_snsrmtn();
    parquet_init_vehmtn();
    parquet_init_objdata();
    parquet_init_blkgdata();
    parquet_init_roadborder();
	parquet_init_node_feedback();
}


/*----------------------------------------------------------------------------*/
/*  INITIALIZE DATA FOR PARQUET                                               */
/*----------------------------------------------------------------------------*/

void ParquetExportSkelgen::parquet_init_radarcfg(void)
{
    add_message("RADARCFG", "timestamp", {{"timestamp", parquet_exporter::DataType::INT64}});
    add_signals("RADARCFG", {
        {"FUNC_ARR", parquet_exporter::DataType::UINT32},
        {"RADAR_ROLE", parquet_exporter::DataType::UINT8},
        {"ACT_ORIENTATION_ROLL", parquet_exporter::DataType::FLOAT32},
        {"ACT_ORIENTATION_PITCH", parquet_exporter::DataType::FLOAT32},
        {"ACT_ORIENTATION_YAW", parquet_exporter::DataType::FLOAT32},
        {"ACT_POSITION_X", parquet_exporter::DataType::FLOAT32},
        {"ACT_POSITION_Y", parquet_exporter::DataType::FLOAT32},
        {"ACT_POSITION_Z", parquet_exporter::DataType::FLOAT32},
        {"NOM_ORIENTATION_ROLL", parquet_exporter::DataType::FLOAT32},
        {"NOM_ORIENTATION_PITCH", parquet_exporter::DataType::FLOAT32},
        {"NOM_ORIENTATION_YAW", parquet_exporter::DataType::FLOAT32},
        {"NOM_POSITION_X", parquet_exporter::DataType::FLOAT32},
        {"NOM_POSITION_Y", parquet_exporter::DataType::FLOAT32},
        {"NOM_POSITION_Z", parquet_exporter::DataType::FLOAT32}
    });
}

void ParquetExportSkelgen::parquet_init_radarcal(void)
{
    add_message("RADAR_CAL", "timestamp", {{"timestamp", parquet_exporter::DataType::INT64}});
    add_signals("RADAR_CAL", {
        {"OCAL_ROT_MATRIX_ROLL_AG", parquet_exporter::DataType::FLOAT64},
        {"OCAL_ROT_MATRIX_PITCH_AG", parquet_exporter::DataType::FLOAT64},
        {"OCAL_ROT_MATRIX_YAW_AG", parquet_exporter::DataType::FLOAT64},
        {"OCAL_ROT_MATRIX_PITCH_AG_STD_DEV", parquet_exporter::DataType::FLOAT64},
        {"OCAL_ROT_MATRIX_ROLL_AG_STD_DEV", parquet_exporter::DataType::FLOAT64},
        {"OCAL_ROT_MATRIX_YAW_AG_STD_DEV", parquet_exporter::DataType::FLOAT64}
    });
}

void ParquetExportSkelgen::parquet_init_radarinfo(void)
{
    add_message("RADAR_INFO", "timestamp", {{"timestamp", parquet_exporter::DataType::INT64}});
    add_signals("RADAR_INFO", {
        {"Blockage_prob", parquet_exporter::DataType::UINT8},
        {"Blockage_status", parquet_exporter::DataType::UINT8},
        {"Crc_radar_info", parquet_exporter::DataType::UINT8},
        {"Mac_radar_info", parquet_exporter::DataType::UINT32},
        {"Mc_radar_info", parquet_exporter::DataType::UINT8},
        {"Mrr_timestamp_n_sec", parquet_exporter::DataType::UINT32},
        {"Mrr_timestamp_sec", parquet_exporter::DataType::UINT32},
        {"Mrr_timesync_status", parquet_exporter::DataType::UINT8},
        {"number_of_objects", parquet_exporter::DataType::UINT8},
        {"Object_timestamp_n_sec", parquet_exporter::DataType::UINT32},
        {"Object_timestamp_sec", parquet_exporter::DataType::UINT16},
        {"radar_scan_id", parquet_exporter::DataType::UINT8},
        {"safety_distance", parquet_exporter::DataType::UINT8},
        {"tunnel_distance", parquet_exporter::DataType::UINT8},
        {"tunnel_presence", parquet_exporter::DataType::UINT8},
        {"tunnel_prob", parquet_exporter::DataType::UINT8},
    });
}

void ParquetExportSkelgen::parquet_init_roadborder(void)
{
    add_message("ROADBORDER", "timestamp", {{"timestamp", parquet_exporter::DataType::INT64}});
    add_signals("ROADBORDER", {
        {"Left_OffsetX", parquet_exporter::DataType::FLOAT32},
        {"Left_OffsetY", parquet_exporter::DataType::FLOAT32},
        {"Left_AngleTan", parquet_exporter::DataType::FLOAT32},
        {"Left_C0", parquet_exporter::DataType::FLOAT32},
        {"Left_C1_0", parquet_exporter::DataType::FLOAT32},
        {"Left_C1_1", parquet_exporter::DataType::FLOAT32},
        {"Left_Range0", parquet_exporter::DataType::FLOAT32},
        {"Left_RangeMax", parquet_exporter::DataType::FLOAT32},
        {"Left_Confidence", parquet_exporter::DataType::UINT8},
        {"Left_Status", parquet_exporter::DataType::UINT8},
        {"Right_OffsetX", parquet_exporter::DataType::FLOAT32},
        {"Right_OffsetY", parquet_exporter::DataType::FLOAT32},
        {"Right_AngleTan", parquet_exporter::DataType::FLOAT32},
        {"Right_C0", parquet_exporter::DataType::FLOAT32},
        {"Right_C1_0", parquet_exporter::DataType::FLOAT32},
        {"Right_C1_1", parquet_exporter::DataType::FLOAT32},
        {"Right_Range0", parquet_exporter::DataType::FLOAT32},
        {"Right_RangeMax", parquet_exporter::DataType::FLOAT32},
        {"Right_Confidence", parquet_exporter::DataType::UINT8},
        {"Right_Status", parquet_exporter::DataType::UINT8}
    });
}

void ParquetExportSkelgen::parquet_init_objdata(void)
{
    add_message("CAN_OBJ_LIST", "timestamp", {{"timestamp", parquet_exporter::DataType::INT64}});
    add_signals("CAN_OBJ_LIST", {
        {"Header_Num_Obj", parquet_exporter::DataType::UINT16},
        {"Header_Timestamp", parquet_exporter::DataType::UINT32},
        {"Header_Timestamp_N_Sec", parquet_exporter::DataType::UINT32},
        {"Header_Scan_Id", parquet_exporter::DataType::UINT32},
        {"ObjArr_Crc_Obj_Data", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Mc_Obj_Data", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_id", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Fu_Sa_level", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Meas_Status", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Confidence", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Age", parquet_exporter::DataType::UINT16, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_motion_st", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Distance_X", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Distance_Std_Dev_X", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Distance_Y", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Distance_Std_Dev_Y", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Distance_Cov_XY", parquet_exporter::DataType::INT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Rel_Velocity_X", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Rel_Velocity_Std_Dev_X", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Rel_Velocity_Y", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Rel_Velocity_Std_Dev_Y", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Rel_Velocity_Cov_XY", parquet_exporter::DataType::INT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Rel_Accelaration_X", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Rel_Accelaration_Std_Dev_X", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Rel_Accelaration_Y", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Rel_Accelaration_Std_Dev_Y", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Rel_Accelaration_Cov_XY", parquet_exporter::DataType::INT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Ref_Point", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Yaw_Angle", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Yaw_Angle_Std_Dev", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Yaw_Rate", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Yaw_Rate_Std_Dev", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Width", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Width_Std_Dev", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Width_St", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Length", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Length_Std_Dev", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Length_St", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Class", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Class_Confidence", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_RCS", parquet_exporter::DataType::FLOAT64, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Over_under_driveable", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Object_Over_under_driveable_conf", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Scan_Id", parquet_exporter::DataType::UINT8, parquet_exporter::ValueType::LIST},
        {"ObjArr_Mac_Object_Data", parquet_exporter::DataType::UINT32, parquet_exporter::ValueType::LIST},
    });
}

void ParquetExportSkelgen::parquet_init_vehdyn(void)
{
    add_message("VEH_DYN", "timestamp", {{"timestamp", parquet_exporter::DataType::INT64}});
    add_signals("VEH_DYN", {
        {"Glb_A_Coor_Ax", parquet_exporter::DataType::FLOAT32},
        {"Glb_A_Coor_Ay", parquet_exporter::DataType::FLOAT32},
        {"Glb_A_Coor_Az", parquet_exporter::DataType::FLOAT32},
        {"Glb_V_Coor_Vx", parquet_exporter::DataType::FLOAT32},
        {"Glb_V_Coor_Vy", parquet_exporter::DataType::FLOAT32},
        {"Glb_V_Coor_Vz", parquet_exporter::DataType::FLOAT32},
        {"Road_Grdt", parquet_exporter::DataType::FLOAT32},
        {"Veh_A_Coor_Ax", parquet_exporter::DataType::FLOAT32},
        {"Veh_A_Coor_Ay", parquet_exporter::DataType::FLOAT32},
        {"Veh_A_Coor_Az", parquet_exporter::DataType::FLOAT32},
        {"Veh_Dyn_st", parquet_exporter::DataType::UINT8},
        {"Veh_V_Coor_Vx", parquet_exporter::DataType::FLOAT32},
        {"Veh_V_Coor_Vy", parquet_exporter::DataType::FLOAT32},
        {"Veh_V_Coor_Vz", parquet_exporter::DataType::FLOAT32},
        {"Yaw_Rate", parquet_exporter::DataType::FLOAT32},

    });
}

void ParquetExportSkelgen::parquet_init_snsrmtn(void)
{
    add_message("SNSR_MTN", "timestamp", {{"timestamp", parquet_exporter::DataType::INT64}});
    add_signals("SNSR_MTN", {
        {"V_Vx", parquet_exporter::DataType::FLOAT32},
        {"V_Vy", parquet_exporter::DataType::FLOAT32},
        {"V_Vz", parquet_exporter::DataType::FLOAT32},
        {"V_Std_De_Vx", parquet_exporter::DataType::FLOAT32},
        {"V_Std_De_Vy", parquet_exporter::DataType::FLOAT32},
        {"V_Std_De_Vz", parquet_exporter::DataType::FLOAT32},
        {"V_Estimn_St", parquet_exporter::DataType::UINT8},
        {"A_Ax", parquet_exporter::DataType::FLOAT32},
        {"A_Ay", parquet_exporter::DataType::FLOAT32},
        {"A_Az", parquet_exporter::DataType::FLOAT32},
        {"A_Std_De_Ax", parquet_exporter::DataType::FLOAT32},
        {"A_Std_De_Ay", parquet_exporter::DataType::FLOAT32},
        {"A_Std_De_Az", parquet_exporter::DataType::FLOAT32},
        {"A_Estimn_St", parquet_exporter::DataType::UINT8},
        {"Yaw_Rate", parquet_exporter::DataType::FLOAT32},
        {"Yaw_Rate_Std_De", parquet_exporter::DataType::FLOAT32},
        {"Yaw_Rate_St", parquet_exporter::DataType::UINT8},
        {"Crv_Rd", parquet_exporter::DataType::FLOAT32},
        {"Crv_Rd_Std_De", parquet_exporter::DataType::FLOAT32},
        {"Crv_Rd_St", parquet_exporter::DataType::UINT8},
    });
}

void ParquetExportSkelgen::parquet_init_vehmtn(void)
{
    add_message("VEH_MTN", "timestamp", {{"timestamp", parquet_exporter::DataType::INT64}});
    add_signals("VEH_MTN", {
        {"V_Vx", parquet_exporter::DataType::FLOAT32},
        {"V_Vy", parquet_exporter::DataType::FLOAT32},
        {"V_Vz", parquet_exporter::DataType::FLOAT32},
        {"V_Std_De_Vx", parquet_exporter::DataType::FLOAT32},
        {"V_Std_De_Vy", parquet_exporter::DataType::FLOAT32},
        {"V_Std_De_Vz", parquet_exporter::DataType::FLOAT32},
        {"V_Estimn_St", parquet_exporter::DataType::UINT8},
        {"A_Ax", parquet_exporter::DataType::FLOAT32},
        {"A_Ay", parquet_exporter::DataType::FLOAT32},
        {"A_Az", parquet_exporter::DataType::FLOAT32},
        {"A_Std_De_Ax", parquet_exporter::DataType::FLOAT32},
        {"A_Std_De_Ay", parquet_exporter::DataType::FLOAT32},
        {"A_Std_De_Az", parquet_exporter::DataType::FLOAT32},
        {"A_Estimn_St", parquet_exporter::DataType::UINT8},
        {"Yaw_Rate", parquet_exporter::DataType::FLOAT32},
        {"Yaw_Rate_Std_De", parquet_exporter::DataType::FLOAT32},
        {"Yaw_Rate_St", parquet_exporter::DataType::UINT8},
        {"Crv_Rd", parquet_exporter::DataType::FLOAT32},
        {"Crv_Rd_Std_De", parquet_exporter::DataType::FLOAT32},
        {"Crv_Rd_St", parquet_exporter::DataType::UINT8},
    });
}

void ParquetExportSkelgen::parquet_init_blkgdata(void)
{
    add_message("BLKG_DBG", "timestamp", {{"timestamp", parquet_exporter::DataType::INT64}});
    add_signals("BLKG_DBG", {
        {"blkg_active", parquet_exporter::DataType::BOOL},
        {"blkg_conf", parquet_exporter::DataType::FLOAT32},
        {"blkg_deactivate_dist_count", parquet_exporter::DataType::FLOAT32},
        {"blkg_deactivate_obj_loss", parquet_exporter::DataType::UINT32},
        {"blkg_deactivate_range", parquet_exporter::DataType::FLOAT32},
        {"blkg_deactivate_time_count", parquet_exporter::DataType::FLOAT32},
        {"blkg_detection_ratio_mean", parquet_exporter::DataType::FLOAT32},
        {"blkg_detection_ratio_mov", parquet_exporter::DataType::FLOAT32},
        {"blkg_detection_ratio_static", parquet_exporter::DataType::FLOAT32},
        {"blkg_dist_count", parquet_exporter::DataType::UINT32},
        {"blkg_fl_conf", parquet_exporter::DataType::FLOAT32},
        {"blkg_fl_mean", parquet_exporter::DataType::FLOAT32},
        {"blkg_fl_mov_max", parquet_exporter::DataType::FLOAT32},
        {"blkg_fl_mov_mean", parquet_exporter::DataType::FLOAT32},
        {"blkg_fl_mov_mean_conf", parquet_exporter::DataType::FLOAT32},
        {"blkg_obj_loss_conf", parquet_exporter::DataType::FLOAT32},
        {"blkg_obj_loss_prob", parquet_exporter::DataType::FLOAT32},
        {"blkg_range_conf", parquet_exporter::DataType::FLOAT32},
        {"blkg_range_max", parquet_exporter::DataType::FLOAT32},
        {"blkg_range_mean", parquet_exporter::DataType::FLOAT32},
        {"blkg_range_prob", parquet_exporter::DataType::FLOAT32},
        {"blkg_st_max", parquet_exporter::DataType::FLOAT32},
        {"blkg_st_mean", parquet_exporter::DataType::FLOAT32},
        {"blkg_st_mean_conf", parquet_exporter::DataType::FLOAT32},
        {"blkg_time_count", parquet_exporter::DataType::UINT32},
        {"blkg_time_dist_count_conf", parquet_exporter::DataType::FLOAT32},
        {"blkg_time_dist_count_prob", parquet_exporter::DataType::FLOAT32},
    });
}

void ParquetExportSkelgen::parquet_init_node_feedback(void)
{
	// Nothing to do
}

/*----------------------------------------------------------------------------*/
/*  WRITE DATA INTO PARQUET                                                   */
/*----------------------------------------------------------------------------*/

void ParquetExportSkelgen::parquet_export_radarcfg(msg_can_addon::msg::MsgRadarcfgType* msg)
{
    memcpy(&radar_cfg_data_, msg, sizeof(radar_cfg_data_));
    append_values("RADARCFG", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"FUNC_ARR", msg->func_arr},
        {"RADAR_ROLE", msg->radar_role},
        {"ACT_ORIENTATION_ROLL", msg->act_orientation.roll},
        {"ACT_ORIENTATION_PITCH", msg->act_orientation.pitch},
        {"ACT_ORIENTATION_YAW", msg->act_orientation.yaw},
        {"ACT_POSITION_X", msg->act_position.x},
        {"ACT_POSITION_Y", msg->act_position.y},
        {"ACT_POSITION_Z", msg->act_position.z},
        {"NOM_ORIENTATION_ROLL", msg->nom_orientation.roll},
        {"NOM_ORIENTATION_PITCH", msg->nom_orientation.pitch},
        {"NOM_ORIENTATION_YAW", msg->nom_orientation.yaw},
        {"NOM_POSITION_X", msg->nom_position.x},
        {"NOM_POSITION_Y", msg->nom_position.y},
        {"NOM_POSITION_Z", msg->nom_position.z}
    });

    vistor_map[parquet_data_id::RADAR_CFG] = true;
    if (is_update_call_ == false)
    {
        m_timestamp_ = msg->header.stamp;
        update_previous_data();
    }
}

void ParquetExportSkelgen::parquet_export_radarcal(msg_can_addon::msg::MsgCanRadarCalDataType* msg)
{
    memcpy(&radar_cal_data_, msg, sizeof(radar_cal_data_));
    append_values("RADAR_CAL", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"OCAL_ROT_MATRIX_ROLL_AG", msg->ocal_rotation_matrix_roll_ag},
        {"OCAL_ROT_MATRIX_PITCH_AG", msg->ocal_rotation_matrix_pitch_ag},
        {"OCAL_ROT_MATRIX_YAW_AG", msg->ocal_rotation_matrix_yaw_ag},
        {"OCAL_ROT_MATRIX_PITCH_AG_STD_DEV", msg->ocal_rotation_matrix_pitch_ag_std_dev},
        {"OCAL_ROT_MATRIX_ROLL_AG_STD_DEV", msg->ocal_rotation_matrix_roll_ag_std_dev},
        {"OCAL_ROT_MATRIX_YAW_AG_STD_DEV", msg->ocal_rotation_matrix_yaw_ag_std_dev}
    });

    vistor_map[parquet_data_id::RADAR_CAL] = true;
    if (is_update_call_ == false)
    {
        m_timestamp_ = msg->header.stamp;
        update_previous_data();
    }
}

void ParquetExportSkelgen::parquet_export_radarinfo(msg_can_addon::msg::MsgCanRadarInfoType* msg)
{
    memcpy(&radar_info_data_, msg, sizeof(radar_info_data_));
    append_values("RADAR_INFO", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"Blockage_prob", msg->blockage_prob},
        {"Blockage_status", msg->blockage_status},
        {"Crc_radar_info", msg->crc_radar_info},
        {"Mac_radar_info", msg->mac_radar_info},
        {"Mc_radar_info", msg->mc_radar_info},
        {"Mrr_timestamp_n_sec", msg->mrr_timestamp_n_sec},
        {"Mrr_timestamp_sec", msg->mrr_timestamp_sec},
        {"Mrr_timesync_status", msg->mrr_timesync_status},
        {"number_of_objects", msg->number_of_objects},
        {"Object_timestamp_n_sec", msg->object_timestamp_n_sec},
        {"Object_timestamp_sec", msg->object_timestamp_sec},
        {"radar_scan_id", msg->radar_scan_id},
        {"safety_distance", msg->safety_distance},
        {"tunnel_distance", msg->tunnel_distance},
        {"tunnel_presence", msg->tunnel_presence},
        {"tunnel_prob", msg->tunnel_prob},
    });
    vistor_map[parquet_data_id::RADAR_INFO] = true;
    if (is_update_call_ == false)
    {
        m_timestamp_ = msg->header.stamp;
        update_previous_data();
    }

}

void ParquetExportSkelgen::parquet_export_roadborder(msg_live_addon::msg::MsgRoadborderType* msg)
{
    memcpy(&rbe_data_, msg, sizeof(rbe_data_));
    append_values("ROADBORDER", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"Left_OffsetX", msg->road_border_left.offset_x},
        {"Left_OffsetY", msg->road_border_left.offset_y},
        {"Left_AngleTan", msg->road_border_left.angle_tan},
        {"Left_C0", msg->road_border_left.c0},
        {"Left_C1_0", msg->road_border_left.c10},
        {"Left_C1_1", msg->road_border_left.c11},
        {"Left_Range0", msg->road_border_left.range0},
        {"Left_RangeMax", msg->road_border_left.range_max},
        {"Left_Confidence", msg->road_border_left.confidence},
        {"Left_Status", msg->road_border_left.status},
        {"Right_OffsetX", msg->road_border_right.offset_x},
        {"Right_OffsetY", msg->road_border_right.offset_y},
        {"Right_AngleTan", msg->road_border_right.angle_tan},
        {"Right_C0", msg->road_border_right.c0},
        {"Right_C1_0", msg->road_border_right.c10},
        {"Right_C1_1", msg->road_border_right.c11},
        {"Right_Range0", msg->road_border_right.range0},
        {"Right_RangeMax", msg->road_border_right.range_max},
        {"Right_Confidence", msg->road_border_right.confidence},
        {"Right_Status", msg->road_border_right.status}
    });

    vistor_map[parquet_data_id::RBE_DATA] = true;
    if (is_update_call_ == false)
    {
        m_timestamp_ = msg->header.stamp;
        update_previous_data();
    }
}

void ParquetExportSkelgen::parquet_export_objdata(msg_live_addon::msg::MsgCanObjListType* msg)
{
    memcpy(&can_obj_list_data_, msg, sizeof(can_obj_list_data_));
    append_values("CAN_OBJ_LIST", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"Header_Num_Obj", msg->r_header.num_obj},
        {"Header_Timestamp", msg->r_header.timestamp},
        {"Header_Timestamp_N_Sec", msg->r_header.timestamp_n_sec},
        {"Header_Scan_Id", msg->r_header.scan_id}
    });
    parquet_exporter::SignalValuesListType list_signal_values;
    for(uint32_t i = 0; i < msg->obj_arr.size(); i++)
    {
        list_signal_values["ObjArr_Crc_Obj_Data"].push_back(msg->obj_arr[i].crc_obj_data);
        list_signal_values["ObjArr_Mc_Obj_Data"].push_back(msg->obj_arr[i].mc_obj_data);
        list_signal_values["ObjArr_Object_id"].push_back(msg->obj_arr[i].object_id);
        list_signal_values["ObjArr_Object_Fu_Sa_level"].push_back(msg->obj_arr[i].object_fu_sa_level);
        list_signal_values["ObjArr_Object_Meas_Status"].push_back(msg->obj_arr[i].object_meas_status);
        list_signal_values["ObjArr_Object_Confidence"].push_back(msg->obj_arr[i].object_confidence);
        list_signal_values["ObjArr_Object_Age"].push_back(msg->obj_arr[i].object_age);
        list_signal_values["ObjArr_Object_motion_st"].push_back(msg->obj_arr[i].object_motion_st);
        list_signal_values["ObjArr_Object_Distance_X"].push_back(msg->obj_arr[i].object_distance_x);
        list_signal_values["ObjArr_Object_Distance_Std_Dev_X"].push_back(msg->obj_arr[i].object_distance_std_dev_x);
        list_signal_values["ObjArr_Object_Distance_Y"].push_back(msg->obj_arr[i].object_distance_y);
        list_signal_values["ObjArr_Object_Distance_Std_Dev_Y"].push_back(msg->obj_arr[i].object_distance_std_dev_y);
        list_signal_values["ObjArr_Object_Distance_Cov_XY"].push_back(msg->obj_arr[i].object_distance_cov_xy);
        list_signal_values["ObjArr_Object_Rel_Velocity_X"].push_back(msg->obj_arr[i].object_rel_velocity_x);
        list_signal_values["ObjArr_Object_Rel_Velocity_Std_Dev_X"].push_back(msg->obj_arr[i].object_rel_velocity_std_dev_x);
        list_signal_values["ObjArr_Object_Rel_Velocity_Y"].push_back(msg->obj_arr[i].object_rel_velocity_y);
        list_signal_values["ObjArr_Object_Rel_Velocity_Std_Dev_Y"].push_back(msg->obj_arr[i].object_rel_velocity_std_dev_y);
        list_signal_values["ObjArr_Object_Rel_Velocity_Cov_XY"].push_back(msg->obj_arr[i].object_rel_velocity_cov_xy);
        list_signal_values["ObjArr_Object_Rel_Accelaration_X"].push_back(msg->obj_arr[i].object_rel_acceleration_x);
        list_signal_values["ObjArr_Object_Rel_Accelaration_Std_Dev_X"].push_back(msg->obj_arr[i].object_rel_acceleration_std_dev_x);
        list_signal_values["ObjArr_Object_Rel_Accelaration_Y"].push_back(msg->obj_arr[i].object_rel_acceleration_y);
        list_signal_values["ObjArr_Object_Rel_Accelaration_Std_Dev_Y"].push_back(msg->obj_arr[i].object_rel_acceleration_std_dev_y);
        list_signal_values["ObjArr_Object_Rel_Accelaration_Cov_XY"].push_back(msg->obj_arr[i].object_rel_acceleration_cov_xy);
        list_signal_values["ObjArr_Object_Ref_Point"].push_back(msg->obj_arr[i].object_ref_point);
        list_signal_values["ObjArr_Object_Yaw_Angle"].push_back(msg->obj_arr[i].object_yaw_angle);
        list_signal_values["ObjArr_Object_Yaw_Angle_Std_Dev"].push_back(msg->obj_arr[i].object_yaw_angle_std_dev);
        list_signal_values["ObjArr_Object_Yaw_Rate"].push_back(msg->obj_arr[i].object_yaw_rate);
        list_signal_values["ObjArr_Object_Yaw_Rate_Std_Dev"].push_back(msg->obj_arr[i].object_yaw_rate_std_dev);
        list_signal_values["ObjArr_Object_Width"].push_back(msg->obj_arr[i].object_width);
        list_signal_values["ObjArr_Object_Width_Std_Dev"].push_back(msg->obj_arr[i].object_width_std_dev);
        list_signal_values["ObjArr_Object_Width_St"].push_back(msg->obj_arr[i].object_width_st);
        list_signal_values["ObjArr_Object_Length"].push_back(msg->obj_arr[i].object_length);
        list_signal_values["ObjArr_Object_Length_Std_Dev"].push_back(msg->obj_arr[i].object_length_std_dev);
        list_signal_values["ObjArr_Object_Length_St"].push_back(msg->obj_arr[i].object_length_st);
        list_signal_values["ObjArr_Object_Class"].push_back(msg->obj_arr[i].object_class);
        list_signal_values["ObjArr_Object_Class_Confidence"].push_back(msg->obj_arr[i].object_class_confidence);
        list_signal_values["ObjArr_Object_RCS"].push_back(msg->obj_arr[i].object_rcs);
        list_signal_values["ObjArr_Object_Over_under_driveable"].push_back(msg->obj_arr[i].object_over_under_drivable);
        list_signal_values["ObjArr_Object_Over_under_driveable_conf"].push_back(msg->obj_arr[i].object_over_under_driveable_conf);
        list_signal_values["ObjArr_Scan_Id"].push_back(msg->obj_arr[i].scan_id);
        list_signal_values["ObjArr_Mac_Object_Data"].push_back(msg->obj_arr[i].mac_object_data);
    }

    append_values("CAN_OBJ_LIST", list_signal_values);

    vistor_map[parquet_data_id::OBJ_DATA] = true;
    if (is_update_call_ == false)
    {
        m_timestamp_ = msg->header.stamp;
        update_previous_data();
    }
}

void ParquetExportSkelgen::parquet_export_vehdyn(msg_can_addon::msg::MsgVehdynType* msg)
{
    memcpy(&veh_dyn_data_, msg, sizeof(veh_dyn_data_));
    append_values("VEH_DYN", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"Glb_A_Coor_Ax", msg->glb_a_coor.ax},
        {"Glb_A_Coor_Ay", msg->glb_a_coor.ay},
        {"Glb_A_Coor_Az", msg->glb_a_coor.az},
        {"Glb_V_Coor_Vx", msg->glb_v_coor.vx},
        {"Glb_V_Coor_Vy", msg->glb_v_coor.vx},
        {"Glb_V_Coor_Vz", msg->glb_v_coor.vx},
        {"Road_Grdt", msg->road_grdt},
        {"Veh_A_Coor_Ax", msg->veh_a_coor.ax},
        {"Veh_A_Coor_Ay", msg->veh_a_coor.ay},
        {"Veh_A_Coor_Az", msg->veh_a_coor.az},
        {"Veh_Dyn_st", msg->veh_dyn_st},
        {"Veh_V_Coor_Vx", msg->veh_v_coor.vx},
        {"Veh_V_Coor_Vy", msg->veh_v_coor.vy},
        {"Veh_V_Coor_Vz", msg->veh_v_coor.vz},
        {"Yaw_Rate", msg->yaw_rate}
    });

    vistor_map[parquet_data_id::VEH_DYN] = true;
    if (is_update_call_ == false)
    {
        m_timestamp_ = msg->header.stamp;
        update_previous_data();
    }
}

void ParquetExportSkelgen::parquet_export_snsrmtn(msg_live_addon::msg::MsgSensrmtnType* msg)
{
    memcpy(&snsr_mtn_data_, msg, sizeof(snsr_mtn_data_));
    append_values("SNSR_MTN", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"V_Vx", msg->snsr_mtn_data.v.vx},
        {"V_Vy", msg->snsr_mtn_data.v.vy},
        {"V_Vz", msg->snsr_mtn_data.v.vz},
        {"V_Std_De_Vx", msg->snsr_mtn_data.v_std_de.vx},
        {"V_Std_De_Vy", msg->snsr_mtn_data.v_std_de.vy},
        {"V_Std_De_Vz", msg->snsr_mtn_data.v_std_de.vz},
        {"V_Estimn_St", msg->snsr_mtn_data.v_estimn_st},
        {"A_Ax", msg->snsr_mtn_data.a.ax},
        {"A_Ay", msg->snsr_mtn_data.a.ay},
        {"A_Az", msg->snsr_mtn_data.a.az},
        {"A_Std_De_Ax", msg->snsr_mtn_data.a_std_de.ax},
        {"A_Std_De_Ay", msg->snsr_mtn_data.a_std_de.ay},
        {"A_Std_De_Az", msg->snsr_mtn_data.a_std_de.az},
        {"A_Estimn_St", msg->snsr_mtn_data.a_estimn_st},
        {"Yaw_Rate", msg->snsr_mtn_data.yaw_rate},
        {"Yaw_Rate_Std_De", msg->snsr_mtn_data.yaw_rate_std_de},
        {"Yaw_Rate_St", msg->snsr_mtn_data.yaw_rate_st},
        {"Crv_Rd", msg->snsr_mtn_data.crv_rd},
        {"Crv_Rd_Std_De", msg->snsr_mtn_data.crv_rd_std_de},
        {"Crv_Rd_St", msg->snsr_mtn_data.crv_rd_st},
    });

    vistor_map[parquet_data_id::SNSR_MTN] = true;
    if (is_update_call_ == false)
    {
        m_timestamp_ = msg->header.stamp;
        update_previous_data();
    }
}

void ParquetExportSkelgen::parquet_export_vehmtn(msg_live_addon::msg::MsgVehmtnType* msg)
{
    memcpy(&veh_mtn_data_, msg, sizeof(veh_mtn_data_));
    append_values("VEH_MTN", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"V_Vx", msg->veh_mtn_data.v.vx},
        {"V_Vy", msg->veh_mtn_data.v.vy},
        {"V_Vz", msg->veh_mtn_data.v.vz},
        {"V_Std_De_Vx", msg->veh_mtn_data.v_std_de.vx},
        {"V_Std_De_Vy", msg->veh_mtn_data.v_std_de.vy},
        {"V_Std_De_Vz", msg->veh_mtn_data.v_std_de.vz},
        {"V_Estimn_St", msg->veh_mtn_data.v_estimn_st},
        {"A_Ax", msg->veh_mtn_data.a.ax},
        {"A_Ay", msg->veh_mtn_data.a.ay},
        {"A_Az", msg->veh_mtn_data.a.az},
        {"A_Std_De_Ax", msg->veh_mtn_data.a_std_de.ax},
        {"A_Std_De_Ay", msg->veh_mtn_data.a_std_de.ay},
        {"A_Std_De_Az", msg->veh_mtn_data.a_std_de.az},
        {"A_Estimn_St", msg->veh_mtn_data.a_estimn_st},
        {"Yaw_Rate", msg->veh_mtn_data.yaw_rate},
        {"Yaw_Rate_Std_De", msg->veh_mtn_data.yaw_rate_std_de},
        {"Yaw_Rate_St", msg->veh_mtn_data.yaw_rate_st},
        {"Crv_Rd", msg->veh_mtn_data.crv_rd},
        {"Crv_Rd_Std_De", msg->veh_mtn_data.crv_rd_std_de},
        {"Crv_Rd_St", msg->veh_mtn_data.crv_rd_st},
    });

    vistor_map[parquet_data_id::VEH_MTN] = true;
    if (is_update_call_ == false)
    {
        m_timestamp_ = msg->header.stamp;
        update_previous_data();
    }
}

void ParquetExportSkelgen::parquet_export_blkgdata(msg_live_addon::msg::MsgBlkgdebugType* msg)
{
    memcpy(&blkg_debug_data_, msg, sizeof(blkg_debug_data_));
    append_values("BLKG_DBG", {
        {"timestamp", rclcpp::Time(msg->header.stamp).nanoseconds()},
        {"blkg_active", msg->blkg_active},
        {"blkg_conf", msg->blkg_conf},
        {"blkg_deactivate_dist_count", msg->blkg_deactivate_dist_count},
        {"blkg_deactivate_obj_loss", msg->blkg_deactivate_obj_loss},
        {"blkg_deactivate_range", msg->blkg_deactivate_range},
        {"blkg_deactivate_time_count", msg->blkg_deactivate_time_count},
        {"blkg_detection_ratio_mean", msg->blkg_detection_ratio_mean},
        {"blkg_detection_ratio_mov", msg->blkg_detection_ratio_mov},
        {"blkg_detection_ratio_static", msg->blkg_detection_ratio_static},
        {"blkg_dist_count", msg->blkg_dist_count},
        {"blkg_fl_conf", msg->blkg_fl_conf},
        {"blkg_fl_mean", msg->blkg_fl_mean},
        {"blkg_fl_mov_max", msg->blkg_mov_max},
        {"blkg_fl_mov_mean",  msg->blkg_mov_mean},
        {"blkg_fl_mov_mean_conf",  msg->blkg_mov_mean_conf},
        {"blkg_obj_loss_conf", msg->blkg_obj_loss_conf},
        {"blkg_obj_loss_prob", msg->blkg_obj_loss_prob},
        {"blkg_range_conf", msg->blkg_range_conf},
        {"blkg_range_max", msg->blkg_range_max},
        {"blkg_range_mean", msg->blkg_range_mean},
        {"blkg_range_prob", msg->blkg_range_prob},
        {"blkg_st_max", msg->blkg_st_max},
        {"blkg_st_mean", msg->blkg_st_mean},
        {"blkg_st_mean_conf", msg->blkg_st_mean_conf},
        {"blkg_time_count", msg->blkg_time_count},
        {"blkg_time_dist_count_conf", msg->blkg_time_dist_count_conf},
        {"blkg_time_dist_count_prob", msg->blkg_time_dist_count_prob},
    });

    vistor_map[parquet_data_id::BLKG_DATA] = true;
    if (is_update_call_ == false)
    {
        m_timestamp_ = msg->header.stamp;
        update_previous_data();
    }
}

void ParquetExportSkelgen::parquet_export_node_feedback(
    msg_swc_common::msg::MsgNodeFeedbackType::UniquePtr msg)
{
    set_filename(msg->file_under_process);
    std::cout << "Writing parquet : " << msg->file_under_process << std::endl;
    std::thread thrd(std::bind(&ParquetExportSkelgen::write_parquet_file, this));
    thrd.detach();
}

void ParquetExportSkelgen::update_previous_data()
{
    is_update_call_ = true;
    if(!vistor_map[parquet_data_id::BLKG_DATA])
    {
        blkg_debug_data_.header.stamp = m_timestamp_;
        parquet_export_blkgdata(&blkg_debug_data_);
    }
    if(!vistor_map[parquet_data_id::OBJ_DATA])
    {
        can_obj_list_data_.header.stamp = m_timestamp_;
        parquet_export_objdata(&can_obj_list_data_);
    }
    if(!vistor_map[parquet_data_id::RADAR_CAL])
    {
        radar_cal_data_.header.stamp = m_timestamp_;
        parquet_export_radarcal(&radar_cal_data_)   ;

    }
    if(!vistor_map[parquet_data_id::RADAR_CFG])
    {
        radar_cfg_data_.header.stamp = m_timestamp_;
        parquet_export_radarcfg(&radar_cfg_data_);
    }
    if(!vistor_map[parquet_data_id::RADAR_INFO])
    {
        radar_info_data_.header.stamp = m_timestamp_;
        parquet_export_radarinfo(&radar_info_data_);
    }
    if(!vistor_map[parquet_data_id::RBE_DATA])
    {
        rbe_data_.header.stamp = m_timestamp_;
        parquet_export_roadborder(&rbe_data_);
    }
    if(!vistor_map[parquet_data_id::SNSR_MTN])
    {
        snsr_mtn_data_.header.stamp = m_timestamp_;
        parquet_export_snsrmtn(&snsr_mtn_data_);
    }
    if(!vistor_map[parquet_data_id::VEH_DYN])
    {
        veh_dyn_data_.header.stamp = m_timestamp_;
        parquet_export_vehdyn(&veh_dyn_data_);
    }
    if(!vistor_map[parquet_data_id::VEH_MTN])
    {
        veh_mtn_data_.header.stamp = m_timestamp_;
        parquet_export_vehmtn(&veh_mtn_data_);
    }
    
    is_update_call_ = false;
    reset_visitor_map();
}

void ParquetExportSkelgen::reset_data()
{
    memset(&radar_cfg_data_, 0, sizeof(radar_cfg_data_));
    memset(&radar_cal_data_, 0, sizeof(radar_cal_data_));
    memset(&veh_dyn_data_, 0, sizeof(veh_dyn_data_));
    memset(&can_obj_list_data_, 0, sizeof(can_obj_list_data_));
    memset(&rbe_data_, 0, sizeof(rbe_data_));
    memset(&snsr_mtn_data_, 0, sizeof(snsr_mtn_data_));
    memset(&veh_mtn_data_, 0, sizeof(veh_mtn_data_));
    memset(&blkg_debug_data_, 0, sizeof(blkg_debug_data_));
    memset(&radar_info_data_, 0, sizeof(radar_info_data_));
}

void ParquetExportSkelgen::reset_visitor_map()
{
    std::for_each(vistor_map.begin(), vistor_map.end(), [](auto& data){data.second = false;});
}