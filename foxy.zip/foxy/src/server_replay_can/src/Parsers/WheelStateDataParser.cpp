#include "WheelStateDataParser.h"
#include "Magna2RosConverter.h"

WheelStateDataParser::WheelStateDataParser(const std::string& dbc_file, const uint32_t frame_id)
    : ParserBase(dbc_file, frame_id)
{
    wheel_state_data_ = std::make_shared<radar_hydra3_private_whl_state_t>();
}

void WheelStateDataParser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    wheel_state_data_->crc_whl_state =
        static_cast<decltype(wheel_state_data_->crc_whl_state)>(DecodeMessage(message, "CRC_WHL_STATE", data));
    wheel_state_data_->mc_whl_state =
        static_cast<decltype(wheel_state_data_->mc_whl_state)>(DecodeMessage(message, "MC_WHL_STATE", data));
    wheel_state_data_->wheel_spd_fl =
        static_cast<decltype(wheel_state_data_->wheel_spd_fl)>(DecodeMessage(message, "WheelSpd_FL", data));
    wheel_state_data_->whl_spd_vld_fl =
        static_cast<decltype(wheel_state_data_->whl_spd_vld_fl)>(DecodeMessage(message, "WhlSpdVld_FL", data));
    wheel_state_data_->wheel_spd_fr =
        static_cast<decltype(wheel_state_data_->wheel_spd_fr)>(DecodeMessage(message, "WheelSpd_FR", data));
    wheel_state_data_->whl_spd_vld_fr =
        static_cast<decltype(wheel_state_data_->whl_spd_vld_fr)>(DecodeMessage(message, "WhlSpdVld_FR", data));
    wheel_state_data_->wheel_spd_rl =
        static_cast<decltype(wheel_state_data_->wheel_spd_rl)>(DecodeMessage(message, "WheelSpd_RL", data));
    wheel_state_data_->whl_spd_vld_rl =
        static_cast<decltype(wheel_state_data_->whl_spd_vld_rl)>(DecodeMessage(message, "WhlSpdVld_RL", data));
    wheel_state_data_->wheel_spd_rr =
        static_cast<decltype(wheel_state_data_->wheel_spd_rr)>(DecodeMessage(message, "WheelSpd_RR", data));
    wheel_state_data_->whl_spd_vld_rr =
        static_cast<decltype(wheel_state_data_->whl_spd_vld_rr)>(DecodeMessage(message, "WhlSpdVld_RR", data));
    wheel_state_data_->whl_dir_fl =
        static_cast<decltype(wheel_state_data_->whl_dir_fl)>(DecodeMessage(message, "WhlDir_FL", data));
    wheel_state_data_->whl_dir_fr =
        static_cast<decltype(wheel_state_data_->whl_dir_fr)>(DecodeMessage(message, "WhlDir_FR", data));
    wheel_state_data_->whl_dir_rl =
        static_cast<decltype(wheel_state_data_->whl_dir_rl)>(DecodeMessage(message, "WhlDir_RL", data));
    wheel_state_data_->whl_dir_rr =
        static_cast<decltype(wheel_state_data_->whl_dir_rr)>(DecodeMessage(message, "WhlDir_RR", data));
    wheel_state_data_->whl_pls_cnt_fl =
        static_cast<decltype(wheel_state_data_->whl_pls_cnt_fl)>(DecodeMessage(message, "WhlPlsCnt_FL", data));
    wheel_state_data_->whl_pls_cnt_fr =
        static_cast<decltype(wheel_state_data_->whl_pls_cnt_fr)>(DecodeMessage(message, "WhlPlsCnt_FR", data));
    wheel_state_data_->whl_pls_cnt_rl =
        static_cast<decltype(wheel_state_data_->whl_pls_cnt_rl)>(DecodeMessage(message, "WhlPlsCnt_RL", data));
    wheel_state_data_->whl_pls_cnt_rr =
        static_cast<decltype(wheel_state_data_->whl_pls_cnt_rr)>(DecodeMessage(message, "WhlPlsCnt_RR", data));
    wheel_state_data_->mac_whl_state =
        static_cast<decltype(wheel_state_data_->mac_whl_state)>(DecodeMessage(message, "MAC_WHL_STATE", data));
}

void WheelStateDataParser::AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const
{
    converter.Convert(*this, timestamp);
}

std::shared_ptr<radar_hydra3_private_whl_state_t> WheelStateDataParser::GetDecodedData() const
{
    return wheel_state_data_;
}
