#include "RadarCfgParser.h"
#include "Magna2RosConverter.h"

const float RadarCfgParser::DEFAULT_RADAR_ORIENTATION_ROLL_DEG = 0.0F;
const float RadarCfgParser::RIGHT_RADAR_ORIENTATION_ROLL_DEG = 180.0F;

RadarCfgParser::RadarCfgParser(const std::string& dbc_file, const uint32_t frame_id) : ParserBase(dbc_file, frame_id)
{
    radar_cfg_ = std::make_shared<radar_hydra3_private_radar_cfg_t>();
}

void RadarCfgParser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    radar_cfg_->crc_radar_cfg =
        static_cast<decltype(radar_cfg_->crc_radar_cfg)>(DecodeMessage(message, "CRC_RadarCfg", data));

    radar_cfg_->mc_radar_cfg =
        static_cast<decltype(radar_cfg_->mc_radar_cfg)>(DecodeMessage(message, "MC_RadarCfg", data));

    radar_cfg_->radar_pos_x = static_cast<decltype(radar_cfg_->radar_pos_x)>(DecodeMessage(message, "RadarPosX", data));
    radar_cfg_->radar_pos_x_st =
        static_cast<decltype(radar_cfg_->radar_pos_x_st)>(DecodeMessage(message, "RadarPosXSt", data));

    radar_cfg_->radar_pos_y = static_cast<decltype(radar_cfg_->radar_pos_y)>(DecodeMessage(message, "RadarPosY", data));
    radar_cfg_->radar_pos_y_st =
        static_cast<decltype(radar_cfg_->radar_pos_y_st)>(DecodeMessage(message, "RadarPosYSt", data));

    radar_cfg_->radar_pos_z = static_cast<decltype(radar_cfg_->radar_pos_z)>(DecodeMessage(message, "RadarPosZ", data));
    radar_cfg_->radar_pos_z_st =
        static_cast<decltype(radar_cfg_->radar_pos_z_st)>(DecodeMessage(message, "RadarPosZSt", data));

    radar_cfg_->radar_angl_azimuth =
        static_cast<decltype(radar_cfg_->radar_angl_azimuth)>(DecodeMessage(message, "RadarAnglAzimuth", data));
    radar_cfg_->radar_angl_azimuth_st =
        static_cast<decltype(radar_cfg_->radar_angl_azimuth_st)>(DecodeMessage(message, "RadarAnglAzimuthSt", data));

    radar_cfg_->radar_role_config =
        static_cast<decltype(radar_cfg_->radar_role_config)>(DecodeMessage(message, "RadarRoleConfig", data));

    radar_cfg_->radar_func_cfg =
        static_cast<decltype(radar_cfg_->radar_func_cfg)>(DecodeMessage(message, "RadarFuncCfg", data));

    radar_cfg_->radar_angl_elevation =
        static_cast<decltype(radar_cfg_->radar_angl_elevation)>(DecodeMessage(message, "RadarAnglElevation", data));
    radar_cfg_->radar_angl_elevation_st = static_cast<decltype(radar_cfg_->radar_angl_elevation_st)>(
        DecodeMessage(message, "RadarAnglElevationSt", data));

    if (!IfSignalGroupHasSignalName(message, "RadarAnglRoll"))
    {
        radar_cfg_->radar_angl_roll = GetDefaultRadarRoll(radar_cfg_->radar_role_config);
    }

    else
    {
        radar_cfg_->radar_angl_roll =
            static_cast<decltype(radar_cfg_->radar_angl_roll)>(DecodeMessage(message, "RadarAnglRoll", data));
        radar_cfg_->radar_angl_roll_st =
            static_cast<decltype(radar_cfg_->radar_angl_roll_st)>(DecodeMessage(message, "RadarAnglRollSt", data));
    }

    radar_cfg_->mac_radar_cfg =
        static_cast<decltype(radar_cfg_->mac_radar_cfg)>(DecodeMessage(message, "MAC_RADAR_CFG", data));
}

void RadarCfgParser::AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const
{
    converter.Convert(*this, timestamp);
}

std::shared_ptr<radar_hydra3_private_radar_cfg_t> RadarCfgParser::GetDecodedData() const
{
    return radar_cfg_;
}

bool RadarCfgParser::IfSignalGroupHasSignalName(const Vector::DBC::Message& dbc_message, const std::string& signal_name)
{
    return (dbc_message.signals.find(signal_name) != dbc_message.signals.end());
}

float RadarCfgParser::GetDefaultRadarRoll(uint8_t radar_role_config)
{
    float radar_roll{0.0f};
    switch (radar_role_config)
    {
    case RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_FRONT_CHOICE:
        radar_roll = DEFAULT_RADAR_ORIENTATION_ROLL_DEG;
        break;

    case RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_CORNER_FL_CHOICE:
        radar_roll = DEFAULT_RADAR_ORIENTATION_ROLL_DEG;
        break;
    case RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_CORNER_FR_CHOICE:
        radar_roll = RIGHT_RADAR_ORIENTATION_ROLL_DEG;
        break;
    case RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_CORNER_RL_CHOICE:
        radar_roll = DEFAULT_RADAR_ORIENTATION_ROLL_DEG;
        break;
    case RADAR_HYDRA3_PRIVATE_RADAR_CFG_RADAR_ROLE_CONFIG_RADAR_ROLE_CONFIG_ROLE_CORNER_RR_CHOICE:
        radar_roll = RIGHT_RADAR_ORIENTATION_ROLL_DEG;
        break;
    default:
        radar_roll = DEFAULT_RADAR_ORIENTATION_ROLL_DEG;
        break;
    }

    return radar_roll;
}