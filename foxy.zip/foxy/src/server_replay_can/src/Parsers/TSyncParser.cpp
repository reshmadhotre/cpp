#include "TSyncParser.h"
#include "Magna2RosConverter.h"

TSyncParser::TSyncParser(const std::string& dbc_file, const uint32_t frame_id) : ParserBase(dbc_file, frame_id)
{
    tsync_ = std::make_shared<radar_hydra3_private_tsync_t>();

    for (unsigned int i = 0; i < RADAR_HYDRA3_PRIVATE_TSYNC_LENGTH; i++)
    {
        encoded_data_.push_back(0);
        encoded_data_mux_1_.push_back(0);
        encoded_data_mux_2_.push_back(0);
    }
}

void TSyncParser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    tsync_->can_t_syn_type =
        static_cast<decltype(tsync_->can_t_syn_type)>(DecodeMessage(message, "CanTSyn_Type", data));
    tsync_->can_t_syn_crc = static_cast<decltype(tsync_->can_t_syn_crc)>(DecodeMessage(message, "CanTSyn_CRC", data));
    tsync_->can_t_syn_d = static_cast<decltype(tsync_->can_t_syn_d)>(DecodeMessage(message, "CanTSyn_D", data));
    tsync_->can_t_syn_sc = static_cast<decltype(tsync_->can_t_syn_sc)>(DecodeMessage(message, "CanTSyn_SC", data));
    tsync_->can_t_syn_rsvrd0 =
        static_cast<decltype(tsync_->can_t_syn_rsvrd0)>(DecodeMessage(message, "CanTSyn_RSVRD0", data));
    tsync_->can_t_syn_usb0 =
        static_cast<decltype(tsync_->can_t_syn_usb0)>(DecodeMessage(message, "CanTSyn_USB0", data));
    tsync_->can_t_syn_fup_sgw =
        static_cast<decltype(tsync_->can_t_syn_fup_sgw)>(DecodeMessage(message, "CanTSyn_FUP_SGW", data));
    tsync_->can_t_syn_ovs = static_cast<decltype(tsync_->can_t_syn_ovs)>(DecodeMessage(message, "CanTSyn_OVS", data));
    tsync_->can_t_syn_sync_time_n_sec =
        static_cast<decltype(tsync_->can_t_syn_sync_time_n_sec)>(DecodeMessage(message, "CanTSyn_SyncTimeNSec", data));
    tsync_->can_t_syn_sync_time_sec =
        static_cast<decltype(tsync_->can_t_syn_sync_time_sec)>(DecodeMessage(message, "CanTSyn_SyncTimeSec", data));
}


void TSyncParser::AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const
{
    converter.Convert(*this, timestamp);
}


std::shared_ptr<radar_hydra3_private_tsync_t> TSyncParser::GetDecodedData() const
{
    return tsync_;
}


void TSyncParser::SetValue(std::string signal_name, double value)
{
    static auto message = GetDBCMessage();
       
    if (signal_name == "CanTSyn_SyncTimeSec")
    {
        tsync_->can_t_syn_sync_time_sec = (uint32_t) value;
        EncodeMessage(message, signal_name, encoded_data_mux_1_, tsync_->can_t_syn_sync_time_sec);
    }
    else if (signal_name == "CanTSyn_SyncTimeNSec")
    {
        tsync_->can_t_syn_sync_time_n_sec = (uint32_t) value;
        EncodeMessage(message, signal_name, encoded_data_mux_2_, tsync_->can_t_syn_sync_time_n_sec);
    }
    else if (signal_name == "CanTSyn_Type")
    {
        tsync_->can_t_syn_type = (uint8_t) value;
        if(toggle_mux_)
            EncodeMessage(message, signal_name, encoded_data_mux_1_, tsync_->can_t_syn_type);
        else
            EncodeMessage(message, signal_name, encoded_data_mux_2_, tsync_->can_t_syn_type);
    }
    else if (signal_name == "time_sync_reset")
    {
        if (value == true)
            time_sync_offset_ = std::chrono::system_clock::from_time_t(0);
        else
            time_sync_offset_ = std::chrono::system_clock::now();
    }
    else
    {
        RCLCPP_ERROR(rclcpp::get_logger("CAN PARSER LOGGER"), "Signal name unknown : %s.", signal_name.c_str());
    }
}


void TSyncParser::Update()
{
    static std::chrono::system_clock::duration sentTime;
    static std::chrono::system_clock::duration confirmationTime;
    
    if (toggle_mux_)
    {
        SetValue("CanTSyn_Type", 0x20);
        auto now = std::chrono::system_clock::now();
        sentTime = now - time_sync_offset_;
        SetValue("CanTSyn_SyncTimeSec", std::chrono::duration_cast<std::chrono::seconds>(sentTime).count());
    }
    else
    {
        SetValue("CanTSyn_Type", 0x28);
        SetValue("CanTSyn_SyncTimeNSec", std::chrono::duration_cast<std::chrono::nanoseconds>(confirmationTime - sentTime).count());
    }

    UpdateSC();
    UpdateCRC();

    if (toggle_mux_)
    {
        confirmationTime = (std::chrono::system_clock::now() - time_sync_offset_);
        encoded_data_ = encoded_data_mux_1_;
    }
    else
        encoded_data_ = encoded_data_mux_2_;

    toggle_mux_ = !toggle_mux_;
}


void TSyncParser::UpdateSC()
{
    static auto message = GetDBCMessage();

    if (toggle_mux_)
    {
        tsync_->can_t_syn_sc = (tsync_->can_t_syn_sc + 1 )& 0xF;
        EncodeMessage(message, "CanTSyn_SC", encoded_data_mux_1_, tsync_->can_t_syn_sc);
    }
    else
        EncodeMessage(message, "CanTSyn_SC", encoded_data_mux_2_, tsync_->can_t_syn_sc);
}

void TSyncParser::UpdateCRC(void)
{
    static auto message = GetDBCMessage();
    uint8_t tmpData[15]{};

    if (toggle_mux_)
        memcpy(&(tmpData[0]), ((uint8_t*)&encoded_data_mux_1_[2]), 13);
    else
        memcpy(&(tmpData[0]), ((uint8_t*)&encoded_data_mux_2_[2]), 13);

    tmpData[14] = tsync_->can_t_syn_sc;
    unsigned char crc = Crc_CalculateCRC8H2F(tmpData, 15, 0, 1);
    tsync_->can_t_syn_crc = crc;

    if (toggle_mux_)
        EncodeMessage(message, "CanTSyn_CRC", encoded_data_mux_1_, tsync_->can_t_syn_crc);
    else
        EncodeMessage(message, "CanTSyn_CRC", encoded_data_mux_2_, tsync_->can_t_syn_crc);
}