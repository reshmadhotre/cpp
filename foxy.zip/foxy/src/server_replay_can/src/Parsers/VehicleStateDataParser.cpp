#include "VehicleStateDataParser.h"
#include "Magna2RosConverter.h"




VehicleStateDataParser::VehicleStateDataParser(const std::string& dbc_file, const uint32_t frame_id)
    : ParserBase(dbc_file, frame_id)
{
    veh_state_data_ = std::make_shared<radar_hydra3_private_veh_state_t>();
    
    for(unsigned int i=0 ; i<RADAR_HYDRA3_PRIVATE_VEH_STATE_LENGTH ; i++)
        encoded_data_.push_back(0);
}


void VehicleStateDataParser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    veh_state_data_->crc_veh_state =
        static_cast<decltype(veh_state_data_->crc_veh_state)>(DecodeMessage(message, "CRC_VEH_STATE", data));

    veh_state_data_->mc_veh_state =
        static_cast<decltype(veh_state_data_->mc_veh_state)>(DecodeMessage(message, "MC_VEH_STATE", data));
    veh_state_data_->veh_speed =
        static_cast<decltype(veh_state_data_->veh_speed)>(DecodeMessage(message, "VehSpeed", data));

    veh_state_data_->veh_accel =
        static_cast<decltype(veh_state_data_->veh_accel)>(DecodeMessage(message, "VehAccel", data));
    veh_state_data_->veh_accel_x =
        static_cast<decltype(veh_state_data_->veh_accel_x)>(DecodeMessage(message, "VehAccelX", data));
    veh_state_data_->veh_accel_y =
        static_cast<decltype(veh_state_data_->veh_accel_y)>(DecodeMessage(message, "VehAccelY", data));

    veh_state_data_->veh_yaw_rate =
        static_cast<decltype(veh_state_data_->veh_yaw_rate)>(DecodeMessage(message, "VehYawRate", data));

    veh_state_data_->steering_angle =
        static_cast<decltype(veh_state_data_->steering_angle)>(DecodeMessage(message, "SteeringAngle", data));

    veh_state_data_->veh_speed_st =
        static_cast<decltype(veh_state_data_->veh_speed_st)>(DecodeMessage(message, "VehSpeedSt", data));

    veh_state_data_->veh_accel_st =
        static_cast<decltype(veh_state_data_->veh_accel_st)>(DecodeMessage(message, "VehAccelSt", data));
    veh_state_data_->veh_accel_x_st =
        static_cast<decltype(veh_state_data_->veh_accel_x_st)>(DecodeMessage(message, "VehAccelXSt", data));
    veh_state_data_->veh_accel_y_st =
        static_cast<decltype(veh_state_data_->veh_accel_y_st)>(DecodeMessage(message, "VehAccelYSt", data));

    veh_state_data_->veh_yaw_rate_st =
        static_cast<decltype(veh_state_data_->veh_yaw_rate_st)>(DecodeMessage(message, "VehYawRateSt", data));

    veh_state_data_->steering_angle_st =
        static_cast<decltype(veh_state_data_->steering_angle_st)>(DecodeMessage(message, "SteeringAngleSt", data));

    veh_state_data_->outside_temp =
        static_cast<decltype(veh_state_data_->outside_temp)>(DecodeMessage(message, "OutsideTemp", data));
    veh_state_data_->brake_st =
        static_cast<decltype(veh_state_data_->brake_st)>(DecodeMessage(message, "BrakeSt", data));
    veh_state_data_->wiper_st =
        static_cast<decltype(veh_state_data_->wiper_st)>(DecodeMessage(message, "WiperSt", data));
    veh_state_data_->dc_st = static_cast<decltype(veh_state_data_->dc_st)>(DecodeMessage(message, "DCSt", data));
    veh_state_data_->steering_angle_spd =
        static_cast<decltype(veh_state_data_->steering_angle_spd)>(DecodeMessage(message, "SteeringAngleSpd", data));
    veh_state_data_->steering_angle_spd_st = static_cast<decltype(veh_state_data_->steering_angle_spd_st)>(
        DecodeMessage(message, "SteeringAngleSpdSt", data));
    veh_state_data_->outside_temp_st =
        static_cast<decltype(veh_state_data_->outside_temp_st)>(DecodeMessage(message, "OutsideTempSt", data));
    veh_state_data_->veh_motion_st =
        static_cast<decltype(veh_state_data_->veh_motion_st)>(DecodeMessage(message, "VehMotionSt", data));
    veh_state_data_->radar_ctrl =
        static_cast<decltype(veh_state_data_->radar_ctrl)>(DecodeMessage(message, "RadarCtrl", data));
    veh_state_data_->rain_sensor_st =
        static_cast<decltype(veh_state_data_->rain_sensor_st)>(DecodeMessage(message, "RainSensorSt", data));
    veh_state_data_->mac_veh_state =
        static_cast<decltype(veh_state_data_->mac_veh_state)>(DecodeMessage(message, "MAC_VEH_STATE", data));
}


void VehicleStateDataParser::AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const
{
    converter.Convert(*this, timestamp);
}


std::shared_ptr<radar_hydra3_private_veh_state_t> VehicleStateDataParser::GetDecodedData() const
{
    return veh_state_data_;
}


void VehicleStateDataParser::SetValue(std::string signal_name, double value)
{
    static auto message = GetDBCMessage();
    if (signal_name == "RadarCtrl")
    {
        veh_state_data_->radar_ctrl = (uint8_t) value;
        EncodeMessage(message, signal_name, encoded_data_, veh_state_data_->radar_ctrl);
    }
    else
    {
        RCLCPP_ERROR(rclcpp::get_logger("CAN PARSER LOGGER"), "Signal name unknown : %s.",
                     signal_name.c_str());
    }
}


void VehicleStateDataParser::Update()
{
    size_t cmac_size = 3;
    UpdateMC();
    UpdateCRC(cmac_size);
    UpdateMAC(cmac_size);
}


void VehicleStateDataParser::UpdateMC()
{
    static auto message = GetDBCMessage();
    veh_state_data_->mc_veh_state++;
    EncodeMessage(message, "MC_VEH_STATE", encoded_data_, veh_state_data_->mc_veh_state);
}


void VehicleStateDataParser::UpdateCRC(size_t cmac_size)
{
    static auto message = GetDBCMessage();
    std::vector<uint8_t> data(encoded_data_.begin()+1, encoded_data_.begin() + (RADAR_HYDRA3_PRIVATE_VEH_STATE_LENGTH - cmac_size));

    unsigned char crc = Crc_CalculateCRC8(&veh_state_data_id[0], veh_state_data_id.size(), 0xFF, false);
    crc = Crc_CalculateCRC8(&data[0], data.size(), crc, false);
    crc = crc ^ 0xFF;

    veh_state_data_->crc_veh_state = crc;
    EncodeMessage(message, "CRC_VEH_STATE", encoded_data_, veh_state_data_->crc_veh_state);
}


/* http://rubenlaguna.com/post/2015-02-05-compute-aes-cmac-using-openssl-slash-libcrypto/*/
void VehicleStateDataParser::UpdateMAC(size_t mac_size)
{
    static auto message = GetDBCMessage();
    unsigned char mact[16] = {0}; 
    static uint16_t mac_magic_number = 437;

    CalculateMAC(mact, mac_size, mac_magic_number);

    if(mac_size == 3)
    {
        veh_state_data_->mac_veh_state = 
            (uint32_t)mact[0] << 16 |
            (uint32_t)mact[1] << 8  |
            (uint32_t)mact[2];
    }
    else
        std::cout << "ERROR - cmac size != 3" << std::endl;

    EncodeMessage(message, "MAC_VEH_STATE", encoded_data_, veh_state_data_->mac_veh_state);
}