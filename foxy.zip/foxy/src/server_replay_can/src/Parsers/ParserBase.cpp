#include "ParserBase.h"
#include "rclcpp/rclcpp.hpp"

Vector::DBC::Network ParserBase::dbc_network_;


ParserBase::ParserBase(const std::string& dbc_file, const uint32_t frame_id)
{
    if (!IsNetworkInitialized())
    {
        SetNetwork(dbc_file);
    }
    frame_id_ = frame_id;
}



void ParserBase::SetNetwork(const std::string& dbc_file)
{
    try
    {
        std::fstream filestream(dbc_file, std::ios::in);
        filestream >> dbc_network_;
    }
    catch (const std::exception& e)
    {
        RCLCPP_ERROR(rclcpp::get_logger("CAN PARSER LOGGER"),
                     "Error setting Vector CAN Network with given dbc file : %s", dbc_file.c_str());
        std::cerr << e.what() << '\n';
    }
}



bool ParserBase::IsNetworkInitialized()
{
    return dbc_network_.successfullyParsed;
}



double ParserBase::DecodeMessage(const Vector::DBC::Message& dbc_msg, const std::string& signal_name,
                                 std::vector<uint8_t>& data)
{
    try
    {
        auto signal = dbc_msg.signals.at(signal_name);
        return signal.rawToPhysicalValue(signal.decode(data));
    }
    catch (const std::exception& e)
    {
        double default_value = 0.0;
        RCLCPP_DEBUG(rclcpp::get_logger("CAN PARSER LOGGER"), "Error decoding signal : %s. Setting value to : %f",
                     signal_name.c_str(), (float)(default_value));
        return default_value;
    }
}



void ParserBase::EncodeMessage(const Vector::DBC::Message& dbc_msg, const std::string& signal_name,
                                 std::vector<uint8_t>& data, double physicalValue)
{
    try
    {
        auto signal = dbc_msg.signals.at(signal_name);
        double raw_value = signal.physicalToRawValue(physicalValue);
        signal.encode(data, raw_value);
    }
    catch (const std::exception& e)
    {
        RCLCPP_DEBUG(rclcpp::get_logger("CAN PARSER LOGGER"), "Error encoding signal : %s.",
                     signal_name.c_str());
    }
}


void ParserBase::SetValue(std::string signal_name, double value)
{
    std::cout << "Override me!" << std::endl;
    std::cout << "Signal name: " << signal_name << std::endl;
    std::cout << "Value: " << value << std::endl;
}



Vector::DBC::Message ParserBase::GetDBCMessage()
{
    return dbc_network_.messages[frame_id_];
}



uint32_t ParserBase::GetFrameID() const
{
    return frame_id_;
}


uint8_t ParserBase::CalculateCRC8(const uint8_t *message, uint32_t nBytes, uint8_t start, uint8_t poly)
{
    uint32_t f = 0;
    uint8_t bit = 0;

    for (f = 0; f < nBytes; f++)
    {
        start ^= message[f];
        for (bit = 0; bit < 8; bit++)
        {
            if ((start & 0x80) != 0)
            {
                start <<= 1;
                start ^= poly;
            }
            else
            {
                start <<= 1;
            }
        }
    }

    return start;
}


uint8_t ParserBase::Crc_CalculateCRC8(const uint8_t *Crc_DataPtr, uint32_t Crc_Length, uint8_t Crc_StartValue8, bool Crc_IsFirstCall)
{
    uint8_t crc = 0x00;

    if (Crc_DataPtr != NULL)
    {
        if (Crc_IsFirstCall)
            crc = CRC8_START_VALUE;
        else
            crc = Crc_StartValue8 ^ CRC8_XOR;

        crc = CalculateCRC8(Crc_DataPtr, Crc_Length, crc, CRC8_POLYNOMIAL);

        crc = crc ^ CRC8_XOR;
    }

    return crc;
}


uint8_t ParserBase::Crc_CalculateCRC8H2F(const uint8_t *Crc_DataPtr, uint32_t Crc_Length, uint8_t Crc_StartValue8, bool Crc_IsFirstCall)
{
    uint8_t crc = 0x00;

    if (Crc_DataPtr != NULL)
    {
        if (Crc_IsFirstCall)
            crc = CRC8_START_VALUE;
        else
            crc = Crc_StartValue8 ^ CRC8_XOR;

        crc = CalculateCRC8(Crc_DataPtr, Crc_Length, crc, CRC8H2F_POLYNOMIAL);

        crc = crc ^ CRC8_XOR;
    }

    return crc;
}


/* http://rubenlaguna.com/post/2015-02-05-compute-aes-cmac-using-openssl-slash-libcrypto/*/
void ParserBase::CalculateMAC(uint8_t *mac, size_t mac_size, uint16_t mac_magic_number)
{
    static unsigned char key[] = { 
        0x00, 0x00, 0x00, 0x00, 
        0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00
    };

    std::vector<uint8_t> data(encoded_data_);
    size_t mactlen;

    data.insert(data.begin() + 0, (mac_magic_number >> 8) & 0xFF);
    data.insert(data.begin() + 1, mac_magic_number & 0xFF);

    CMAC_CTX *ctx = CMAC_CTX_new();

    CMAC_Init(ctx, key, 16, EVP_aes_128_cbc(), NULL);
    CMAC_Update(ctx, &data[0], data.size()- mac_size);
    CMAC_Final(ctx, mac, &mactlen);

    CMAC_CTX_free(ctx);
}

