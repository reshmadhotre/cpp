#include "ObjectDataParser.h"
#include "FrameIDDefs.h"
#include "Magna2RosConverter.h"

ObjectDataParser::ObjectDataParser(const std::string& dbc_file, const uint32_t frame_id)
    : ParserBase(dbc_file, frame_id)
{
    object_data_ = std::make_shared<radar_hydra3_private_obj_data_t>();
}

void ObjectDataParser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    auto frame_id = GetFrameID();
    auto obj_index = GetObjIndexFromFrameID(frame_id);
    if (obj_index < 0)
    {
        std::cerr << "Frame ID : " << frame_id << " doesn't have an associated object index!!!" << std::endl;
        return;
    }
    std::string suffix = GenerateSuffixFromObjIndex(obj_index);

    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    object_data_->crc_obj_data =
        static_cast<decltype(object_data_->crc_obj_data)>(DecodeMessage(message, "CRC_OBJ_DATA" + suffix, data));

    object_data_->mc_obj_data =
        static_cast<decltype(object_data_->mc_obj_data)>(DecodeMessage(message, "MC_OBJ_DATA" + suffix, data));

    object_data_->object_id =
        static_cast<decltype(object_data_->object_id)>(DecodeMessage(message, "ObjectID" + suffix, data));

    object_data_->object_fu_sa_level = static_cast<decltype(object_data_->object_fu_sa_level)>(
        DecodeMessage(message, "ObjectFuSaLevel" + suffix, data));

    object_data_->object_meas_status = static_cast<decltype(object_data_->object_meas_status)>(
        DecodeMessage(message, "ObjectMeasStatus" + suffix, data));

    object_data_->object_confidence = static_cast<decltype(object_data_->object_confidence)>(
        DecodeMessage(message, "ObjectConfidence" + suffix, data));

    object_data_->object_age =
        static_cast<decltype(object_data_->object_age)>(DecodeMessage(message, "ObjectAge" + suffix, data));
    object_data_->object_motion_st =
        static_cast<decltype(object_data_->object_motion_st)>(DecodeMessage(message, "ObjectMotionSt" + suffix, data));

    object_data_->object_distance_x = static_cast<decltype(object_data_->object_distance_x)>(
        DecodeMessage(message, "ObjectDistanceX" + suffix, data));
    object_data_->object_distance_std_dev_x = static_cast<decltype(object_data_->object_distance_std_dev_x)>(
        DecodeMessage(message, "ObjectDistanceStdDevX" + suffix, data));

    object_data_->object_distance_y = static_cast<decltype(object_data_->object_distance_y)>(
        DecodeMessage(message, "ObjectDistanceY" + suffix, data));
    object_data_->object_distance_std_dev_y = static_cast<decltype(object_data_->object_distance_std_dev_y)>(
        DecodeMessage(message, "ObjectDistanceStdDevY" + suffix, data));

    object_data_->object_distance_cov_xy = static_cast<decltype(object_data_->object_distance_cov_xy)>(
        DecodeMessage(message, "ObjectDistanceCovXY" + suffix, data));

    object_data_->object_rel_velocity_x = static_cast<decltype(object_data_->object_rel_velocity_x)>(
        DecodeMessage(message, "ObjectRelVelocityX" + suffix, data));
    object_data_->object_rel_velocity_std_dev_x = static_cast<decltype(object_data_->object_rel_velocity_std_dev_x)>(
        DecodeMessage(message, "ObjectRelVelocityStdDevX" + suffix, data));

    object_data_->object_rel_velocity_y = static_cast<decltype(object_data_->object_rel_velocity_y)>(
        DecodeMessage(message, "ObjectRelVelocityY" + suffix, data));
    object_data_->object_rel_velocity_std_dev_y = static_cast<decltype(object_data_->object_rel_velocity_std_dev_y)>(
        DecodeMessage(message, "ObjectRelVelocityStdDevY" + suffix, data));

    object_data_->object_rel_velocity_cov_xy = static_cast<decltype(object_data_->object_rel_velocity_cov_xy)>(
        DecodeMessage(message, "ObjectRelVelocityCovXY" + suffix, data));

    object_data_->object_rel_acceleration_x = static_cast<decltype(object_data_->object_rel_acceleration_x)>(
        DecodeMessage(message, "ObjectRelAccelerationX" + suffix, data));
    object_data_->object_rel_acceleration_std_dev_x =
        static_cast<decltype(object_data_->object_rel_acceleration_std_dev_x)>(
            DecodeMessage(message, "ObjectRelAccelerationStdDevX" + suffix, data));

    object_data_->object_rel_acceleration_y = static_cast<decltype(object_data_->object_rel_acceleration_y)>(
        DecodeMessage(message, "ObjectRelAccelerationY" + suffix, data));
    object_data_->object_rel_acceleration_std_dev_y =
        static_cast<decltype(object_data_->object_rel_acceleration_std_dev_y)>(
            DecodeMessage(message, "ObjectRelAccelerationStdDevY" + suffix, data));

    object_data_->object_rel_acceleration_cov_xy = static_cast<decltype(object_data_->object_rel_acceleration_cov_xy)>(
        DecodeMessage(message, "ObjectRelAccelerationCovXY" + suffix, data));

    object_data_->object_ref_point =
        static_cast<decltype(object_data_->object_ref_point)>(DecodeMessage(message, "ObjectRefPoint" + suffix, data));

    object_data_->object_yaw_angle =
        static_cast<decltype(object_data_->object_yaw_angle)>(DecodeMessage(message, "ObjectYawAngle" + suffix, data));
    object_data_->object_yaw_angle_std_dev = static_cast<decltype(object_data_->object_yaw_angle_std_dev)>(
        DecodeMessage(message, "ObjectYawAngleStdDev" + suffix, data));

    object_data_->object_yaw_rate =
        static_cast<decltype(object_data_->object_yaw_rate)>(DecodeMessage(message, "ObjectYawRate" + suffix, data));
    object_data_->object_yaw_rate_std_dev = static_cast<decltype(object_data_->object_yaw_rate_std_dev)>(
        DecodeMessage(message, "ObjectYawRateStdDev" + suffix, data));

    object_data_->object_width =
        static_cast<decltype(object_data_->object_width)>(DecodeMessage(message, "ObjectWidth" + suffix, data));
    object_data_->object_width_std_dev = static_cast<decltype(object_data_->object_width_std_dev)>(
        DecodeMessage(message, "ObjectWidthStdDev" + suffix, data));
    object_data_->object_width_st =
        static_cast<decltype(object_data_->object_width_st)>(DecodeMessage(message, "ObjectWidthSt" + suffix, data));

    object_data_->object_length =
        static_cast<decltype(object_data_->object_length)>(DecodeMessage(message, "ObjectLength" + suffix, data));
    object_data_->object_length_std_dev = static_cast<decltype(object_data_->object_length_std_dev)>(
        DecodeMessage(message, "ObjectLengthStdDev" + suffix, data));
    object_data_->object_length_st =
        static_cast<decltype(object_data_->object_length_st)>(DecodeMessage(message, "ObjectLengthSt" + suffix, data));

    object_data_->object_class =
        static_cast<decltype(object_data_->object_class)>(DecodeMessage(message, "ObjectClass" + suffix, data));
    object_data_->object_class_confidence = static_cast<decltype(object_data_->object_class_confidence)>(
        DecodeMessage(message, "ObjectClassConfidence" + suffix, data));

    object_data_->object_rcs =
        static_cast<decltype(object_data_->object_rcs)>(DecodeMessage(message, "ObjectRCS" + suffix, data));

    object_data_->object_over_under_drivable = static_cast<decltype(object_data_->object_over_under_drivable)>(
        DecodeMessage(message, "ObjectOverUnderDrivable" + suffix, data));
    object_data_->object_over_under_driveable_conf =
        static_cast<decltype(object_data_->object_over_under_driveable_conf)>(
            DecodeMessage(message, "ObjectOverUnderDriveableConf" + suffix, data));

    object_data_->scan_id =
        static_cast<decltype(object_data_->scan_id)>(DecodeMessage(message, "ScanID" + suffix, data));

    object_data_->mac_object_data =
        static_cast<decltype(object_data_->mac_object_data)>(DecodeMessage(message, "MAC_OBJECT_DATA" + suffix, data));
}

int8_t ObjectDataParser::GetObjIndexFromFrameID(uint32_t frame_id)
{
    switch (frame_id)
    {
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_00_FRAME_ID:
        return 0;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_01_FRAME_ID:
        return 1;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_02_FRAME_ID:
        return 2;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_03_FRAME_ID:
        return 3;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_04_FRAME_ID:
        return 4;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_05_FRAME_ID:
        return 5;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_06_FRAME_ID:
        return 6;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_07_FRAME_ID:
        return 7;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_08_FRAME_ID:
        return 8;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_09_FRAME_ID:
        return 9;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_10_FRAME_ID:
        return 10;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_11_FRAME_ID:
        return 11;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_12_FRAME_ID:
        return 12;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_13_FRAME_ID:
        return 13;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_14_FRAME_ID:
        return 14;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_15_FRAME_ID:
        return 15;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_16_FRAME_ID:
        return 16;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_17_FRAME_ID:
        return 17;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_18_FRAME_ID:
        return 18;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_19_FRAME_ID:
        return 19;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_20_FRAME_ID:
        return 20;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_21_FRAME_ID:
        return 21;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_22_FRAME_ID:
        return 22;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_23_FRAME_ID:
        return 23;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_24_FRAME_ID:
        return 24;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_25_FRAME_ID:
        return 25;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_26_FRAME_ID:
        return 26;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_27_FRAME_ID:
        return 27;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_28_FRAME_ID:
        return 28;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_29_FRAME_ID:
        return 29;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_30_FRAME_ID:
        return 30;
    case RADAR_HYDRA3_PRIVATE_OBJ_DATA_31_FRAME_ID:
        return 31;
    default:
        return -1;
    }
}

std::string ObjectDataParser::GenerateSuffixFromObjIndex(uint8_t obj_index)
{
    if (obj_index < 10)
    {
        return "0" + std::to_string(obj_index);
    }
    else
    {
        return std::to_string(obj_index);
    }
}

void ObjectDataParser::AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const
{
    converter.Convert(*this, timestamp);
}

std::shared_ptr<radar_hydra3_private_obj_data_t> ObjectDataParser::GetDecodedData() const
{
    return object_data_;
}