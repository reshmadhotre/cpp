#include "RadarInfoParser.h"
#include "Magna2RosConverter.h"

RadarInfoParser::RadarInfoParser(const std::string& dbc_file, const uint32_t frame_id) : ParserBase(dbc_file, frame_id)
{
    radar_info_ = std::make_shared<radar_hydra3_private_radar_info_t>();
}

void RadarInfoParser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    radar_info_->crc_radar_info =
        static_cast<decltype(radar_info_->crc_radar_info)>(DecodeMessage(message, "CRC_RADAR_INFO", data));
    radar_info_->mc_radar_info =
        static_cast<decltype(radar_info_->mc_radar_info)>(DecodeMessage(message, "MC_RADAR_INFO", data));
    radar_info_->mrr_timestamp_sec =
        static_cast<decltype(radar_info_->mrr_timestamp_sec)>(DecodeMessage(message, "MRRTimestampSec", data));
    radar_info_->mrr_timestamp_n_sec =
        static_cast<decltype(radar_info_->mrr_timestamp_n_sec)>(DecodeMessage(message, "MRRTimestampNSec", data));
    radar_info_->mrr_timesync_status =
        static_cast<decltype(radar_info_->mrr_timesync_status)>(DecodeMessage(message, "MRRTimesyncStatus", data));
    radar_info_->blockage_status =
        static_cast<decltype(radar_info_->blockage_status)>(DecodeMessage(message, "BlockageStatus", data));
    radar_info_->blockage_prob =
        static_cast<decltype(radar_info_->blockage_prob)>(DecodeMessage(message, "BlockageProb", data));
    radar_info_->safety_distance =
        static_cast<decltype(radar_info_->safety_distance)>(DecodeMessage(message, "SafetyDistance", data));
    radar_info_->tunnel_presence =
        static_cast<decltype(radar_info_->tunnel_presence)>(DecodeMessage(message, "TunnelPresence", data));
    radar_info_->tunnel_distance =
        static_cast<decltype(radar_info_->tunnel_distance)>(DecodeMessage(message, "TunnelDistance", data));
    radar_info_->tunnel_prob =
        static_cast<decltype(radar_info_->tunnel_prob)>(DecodeMessage(message, "TunnelProb", data));
    radar_info_->object_timestamp_sec =
        static_cast<decltype(radar_info_->object_timestamp_sec)>(DecodeMessage(message, "ObjectTimestampSec", data));
    radar_info_->object_timestamp_n_sec =
        static_cast<decltype(radar_info_->object_timestamp_n_sec)>(DecodeMessage(message, "ObjectTimestampNSec", data));
    radar_info_->radar_scan_id =
        static_cast<decltype(radar_info_->radar_scan_id)>(DecodeMessage(message, "RadarScanID", data));
    radar_info_->number_of_objects =
        static_cast<decltype(radar_info_->number_of_objects)>(DecodeMessage(message, "NumberOfObjects", data));
    radar_info_->mac_radar_info =
        static_cast<decltype(radar_info_->mac_radar_info)>(DecodeMessage(message, "MAC_RADAR_INFO", data));
}

std::shared_ptr<radar_hydra3_private_radar_info_t> RadarInfoParser::GetDecodedData() const
{
    return radar_info_;
}

void RadarInfoParser::AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const
{
    converter.Convert(*this, timestamp);
}
