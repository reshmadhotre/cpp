#include "EgoMotionParser.h"
#include "Magna2RosConverter.h"

EgoMotionParser::EgoMotionParser(const std::string& dbc_file, const uint32_t frame_id) : ParserBase(dbc_file, frame_id)
{
    ego_motion_data_ = std::make_shared<radar_hydra3_private_egomotion_t>();
}

void EgoMotionParser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    ego_motion_data_->ego_motion_vx =
        static_cast<decltype(ego_motion_data_->ego_motion_vx)>(DecodeMessage(message, "EgoMotion_vx", data));
    ego_motion_data_->ego_motion_vx_std_dev = static_cast<decltype(ego_motion_data_->ego_motion_vx_std_dev)>(
        DecodeMessage(message, "EgoMotion_vxStdDev", data));

    ego_motion_data_->ego_motion_vy =
        static_cast<decltype(ego_motion_data_->ego_motion_vy)>(DecodeMessage(message, "EgoMotion_vy", data));
    ego_motion_data_->ego_motion_vy_std_dev = static_cast<decltype(ego_motion_data_->ego_motion_vy_std_dev)>(
        DecodeMessage(message, "EgoMotion_vyStdDev", data));

    ego_motion_data_->ego_motion_vz =
        static_cast<decltype(ego_motion_data_->ego_motion_vz)>(DecodeMessage(message, "EgoMotion_vz", data));
    ego_motion_data_->ego_motion_vz_std_dev = static_cast<decltype(ego_motion_data_->ego_motion_vz_std_dev)>(
        DecodeMessage(message, "EgoMotion_vzStdDev", data));

    ego_motion_data_->ego_motion_v_st =
        static_cast<decltype(ego_motion_data_->ego_motion_v_st)>(DecodeMessage(message, "EgoMotion_vSt", data));

    ego_motion_data_->ego_motion_ax =
        static_cast<decltype(ego_motion_data_->ego_motion_ax)>(DecodeMessage(message, "EgoMotion_ax", data));
    ego_motion_data_->ego_motion_ax_std_dev = static_cast<decltype(ego_motion_data_->ego_motion_ax_std_dev)>(
        DecodeMessage(message, "EgoMotion_axStdDev", data));

    ego_motion_data_->ego_motion_ay =
        static_cast<decltype(ego_motion_data_->ego_motion_ay)>(DecodeMessage(message, "EgoMotion_ay", data));
    ego_motion_data_->ego_motion_ay_std_dev = static_cast<decltype(ego_motion_data_->ego_motion_ay_std_dev)>(
        DecodeMessage(message, "EgoMotion_ayStdDev", data));

    ego_motion_data_->ego_motion_az =
        static_cast<decltype(ego_motion_data_->ego_motion_az)>(DecodeMessage(message, "EgoMotion_az", data));
    ego_motion_data_->ego_motion_az_std_dev = static_cast<decltype(ego_motion_data_->ego_motion_az_std_dev)>(
        DecodeMessage(message, "EgoMotion_azStdDev", data));

    ego_motion_data_->ego_motion_a_st =
        static_cast<decltype(ego_motion_data_->ego_motion_a_st)>(DecodeMessage(message, "EgoMotion_aSt", data));

    ego_motion_data_->ego_motion_yaw_rate =
        static_cast<decltype(ego_motion_data_->ego_motion_yaw_rate)>(DecodeMessage(message, "EgoMotion_YawRate", data));
    ego_motion_data_->ego_motion_yaw_rate_std_dev =
        static_cast<decltype(ego_motion_data_->ego_motion_yaw_rate_std_dev)>(
            DecodeMessage(message, "EgoMotion_YawRateStdDev", data));
    ego_motion_data_->ego_motion_yaw_rate_st = static_cast<decltype(ego_motion_data_->ego_motion_yaw_rate_st)>(
        DecodeMessage(message, "EgoMotion_YawRateSt", data));

    ego_motion_data_->ego_motion_crv_rd =
        static_cast<decltype(ego_motion_data_->ego_motion_crv_rd)>(DecodeMessage(message, "EgoMotion_CrvRd", data));
    ego_motion_data_->ego_motion_crv_rd_std_dev = static_cast<decltype(ego_motion_data_->ego_motion_crv_rd_std_dev)>(
        DecodeMessage(message, "EgoMotion_CrvRdStdDev", data));
    ego_motion_data_->ego_motion_crv_rd_st = static_cast<decltype(ego_motion_data_->ego_motion_crv_rd_st)>(
        DecodeMessage(message, "EgoMotion_CrvRdSt", data));

    ego_motion_data_->ego_motion_scan_id =
        static_cast<decltype(ego_motion_data_->ego_motion_scan_id)>(DecodeMessage(message, "EgoMotion_ScanID", data));
}

void EgoMotionParser::AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const
{
    converter.Convert(*this, timestamp);
}

std::shared_ptr<radar_hydra3_private_egomotion_t> EgoMotionParser::GetDecodedData() const
{
    return ego_motion_data_;
}