#include "RoadBorderParser.h"
#include "Magna2RosConverter.h"

RoadBorderParser::RoadBorderParser(const std::string& dbc_file, const uint32_t frame_id)
    : ParserBase(dbc_file, frame_id)
{
    road_border_data_ = std::make_shared<radar_hydra3_private_road_border_t>();
}

void RoadBorderParser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    road_border_data_->crc_road_border =
        static_cast<decltype(road_border_data_->crc_road_border)>(DecodeMessage(message, "CRC_ROAD_BORDER", data));
    road_border_data_->mc_road_border =
        static_cast<decltype(road_border_data_->mc_road_border)>(DecodeMessage(message, "MC_ROAD_BORDER", data));
    road_border_data_->road_border_timestamp_sec = static_cast<decltype(road_border_data_->road_border_timestamp_sec)>(
        DecodeMessage(message, "RoadBorderTimestampSec", data));
    road_border_data_->road_border_timestamp_n_sec =
        static_cast<decltype(road_border_data_->road_border_timestamp_n_sec)>(
            DecodeMessage(message, "RoadBorderTimestampNSec", data));
    road_border_data_->road_border_st_lt =
        static_cast<decltype(road_border_data_->road_border_st_lt)>(DecodeMessage(message, "RoadBorderStLt", data));
    road_border_data_->road_border_offset_y_lt = static_cast<decltype(road_border_data_->road_border_offset_y_lt)>(
        DecodeMessage(message, "RoadBorderOffsetYLt", data));
    road_border_data_->road_border_angle_lt = static_cast<decltype(road_border_data_->road_border_angle_lt)>(
        DecodeMessage(message, "RoadBorderAngleLt", data));
    road_border_data_->road_border_initial_curvature_lt =
        static_cast<decltype(road_border_data_->road_border_initial_curvature_lt)>(
            DecodeMessage(message, "RoadBorderInitialCurvatureLt", data));
    road_border_data_->road_border_initial_curvature_grad_lt =
        static_cast<decltype(road_border_data_->road_border_initial_curvature_grad_lt)>(
            DecodeMessage(message, "RoadBorderInitialCurvatureGradLt", data));
    road_border_data_->road_border_second_curvature_grad_lt =
        static_cast<decltype(road_border_data_->road_border_second_curvature_grad_lt)>(
            DecodeMessage(message, "RoadBorderSecondCurvatureGradLt", data));
    road_border_data_->road_border_transition_point_lt =
        static_cast<decltype(road_border_data_->road_border_transition_point_lt)>(
            DecodeMessage(message, "RoadBorderTransitionPointLt", data));
    road_border_data_->road_border_max_range_lt = static_cast<decltype(road_border_data_->road_border_max_range_lt)>(
        DecodeMessage(message, "RoadBorderMaxRangeLt", data));
    road_border_data_->road_border_confidence_lt = static_cast<decltype(road_border_data_->road_border_confidence_lt)>(
        DecodeMessage(message, "RoadBorderConfidenceLt", data));
    road_border_data_->road_border_st_rt =
        static_cast<decltype(road_border_data_->road_border_st_rt)>(DecodeMessage(message, "RoadBorderStRt", data));
    road_border_data_->road_border_offset_y_rt = static_cast<decltype(road_border_data_->road_border_offset_y_rt)>(
        DecodeMessage(message, "RoadBorderOffsetYRt", data));
    road_border_data_->road_border_angle_rt = static_cast<decltype(road_border_data_->road_border_angle_rt)>(
        DecodeMessage(message, "RoadBorderAngleRt", data));
    road_border_data_->road_border_initial_curvature_rt =
        static_cast<decltype(road_border_data_->road_border_initial_curvature_rt)>(
            DecodeMessage(message, "RoadBorderInitialCurvatureRt", data));
    road_border_data_->road_border_initial_curvature_grad_rt =
        static_cast<decltype(road_border_data_->road_border_initial_curvature_grad_rt)>(
            DecodeMessage(message, "RoadBorderInitialCurvatureGradRt", data));

    road_border_data_->road_border_second_curvature_grad_rt =
        static_cast<decltype(road_border_data_->road_border_second_curvature_grad_rt)>(
            DecodeMessage(message, "RoadBorderSecondCurvatureGradRt", data));
    road_border_data_->road_border_transition_point_rt =
        static_cast<decltype(road_border_data_->road_border_transition_point_rt)>(
            DecodeMessage(message, "RoadBorderTransitionPointRt", data));
    road_border_data_->road_border_max_range_rt = static_cast<decltype(road_border_data_->road_border_max_range_rt)>(
        DecodeMessage(message, "RoadBorderMaxRangeRt", data));
    road_border_data_->road_border_confidence_rt = static_cast<decltype(road_border_data_->road_border_confidence_rt)>(
        DecodeMessage(message, "RoadBorderConfidenceRt", data));
    road_border_data_->road_border_offset_x_lt = static_cast<decltype(road_border_data_->road_border_offset_x_lt)>(
        DecodeMessage(message, "RoadBorderOffsetXLt", data));
    road_border_data_->road_border_offset_x_rt = static_cast<decltype(road_border_data_->road_border_offset_x_rt)>(
        DecodeMessage(message, "RoadBorderOffsetXRt", data));

    road_border_data_->road_border_scan_id =
        static_cast<decltype(road_border_data_->road_border_scan_id)>(DecodeMessage(message, "RoadBorderScanID", data));
    road_border_data_->mac_road_border =
        static_cast<decltype(road_border_data_->mac_road_border)>(DecodeMessage(message, "MAC_ROAD_BORDER", data));
}

void RoadBorderParser::AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const
{
    converter.Convert(*this, timestamp);
}

std::shared_ptr<radar_hydra3_private_road_border_t> RoadBorderParser::GetDecodedData() const
{
    return road_border_data_;
}