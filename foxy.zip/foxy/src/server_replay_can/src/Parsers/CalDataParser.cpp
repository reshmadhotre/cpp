#include "CalDataParser.h"
#include "Magna2RosConverter.h"

CalDataParser::CalDataParser(const std::string& dbc_file, const uint32_t frame_id) : ParserBase(dbc_file, frame_id)
{
    radar_cal_data_ = std::make_shared<radar_hydra3_private_radar_cal_data_t>();
}

void CalDataParser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    radar_cal_data_->ocal_rotation_matrix_roll_ag =
        static_cast<decltype(radar_cal_data_->ocal_rotation_matrix_roll_ag)>(
            DecodeMessage(message, "OCALRotationMatrixRollAg", data));
    radar_cal_data_->ocal_rotation_matrix_pitch_ag =
        static_cast<decltype(radar_cal_data_->ocal_rotation_matrix_pitch_ag)>(
            DecodeMessage(message, "OCALRotationMatrixPitchAg", data));
    radar_cal_data_->ocal_rotation_matrix_yaw_ag = static_cast<decltype(radar_cal_data_->ocal_rotation_matrix_yaw_ag)>(
        DecodeMessage(message, "OCALRotationMatrixYawAg", data));
    radar_cal_data_->ocal_rotation_matrix_pitch_ag_std_dev =
        static_cast<decltype(radar_cal_data_->ocal_rotation_matrix_pitch_ag_std_dev)>(
            DecodeMessage(message, "OCALRotationMatrixPitchAgStdDev", data));
    radar_cal_data_->ocal_rotation_matrix_roll_ag_std_dev =
        static_cast<decltype(radar_cal_data_->ocal_rotation_matrix_roll_ag_std_dev)>(
            DecodeMessage(message, "OCALRotationMatrixRollAgStdDev", data));
    radar_cal_data_->ocal_rotation_matrix_yaw_ag_std_dev =
        static_cast<decltype(radar_cal_data_->ocal_rotation_matrix_yaw_ag_std_dev)>(
            DecodeMessage(message, "OCALRotationMatrixYawAgStdDev", data));
}

void CalDataParser::AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const
{
    converter.Convert(*this, timestamp);
}

std::shared_ptr<radar_hydra3_private_radar_cal_data_t> CalDataParser::GetDecodedData() const
{
    return radar_cal_data_;
}