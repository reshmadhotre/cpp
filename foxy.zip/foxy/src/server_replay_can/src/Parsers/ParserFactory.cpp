#include "ParserFactory.h"
#include "BlockageParser.h"
#include "CalDataParser.h"
#include "EgoMotionParser.h"
#include "FrameIDDefs.h"
#include "ObjectDataParser.h"
#include "RadarCfgParser.h"
#include "RadarInfoParser.h"
#include "RoadBorderParser.h"
#include "TSyncParser.h"
#include "VehicleStateDataParser.h"
#include "WheelStateDataParser.h"

const uint32_t ParserFactory::OBJ_DATA_FRAME_ID_START = RADAR_HYDRA3_PRIVATE_OBJ_DATA_00_FRAME_ID;
const uint32_t ParserFactory::OBJ_DATA_FRAME_ID_END = RADAR_HYDRA3_PRIVATE_OBJ_DATA_31_FRAME_ID;

ParserFactory::ParserFactory(const std::string& dbc_file)
{
    frameID_parser_map_.insert(
        {RADAR_HYDRA3_PRIVATE_RADAR_CAL_DATA_FRAME_ID,
         std::make_shared<CalDataParser>(dbc_file, RADAR_HYDRA3_PRIVATE_RADAR_CAL_DATA_FRAME_ID)});

    for (uint32_t frame_id = OBJ_DATA_FRAME_ID_START; frame_id <= OBJ_DATA_FRAME_ID_END; frame_id++)
    {
        frameID_parser_map_.insert({frame_id, std::make_shared<ObjectDataParser>(dbc_file, frame_id)});
    }

    frameID_parser_map_.insert({RADAR_HYDRA3_PRIVATE_RADAR_CFG_FRAME_ID,
                                std::make_shared<RadarCfgParser>(dbc_file, RADAR_HYDRA3_PRIVATE_RADAR_CFG_FRAME_ID)});
    frameID_parser_map_.insert({RADAR_HYDRA3_PRIVATE_RADAR_INFO_FRAME_ID,
                                std::make_shared<RadarInfoParser>(dbc_file, RADAR_HYDRA3_PRIVATE_RADAR_INFO_FRAME_ID)});
    frameID_parser_map_.insert({RADAR_HYDRA3_PRIVATE_TSYNC_FRAME_ID,
                                std::make_shared<TSyncParser>(dbc_file, RADAR_HYDRA3_PRIVATE_TSYNC_FRAME_ID)});
    frameID_parser_map_.insert(
        {RADAR_HYDRA3_PRIVATE_VEH_STATE_FRAME_ID,
         std::make_shared<VehicleStateDataParser>(dbc_file, RADAR_HYDRA3_PRIVATE_VEH_STATE_FRAME_ID)});
    frameID_parser_map_.insert(
        {RADAR_HYDRA3_PRIVATE_WHL_STATE_FRAME_ID,
         std::make_shared<WheelStateDataParser>(dbc_file, RADAR_HYDRA3_PRIVATE_WHL_STATE_FRAME_ID)});
    frameID_parser_map_.insert(
        {RADAR_HYDRA3_PRIVATE_ROAD_BORDER_FRAME_ID,
         std::make_shared<RoadBorderParser>(dbc_file, RADAR_HYDRA3_PRIVATE_ROAD_BORDER_FRAME_ID)});

    frameID_parser_map_.insert({RADAR_HYDRA3_PRIVATE_EGOMOTION_FRAME_ID,
                                std::make_shared<EgoMotionParser>(dbc_file, RADAR_HYDRA3_PRIVATE_EGOMOTION_FRAME_ID)});
    frameID_parser_map_.insert({RADAR_HYDRA3_PRIVATE_BLOCKAGE_DEBUG_FRAME_ID, 
                                std::make_shared<BlockageParser>(dbc_file, RADAR_HYDRA3_PRIVATE_BLOCKAGE_DEBUG_FRAME_ID)});
}

std::shared_ptr<ParserBase> ParserFactory::GetParser(const uint32_t frame_id)
{
    auto iter = frameID_parser_map_.find(frame_id);

    if (iter == frameID_parser_map_.end())
    {
        return nullptr;
    }

    return iter->second;
}
