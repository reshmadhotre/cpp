#include "BlockageParser.h"
#include "Magna2RosConverter.h"

BlockageParser::BlockageParser(const std::string& dbc_file, const uint32_t frame_id):ParserBase(dbc_file, frame_id)
{
    blkg_data_ = std::make_shared<radar_hydra3_private_blkg_debug_t>();
}

void BlockageParser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    blkg_data_->blkg_active = static_cast<decltype(blkg_data_->blkg_active)>(DecodeMessage(message, "BlkgActive", data));
    blkg_data_->blkg_conf = static_cast<decltype(blkg_data_->blkg_conf)>(DecodeMessage(message, "BlkgConf", data));
    blkg_data_->blkg_deactivate_dist_count = static_cast<decltype(blkg_data_->blkg_deactivate_dist_count)>(DecodeMessage(message, "BlkgDeactivateDistCount", data));
    blkg_data_->blkg_deactivate_obj_loss = static_cast<decltype(blkg_data_->blkg_deactivate_obj_loss)>(DecodeMessage(message, "BlkgDeactivateObjLoss", data));
    blkg_data_->blkg_deactivate_range = static_cast<decltype(blkg_data_->blkg_deactivate_range)>(DecodeMessage(message, "BlkgDeactivateRange", data));
    blkg_data_->blkg_deactivate_time_count = static_cast<decltype(blkg_data_->blkg_deactivate_time_count)>(DecodeMessage(message, "BlkgDeactivateTimeCount", data));
    blkg_data_->blkg_detection_ratio_mean = static_cast<decltype(blkg_data_->blkg_detection_ratio_mean)>(DecodeMessage(message, "BlkgDetectionRatioMean", data));
    blkg_data_->blkg_detection_ratio_mov = static_cast<decltype(blkg_data_->blkg_detection_ratio_mov)>(DecodeMessage(message, "BlkgDetectionRatioMov", data));
    blkg_data_->blkg_detection_ratio_static = static_cast<decltype(blkg_data_->blkg_detection_ratio_static)>(DecodeMessage(message, "BlkgDetectionRatioStatic", data));
    blkg_data_->blkg_dist_count = static_cast<decltype(blkg_data_->blkg_dist_count)>(DecodeMessage(message, "BlkgDistCount", data));
    blkg_data_->blkg_fl_conf = static_cast<decltype(blkg_data_->blkg_fl_conf)>(DecodeMessage(message, "BlkgFLConf", data));
    blkg_data_->blkg_fl_mean = static_cast<decltype(blkg_data_->blkg_fl_mean)>(DecodeMessage(message, "BlkgFLMean", data));
    blkg_data_->blkg_mov_max = static_cast<decltype(blkg_data_->blkg_mov_max)>(DecodeMessage(message, "BlkgMovMax", data));
    blkg_data_->blkg_mov_mean = static_cast<decltype(blkg_data_->blkg_mov_mean)>(DecodeMessage(message, "BlkgMovMean", data));
    blkg_data_->blkg_mov_mean_conf = static_cast<decltype(blkg_data_->blkg_mov_mean_conf)>(DecodeMessage(message, "BlkgMovMeanConf", data));
    blkg_data_->blkg_obj_loss_conf = static_cast<decltype(blkg_data_->blkg_obj_loss_conf)>(DecodeMessage(message, "BlkgObjLossConf", data));
    blkg_data_->blkg_obj_loss_prob = static_cast<decltype(blkg_data_->blkg_obj_loss_prob)>(DecodeMessage(message, "BlkgObjLossProb", data));
    blkg_data_->blkg_range_conf = static_cast<decltype(blkg_data_->blkg_range_conf)>(DecodeMessage(message, "BlkgRangeConf", data));
    blkg_data_->blkg_range_max = static_cast<decltype(blkg_data_->blkg_range_max)>(DecodeMessage(message, "BlkgRangeMax", data));
    blkg_data_->blkg_range_mean = static_cast<decltype(blkg_data_->blkg_range_mean)>(DecodeMessage(message, "BlkgRangeMean", data));
    blkg_data_->blkg_range_prob = static_cast<decltype(blkg_data_->blkg_range_prob)>(DecodeMessage(message, "BlkgRangeProb", data));
    blkg_data_->blkg_scan_id = static_cast<decltype(blkg_data_->blkg_scan_id)>(DecodeMessage(message, "BlkgScanID", data));
    blkg_data_->blkg_st_max = static_cast<decltype(blkg_data_->blkg_st_max)>(DecodeMessage(message, "BlkgStMax", data));
    blkg_data_->blkg_st_mean = static_cast<decltype(blkg_data_->blkg_st_mean)>(DecodeMessage(message, "BlkgStMean", data));
    blkg_data_->blkg_st_mean_conf = static_cast<decltype(blkg_data_->blkg_st_mean_conf)>(DecodeMessage(message, "BlkgMovMeanConf", data));
    blkg_data_->blkg_time_count = static_cast<decltype(blkg_data_->blkg_time_count)>(DecodeMessage(message, "BlkgTimeCount", data));
    blkg_data_->blkg_time_dist_count_conf = static_cast<decltype(blkg_data_->blkg_time_dist_count_conf)>(DecodeMessage(message, "BlkgTimeDistCountConf", data));
    blkg_data_->blkg_time_dist_count_prob = static_cast<decltype(blkg_data_->blkg_time_dist_count_prob)>(DecodeMessage(message, "BlkgTimeDistCountProb", data));
}

void BlockageParser::AcceptROSConverter(const Magna2RosConverter& converter, const int64_t timestamp) const
{
    converter.Convert(*this, timestamp);
}

std::shared_ptr<radar_hydra3_private_blkg_debug_t> BlockageParser::GetDecodedData() const
{
    return blkg_data_;
}