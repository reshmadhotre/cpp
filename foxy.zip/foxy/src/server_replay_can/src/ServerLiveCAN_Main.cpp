#include "CANAdapterLive.h"
#include "CANNodeLive.h"
#include "Magna2RosConverter.h"
#include "rclcpp/rclcpp.hpp"

int main(int argc, char* argv[])
{
    rclcpp::init(argc, argv);

    auto node = std::make_shared<rclcpp::Node>("server_live_can_node");

    std::shared_ptr<CANNode> can_node = std::make_shared<CANNodeLive>(node);
    auto magna_ros_converter = std::make_shared<Magna2RosConverter>();
    magna_ros_converter->SetCANNode(can_node);

    auto can_live_adapter = std::make_shared<CANAdapterLive>(node);
    can_live_adapter->SetCANNode(can_node);
    can_live_adapter->SetMagna2RosConverter(magna_ros_converter);

    while (rclcpp::ok())
    {
        can_live_adapter->ReadNextMessage();
        rclcpp::spin_some(node);
    }

    rclcpp::shutdown();
    return 0;
}