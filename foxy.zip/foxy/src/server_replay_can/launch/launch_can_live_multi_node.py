from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python import get_package_share_directory
import os


def generate_launch_description():

    DBC_FILEPATH = "DBC_FILEPATH_HERE"

    can_live_radar_front_center = Node(
        node_namespace="can_live_radar_front_center",
        name="can_live_radar_front_center_node",
        package="server_replay_can",
        executable="server_replay_can_live_node",
        output="screen",
        parameters=[
            {"dbc_filepath": DBC_FILEPATH},
            {"rosbag_path": ""},
            {"record_rosbags": False},
            {"sensor_position_x": 0.0},
            {"sensor_position_y": 0.0},
            {"sensor_position_z": 0.0},
            {"sensor_yaw": 0.0},
            {"sensor_pitch": 0.0},
            {"sensor_roll": 0.0}
        ]
    )

    can_live_radar_front_left = Node(
        node_namespace="can_live_radar_front_left",
        name="can_live_radar_front_left_node",
        package="server_replay_can",
        executable="server_replay_can_live_node",
        output="screen",
        parameters=[
            {"dbc_filepath": DBC_FILEPATH},
            {"rosbag_path": ""},
            {"record_rosbags": False},
            {"sensor_position_x": 0.0},
            {"sensor_position_y": 0.0},
            {"sensor_position_z": 0.0},
            {"sensor_yaw": 0.0},
            {"sensor_pitch": 0.0},
            {"sensor_roll": 0.0}
        ]
    )

    return LaunchDescription([
        can_live_radar_front_center,
        can_live_radar_front_left
    ])
