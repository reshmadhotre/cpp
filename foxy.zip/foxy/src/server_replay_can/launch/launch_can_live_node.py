from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python import get_package_share_directory
import os


def generate_launch_description():

    params_config = os.path.join(
        get_package_share_directory('server_replay_can'),
        'config',
        'config_server_live_can.yaml'
    )

    server_live_can_node = Node(
        package="server_replay_can",
        executable="server_replay_can_live_node",
        output="screen",
        name="server_replay_can_live_node",
        parameters=[
            params_config
        ]
    )

    return LaunchDescription([
        server_live_can_node
    ])
