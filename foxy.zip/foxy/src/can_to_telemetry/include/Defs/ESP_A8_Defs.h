#ifndef VEHICLE_GRAND_CHEROKEE_ESP_A8_DEFS_H
#define VEHICLE_GRAND_CHEROKEE_ESP_A8_DEFS_H

#include <iostream>
#include <stdint.h>

#define VEHICLE_GRAND_CHEROKEE_ESP_A8_BRK_TRQ_SNA_CHOICE (4095u)
#define VEHICLE_GRAND_CHEROKEE_ESP_A8_BRK_TRQ_D_SNA_CHOICE (4095u)
#define VEHICLE_GRAND_CHEROKEE_ESP_A8_VEH_SPEED_SNA_CHOICE (65535u)

/**
 * Signals in message ESP_A8.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */
struct vehicle_grand_cherokee_esp_a8_t
{
    /**
     * Actual brake torque
     *
     * Range: 0..4094 (0..12282 Nm)
     * Scale: 3
     * Offset: 0
     */
    uint16_t brk_trq;

    /**
     * Vehicle is stopped status signal
     *
     * Range: -
     * Scale: 1
     * Offset: 0
     */
    uint8_t veh_sp_sts;

    /**
     * Brake torque requested by driver
     *
     * Range: 0..4094 (0..12282 Nm)
     * Scale: 3
     * Offset: 0
     */
    uint16_t brk_trq_d;

    /**
     * Vehicle speed
     *
     * Range: 0..65534 (0..511.984375 km/h)
     * Scale: 0.0078125
     * Offset: 0
     */
    double veh_speed;

    /**
     * Message counter
     *
     * Range: 0..15 (0..15 -)
     * Scale: 1
     * Offset: 0
     */
    uint8_t mc_veh_speed;

    /**
     * CRC-checksum byte 1 to 7 according to SAE J1850
     *
     * Range: -
     * Scale: 1
     * Offset: 0
     */
    uint8_t crc_veh_speed;
};

#endif