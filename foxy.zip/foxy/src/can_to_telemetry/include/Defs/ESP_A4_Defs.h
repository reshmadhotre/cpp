#ifndef VEHICLE_GRAND_CHEROKEE_ESP_A4_DEFS_H
#define VEHICLE_GRAND_CHEROKEE_ESP_A4_DEFS_H

#include <iostream>
#include <stdint.h>

#define VEHICLE_GRAND_CHEROKEE_ESP_A4_VEH_YAW_RATE_RAW_SNA_CHOICE (65535u)
#define VEHICLE_GRAND_CHEROKEE_ESP_A4_VEH_YAW_RATE_OFFSET_SNA_CHOICE (255u)
#define VEHICLE_GRAND_CHEROKEE_ESP_A4_VEH_ACCEL_X_OFFSET_SNA_CHOICE (255u)
#define VEHICLE_GRAND_CHEROKEE_ESP_A4_VEH_ACCEL_X_SNA_CHOICE (255u)
#define VEHICLE_GRAND_CHEROKEE_ESP_A4_VEH_ACCEL_Y_SNA_CHOICE (255u)
#define VEHICLE_GRAND_CHEROKEE_ESP_A4_VEH_ACCEL_Y_OFFSET_SNA_CHOICE (255u)

/**
 * Signals in message ESP_A4.
 *
 * Generated using cantools generate_c_source. Modified types to reflect physical values.
 */
struct vehicle_grand_cherokee_esp_a4_t
{
    /**
     * Vehicle yaw rate unfiltered/unadjusted (+ means left)
     *
     * Range: 0..65534 (-327.68..327.66 °/s)
     * Scale: 0.01
     * Offset: -327.68
     */
    double veh_yaw_rate_raw;

    /**
     * Offset of vehicle yaw rate unfiltered/unadjusted (+ means left)
     *
     * Range: 41..215 (-6.96..6.96 -)
     * Scale: 0.08
     * Offset: -10.24
     */
    double veh_yaw_rate_offset;

    /**
     * Offset of vehicle longitudinal acceleration (+ means forward)
     *
     * Range: 0..254 (-2.56..2.52 m/s²)
     * Scale: 0.02
     * Offset: -2.56
     */
    double veh_accel_x_offset;

    /**
     * Vehicle longitudinal acceleration (+ means forward)
     *
     * Range: 0..254 (-10.24..10.08 m/s²)
     * Scale: 0.08
     * Offset: -10.24
     */
    double veh_accel_x;

    /**
     * Vehicle lateral acceleration (+ means left, specific to center of gravity, offset-corrected )
     *
     * Range: 0..254 (-10.24..10.08 m/s²)
     * Scale: 0.08
     * Offset: -10.24
     */
    double veh_accel_y;

    /**
     * Message counter
     *
     * Range: 0..15 (0..15 -)
     * Scale: 1
     * Offset: 0
     */
    uint8_t mc_veh_dyn_stat;

    /**
     * Offset of vehicle lateral acceleration (+ means left)
     *
     * Range: 0..254 (-2.56..2.52 m/s²)
     * Scale: 0.02
     * Offset: -2.56
     */
    double veh_accel_y_offset;
};

#endif