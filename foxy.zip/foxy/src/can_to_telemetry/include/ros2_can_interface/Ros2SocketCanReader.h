#ifndef ROS2_SOCKET_CAN_READER_H
#define ROS2_SOCKET_CAN_READER_H

#include "RosParamUtil.hpp"
#include "can_to_telemetry/msg/msg_frame.hpp"
#include "rclcpp/rclcpp.hpp"
#include <boost/asio.hpp>
#include <linux/can/raw.h>

// Adapted from : https://github.com/ROS4SPACE/ros2can_bridge

class Ros2SocketCanReader
{
  public:
    Ros2SocketCanReader(std::shared_ptr<rclcpp::Node> node, const std::vector<uint32_t>& frame_ids_to_process = {});
    ~Ros2SocketCanReader();

  private:
    void InitRosParams();
    void Stop();
    void CanListener(struct can_frame& rec_frame, boost::asio::posix::basic_stream_descriptor<>& stream);
    void PublishCanFrame(std::shared_ptr<can_to_telemetry::msg::MsgFrame> can_frame);
    bool ProcessFrameID(const uint32_t frame_id);
    void InitCANInterface();
    void InitPublishers();

    std::vector<uint32_t> frame_ids_to_process_;

    boost::asio::io_service ios;
    boost::asio::posix::basic_stream_descriptor<> stream;
    boost::asio::signal_set signals;

    std::string can_socket_{"can0"};
    struct sockaddr_can addr;
    struct can_frame frame;
    struct can_frame rec_frame;
    struct ifreq ifr;

    int natsock = socket(PF_CAN, SOCK_RAW, CAN_RAW);

    std::shared_ptr<rclcpp::Node> node_;
    rclcpp::Publisher<can_to_telemetry::msg::MsgFrame>::SharedPtr can_frame_publisher_;
    std::shared_ptr<RosParamUtil> ros_param_util_;

    static const uint8_t DEFAULT_HISTORY_SIZE;
};
#endif