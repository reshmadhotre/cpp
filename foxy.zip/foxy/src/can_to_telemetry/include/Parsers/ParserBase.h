#ifndef PARSER_BASE_H
#define PARSER_BASE_H

#include "DBC.h"
#include <fstream>
#include <memory>

class CANNode;
class ParserBase
{
  public:
    ParserBase(const std::string& dbc_file, const uint32_t frame_id);
    void SetNetwork(const std::string& dbc_file);
    uint32_t GetFrameID() const;
    static bool IsNetworkInitialized();
    virtual void Decode(const std::vector<unsigned char>& payload) = 0;
    virtual void SendDataToCanNode(std::shared_ptr<CANNode> can_node);

  protected:
    Vector::DBC::Message GetDBCMessage();
    double DecodeMessage(const Vector::DBC::Message& dbc_msg, const std::string& signal_name,
                         std::vector<uint8_t>& data);

  private:
    uint32_t frame_id_;
    static Vector::DBC::Network dbc_network_;
};

#endif