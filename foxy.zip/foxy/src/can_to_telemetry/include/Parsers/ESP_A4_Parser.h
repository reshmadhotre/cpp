#ifndef ESP_A4_PARSER_H
#define ESP_A4_PARSER_H

#include "ESP_A4_Defs.h"
#include "ParserBase.h"
#include "memory"

class ESP_A4_Parser : public ParserBase
{
  public:
    ESP_A4_Parser(const std::string& dbc_file, const uint32_t frame_id);
    void Decode(const std::vector<unsigned char>& payload) override;
    std::shared_ptr<vehicle_grand_cherokee_esp_a4_t> GetDecodedData() const;
    void SendDataToCanNode(std::shared_ptr<CANNode> can_node) override;

  private:
    std::shared_ptr<vehicle_grand_cherokee_esp_a4_t> esp_a4_data_;
};
#endif