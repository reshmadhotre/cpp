#ifndef PARSER_FACTORY_H
#define PARSER_FACTORY_H

#include "ParserBase.h"
#include <memory>

class ParserFactory
{
  public:
    ParserFactory(const std::string& dbc_file);
    std::shared_ptr<ParserBase> GetParser(const uint32_t frame_id);

  private:
    std::map<uint32_t, std::shared_ptr<ParserBase>> frameID_parser_map_;
};
#endif