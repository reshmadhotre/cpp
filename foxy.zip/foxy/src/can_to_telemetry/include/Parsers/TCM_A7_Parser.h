#ifndef TCM_A7_PARSER_H
#define TCM_A7_PARSER_H

#include "ParserBase.h"
#include "TCM_A7_Defs.h"
#include "memory"

class TCM_A7_Parser : public ParserBase
{
  public:
    TCM_A7_Parser(const std::string& dbc_file, const uint32_t frame_id);
    void Decode(const std::vector<unsigned char>& payload) override;
    std::shared_ptr<vehicle_grand_cherokee_tcm_a7_t> GetDecodedData() const;
    void SendDataToCanNode(std::shared_ptr<CANNode> can_node) override;

  private:
    std::shared_ptr<vehicle_grand_cherokee_tcm_a7_t> tcm_a7_data_;
};
#endif