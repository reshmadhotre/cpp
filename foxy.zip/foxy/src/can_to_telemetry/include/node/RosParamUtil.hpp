#ifndef ROS_PARAM_UTIL_HPP
#define ROS_PARAM_UTIL_HPP

#include "rclcpp/rclcpp.hpp"

class RosParamUtil
{
  public:
    RosParamUtil(std::shared_ptr<rclcpp::Node> node) : node_(node)
    {
    }

    template <typename ParameterT> void DeclareParameter(const std::string& param_name, const ParameterT& default_value)
    {
        if (!node_->has_parameter(param_name))
        {
            node_->declare_parameter(param_name, rclcpp::ParameterValue(default_value));
        }
    }

    rclcpp::Parameter GetParameter(const std::string& param_name)
    {
        return node_->get_parameter(param_name);
    }

  private:
    std::shared_ptr<rclcpp::Node> node_;
};
#endif
