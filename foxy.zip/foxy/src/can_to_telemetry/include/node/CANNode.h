#ifndef CAN_NODE_H
#define CAN_NODE_H

#include "ESP_A4_Defs.h"
#include "ESP_A8_Defs.h"
#include "TCM_A7_Defs.h"
#include "msg_replay_radar/msg/msg_telemetry_uhdp.hpp"
#include "msg_replay_radar/msg/msg_vehicle_signals.hpp"
#include "server_replay_lrr/msg/msg_telemetry_uhdp.hpp"

#include "RosParamUtil.hpp"
#include "rclcpp/rclcpp.hpp"
#include <bitset>

class CANNode
{
  public:
    CANNode(std::shared_ptr<rclcpp::Node> node);
    void AddData(std::shared_ptr<vehicle_grand_cherokee_esp_a4_t> esp_a4_data);
    void AddData(std::shared_ptr<vehicle_grand_cherokee_tcm_a7_t> tcm_a7_data);
    void AddData(std::shared_ptr<vehicle_grand_cherokee_esp_a8_t> esp_a8_data);

  private:
    void InitRosParams();
    void InitPublishers();
    void PublishData();
    void PublishOnCompletion();

    bool veh_speed_recevied_{false};

    std::bitset<3> signals_received_completion_map_;
    rclcpp::Time prev_can_msg_timestamp_;

    msg_replay_radar::msg::MsgVehicleSignals current_vehicle_signals_;

    double sensor_pos_x_; // Distance to Rear axis
    double sensor_pos_y_; // Sensor Lateral Displacement
    double sensor_pos_z_; // Sensor Height
    double sensor_yaw_;   // Sensor Azimuth angle

    std::shared_ptr<rclcpp::Node> node_;
    std::shared_ptr<RosParamUtil> ros_param_util_;

    rclcpp::Publisher<msg_replay_radar::msg::MsgTelemetryUhdp>::SharedPtr telemetry_publisher_;
    rclcpp::Publisher<server_replay_lrr::msg::MsgTelemetryUhdp>::SharedPtr
        lrr_telemetry_publisher_; // Todo : Remove once lrr is moved to v8.1
    rclcpp::Publisher<msg_replay_radar::msg::MsgVehicleSignals>::SharedPtr vehicle_signals_publisher_;

    static const int64_t FULL_CONTENT_LISTEN_DURATION_NS;
    static const double KMPH_TO_MPS;
    static const float DEG_TO_RAD;
    static const uint32_t DEFAULT_QUEUE_SIZE;
};

#endif
