#ifndef ROS_TOPICS_H
#define ROS_TOPICS_H

#include <string>

namespace ROS_PUBLISHER_TOPICS
{
extern const std::string TOPIC_TELEMETRY_UHDP;
extern const std::string TOPIC_LRR_TELEMETRY_UHDP; // Todo : Remove once lrr is moved to v8.1
extern const std::string TOPIC_CAN_VEHICLE_SIGNALS;
extern const std::string TOPIC_CAN_FRAME;

} // namespace ROS_PUBLISHER_TOPICS

namespace ROS_SUBSCRIBER_TOPICS
{
extern const std::string TOPIC_CAN_FRAME;
} // namespace ROS_SUBSCRIBER_TOPICS
#endif