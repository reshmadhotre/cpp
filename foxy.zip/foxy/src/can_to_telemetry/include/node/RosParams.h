#ifndef ROS_PARAMS_H
#define ROS_PARAMS_H

#include <string>

namespace ROS_PARAM_NAMES
{
extern const std::string CAN_DEVICE;
extern const std::string DBC_FILEPATH;
extern const std::string SENSOR_POSITION_X;
extern const std::string SENSOR_POSITION_Y;
extern const std::string SENSOR_POSITION_Z;
extern const std::string SENSOR_YAW;
extern const std::string SENSOR_PITCH;
extern const std::string SENSOR_ROLL;

} // namespace ROS_PARAM_NAMES
#endif