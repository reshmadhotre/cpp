#ifndef CAN_ADAPTER_H
#define CAN_ADAPTER_H

#include "ParserFactory.h"
#include "Ros2SocketCanReader.h"
#include "RosParamUtil.hpp"
#include "rclcpp/rclcpp.hpp"

class CANAdapter
{
  public:
    CANAdapter(std::shared_ptr<rclcpp::Node> node);
    ~CANAdapter();
    void SetCANNode(std::shared_ptr<CANNode> can_node);
    void ReadNextMessage();

  private:
    void InitSubscribers();
    void InitCANParser();
    void InitROSParams();
    void InitCANReader();

    void CanFrameCB(can_to_telemetry::msg::MsgFrame::UniquePtr msg);
    bool ProcessFrameID(const uint32_t frame_id);
    bool FileExists(const std::string& file_path);
    std::string RemoveExtensionFromFilePath(const std::string& file_path);
    void InitFrameIDsToProcess();

    std::vector<uint32_t> frame_ids_to_process_;

    std::shared_ptr<ParserFactory> parser_factory_;
    bool can_parser_initialized_{false};
    std::string dbc_filepath_{""};

    bool record_rosbags_;

    std::shared_ptr<rclcpp::Node> node_;
    std::shared_ptr<CANNode> can_node_;
    std::shared_ptr<RosParamUtil> ros_param_util_;
    rclcpp::Subscription<can_to_telemetry::msg::MsgFrame>::SharedPtr can_frame_subscriber_;

    std::shared_ptr<Ros2SocketCanReader> ros2_socket_can_reader_;

    static const uint8_t DEFAULT_HISTORY_SIZE;
};
#endif