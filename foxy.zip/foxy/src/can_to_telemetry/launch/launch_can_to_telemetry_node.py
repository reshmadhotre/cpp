#
# \file launch_lrr_uhdp_server.py
#
# \author Magna Electronics Europe GmbH & Co. OHG,
#         63877 Sailauf, Germany
#
# Copyright 2019 - 2021 Magna Electronics Europe GmbH & Co. OHG
# All rights exclusively reserved for Magna Electronics Europe GmbH & Co. OHG,
# unless expressly agreed to otherwise.

from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python import get_package_share_directory
import os


def generate_launch_description():

    can_to_telemetry_config = os.path.join(
        get_package_share_directory('can_to_telemetry'),
        'config',
        'params.yaml'
    )

    can_to_telemetry_node = Node(
        package="can_to_telemetry",
        executable="can_to_telemetry_node",
        name="can_to_telemetry_node",
        output="screen",
        parameters=[
            can_to_telemetry_config
        ]
    )

    return LaunchDescription([
        can_to_telemetry_node
    ])
