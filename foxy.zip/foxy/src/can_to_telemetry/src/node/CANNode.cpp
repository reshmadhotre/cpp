#include "CANNode.h"
#include "RosParams.h"
#include "RosTopics.h"

const double CANNode::KMPH_TO_MPS{0.277778};
const float CANNode::DEG_TO_RAD{M_PI / 180.0F};
const uint32_t CANNode::DEFAULT_QUEUE_SIZE{10};
const int64_t CANNode::FULL_CONTENT_LISTEN_DURATION_NS = 0.015 * 1e9; // 15ms

CANNode::CANNode(std::shared_ptr<rclcpp::Node> node)
{
    node_ = node;
    ros_param_util_ = std::make_shared<RosParamUtil>(node);

    InitRosParams();
    InitPublishers();
}

void CANNode::InitRosParams()
{
    using namespace ROS_PARAM_NAMES;
    ros_param_util_->DeclareParameter(SENSOR_POSITION_X, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_POSITION_Y, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_POSITION_Z, 0.0f);
    ros_param_util_->DeclareParameter(SENSOR_YAW, 0.0f);

    sensor_pos_x_ = ros_param_util_->GetParameter(SENSOR_POSITION_X).as_double();
    sensor_pos_y_ = ros_param_util_->GetParameter(SENSOR_POSITION_Y).as_double();
    sensor_pos_z_ = ros_param_util_->GetParameter(SENSOR_POSITION_Z).as_double();
    sensor_yaw_ = ros_param_util_->GetParameter(SENSOR_YAW).as_double();
}

void CANNode::InitPublishers()
{
    using namespace ROS_PUBLISHER_TOPICS;
    telemetry_publisher_ =
        node_->create_publisher<msg_replay_radar::msg::MsgTelemetryUhdp>(TOPIC_TELEMETRY_UHDP, DEFAULT_QUEUE_SIZE);
    lrr_telemetry_publisher_ =
        node_->create_publisher<server_replay_lrr::msg::MsgTelemetryUhdp>(TOPIC_LRR_TELEMETRY_UHDP, DEFAULT_QUEUE_SIZE);
    vehicle_signals_publisher_ = node_->create_publisher<msg_replay_radar::msg::MsgVehicleSignals>(
        TOPIC_CAN_VEHICLE_SIGNALS, DEFAULT_QUEUE_SIZE);
}

void CANNode::PublishOnCompletion()
{

    if (signals_received_completion_map_.all())
    {
        PublishData();
    }
}

void CANNode::PublishData()
{
    auto telemetry_msg = std::make_shared<msg_replay_radar::msg::MsgTelemetryUhdp>();
    auto lrr_telemetry_msg = std::make_shared<server_replay_lrr::msg::MsgTelemetryUhdp>();

    telemetry_msg->header.stamp = current_vehicle_signals_.meas_time;
    telemetry_msg->meas_time = current_vehicle_signals_.meas_time;

    lrr_telemetry_msg->header.stamp = current_vehicle_signals_.meas_time;
    lrr_telemetry_msg->meas_time = current_vehicle_signals_.meas_time;

    const auto& veh_speed = current_vehicle_signals_.veh_speed;
    const auto& ego_vehicle_yaw_rate = current_vehicle_signals_.ego_vehicle_yaw_rate_raw;
    const auto& vehicle_motion_state = current_vehicle_signals_.motion_state;

    // Calculate Sensor Velocity vx, vy, vz
    float vx_sensor{veh_speed + ((ego_vehicle_yaw_rate * DEG_TO_RAD) * (float)sensor_pos_y_)};
    float vy_sensor{(ego_vehicle_yaw_rate * (float)DEG_TO_RAD) * (float)sensor_pos_x_};
    const float vz_sensor{0.0F};

    if (vehicle_motion_state != msg_replay_radar::msg::MsgVehicleSignals::MTN_STATE_BACKWARD)
    {
        // World velocity is inverse of ego velocity. Radar expects World velocity
        vx_sensor = -1.0 * vx_sensor;
    }

    // velocity[2]
    const float velocity[2] = {vx_sensor, vy_sensor};
    const float azimuth_angle{-1.0f * (float)sensor_yaw_ * DEG_TO_RAD};

    // rotation_z_axis[4]
    const float rotation_z_axis[4] = {cosf(azimuth_angle), -1.0f * sinf(azimuth_angle), sinf(azimuth_angle),
                                      cosf(azimuth_angle)};

    // rotation_z_axis[4] * velocity[2]
    vx_sensor = rotation_z_axis[0] * velocity[0] + rotation_z_axis[1] * velocity[1];
    vy_sensor = rotation_z_axis[2] * velocity[0] + rotation_z_axis[3] * velocity[1];

    telemetry_msg->vx = vx_sensor;
    telemetry_msg->vy = vy_sensor;
    telemetry_msg->vz = vz_sensor;

    lrr_telemetry_msg->vx = vx_sensor;
    lrr_telemetry_msg->vy = vy_sensor;
    lrr_telemetry_msg->vz = vz_sensor;

    telemetry_publisher_->publish(*telemetry_msg.get());
    lrr_telemetry_publisher_->publish(*lrr_telemetry_msg.get()); // Todo : Remove once lrr is moved to v8.1

    vehicle_signals_publisher_->publish(current_vehicle_signals_);

    signals_received_completion_map_.reset();
}

void CANNode::AddData(std::shared_ptr<vehicle_grand_cherokee_esp_a4_t> esp_a4_data)
{
    rclcpp::Time time_now = node_->get_clock()->now();
    if (time_now.nanoseconds() - prev_can_msg_timestamp_.nanoseconds() > FULL_CONTENT_LISTEN_DURATION_NS)
    {
        signals_received_completion_map_.reset();
        current_vehicle_signals_ = msg_replay_radar::msg::MsgVehicleSignals();
    }
    prev_can_msg_timestamp_ = time_now;

    auto ego_vehicle_yaw_rate_raw = esp_a4_data->veh_yaw_rate_raw + esp_a4_data->veh_yaw_rate_offset;

    current_vehicle_signals_.ego_vehicle_yaw_rate_raw = ego_vehicle_yaw_rate_raw;
    // current_vehicle_signals_.meas_time = time_now;

    signals_received_completion_map_.set(0);

    PublishOnCompletion();
}

void CANNode::AddData(std::shared_ptr<vehicle_grand_cherokee_tcm_a7_t> tcm_a7_data)
{
    rclcpp::Time time_now = node_->get_clock()->now();
    if (time_now.nanoseconds() - prev_can_msg_timestamp_.nanoseconds() > FULL_CONTENT_LISTEN_DURATION_NS)
    {
        signals_received_completion_map_.reset();
        current_vehicle_signals_ = msg_replay_radar::msg::MsgVehicleSignals();
    }
    prev_can_msg_timestamp_ = time_now;

    uint8_t current_gear = tcm_a7_data->current_gear;
    std::string vehicle_motion_state;

    switch (current_gear)
    {
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_N_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_D1_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_D2_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_D3_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_D4_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_D5_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_D6_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_D7_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_D8_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_D2_P_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_D9_CHOICE:
        vehicle_motion_state = msg_replay_radar::msg::MsgVehicleSignals::MTN_STATE_FORWARD;
        break;
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_R_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_R2_CHOICE:
        vehicle_motion_state = msg_replay_radar::msg::MsgVehicleSignals::MTN_STATE_BACKWARD;
        break;
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_P_CHOICE:
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_ABBRUCH_CHOICE:
        vehicle_motion_state = msg_replay_radar::msg::MsgVehicleSignals::MTN_STATE_STOPPED;
        break;
    case VEHICLE_GRAND_CHEROKEE_TCM_A7_TARGET_GEAR_SNA_CHOICE:
    default:
        vehicle_motion_state = msg_replay_radar::msg::MsgVehicleSignals::MTN_STATE_IDLE;
        break;
    }

    current_vehicle_signals_.motion_state = vehicle_motion_state;
    // current_vehicle_signals_.meas_time = time_now;

    signals_received_completion_map_.set(1);
    PublishOnCompletion();
}

void CANNode::AddData(std::shared_ptr<vehicle_grand_cherokee_esp_a8_t> esp_a8_data)
{
    rclcpp::Time time_now = node_->get_clock()->now();
    if (time_now.nanoseconds() - prev_can_msg_timestamp_.nanoseconds() > FULL_CONTENT_LISTEN_DURATION_NS)
    {
        signals_received_completion_map_.reset();
        current_vehicle_signals_ = msg_replay_radar::msg::MsgVehicleSignals();
    }
    prev_can_msg_timestamp_ = time_now;

    double veh_speed = esp_a8_data->veh_speed * KMPH_TO_MPS;

    current_vehicle_signals_.veh_speed = veh_speed;
    current_vehicle_signals_.meas_time = time_now;
    signals_received_completion_map_.set(2);

    PublishOnCompletion();
}
