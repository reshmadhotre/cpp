#include "RosParams.h"

namespace ROS_PARAM_NAMES
{
const std::string CAN_DEVICE{"can_device"};
const std::string DBC_FILEPATH{"dbc_filepath"};
const std::string SENSOR_POSITION_X{"sensor_position_x"};
const std::string SENSOR_POSITION_Y{"sensor_position_y"};
const std::string SENSOR_POSITION_Z{"sensor_position_z"};
const std::string SENSOR_YAW{"sensor_yaw"};
const std::string SENSOR_PITCH{"sensor_pitch"};
const std::string SENSOR_ROLL{"sensor_roll"};

} // namespace ROS_PARAM_NAMES