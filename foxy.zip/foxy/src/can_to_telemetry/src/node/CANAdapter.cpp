#include "CANAdapter.h"
#include "FrameIDDefs.h"
#include "RosParams.h"
#include "RosTopics.h"
#include <sys/stat.h>

const uint8_t CANAdapter::DEFAULT_HISTORY_SIZE{10};

CANAdapter::CANAdapter(std::shared_ptr<rclcpp::Node> node) : node_(node)
{
    ros_param_util_ = std::make_shared<RosParamUtil>(node);
    InitROSParams();
    InitSubscribers();
    InitFrameIDsToProcess();
    InitCANParser();
    InitCANReader();
}

CANAdapter::~CANAdapter()
{
    ros2_socket_can_reader_.reset();
}

void CANAdapter::InitCANParser()
{
    try
    {
        if (FileExists(dbc_filepath_))
        {
            parser_factory_ = std::make_shared<ParserFactory>(dbc_filepath_);
            can_parser_initialized_ = true;
        }
        else
        {
            RCLCPP_ERROR(node_->get_logger(), "CAN Parsers not initialized. Given DBC File path : %s",
                         dbc_filepath_.c_str());
        }
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        can_parser_initialized_ = false;
        RCLCPP_ERROR(node_->get_logger(), "CAN Parsers not initialized. Given DBC File path : %s",
                     dbc_filepath_.c_str());
    }
}

void CANAdapter::InitSubscribers()
{
    using namespace ROS_SUBSCRIBER_TOPICS;
    can_frame_subscriber_ = node_->create_subscription<can_to_telemetry::msg::MsgFrame>(
        TOPIC_CAN_FRAME, DEFAULT_HISTORY_SIZE, std::bind(&CANAdapter::CanFrameCB, this, std::placeholders::_1));
}

void CANAdapter::CanFrameCB(can_to_telemetry::msg::MsgFrame::UniquePtr msg)
{
    auto frame_id = msg->id;
    auto parser = parser_factory_->GetParser(frame_id);
    if (parser == nullptr)
    {
        RCLCPP_ERROR(node_->get_logger(), "Parser not available for CAN ID : %u", frame_id);
        return;
    }
    std::vector<uint8_t> data;
    std::copy(std::begin(msg->data), std::end(msg->data), std::back_inserter(data));
    parser->Decode(data);
    parser->SendDataToCanNode(can_node_);
}

void CANAdapter::ReadNextMessage()
{
    if (!can_parser_initialized_)
    {
        return;
        RCLCPP_ERROR(node_->get_logger(), "CAN Parsers not initialized. Given DBC File path : %s",
                     dbc_filepath_.c_str());
    }
}

void CANAdapter::InitROSParams()
{
    using namespace ROS_PARAM_NAMES;
    ros_param_util_->DeclareParameter(DBC_FILEPATH, "");
    dbc_filepath_ = ros_param_util_->GetParameter(DBC_FILEPATH).as_string();
}

void CANAdapter::InitFrameIDsToProcess()
{
    frame_ids_to_process_.push_back(VEHICLE_GRAND_CHEROKEE_ESP_A4_FRAME_ID);
    frame_ids_to_process_.push_back(VEHICLE_GRAND_CHEROKEE_ESP_A8_FRAME_ID);
    frame_ids_to_process_.push_back(VEHICLE_GRAND_CHEROKEE_TCM_A7_FRAME_ID);

    std::sort(frame_ids_to_process_.begin(), frame_ids_to_process_.end());
}

void CANAdapter::InitCANReader()
{

    ros2_socket_can_reader_ = std::make_shared<Ros2SocketCanReader>(node_, frame_ids_to_process_);
}

void CANAdapter::SetCANNode(std::shared_ptr<CANNode> can_node)
{
    can_node_ = can_node;
}

bool CANAdapter::ProcessFrameID(const uint32_t frame_id)
{
    return std::find(frame_ids_to_process_.begin(), frame_ids_to_process_.end(), frame_id) !=
           frame_ids_to_process_.end();
}

bool CANAdapter::FileExists(const std::string& file_path)
{
    struct stat buffer;
    return (stat(file_path.c_str(), &buffer) == 0);
}

std::string CANAdapter::RemoveExtensionFromFilePath(const std::string& file_path)
{
    size_t lastdot = file_path.find_last_of(".");
    if (lastdot == std::string::npos)
    {
        return file_path;
    }
    return file_path.substr(0, lastdot);
}