#include "RosTopics.h"

namespace ROS_PUBLISHER_TOPICS
{

const std::string TOPIC_TELEMETRY_UHDP{"/topic_telemetry_uhdp"};
const std::string TOPIC_LRR_TELEMETRY_UHDP{
    "/topic_lrr_telemetry_uhdp"}; // Topic name has '/' to make it global. Irrespective of the namespace the node is
                                  // launched in, the topic is always /topic_telemetry_uhdp. Without a '/', the
                                  // namespace of the node would get appended. For eg., /foo/topic_telemetry_uhdp
const std::string TOPIC_CAN_VEHICLE_SIGNALS{"/topic_can_vehicle_signals"};
const std::string TOPIC_CAN_FRAME{"topic_can_frame"};

} // namespace ROS_PUBLISHER_TOPICS

namespace ROS_SUBSCRIBER_TOPICS
{

const std::string TOPIC_CAN_FRAME{"topic_can_frame"};

} // namespace ROS_SUBSCRIBER_TOPICS