
#include "CANAdapter.h"
#include "CANNode.h"
#include "rclcpp/rclcpp.hpp"
#include <csignal>

std::shared_ptr<CANAdapter> can_adapter;

void sigint_handler(int sig_num)
{
    if (can_adapter != nullptr)
    {
        can_adapter.reset();
    }
    rclcpp::shutdown();

    exit(sig_num);
}

int main(int argc, char* argv[])
{
    std::signal(SIGINT, sigint_handler);

    rclcpp::InitOptions options = rclcpp::InitOptions();
    options.shutdown_on_sigint = false;

    rclcpp::init(argc, argv, options);

    auto node = std::make_shared<rclcpp::Node>("can_to_telemetry_node");

    auto can_node = std::make_shared<CANNode>(node);

    can_adapter = std::make_shared<CANAdapter>(node);

    can_adapter->SetCANNode(can_node);

    while (rclcpp::ok())
    {
        can_adapter->ReadNextMessage();
        rclcpp::spin_some(node);
    }

    can_adapter.reset();
    rclcpp::shutdown();

    return 0;
}