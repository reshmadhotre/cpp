#include "Ros2SocketCanReader.h"
#include "RosParams.h"
#include "RosTopics.h"

const uint8_t Ros2SocketCanReader::DEFAULT_HISTORY_SIZE{10};

Ros2SocketCanReader::Ros2SocketCanReader(std::shared_ptr<rclcpp::Node> node,
                                         const std::vector<uint32_t>& frame_ids_to_process)
    : stream(ios), signals(ios, SIGINT, SIGTERM)
{
    node_ = node;
    ros_param_util_ = std::make_shared<RosParamUtil>(node);
    std::copy(frame_ids_to_process.begin(), frame_ids_to_process.end(), std::back_inserter(frame_ids_to_process_));
    InitRosParams();
    InitPublishers();
    InitCANInterface();
}

Ros2SocketCanReader::~Ros2SocketCanReader()
{
    RCLCPP_INFO(node_->get_logger(), "Calling stop for ros2 socket can reader.");
    Stop();
}

void Ros2SocketCanReader::InitRosParams()
{
    using namespace ROS_PARAM_NAMES;
    ros_param_util_->DeclareParameter(CAN_DEVICE, "can0");
    can_socket_ = ros_param_util_->GetParameter(CAN_DEVICE).as_string();
}

void Ros2SocketCanReader::InitCANInterface()
{
    strcpy(ifr.ifr_name, can_socket_.c_str());
    ioctl(natsock, SIOCGIFINDEX, &ifr);

    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    if (bind(natsock, (struct sockaddr*)&addr, sizeof(addr)) < 0)
    {
        RCLCPP_ERROR(node_->get_logger(), "Error in socket bind. CAN Interface not initialized for %s",
                     can_socket_.c_str());
        perror("Error in socket bind");
        return;
    }

    stream.assign(natsock);

    stream.async_read_some(boost::asio::buffer(&rec_frame, sizeof(rec_frame)),
                           std::bind(&Ros2SocketCanReader::CanListener, this, std::ref(rec_frame), std::ref(stream)));

    signals.async_wait(std::bind(&Ros2SocketCanReader::Stop, this));

    std::size_t (boost::asio::io_service::*run)() = &boost::asio::io_service::run;
    std::thread bt(std::bind(run, &ios));
    bt.detach();

    RCLCPP_INFO(node_->get_logger(), "ROS2Socket Can Reader Initialized.");
}

void Ros2SocketCanReader::InitPublishers()
{
    using namespace ROS_PUBLISHER_TOPICS;
    can_frame_publisher_ =
        node_->create_publisher<can_to_telemetry::msg::MsgFrame>(TOPIC_CAN_FRAME, DEFAULT_HISTORY_SIZE);
}

void Ros2SocketCanReader::CanListener(struct can_frame& rec_frame,
                                      boost::asio::posix::basic_stream_descriptor<>& stream)
{
    auto frame = std::make_shared<can_to_telemetry::msg::MsgFrame>();

    frame->id = rec_frame.can_id;

    if (ProcessFrameID(frame->id))
    {
        frame->dlc = int(rec_frame.can_dlc);

        for (int i = 0; i < rec_frame.can_dlc; i++)
        {
            frame->data[i] = rec_frame.data[i];
        }

        PublishCanFrame(frame);
    }

    stream.async_read_some(boost::asio::buffer(&rec_frame, sizeof(rec_frame)),
                           std::bind(&Ros2SocketCanReader::CanListener, this, std::ref(rec_frame), std::ref(stream)));
}

void Ros2SocketCanReader::Stop()
{
    ios.stop();
    signals.clear();
}

bool Ros2SocketCanReader::ProcessFrameID(const uint32_t frame_id)
{
    return std::find(frame_ids_to_process_.begin(), frame_ids_to_process_.end(), frame_id) !=
           frame_ids_to_process_.end();
}

void Ros2SocketCanReader::PublishCanFrame(std::shared_ptr<can_to_telemetry::msg::MsgFrame> can_frame)
{
    can_frame_publisher_->publish(*can_frame.get());
}