#include "ESP_A8_Parser.h"
#include "CANNode.h"

ESP_A8_Parser::ESP_A8_Parser(const std::string& dbc_file, const uint32_t frame_id) : ParserBase(dbc_file, frame_id)
{
    esp_a8_data_ = std::make_shared<vehicle_grand_cherokee_esp_a8_t>();
}

void ESP_A8_Parser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    esp_a8_data_->brk_trq = static_cast<decltype(esp_a8_data_->brk_trq)>(DecodeMessage(message, "BrkTrq", data));
    esp_a8_data_->veh_sp_sts =
        static_cast<decltype(esp_a8_data_->veh_sp_sts)>(DecodeMessage(message, "VehSpSts", data));
    esp_a8_data_->brk_trq_d = static_cast<decltype(esp_a8_data_->brk_trq_d)>(DecodeMessage(message, "BrkTrq_D", data));
    esp_a8_data_->veh_speed = static_cast<decltype(esp_a8_data_->veh_speed)>(DecodeMessage(message, "VEH_SPEED", data));
    esp_a8_data_->mc_veh_speed =
        static_cast<decltype(esp_a8_data_->mc_veh_speed)>(DecodeMessage(message, "MC_VEH_SPEED", data));
    esp_a8_data_->crc_veh_speed =
        static_cast<decltype(esp_a8_data_->crc_veh_speed)>(DecodeMessage(message, "CRC_VEH_SPEED", data));
}

void ESP_A8_Parser::SendDataToCanNode(std::shared_ptr<CANNode> can_node)
{
    can_node->AddData(esp_a8_data_);
}

std::shared_ptr<vehicle_grand_cherokee_esp_a8_t> ESP_A8_Parser::GetDecodedData() const
{
    return esp_a8_data_;
}