#include "ESP_A4_Parser.h"
#include "CANNode.h"

ESP_A4_Parser::ESP_A4_Parser(const std::string& dbc_file, const uint32_t frame_id) : ParserBase(dbc_file, frame_id)
{
    esp_a4_data_ = std::make_shared<vehicle_grand_cherokee_esp_a4_t>();
}

void ESP_A4_Parser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    esp_a4_data_->veh_yaw_rate_raw =
        static_cast<decltype(esp_a4_data_->veh_yaw_rate_raw)>(DecodeMessage(message, "VehYawRate_Raw", data));
    esp_a4_data_->veh_yaw_rate_offset =
        static_cast<decltype(esp_a4_data_->veh_yaw_rate_offset)>(DecodeMessage(message, "VehYawRate_Offset", data));
    esp_a4_data_->veh_accel_x_offset =
        static_cast<decltype(esp_a4_data_->veh_accel_x_offset)>(DecodeMessage(message, "VehAccel_X_Offset", data));
    esp_a4_data_->veh_accel_x =
        static_cast<decltype(esp_a4_data_->veh_accel_x)>(DecodeMessage(message, "VehAccel_X", data));
    esp_a4_data_->veh_accel_y =
        static_cast<decltype(esp_a4_data_->veh_accel_y)>(DecodeMessage(message, "VehAccel_Y", data));
    esp_a4_data_->mc_veh_dyn_stat =
        static_cast<decltype(esp_a4_data_->mc_veh_dyn_stat)>(DecodeMessage(message, "MC_VEH_DYN_STAT", data));
    esp_a4_data_->veh_accel_y_offset =
        static_cast<decltype(esp_a4_data_->veh_accel_y_offset)>(DecodeMessage(message, "VehAccel_Y_Offset", data));
}

void ESP_A4_Parser::SendDataToCanNode(std::shared_ptr<CANNode> can_node)
{
    can_node->AddData(esp_a4_data_);
}

std::shared_ptr<vehicle_grand_cherokee_esp_a4_t> ESP_A4_Parser::GetDecodedData() const
{
    return esp_a4_data_;
}