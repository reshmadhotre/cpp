#include "TCM_A7_Parser.h"
#include "CANNode.h"

TCM_A7_Parser::TCM_A7_Parser(const std::string& dbc_file, const uint32_t frame_id) : ParserBase(dbc_file, frame_id)
{
    tcm_a7_data_ = std::make_shared<vehicle_grand_cherokee_tcm_a7_t>();
}

void TCM_A7_Parser::Decode(const std::vector<unsigned char>& payload)
{
    auto message = GetDBCMessage();
    std::vector<unsigned char> data;
    data.assign(payload.begin(), payload.end());

    tcm_a7_data_->eng_shut_off_rq_tcm =
        static_cast<decltype(tcm_a7_data_->eng_shut_off_rq_tcm)>(DecodeMessage(message, "EngShutOffRq_TCM", data));
    tcm_a7_data_->current_gear =
        static_cast<decltype(tcm_a7_data_->current_gear)>(DecodeMessage(message, "CurrentGear", data));
    tcm_a7_data_->current_gear_for_display = static_cast<decltype(tcm_a7_data_->current_gear_for_display)>(
        DecodeMessage(message, "CurrentGearForDisplay", data));
    tcm_a7_data_->target_gear =
        static_cast<decltype(tcm_a7_data_->target_gear)>(DecodeMessage(message, "TargetGear", data));
    tcm_a7_data_->tx_warn2 = static_cast<decltype(tcm_a7_data_->tx_warn2)>(DecodeMessage(message, "TX_WARN2", data));
    tcm_a7_data_->tcc_temp_excess =
        static_cast<decltype(tcm_a7_data_->tcc_temp_excess)>(DecodeMessage(message, "TCCTemp_Excess", data));
    tcm_a7_data_->mc_tcm_a7 = static_cast<decltype(tcm_a7_data_->mc_tcm_a7)>(DecodeMessage(message, "MC_TCM_A7", data));
    tcm_a7_data_->crc_tcm_a7 =
        static_cast<decltype(tcm_a7_data_->crc_tcm_a7)>(DecodeMessage(message, "CRC_TCM_A7", data));
}

void TCM_A7_Parser::SendDataToCanNode(std::shared_ptr<CANNode> can_node)
{
    can_node->AddData(tcm_a7_data_);
}

std::shared_ptr<vehicle_grand_cherokee_tcm_a7_t> TCM_A7_Parser::GetDecodedData() const
{
    return tcm_a7_data_;
}