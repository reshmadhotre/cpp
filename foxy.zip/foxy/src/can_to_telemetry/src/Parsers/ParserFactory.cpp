#include "ParserFactory.h"
#include "ESP_A4_Parser.h"
#include "ESP_A8_Parser.h"
#include "FrameIDDefs.h"
#include "TCM_A7_Parser.h"

ParserFactory::ParserFactory(const std::string& dbc_file)
{
    frameID_parser_map_.insert({VEHICLE_GRAND_CHEROKEE_ESP_A4_FRAME_ID,
                                std::make_shared<ESP_A4_Parser>(dbc_file, VEHICLE_GRAND_CHEROKEE_ESP_A4_FRAME_ID)});
    frameID_parser_map_.insert({VEHICLE_GRAND_CHEROKEE_ESP_A8_FRAME_ID,
                                std::make_shared<ESP_A8_Parser>(dbc_file, VEHICLE_GRAND_CHEROKEE_ESP_A8_FRAME_ID)});
    frameID_parser_map_.insert({VEHICLE_GRAND_CHEROKEE_TCM_A7_FRAME_ID,
                                std::make_shared<TCM_A7_Parser>(dbc_file, VEHICLE_GRAND_CHEROKEE_TCM_A7_FRAME_ID)});
}

std::shared_ptr<ParserBase> ParserFactory::GetParser(const uint32_t frame_id)
{
    auto iter = frameID_parser_map_.find(frame_id);

    if (iter == frameID_parser_map_.end())
    {
        return nullptr;
    }

    return iter->second;
}
