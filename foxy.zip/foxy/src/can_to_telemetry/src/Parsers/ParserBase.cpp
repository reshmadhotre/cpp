#include "ParserBase.h"
#include "rclcpp/rclcpp.hpp"

Vector::DBC::Network ParserBase::dbc_network_;
ParserBase::ParserBase(const std::string& dbc_file, const uint32_t frame_id)
{
    if (!IsNetworkInitialized())
    {
        SetNetwork(dbc_file);
    }
    frame_id_ = frame_id;
}

void ParserBase::SetNetwork(const std::string& dbc_file)
{
    try
    {
        std::fstream filestream(dbc_file, std::ios::in);
        filestream >> dbc_network_;
    }
    catch (const std::exception& e)
    {
        RCLCPP_ERROR(rclcpp::get_logger("CAN PARSER LOGGER"),
                     "Error setting Vector CAN Network with given dbc file : %s", dbc_file.c_str());
        std::cerr << e.what() << '\n';
    }
}

bool ParserBase::IsNetworkInitialized()
{
    return dbc_network_.successfullyParsed;
}

double ParserBase::DecodeMessage(const Vector::DBC::Message& dbc_msg, const std::string& signal_name,
                                 std::vector<uint8_t>& data)
{
    try
    {
        auto signal = dbc_msg.signals.at(signal_name);
        return signal.rawToPhysicalValue(signal.decode(data));
    }
    catch (const std::exception& e)
    {
        double default_value = 0.0;
        RCLCPP_DEBUG(rclcpp::get_logger("CAN PARSER LOGGER"), "Error decoding signal : %s. Setting value to : %f",
                     signal_name.c_str(), (float)(default_value));
        return default_value;
    }
}

Vector::DBC::Message ParserBase::GetDBCMessage()
{
    return dbc_network_.messages[frame_id_];
}

uint32_t ParserBase::GetFrameID() const
{
    return frame_id_;
}

void ParserBase::SendDataToCanNode(std::shared_ptr<CANNode> can_node)
{
    (void)can_node;
}