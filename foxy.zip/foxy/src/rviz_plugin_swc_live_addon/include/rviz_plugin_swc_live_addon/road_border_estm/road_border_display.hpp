#ifndef ROAD_BORDER_DISPLAY_H
#define ROAD_BORDER_DISPLAY_H

#include "msg_live_addon/msg/msg_roadborder_type.hpp"
#include "rviz_plugin_swc_live_addon/road_border_estm/road_border_visual.hpp"
#include "rviz_plugin_swc_live_addon/visibility_control.hpp"
#include <rviz_common/message_filter_display.hpp>
#include <rviz_common/properties/bool_property.hpp>
#include <rviz_common/properties/color_property.hpp>
#include <rviz_common/properties/float_property.hpp>
#include <rviz_common/properties/int_property.hpp>

namespace rviz_plugin_swc_live_addon
{
class REC_REPLAY_PLUGIN_PUBLIC RoadBorderDisplay
    : public rviz_common::MessageFilterDisplay<msg_live_addon::msg::MsgRoadborderType>
{
    Q_OBJECT

  public:
    RoadBorderDisplay();
    ~RoadBorderDisplay();
    void onInitialize();
    void reset();
    virtual void update(float wall_dt, float ros_dt);

  protected:
    void onEnable() override;
    void onDisable() override;

  private slots:
    void updateKeepVisualizations();
    void updateLineWidth();
    void updateRightLineColour();
    void updateLeftLineColour();
    void updateNumSegments();

  private:
    void processMessage(const msg_live_addon::msg::MsgRoadborderType::ConstSharedPtr msg);
    void clearVisuals();

    std::chrono::steady_clock::time_point msg_receive_time_;
    float visual_decay_time_secs_{0.5};

    rclcpp::Publisher<msg_live_addon::msg::MsgRoadborderType>::SharedPtr road_border_publisher_;

    rviz_common::properties::BoolProperty* keep_visualizations_property_;
    rviz_common::properties::FloatProperty* line_width_property_;
    rviz_common::properties::ColorProperty* right_line_colour_property_;
    rviz_common::properties::ColorProperty* left_line_colour_property_;
    rviz_common::properties::IntProperty* num_segments_property_;
    bool keep_visualizations_;
    uint8_t num_segments_{120};
    Ogre::ColourValue right_road_border_colour_{0.0f, 1.0f, 0.0f, 1.0f}; // Default Green
    Ogre::ColourValue left_road_border_colour_{1.0f, 0.0f, 0.0f, 1.0f};  // Default Red
    float line_width_{0.1};
    std::shared_ptr<RoadBorderVisual> left_road_border_visual_;
    std::shared_ptr<RoadBorderVisual> right_road_border_visual_;
    std::shared_ptr<msg_live_addon::msg::MsgRoadborderType> road_border_data_;
};
} // namespace rviz_plugin_swc_live_addon

#endif