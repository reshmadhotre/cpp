#ifndef ROAD_BORDER_VISUAL_H
#define ROAD_BORDER_VISUAL_H

#include "OgreSceneManager.h"
#include "OgreSceneNode.h"
#include "msg_live_addon/msg/msg_simple_clothoid_type.hpp"
#include "rviz_rendering/objects/billboard_line.hpp"
#include "rviz_rendering/objects/shape.hpp"
#include "rviz_plugin_swc_live_addon/visibility_control.hpp"

namespace rviz_plugin_swc_live_addon
{
class REC_REPLAY_PLUGIN_PUBLIC RoadBorderVisual
{
  public:
    RoadBorderVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node);
    ~RoadBorderVisual();

    void setMessage(const msg_live_addon::msg::MsgSimpleClothoidType& simple_clothoid, uint8_t num_segements,
                    const Ogre::ColourValue& line_colour);
    void setFramePosition(const Ogre::Vector3& position);
    void setFrameOrientation(const Ogre::Quaternion& orientation);
    void clearPoints();
    void setLineWidth(float width);

  private:
    Ogre::SceneNode* frame_node_;
    Ogre::SceneManager* scene_manager_;
    rviz_rendering::BillboardLine* billboard_line_;
    float billboard_width_{0.1};

    inline bool validateFloats(float val)
    {
        return !(std::isnan(val) || std::isinf(val));
    }
    bool validateFloats(const Ogre::Vector3& pos);
    void createBillboardLine();
    void destroyBillboardLine();
    std::vector<Ogre::Vector3> generateCartesianPositions(
        const msg_live_addon::msg::MsgSimpleClothoidType& simple_clothoid, uint8_t num_segements);
};
} // namespace rviz_plugin_swc_live_addon

#endif