#ifndef OBJECT_SELECTION_HANDLER_HPP
#define OBJECT_SELECTION_HANDLER_HPP

#include "rviz_common/interaction/selection_manager.hpp"
#include "rviz_plugin_swc_live_addon/visibility_control.hpp"

namespace rviz_plugin_swc_live_addon
{
class REC_REPLAY_PLUGIN_PUBLIC ObjectSelectionHandler : public rviz_common::interaction::SelectionHandler
{
  public:
    ObjectSelectionHandler(rviz_common::DisplayContext* context);
    ~ObjectSelectionHandler() override;

    void onSelect(const rviz_common::interaction::Picked& obj) override;
    void onDeselect(const rviz_common::interaction::Picked& obj) override;

    bool isObjectSelected();

  private:
    bool object_selected_{false};
};
} // namespace rviz_plugin_swc_live_addon
#endif