#ifndef CAN_OBJECT_VISUAL_H
#define CAN_OBJECT_VISUAL_H

#include "msg_live_addon/msg/msg_can_obj_list_type.hpp"
#include "rviz_plugin_swc_live_addon/object_selection_handler.hpp"
#include "rviz_plugin_swc_live_addon/visibility_control.hpp"
#include <rviz_common/display_context.hpp>
#include <rviz_rendering/objects/arrow.hpp>
#include <rviz_rendering/objects/movable_text.hpp>
#include <rviz_rendering/objects/shape.hpp>
#include <tf2/LinearMath/Quaternion.h>

namespace rviz_plugin_swc_live_addon
{

class REC_REPLAY_PLUGIN_PUBLIC CanObjectVisual
{
  public:
    enum ObjAge_E
    {
        OLD = 0,
        NEW
    };

  public:
    CanObjectVisual(Ogre::SceneNode* parent_node, rviz_common::DisplayContext* context);
    virtual ~CanObjectVisual();

    // setMessage for Object from Tracker Node
    void setMessage(const msg_live_addon::msg::MsgCanObjType& object, bool use_shape_estimation, bool use_object_yaw,
                    bool show_orientation_arrow);
    void setAge(CanObjectVisual::ObjAge_E object_age_enum, const float color_alpha);
    void setFramePosition(const Ogre::Vector3& position);
    void setFrameOrientation(const Ogre::Quaternion& orientation);
    bool isObjectSelected();
    std::shared_ptr<msg_live_addon::msg::MsgCanObjType> getObject();
    void setObjectClassVisibility(bool visible, float label_font_size);

  private:
    Ogre::Vector3 computeObjectScale(const msg_live_addon::msg::MsgCanObjType& object, bool use_shape_estimation);
    void updateObjectClassLabel(const msg_live_addon::msg::MsgCanObjType& object,
                                const CanObjectVisual::ObjAge_E& object_age_enum, float label_font_size);
    std::string getObjectClassFromMap(uint8_t class_number);

    rviz_common::DisplayContext* context_;
    Ogre::SceneNode* frame_node_;
    Ogre::SceneManager* scene_manager_;
    std::shared_ptr<rviz_rendering::Shape> object_shape_;
    std::shared_ptr<rviz_rendering::Shape> object_class_label_pivot_;
    std::shared_ptr<rviz_rendering::MovableText> object_class_label_;
    std::shared_ptr<rviz_rendering::Arrow> object_orientation_arrow_;
    std::shared_ptr<ObjectSelectionHandler> selection_handler_;
    std::shared_ptr<msg_live_addon::msg::MsgCanObjType> ros_can_object_;
    CanObjectVisual::ObjAge_E object_age_;

    const static float DEFAULT_OBJECT_LENGTH;
    const static float DEFAULT_OBJECT_WIDTH;
    const static float DEFAULT_OBJECT_HEIGHT;
    const static Ogre::ColourValue NEW_OBJECT_COLOUR_VALUE_BLUE;
    const static Ogre::ColourValue OLD_OBJECT_COLOUR_VALUE_ORANGE;
    const static rviz_rendering::Shape::Type OBJECT_SHAPE_TYPE;
};
} // namespace rviz_plugin_swc_live_addon
#endif