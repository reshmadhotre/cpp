#ifndef CAN_OBJECT_PROPERTIES_WIDGET_HPP
#define CAN_OBJECT_PROPERTIES_WIDGET_HPP

#include "msg_live_addon/msg/msg_can_obj_type.hpp"
#include "rviz_plugin_swc_live_addon/visibility_control.hpp"
#include <QHeaderView>
#include <QTableWidget>
#include <QVBoxLayout>

namespace rviz_plugin_swc_live_addon
{
class REC_REPLAY_PLUGIN_PUBLIC CanObjectPropertiesWidget : public QWidget
{
    Q_OBJECT
  public:
    CanObjectPropertiesWidget(QWidget* parent = 0);
    void updateData(const msg_live_addon::msg::MsgCanObjType& object);
    void clearTableValues();

  private:
    void initTableWithEmptyData();

    std::map<std::string, std::string> formatObjectDataAsTable(const msg_live_addon::msg::MsgCanObjType& object);
    QTableWidget* table_widget_;
    QStringList table_header_strings_;
    uint16_t num_rows_{0};
};
} // namespace rviz_plugin_swc_live_addon
#endif