#ifndef CAN_OBJECT_LIST_DISPLAY_H
#define CAN_OBJECT_LIST_DISPLAY_H

#include "msg_live_addon/msg/msg_can_obj_list_type.hpp"
#include "rviz_plugin_swc_live_addon/can_object_list/can_object_visual.hpp"
#include "rviz_plugin_swc_live_addon/visibility_control.hpp"
#include <algorithm>
#include <chrono>
#include <rviz_common/message_filter_display.hpp>
#include <rviz_common/properties/bool_property.hpp>
#include <rviz_common/properties/float_property.hpp>

namespace rviz_plugin_swc_live_addon
{
class REC_REPLAY_PLUGIN_PUBLIC CanObjectListDisplay
    : public rviz_common::MessageFilterDisplay<msg_live_addon::msg::MsgCanObjListType>
{
    Q_OBJECT

  public:
    CanObjectListDisplay();
    ~CanObjectListDisplay();
    void onInitialize();
    void reset();
    virtual void update(float wall_dt, float ros_dt);

  protected:
    void onEnable() override;
    void onDisable() override;

  private slots:
    void updateKeepVisualizations();
    void updateShowStaticObjects();
    void updateAgeThreshold();
    void updateUseShapeEstimation();
    void updateRestrictFOV();
    void updateFOV();
    void updateShowNewObjects();
    void updateShowObjectClass();
    void updateObjectLabelFontSize();
    void updateUseObjectYaw();
    void updateShowOrientationArrow();
    void updateVisualTransparency();

  private:
    void processMessage(const msg_live_addon::msg::MsgCanObjListType::ConstSharedPtr msg);
    void clearVisuals();
    bool showObject(const msg_live_addon::msg::MsgCanObjType& object);
    std::vector<uint16_t> getCurrentObjectIDs();

    std::map<uint16_t, std::shared_ptr<CanObjectVisual>> id_visuals_map_;
    rclcpp::Publisher<msg_live_addon::msg::MsgCanObjType>::SharedPtr obj_data_publisher_;
    std::chrono::steady_clock::time_point msg_receive_time_;
    float visual_decay_time_secs_{0.5};
    rviz_common::properties::BoolProperty* keep_visualizations_property_;
    rviz_common::properties::BoolProperty* show_static_objects_property_;
    rviz_common::properties::FloatProperty* age_threshold_property_;
    rviz_common::properties::BoolProperty* use_shape_estimation_property_;
    rviz_common::properties::BoolProperty* restrict_fov_property_;
    rviz_common::properties::FloatProperty* fov_value_property_;
    rviz_common::properties::BoolProperty* show_new_objects_property_;
    rviz_common::properties::BoolProperty* show_object_class_property_;
    rviz_common::properties::FloatProperty* object_class_label_font_size_property_;
    rviz_common::properties::BoolProperty* use_object_yaw_property_;
    rviz_common::properties::BoolProperty* show_orientation_arrow_property_;
    rviz_common::properties::FloatProperty* visual_transparency_property_;

    bool keep_visualizations_;
    bool show_static_objects_;
    float age_threshold_;
    bool use_shape_estimation_;
    bool restrict_fov_value_;
    float fov_value_radians_;
    bool show_new_objects_;
    bool show_object_class_;
    float object_class_label_font_size_;
    bool use_object_yaw_;
    bool show_orientation_arrow_;
    float visual_transparency_;

    const static std::string TOPIC_CAN_SELECTED_OBJECT;
};
} // namespace rviz_plugin_swc_live_addon
#endif