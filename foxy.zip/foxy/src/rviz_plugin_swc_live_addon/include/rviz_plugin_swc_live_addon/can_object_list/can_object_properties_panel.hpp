#ifndef CAN_OBJECT_PROPERTIES_PANEL_HPP
#define CAN_OBJECT_PROPERTIES_PANEL_HPP

#include "msg_live_addon/msg/msg_can_obj_type.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rviz_common/display_context.hpp"
#include "rviz_plugin_swc_live_addon/can_object_list/can_object_properties_widget.hpp"
#include "rviz_plugin_swc_live_addon/visibility_control.hpp"
#include <QVBoxLayout>
#include <rviz_common/panel.hpp>

namespace rviz_plugin_swc_live_addon
{
class REC_REPLAY_PLUGIN_PUBLIC CanObjectPropertiesPanel : public rviz_common::Panel
{
    Q_OBJECT

  public:
    explicit CanObjectPropertiesPanel(QWidget* parent = 0);

    void onInitialize() override;
    void save(rviz_common::Config config) const override;
    void load(const rviz_common::Config& config) override;

  private:
    void callback_object_data(msg_live_addon::msg::MsgCanObjType::SharedPtr msg);
    void onTimeOutCallback();

    CanObjectPropertiesWidget* properties_widget_;
    rclcpp::Subscription<msg_live_addon::msg::MsgCanObjType>::SharedPtr object_data_subscriber_;
    rclcpp::TimerBase::SharedPtr clear_table_timer_;
    std::chrono::steady_clock::time_point msg_receive_time_;
    float visual_decay_time_secs_{0.5};
};
} // namespace rviz_plugin_swc_live_addon
#endif