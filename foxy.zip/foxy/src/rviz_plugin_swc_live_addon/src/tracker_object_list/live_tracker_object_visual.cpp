#include "rviz_plugin_swc_live_addon/tracker_object_list/live_tracker_object_visual.hpp"
#include "rviz_plugin_swc_live_addon/tracker_object_list/tracker_object_classification_map.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>
#include <OgreVector3.h>

namespace
{
inline bool validateFloats(float val)
{
    return !(std::isnan(val) || std::isinf(val));
}

bool validateFloats(Ogre::Vector3 pos)
{
    bool valid = true;
    valid = valid && validateFloats(pos.x);
    valid = valid && validateFloats(pos.y);
    valid = valid && validateFloats(pos.z);
    return valid;
}
} // namespace

namespace rviz_plugin_swc_live_addon
{

const float LiveTrackerObjectVisual::DEFAULT_OBJECT_LENGTH = 4.0f;
const float LiveTrackerObjectVisual::DEFAULT_OBJECT_WIDTH = 2.5f;
const float LiveTrackerObjectVisual::DEFAULT_OBJECT_HEIGHT = 1.5f;
const Ogre::ColourValue LiveTrackerObjectVisual::NEW_OBJECT_COLOUR_VALUE_BLUE =
    Ogre::ColourValue(0.0f, 0.0f, 1.0f, 1.0f);
const Ogre::ColourValue LiveTrackerObjectVisual::OLD_OBJECT_COLOUR_VALUE_ORANGE =
    Ogre::ColourValue(0.9f, 0.5f, 0.0f, 1.0f);
const rviz_rendering::Shape::Type LiveTrackerObjectVisual::OBJECT_SHAPE_TYPE = rviz_rendering::Shape::Cube;

LiveTrackerObjectVisual::LiveTrackerObjectVisual(Ogre::SceneNode* parent_node, rviz_common::DisplayContext* context)
{
    context_ = context;
    scene_manager_ = context_->getSceneManager();
    frame_node_ = parent_node->createChildSceneNode();

    object_shape_.reset(new rviz_rendering::Shape(OBJECT_SHAPE_TYPE, scene_manager_, frame_node_));

    object_class_label_pivot_ =
        std::make_shared<rviz_rendering::Shape>(rviz_rendering::Shape::Sphere, scene_manager_, frame_node_);
    object_class_label_pivot_->setScale(Ogre::Vector3(0.05, 0.05, 0.05));

    selection_handler_ = rviz_common::interaction::createSelectionHandler<ObjectSelectionHandler>(context_);
    selection_handler_->addTrackedObjects(frame_node_);
}

LiveTrackerObjectVisual::~LiveTrackerObjectVisual()
{
    scene_manager_->destroySceneNode(frame_node_);
}

void LiveTrackerObjectVisual::setAge(const ObjAge_E& object_age_enum, const float color_alpha)
{
    // Set Object color based on age of the object. Age <= 10 - Blue; Age > 10 Orange
    if (object_age_enum == ObjAge_E::NEW)
    {
        auto color = NEW_OBJECT_COLOUR_VALUE_BLUE;
        color.a = color_alpha;
        object_shape_->setColor(color);
    }
    else if (object_age_enum == ObjAge_E::OLD)
    {
        auto color = OLD_OBJECT_COLOUR_VALUE_ORANGE;
        color.a = color_alpha;
        object_shape_->setColor(color);
    }

    object_age_ = object_age_enum;
}

void LiveTrackerObjectVisual::setMessage(const msg_live_addon::msg::MsgObjType& object, bool use_shape_estimation,
                                         bool use_object_yaw, bool show_orientation_arrow)
{
    float pos_x = object.coor_rel_host.x;
    float pos_y = object.coor_rel_host.y;
    float pos_z = object.coor_rel_host.z;

    float object_yaw = 0.0;
    if (use_object_yaw)
    {
        object_yaw = object.yaw_ag;
    }

    Ogre::Vector3 cartesian_position;
    cartesian_position[0] = pos_x;
    cartesian_position[1] = -pos_y; //- for conversion from LHS to RHS system. Radar publishes in
                                    // LHS. Rviz renders in RHS
    cartesian_position[2] = pos_z;

    if (validateFloats(cartesian_position))
    {
        object_shape_->setPosition(cartesian_position);

        tf2::Quaternion orientation_quat;
        orientation_quat.setRPY(0.0, 0.0, -object_yaw);
        Ogre::Quaternion ogre_quat(orientation_quat.w(), orientation_quat.x(), orientation_quat.y(),
                                   orientation_quat.z());
        object_shape_->setOrientation(ogre_quat);

        Ogre::Vector3 scale = computeObjectScale(object, use_shape_estimation);
        object_shape_->setScale(scale);

        ros_tracker_object_ = std::make_shared<msg_live_addon::msg::MsgObjType>(object);

        if (show_orientation_arrow)
        {
            if (object_orientation_arrow_ == nullptr)
            {
                object_orientation_arrow_.reset(new rviz_rendering::Arrow(scene_manager_, frame_node_));
            }

            Ogre::Vector3 arrow_position = cartesian_position;
            arrow_position.z = (scale.z / 2.0f) + 0.05f;
            object_orientation_arrow_->setPosition(arrow_position);

            // Remember the arrow points in -Z direction, so rotate the orientation before display.
            object_orientation_arrow_->setOrientation(ogre_quat *
                                                      Ogre::Quaternion(Ogre::Degree(-90), Ogre::Vector3::UNIT_Y));

            auto arrow_length = (scale.x / 2.0f) + 1.0f;
            object_orientation_arrow_->set(arrow_length, 0.1f, 0.3f, 0.2f);
        }

        else
        {
            object_orientation_arrow_.reset();
        }
    }
}

void LiveTrackerObjectVisual::setObjectClassVisibility(bool visible, float label_font_size)
{
    if (!visible)
    {
        object_class_label_.reset();
        return;
    }
    updateObjectClassLabel(*ros_tracker_object_.get(), object_age_, label_font_size);
}

void LiveTrackerObjectVisual::updateObjectClassLabel(const msg_live_addon::msg::MsgObjType& object,
                                                     const LiveTrackerObjectVisual::ObjAge_E& object_age_enum,
                                                     float label_font_size)
{
    // Do not show label for new objects
    if (object_age_enum == LiveTrackerObjectVisual::ObjAge_E::NEW)
    {
        object_class_label_.reset();
        return;
    }

    float pos_x = object.coor_rel_host.x;
    float pos_y = object.coor_rel_host.y;

    object_class_label_pivot_->setPosition(Ogre::Vector3(pos_x, -pos_y, DEFAULT_OBJECT_HEIGHT + 0.1f));

    auto object_class_str = getObjectClassFromMap(object.obj_classn);
    auto object_id = object.id;

    std::stringstream stream;
    stream << "Class : " << object_class_str << "(" << (unsigned)object.obj_classn << "u)" << std::endl
           << "Id : " << object_id;

    object_class_label_.reset();
    object_class_label_ =
        std::make_shared<rviz_rendering::MovableText>(stream.str(), "Liberation Sans", label_font_size);
    object_class_label_->setTextAlignment(rviz_rendering::MovableText::H_CENTER, rviz_rendering::MovableText::V_CENTER);
    object_class_label_pivot_->getRootNode()->attachObject(object_class_label_.get());
}

std::string LiveTrackerObjectVisual::getObjectClassFromMap(uint8_t class_number)
{
    auto iter = TRACKER_OBJECT_CLASSIFICATION_MAP.find(class_number);
    if (iter != TRACKER_OBJECT_CLASSIFICATION_MAP.end())
    {
        return iter->second;
    }

    else
    {
        std::cout << "Object Class not found for value : " << class_number << ". Setting to Unknown" << std::endl;
    }

    return "Unknown";
}

std::shared_ptr<msg_live_addon::msg::MsgObjType> LiveTrackerObjectVisual::getObject()
{
    return ros_tracker_object_;
}

Ogre::Vector3 LiveTrackerObjectVisual::computeObjectScale(const msg_live_addon::msg::MsgObjType& object,
                                                          bool use_shape_estimation)
{
    float shape_length{DEFAULT_OBJECT_LENGTH};
    float shape_width{DEFAULT_OBJECT_WIDTH};
    float shape_height{DEFAULT_OBJECT_HEIGHT};

    if (use_shape_estimation)
    {
        shape_length = (object.obj_len == 0) ? DEFAULT_OBJECT_LENGTH : object.obj_len;
        shape_width = (object.obj_width == 0) ? DEFAULT_OBJECT_WIDTH : object.obj_width;
    }

    Ogre::Vector3 scale(shape_length, shape_width, shape_height);
    return scale;
}

void LiveTrackerObjectVisual::setFramePosition(const Ogre::Vector3& position)
{
    frame_node_->setPosition(position);
}

void LiveTrackerObjectVisual::setFrameOrientation(const Ogre::Quaternion& orientation)
{
    frame_node_->setOrientation(orientation);
}

bool LiveTrackerObjectVisual::isObjectSelected()
{
    return selection_handler_->isObjectSelected();
}
} // namespace rviz_plugin_swc_live_addon