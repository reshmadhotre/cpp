#include "rviz_plugin_swc_live_addon/tracker_object_list/live_tracker_object_list_display.hpp"
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>

namespace rviz_plugin_swc_live_addon
{

const std::string LiveTrackerObjectListDisplay::TOPIC_TRACKER_SELECTED_OBJECT{"/topic_object_properties_panel"};

LiveTrackerObjectListDisplay::LiveTrackerObjectListDisplay()
{
    keep_visualizations_ = true;
    keep_visualizations_property_ =
        new rviz_common::properties::BoolProperty("Keep Visualizations", keep_visualizations_,
                                                  "Keep Visualizations if no update received. Visualizations for this \
				display plugin are not cleared after set timeout and \
				persist until a new message is received.",
                                                  this, SLOT(updateKeepVisualizations()));

    show_static_objects_ = true;
    show_static_objects_property_ = new rviz_common::properties::BoolProperty(
        "Show Static Objects", show_static_objects_,
        "Show/Hide Static Objects. An Object is static/dynamic based on the motion status value.", this,
        SLOT(updateShowStaticObjects()));

    age_threshold_ = 10.0;
    age_threshold_property_ = new rviz_common::properties::FloatProperty(
        "Age Threshold Value", age_threshold_,
        "Age Threshold value used to define Old/New objects. Object age <= value are rendered blue and Object age > "
        "value are rendered orange.",
        this, SLOT(updateAgeThreshold()));

    use_shape_estimation_ = true;
    use_shape_estimation_property_ = new rviz_common::properties::BoolProperty(
        "Use Shape Estimation", use_shape_estimation_,
        "Use object length and width properties provided by Shape Estimation to render objects. If False, default "
        "values are used for all objects.",
        this, SLOT(updateUseShapeEstimation()));

    restrict_fov_value_ = false;
    restrict_fov_property_ = new rviz_common::properties::BoolProperty(
        "Restrict FOV", restrict_fov_value_, "Restrict FOV to the value defined by FOV Value property.", this,
        SLOT(updateRestrictFOV()));

    fov_value_radians_ = (Ogre::Math::PI * 90.0) / 180.0; // -90 deg to +90 deg
    fov_value_property_ = new rviz_common::properties::FloatProperty(
        "FOV Value (degrees)", 90.0,
        "FOV (degrees) of the detections to display. Detections in the range +value to -value are displayed.", this,
        SLOT(updateFOV()));

    fov_value_property_->setHidden(!restrict_fov_property_->getBool());

    show_new_objects_ = false;
    show_new_objects_property_ = new rviz_common::properties::BoolProperty(
        "Show New Objects", show_new_objects_, "Show/Hide Objects with age less than Age Threshold value.", this,
        SLOT(updateShowNewObjects()));

    show_object_class_ = false;
    show_object_class_property_ = new rviz_common::properties::BoolProperty(
        "Show Object Class for All Objects", show_object_class_, "Show/Hide Object Class for all objects.", this,
        SLOT(updateShowObjectClass()));

    object_class_label_font_size_ = 30.0f;
    object_class_label_font_size_property_ = new rviz_common::properties::FloatProperty(
        "Object Class Label Font Size", object_class_label_font_size_,
        "Font size of the text label used to show the object class. Min value : 10, Max Value : 100", this,
        SLOT(updateObjectLabelFontSize()));
    object_class_label_font_size_property_->setMin(10.0f);
    object_class_label_font_size_property_->setMax(100.0f);

    use_object_yaw_ = true;
    use_object_yaw_property_ = new rviz_common::properties::BoolProperty(
        "Use Object Yaw", use_object_yaw_,
        "If enabled, use object yaw value from the ROS Message, else yaw is always 0.0", this,
        SLOT(updateUseObjectYaw()));

    show_orientation_arrow_ = true;
    show_orientation_arrow_property_ = new rviz_common::properties::BoolProperty(
        "Show Orientation Arrow", use_object_yaw_,
        "If enabled, an orientation arrow is drawn on the objects in the direction of the object orientation.", this,
        SLOT(updateShowOrientationArrow()));

    visual_transparency_ = 0.5f;
    visual_transparency_property_ = new rviz_common::properties::FloatProperty(
        "Transparency of Objects", visual_transparency_,
        "Set the transparency of the objects displayed. Range : 0.1 to 1.0.", this, SLOT(updateVisualTransparency()));
    visual_transparency_property_->setMin(0.1f);
    visual_transparency_property_->setMax(1.0f);
}

LiveTrackerObjectListDisplay::~LiveTrackerObjectListDisplay()
{
}

void LiveTrackerObjectListDisplay::onInitialize()
{
    MFDClass::onInitialize();
    auto node = context_->getRosNodeAbstraction().lock()->get_raw_node();
    obj_data_publisher_ = node->create_publisher<msg_live_addon::msg::MsgObjType>(TOPIC_TRACKER_SELECTED_OBJECT,
                                                                                  rclcpp::SystemDefaultsQoS());
}

void LiveTrackerObjectListDisplay::reset()
{
    MFDClass::reset();
    clearVisuals();
}

void LiveTrackerObjectListDisplay::onEnable()
{
    MFDClass::onEnable();
}

void LiveTrackerObjectListDisplay::onDisable()
{
    MFDClass::onDisable();
}

void LiveTrackerObjectListDisplay::updateKeepVisualizations()
{
    keep_visualizations_ = keep_visualizations_property_->getBool();
}

void LiveTrackerObjectListDisplay::updateShowStaticObjects()
{
    show_static_objects_ = show_static_objects_property_->getBool();
}

void LiveTrackerObjectListDisplay::updateAgeThreshold()
{
    age_threshold_ = age_threshold_property_->getFloat();
}

void LiveTrackerObjectListDisplay::updateUseShapeEstimation()
{
    use_shape_estimation_ = use_shape_estimation_property_->getBool();
}

void LiveTrackerObjectListDisplay::updateRestrictFOV()
{
    restrict_fov_value_ = restrict_fov_property_->getBool();
    fov_value_property_->setHidden(!restrict_fov_value_);
}

void LiveTrackerObjectListDisplay::updateFOV()
{
    float fov_value_degrees = fov_value_property_->getFloat();
    fov_value_radians_ = (Ogre::Math::PI * fov_value_degrees) / 180.0;
}

void LiveTrackerObjectListDisplay::updateShowNewObjects()
{
    show_new_objects_ = show_new_objects_property_->getBool();
}

void LiveTrackerObjectListDisplay::updateShowObjectClass()
{
    show_object_class_ = show_object_class_property_->getBool();
}

void LiveTrackerObjectListDisplay::updateObjectLabelFontSize()
{
    object_class_label_font_size_ = object_class_label_font_size_property_->getFloat();
}

void LiveTrackerObjectListDisplay::updateUseObjectYaw()
{
    use_object_yaw_ = use_object_yaw_property_->getBool();
}

void LiveTrackerObjectListDisplay::updateShowOrientationArrow()
{
    show_orientation_arrow_ = show_orientation_arrow_property_->getBool();
}

void LiveTrackerObjectListDisplay::updateVisualTransparency()
{
    visual_transparency_ = visual_transparency_property_->getFloat();
}

void LiveTrackerObjectListDisplay::clearVisuals()
{
    id_visuals_map_.clear();
}

bool LiveTrackerObjectListDisplay::showObject(const msg_live_addon::msg::MsgObjType& object)
{
    bool show_object{true};

    // Check if static objects are disabled
    if (!show_static_objects_)
    {
        // Object is static if mtn_st == 8 (defined by enum : OBJ_MTN_STATIONARY in 'Rte_MEMplObjTrckng_Type.h')
        uint8_t object_mtn_status = object.mtn_st;
        bool is_object_static = (object_mtn_status == 8);

        show_object = (show_object && !is_object_static);
    }

    // Check if new objects are disabled
    if (!show_new_objects_)
    {
        auto object_age = object.age;
        bool is_object_new = object_age <= age_threshold_;

        show_object = (show_object && !is_object_new);
    }

    // Check if object is within the set FOV
    if (restrict_fov_value_)
    {
        float x = object.coor_rel_host.x;
        float y = object.coor_rel_host.y;

        float range = sqrt(x * x + y * y);

        float azimuth = acos(x / range);
        show_object = show_object && (azimuth <= fov_value_radians_ && azimuth >= -fov_value_radians_);
    }

    return show_object;
}

// Update function used to clear visuals after a certain decay time.
void LiveTrackerObjectListDisplay::update(float wall_dt, float ros_dt)
{
    if (!keep_visualizations_)
    {
        auto current_time = std::chrono::steady_clock::now();
        std::chrono::duration<float, std::milli> time_elapsed_secs = ((current_time - msg_receive_time_) / 1000.0);

        if (time_elapsed_secs.count() >= visual_decay_time_secs_)
        {
            clearVisuals();
        }
    }

    // Publish data for the properties panel if object is selected
    for (const auto& kv : id_visuals_map_)
    {
        auto object_visual = kv.second;
        auto object = object_visual->getObject();
        if (object_visual->isObjectSelected() && object != nullptr)
        {
            obj_data_publisher_->publish(*object.get());
            object_visual->setObjectClassVisibility(true, object_class_label_font_size_);
        }
    }
}

void LiveTrackerObjectListDisplay::processMessage(const msg_live_addon::msg::MsgObjdataType::ConstSharedPtr msg)
{
    msg_receive_time_ = std::chrono::steady_clock::now();

    Ogre::Quaternion orientation;
    Ogre::Vector3 position;
    if (!context_->getFrameManager()->getTransform(msg->header.frame_id, msg->header.stamp, position, orientation))
    {
        RCLCPP_INFO(rclcpp::get_logger("Tracker Object Data Display"),
                    "Error transforming from frame '%s' to frame '%s'", msg->header.frame_id.c_str(),
                    qPrintable(fixed_frame_));
        return;
    }

    auto num_valid_objects = msg->obj_list.r_header.num_obj;

    std::vector<uint16_t> current_ids = getCurrentObjectIDs();

    for (std::size_t i = 0; i < num_valid_objects; i++)
    {
        msg_live_addon::msg::MsgObjType object = msg->obj_list.obj_arr[i];

        if (showObject(object))
        {
            auto obj_age = object.age;
            auto obj_id = object.id;

            std::shared_ptr<LiveTrackerObjectVisual> object_visual;

            // If object id doesn't exist in map, create a new Visual
            auto id_position = std::find(current_ids.begin(), current_ids.end(), obj_id);
            if (id_position == current_ids.end())
            {
                object_visual = std::make_shared<LiveTrackerObjectVisual>(scene_node_, context_);
                id_visuals_map_.insert({obj_id, object_visual});
            }

            // Reuse existing visual and mark obj_id for non deletion
            else
            {
                object_visual = id_visuals_map_.find(obj_id)->second;
                current_ids.erase(id_position);
            }

            auto obj_age_enum = obj_age <= age_threshold_ ? LiveTrackerObjectVisual::ObjAge_E::NEW
                                                          : LiveTrackerObjectVisual::ObjAge_E::OLD;
            object_visual->setFramePosition(position);
            object_visual->setFrameOrientation(orientation);
            object_visual->setAge(obj_age_enum, visual_transparency_);
            object_visual->setMessage(object, use_shape_estimation_, use_object_yaw_, show_orientation_arrow_);
            object_visual->setObjectClassVisibility(show_object_class_, object_class_label_font_size_);
        }
    }

    // Remove visuals with ids that have expired
    for (uint16_t id_to_remove : current_ids)
    {
        id_visuals_map_.erase(id_to_remove);
    }
}

std::vector<uint16_t> LiveTrackerObjectListDisplay::getCurrentObjectIDs()
{
    std::vector<uint16_t> ids;
    for (auto it = id_visuals_map_.begin(); it != id_visuals_map_.end(); it++)
    {
        ids.push_back(it->first);
    }

    return ids;
}
} // namespace rviz_plugin_swc_live_addon

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(rviz_plugin_swc_live_addon::LiveTrackerObjectListDisplay, rviz_common::Display)