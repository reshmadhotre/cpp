#include "rviz_plugin_swc_live_addon/tracker_object_list/live_object_properties_panel.hpp"

namespace rviz_plugin_swc_live_addon
{
LiveObjectPropertiesPanel::LiveObjectPropertiesPanel(QWidget* parent) : Panel(parent)
{
    properties_widget_ = new LiveObjectPropertiesWidget(parent);
    QVBoxLayout* layout = new QVBoxLayout;
    layout->addWidget(properties_widget_);
    // layout->setContentsMargins(10, 10, 10, 10);
    setLayout(layout);
}

void LiveObjectPropertiesPanel::save(rviz_common::Config config) const
{
    Panel::save(config);
}

void LiveObjectPropertiesPanel::load(const rviz_common::Config& conf)
{
    Panel::load(conf);
}

void LiveObjectPropertiesPanel::onInitialize()
{
    auto node = getDisplayContext()->getRosNodeAbstraction().lock()->get_raw_node();
    object_data_subscriber_ = node->create_subscription<msg_live_addon::msg::MsgObjType>(
        "/topic_object_properties_panel", rclcpp::SystemDefaultsQoS(),
        std::bind(&LiveObjectPropertiesPanel::callback_object_data, this, std::placeholders::_1));
    clear_table_timer_ = node->create_wall_timer(std::chrono::milliseconds(500),
                                                 std::bind(&LiveObjectPropertiesPanel::onTimeOutCallback, this));
}

void LiveObjectPropertiesPanel::onTimeOutCallback()
{
    auto current_time = std::chrono::steady_clock::now();
    std::chrono::duration<float, std::milli> time_elapsed_secs = ((current_time - msg_receive_time_) / 1000.0);
    if (time_elapsed_secs.count() >= visual_decay_time_secs_)
    {
        properties_widget_->clearTableValues();
    }
}

void LiveObjectPropertiesPanel::callback_object_data(msg_live_addon::msg::MsgObjType::SharedPtr msg)
{
    msg_receive_time_ = std::chrono::steady_clock::now();
    properties_widget_->updateData(*msg.get());
}

} // namespace rviz_plugin_swc_live_addon

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(rviz_plugin_swc_live_addon::LiveObjectPropertiesPanel, rviz_common::Panel)