#include "rviz_plugin_swc_live_addon/tracker_object_list/live_object_properties_widget.hpp"

namespace rviz_plugin_swc_live_addon
{
LiveObjectPropertiesWidget::LiveObjectPropertiesWidget(QWidget* parent) : QWidget(parent)
{
    table_widget_ = new QTableWidget(this);

    table_widget_->setColumnCount(2);
    table_header_strings_ << "Property"
                          << "Value";
    table_widget_->setHorizontalHeaderLabels(table_header_strings_);
    table_widget_->setShowGrid(true);

    initTableWithEmptyData();

    QVBoxLayout* layout = new QVBoxLayout;
    layout->addWidget(table_widget_);
    setLayout(layout);
}

void LiveObjectPropertiesWidget::initTableWithEmptyData()
{
    msg_live_addon::msg::MsgObjType object;
    std::map<std::string, std::string> table_data = formatObjectDataAsTable(object);
    num_rows_ = table_data.size();
    table_widget_->setRowCount(num_rows_);

    int row_idx = 0;

    for (auto kv : table_data)
    {
        auto table_item_prop_name = new QTableWidgetItem(kv.first.c_str());
        table_item_prop_name->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);

        auto table_item_value = new QTableWidgetItem("");
        table_item_value->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);

        table_widget_->setItem(row_idx, 0, table_item_prop_name);
        table_widget_->setItem(row_idx, 1, table_item_value);

        row_idx++;
    }

    table_widget_->horizontalHeader()->setStretchLastSection(true);
    table_widget_->resizeColumnsToContents();
    table_widget_->resizeRowsToContents();
    table_widget_->setAlternatingRowColors(true);
}

void LiveObjectPropertiesWidget::updateData(const msg_live_addon::msg::MsgObjType& object)
{
    std::map<std::string, std::string> table_data = formatObjectDataAsTable(object);
    int row_idx = 0;

    for (auto kv : table_data)
    {
        table_widget_->item(row_idx, 1)->setText(kv.second.c_str());
        row_idx++;
    }
}

void LiveObjectPropertiesWidget::clearTableValues()
{
    int row_idx = 0;

    for (uint16_t row_idx = 0; row_idx < num_rows_; row_idx++)
    {
        table_widget_->item(row_idx, 1)->setText("");
    }
}

std::map<std::string, std::string> LiveObjectPropertiesWidget::formatObjectDataAsTable(
    const msg_live_addon::msg::MsgObjType& object)
{
    std::map<std::string, std::string> table_data;

    table_data.insert({"id", std::to_string(object.id)});
    table_data.insert({"confidence", std::to_string(object.confidence)});
    table_data.insert({"coor_rel_host.x", std::to_string(object.coor_rel_host.x)});
    table_data.insert({"coor_rel_host.y", std::to_string(object.coor_rel_host.y)});
    table_data.insert({"coor_rel_host.z", std::to_string(object.coor_rel_host.z)});
    table_data.insert({"v_rel_host.vx", std::to_string(object.v_rel_host.vx)});
    table_data.insert({"v_rel_host.vy", std::to_string(object.v_rel_host.vy)});
    table_data.insert({"a_rel_host.ax", std::to_string(object.a_rel_host.ax)});
    table_data.insert({"a_rel_host.ay", std::to_string(object.a_rel_host.ay)});
    table_data.insert({"yaw_rate", std::to_string(object.yaw_rate)});
    table_data.insert({"yaw_rate_std_de", std::to_string(object.yaw_rate_std_de)});
    table_data.insert({"yaw_ag", std::to_string(object.yaw_ag)});
    table_data.insert({"yaw_ag_std_de", std::to_string(object.yaw_ag_std_de)});
    table_data.insert({"age", std::to_string(object.age)});
    table_data.insert({"mtn_st", std::to_string(object.mtn_st)});
    table_data.insert({"obj_meas_st", std::to_string(object.obj_meas_st)});
    table_data.insert({"obj_classn", std::to_string(object.obj_classn)});
    table_data.insert({"obj_width", std::to_string(object.obj_width)});
    table_data.insert({"obj_width_std_de", std::to_string(object.obj_width_std_de)});
    table_data.insert({"obj_width_st", std::to_string(object.obj_width_st)});
    table_data.insert({"obj_len", std::to_string(object.obj_len)});
    table_data.insert({"obj_len_std_de", std::to_string(object.obj_len_std_de)});
    table_data.insert({"obj_len_st", std::to_string(object.obj_len_st)});
    table_data.insert({"std_de.x", std::to_string(object.std_de.x)});
    table_data.insert({"std_de.y", std::to_string(object.std_de.y)});
    table_data.insert({"std_de.z", std::to_string(object.std_de.z)});
    table_data.insert({"v_std_de.vx", std::to_string(object.v_std_de.vx)});
    table_data.insert({"v_std_de.vy", std::to_string(object.v_std_de.vy)});
    table_data.insert({"a_std_de.ax", std::to_string(object.a_std_de.ax)});
    table_data.insert({"a_std_de.ay", std::to_string(object.a_std_de.ay)});
    table_data.insert({"cov_xy", std::to_string(object.cov_xy)});
    table_data.insert({"cov_vxvy", std::to_string(object.cov_vxvy)});
    table_data.insert({"cov_axay", std::to_string(object.cov_axay)});
    table_data.insert({"asil_level", std::to_string(object.asil_level)});
    table_data.insert({"obj_rcs", std::to_string(object.obj_rcs)});
    table_data.insert({"over_under_drivability", std::to_string(object.over_under_drivability)});
    table_data.insert({"over_under_drivability_conf", std::to_string(object.over_under_drivability_conf)});
    table_data.insert({"ref_point", std::to_string(object.ref_point)});
    table_data.insert({"cluster_id", std::to_string(object.cluster_id)});
    table_data.insert({"ref_coor_rel_host.x", std::to_string(object.ref_coor_rel_host.x)});
    table_data.insert({"ref_coor_rel_host.y", std::to_string(object.ref_coor_rel_host.y)});
    table_data.insert({"ref_coor_rel_host.z", std::to_string(object.ref_coor_rel_host.z)});

    std::string obj_padding_bytes_str{""};

    for (const auto& byte : object.obj_padding_bytes)
    {
        obj_padding_bytes_str += std::to_string(byte) + " ";
    }
    table_data.insert({"obj_padding_bytes", obj_padding_bytes_str});

    return table_data;
}
} // namespace rviz_plugin_swc_live_addon