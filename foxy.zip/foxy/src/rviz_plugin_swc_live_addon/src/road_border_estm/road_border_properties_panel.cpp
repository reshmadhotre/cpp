#include "rviz_plugin_swc_live_addon/road_border_estm/road_border_properties_panel.hpp"

namespace rviz_plugin_swc_live_addon
{
RoadBorderPropertiesPanel::RoadBorderPropertiesPanel(QWidget* parent) : Panel(parent)
{
    properties_widget_ = new RoadBorderPropertiesWidget(parent);
    QVBoxLayout* layout = new QVBoxLayout;
    layout->addWidget(properties_widget_);
    // layout->setContentsMargins(10, 10, 10, 10);
    setLayout(layout);
}

void RoadBorderPropertiesPanel::save(rviz_common::Config config) const
{
    Panel::save(config);
}

void RoadBorderPropertiesPanel::load(const rviz_common::Config& conf)
{
    Panel::load(conf);
}

void RoadBorderPropertiesPanel::onInitialize()
{
    auto node = getDisplayContext()->getRosNodeAbstraction().lock()->get_raw_node();
    road_border_data_subscriber_ = node->create_subscription<msg_live_addon::msg::MsgRoadborderType>(
        "/topic_can_road_border_properties_panel", rclcpp::SystemDefaultsQoS(),
        std::bind(&RoadBorderPropertiesPanel::callback_road_border_data, this, std::placeholders::_1));
    clear_table_timer_ = node->create_wall_timer(std::chrono::milliseconds(500),
                                                 std::bind(&RoadBorderPropertiesPanel::onTimeOutCallback, this));
}

void RoadBorderPropertiesPanel::onTimeOutCallback()
{
    auto current_time = std::chrono::steady_clock::now();
    std::chrono::duration<float, std::milli> time_elapsed_secs = ((current_time - msg_receive_time_) / 1000.0);
    if (time_elapsed_secs.count() >= visual_decay_time_secs_)
    {
        properties_widget_->clearTableValues();
    }
}

void RoadBorderPropertiesPanel::callback_road_border_data(msg_live_addon::msg::MsgRoadborderType::SharedPtr msg)
{
    msg_receive_time_ = std::chrono::steady_clock::now();
    properties_widget_->updateData(*msg.get());
}

} // namespace rviz_plugin_swc_live_addon

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(rviz_plugin_swc_live_addon::RoadBorderPropertiesPanel, rviz_common::Panel)