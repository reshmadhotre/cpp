#include "rviz_plugin_swc_live_addon/road_border_estm/road_border_visual.hpp"
namespace rviz_plugin_swc_live_addon
{
RoadBorderVisual::RoadBorderVisual(Ogre::SceneManager* scene_manager, Ogre::SceneNode* parent_node)
{
    scene_manager_ = scene_manager;
    frame_node_ = parent_node->createChildSceneNode();
    createBillboardLine();
}

RoadBorderVisual::~RoadBorderVisual()
{
    destroyBillboardLine();
    scene_manager_->destroySceneNode(frame_node_);
}

void RoadBorderVisual::createBillboardLine()
{
    billboard_line_ = new rviz_rendering::BillboardLine(scene_manager_, frame_node_);
}

void RoadBorderVisual::destroyBillboardLine()
{
    if (billboard_line_)
    {
        delete billboard_line_;
        billboard_line_ = nullptr;
    }
}

void RoadBorderVisual::clearPoints()
{
    billboard_line_->clear();
}

void RoadBorderVisual::setFramePosition(const Ogre::Vector3& position)
{
    frame_node_->setPosition(position);
}

void RoadBorderVisual::setFrameOrientation(const Ogre::Quaternion& orientation)
{
    frame_node_->setOrientation(orientation);
}

void RoadBorderVisual::setLineWidth(float width)
{
    billboard_width_ = width;
}

bool RoadBorderVisual::validateFloats(const Ogre::Vector3& pos)
{
    bool valid{true};
    valid = valid && validateFloats(pos.x);
    valid = valid && validateFloats(pos.y);
    valid = valid && validateFloats(pos.z);

    return valid;
}

void RoadBorderVisual::setMessage(const msg_live_addon::msg::MsgSimpleClothoidType& simple_clothoid,
                                  uint8_t num_segements, const Ogre::ColourValue& line_colour)
{
    std::vector<Ogre::Vector3> positions = generateCartesianPositions(simple_clothoid, num_segements);

    billboard_line_->clear();
    billboard_line_->setNumLines(1);
    billboard_line_->setMaxPointsPerLine(num_segements);
    billboard_line_->setLineWidth(billboard_width_);

    for (const auto& pos : positions)
    {
        billboard_line_->addPoint(pos, line_colour);
    }
}

std::vector<Ogre::Vector3> RoadBorderVisual::generateCartesianPositions(
    const msg_live_addon::msg::MsgSimpleClothoidType& simple_clothoid, uint8_t num_segements)
{
    float offset_y = simple_clothoid.offset_y;
    float angle_tan = simple_clothoid.angle_tan;
    float c0 = simple_clothoid.c0;
    float c10 = simple_clothoid.c10;
    float range0 = simple_clothoid.range0;
    float range_max = simple_clothoid.range_max;

    float delta_x = (range_max - range0) / (num_segements - 1.0);

    std::vector<Ogre::Vector3> positions;

    for (size_t i = 0; i < num_segements; i++)
    {
        float x = range0 + (i * delta_x);
        float x_square = x * x;
        float x_cube = x_square * x;

        float y = offset_y + (angle_tan * x) + (c0 * x_square) + (c10 * x_cube);

        y = -1.0 * y; // Car frame of reference has positive y to the right, RVIZ has positive y to the left.

        Ogre::Vector3 pos(x, y, 0.0);
        if (validateFloats(pos))
        {
            positions.emplace_back(pos);
        }
    }

    return positions;
}

} // namespace rviz_plugin_swc_live_addon