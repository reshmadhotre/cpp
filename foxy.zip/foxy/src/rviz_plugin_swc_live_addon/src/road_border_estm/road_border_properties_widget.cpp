#include "rviz_plugin_swc_live_addon/road_border_estm/road_border_properties_widget.hpp"

namespace rviz_plugin_swc_live_addon
{
RoadBorderPropertiesWidget::RoadBorderPropertiesWidget(QWidget* parent) : QWidget(parent)
{
    table_widget_ = new QTableWidget(this);

    table_widget_->setColumnCount(2);
    table_header_strings_ << "Property"
                          << "Value";
    table_widget_->setHorizontalHeaderLabels(table_header_strings_);
    table_widget_->setShowGrid(true);

    initTableWithEmptyData();

    QVBoxLayout* layout = new QVBoxLayout;
    layout->addWidget(table_widget_);
    setLayout(layout);
}

void RoadBorderPropertiesWidget::initTableWithEmptyData()
{
    msg_live_addon::msg::MsgRoadborderType road_border_data;
    std::map<std::string, std::string> table_data = formatRoadBorderDataAsTable(road_border_data);
    num_rows_ = table_data.size();
    table_widget_->setRowCount(num_rows_);

    int row_idx = 0;

    for (auto kv : table_data)
    {
        auto table_item_prop_name = new QTableWidgetItem(kv.first.c_str());
        table_item_prop_name->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);

        auto table_item_value = new QTableWidgetItem("");
        table_item_value->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);

        table_widget_->setItem(row_idx, 0, table_item_prop_name);
        table_widget_->setItem(row_idx, 1, table_item_value);

        row_idx++;
    }

    table_widget_->horizontalHeader()->setStretchLastSection(true);
    table_widget_->resizeColumnsToContents();
    table_widget_->resizeRowsToContents();
    table_widget_->setAlternatingRowColors(true);
}

void RoadBorderPropertiesWidget::updateData(const msg_live_addon::msg::MsgRoadborderType& road_border_data)
{
    std::map<std::string, std::string> table_data = formatRoadBorderDataAsTable(road_border_data);
    int row_idx = 0;

    for (auto kv : table_data)
    {
        table_widget_->item(row_idx, 1)->setText(kv.second.c_str());
        row_idx++;
    }
}

void RoadBorderPropertiesWidget::clearTableValues()
{
    int row_idx = 0;

    for (uint16_t row_idx = 0; row_idx < num_rows_; row_idx++)
    {
        table_widget_->item(row_idx, 1)->setText("");
    }
}

std::map<std::string, std::string> RoadBorderPropertiesWidget::formatRoadBorderDataAsTable(
    const msg_live_addon::msg::MsgRoadborderType& road_border_data)
{
    std::map<std::string, std::string> table_data;

    // Left Simple Clothoid
    table_data.insert({"road_border_left.angle_tan", std::to_string(road_border_data.road_border_left.angle_tan)});
    table_data.insert({"road_border_left.c0", std::to_string(road_border_data.road_border_left.c0)});
    table_data.insert({"road_border_left.c10", std::to_string(road_border_data.road_border_left.c10)});
    table_data.insert({"road_border_left.c11", std::to_string(road_border_data.road_border_left.c11)});
    table_data.insert({"road_border_left.confidence", std::to_string(road_border_data.road_border_left.confidence)});
    table_data.insert({"road_border_left.offset_x", std::to_string(road_border_data.road_border_left.offset_x)});
    table_data.insert({"road_border_left.offset_y", std::to_string(road_border_data.road_border_left.offset_y)});
    table_data.insert({"road_border_left.range0", std::to_string(road_border_data.road_border_left.range0)});
    table_data.insert({"road_border_left.range_max", std::to_string(road_border_data.road_border_left.range_max)});
    table_data.insert({"road_border_left.status", std::to_string(road_border_data.road_border_left.status)});

    // Right Simple Clothoid
    table_data.insert({"road_border_right.c0", std::to_string(road_border_data.road_border_right.c0)});
    table_data.insert({"road_border_right.angle_tan", std::to_string(road_border_data.road_border_right.angle_tan)});
    table_data.insert({"road_border_right.c10", std::to_string(road_border_data.road_border_right.c10)});
    table_data.insert({"road_border_right.c11", std::to_string(road_border_data.road_border_right.c11)});
    table_data.insert({"road_border_right.confidence", std::to_string(road_border_data.road_border_right.confidence)});
    table_data.insert({"road_border_right.offset_x", std::to_string(road_border_data.road_border_right.offset_x)});
    table_data.insert({"road_border_right.offset_y", std::to_string(road_border_data.road_border_right.offset_y)});
    table_data.insert({"road_border_right.range0", std::to_string(road_border_data.road_border_right.range0)});
    table_data.insert({"road_border_right.range_max", std::to_string(road_border_data.road_border_right.range_max)});
    table_data.insert({"road_border_right.status", std::to_string(road_border_data.road_border_right.status)});

    return table_data;
}
} // namespace rviz_plugin_swc_live_addon