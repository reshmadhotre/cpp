#include "rviz_plugin_swc_live_addon/road_border_estm/road_border_display.hpp"

namespace rviz_plugin_swc_live_addon
{
RoadBorderDisplay::RoadBorderDisplay()
{
    keep_visualizations_ = true;
    keep_visualizations_property_ =
        new rviz_common::properties::BoolProperty("Keep Visualizations", keep_visualizations_,
                                                  "Keep Visualizations if no update received. Visualizations for this \
				display plugin are not cleared after set timeout and \
				persist until a new message is received.",
                                                  this, SLOT(updateKeepVisualizations()));

    line_width_property_ = new rviz_common::properties::FloatProperty(
        "Line Width", line_width_, "The width in metres of each road border line.", this, SLOT(updateLineWidth()));
    line_width_property_->setMin(0.05);
    line_width_property_->setMax(2.0);

    right_line_colour_property_ = new rviz_common::properties::ColorProperty("Right Line Colour", QColor(0, 255, 0),
                                                                             "Colour to draw the Right road border",
                                                                             this, SLOT(updateRightLineColour()));

    left_line_colour_property_ = new rviz_common::properties::ColorProperty("Left Line Colour", QColor(255, 0, 0),
                                                                            "Colour to draw the Left road border", this,
                                                                            SLOT(updateLeftLineColour()));

    num_segments_property_ = new rviz_common::properties::IntProperty(
        "Num Segments", num_segments_,
        "Number of Segments used to contruct the road border line from the simple clothoid parameters.", this,
        SLOT(updateNumSegments()));
    num_segments_property_->setMin(10);
    num_segments_property_->setMax(1000);
}

RoadBorderDisplay::~RoadBorderDisplay()
{
}

void RoadBorderDisplay::onInitialize()
{
    MFDClass::onInitialize();
    auto node = context_->getRosNodeAbstraction().lock()->get_raw_node();
    road_border_publisher_ = node->create_publisher<msg_live_addon::msg::MsgRoadborderType>(
        "/topic_can_road_border_properties_panel", rclcpp::SystemDefaultsQoS());
}

void RoadBorderDisplay::reset()
{
    MFDClass::reset();
    clearVisuals();
}

void RoadBorderDisplay::onEnable()
{
    MFDClass::onEnable();
    left_road_border_visual_ = std::make_shared<RoadBorderVisual>(context_->getSceneManager(), scene_node_);
    right_road_border_visual_ = std::make_shared<RoadBorderVisual>(context_->getSceneManager(), scene_node_);
}

void RoadBorderDisplay::onDisable()
{
    MFDClass::onDisable();
}

void RoadBorderDisplay::updateKeepVisualizations()
{
    keep_visualizations_ = keep_visualizations_property_->getBool();
}

void RoadBorderDisplay::updateLineWidth()
{
    line_width_ = line_width_property_->getFloat();
    left_road_border_visual_->setLineWidth(line_width_);
    right_road_border_visual_->setLineWidth(line_width_);
}

void RoadBorderDisplay::updateRightLineColour()
{
    right_road_border_colour_ = right_line_colour_property_->getOgreColor();
}

void RoadBorderDisplay::updateLeftLineColour()
{
    left_road_border_colour_ = left_line_colour_property_->getOgreColor();
}

void RoadBorderDisplay::updateNumSegments()
{
    num_segments_ = num_segments_property_->getInt();
}

void RoadBorderDisplay::clearVisuals()
{
    if (left_road_border_visual_)
    {
        left_road_border_visual_->clearPoints();
    }
    if (right_road_border_visual_)
    {
        right_road_border_visual_->clearPoints();
    }
    road_border_data_.reset();
}

// Update function used to clear visuals after a certain decay time.
void RoadBorderDisplay::update(float wall_dt, float ros_dt)
{
    if (!keep_visualizations_)
    {
        auto current_time = std::chrono::steady_clock::now();
        std::chrono::duration<float, std::milli> time_elapsed_secs = ((current_time - msg_receive_time_) / 1000.0);

        if (time_elapsed_secs.count() >= visual_decay_time_secs_)
        {
            clearVisuals();
        }
    }

    // Publish data to panel
    if (road_border_data_ != nullptr)
    {
        road_border_publisher_->publish(*road_border_data_.get());
    }
}

void RoadBorderDisplay::processMessage(const msg_live_addon::msg::MsgRoadborderType::ConstSharedPtr msg)
{
    msg_receive_time_ = std::chrono::steady_clock::now();

    Ogre::Quaternion orientation;
    Ogre::Vector3 position;
    if (!context_->getFrameManager()->getTransform(msg->header.frame_id, msg->header.stamp, position, orientation))
    {
        RCLCPP_INFO(rclcpp::get_logger("Tracker Object Data Display"),
                    "Error transforming from frame '%s' to frame '%s'", msg->header.frame_id.c_str(),
                    qPrintable(fixed_frame_));
        return;
    }

    left_road_border_visual_->setFramePosition(position);
    left_road_border_visual_->setFrameOrientation(orientation);
    left_road_border_visual_->setMessage(msg->road_border_left, num_segments_, left_road_border_colour_);

    right_road_border_visual_->setFramePosition(position);
    right_road_border_visual_->setFrameOrientation(orientation);
    right_road_border_visual_->setMessage(msg->road_border_right, num_segments_, right_road_border_colour_);

    road_border_data_ = std::make_shared<msg_live_addon::msg::MsgRoadborderType>(*msg.get());
}

} // namespace rviz_plugin_swc_live_addon

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(rviz_plugin_swc_live_addon::RoadBorderDisplay, rviz_common::Display)