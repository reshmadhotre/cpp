#include "rviz_plugin_swc_live_addon/can_object_list/can_object_properties_widget.hpp"

namespace rviz_plugin_swc_live_addon
{
CanObjectPropertiesWidget::CanObjectPropertiesWidget(QWidget* parent) : QWidget(parent)
{
    table_widget_ = new QTableWidget(this);

    table_widget_->setColumnCount(2);
    table_header_strings_ << "Property"
                          << "Value";
    table_widget_->setHorizontalHeaderLabels(table_header_strings_);
    table_widget_->setShowGrid(true);

    initTableWithEmptyData();

    QVBoxLayout* layout = new QVBoxLayout;
    layout->addWidget(table_widget_);
    setLayout(layout);
}

void CanObjectPropertiesWidget::initTableWithEmptyData()
{
    msg_live_addon::msg::MsgCanObjType object;
    std::map<std::string, std::string> table_data = formatObjectDataAsTable(object);
    num_rows_ = table_data.size();
    table_widget_->setRowCount(num_rows_);

    int row_idx = 0;

    for (auto kv : table_data)
    {
        auto table_item_prop_name = new QTableWidgetItem(kv.first.c_str());
        table_item_prop_name->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);

        auto table_item_value = new QTableWidgetItem("");
        table_item_value->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);

        table_widget_->setItem(row_idx, 0, table_item_prop_name);
        table_widget_->setItem(row_idx, 1, table_item_value);

        row_idx++;
    }

    table_widget_->horizontalHeader()->setStretchLastSection(true);
    table_widget_->resizeColumnsToContents();
    table_widget_->resizeRowsToContents();
    table_widget_->setAlternatingRowColors(true);
}

void CanObjectPropertiesWidget::updateData(const msg_live_addon::msg::MsgCanObjType& object)
{
    std::map<std::string, std::string> table_data = formatObjectDataAsTable(object);
    int row_idx = 0;

    for (auto kv : table_data)
    {
        table_widget_->item(row_idx, 1)->setText(kv.second.c_str());
        row_idx++;
    }
}

void CanObjectPropertiesWidget::clearTableValues()
{
    int row_idx = 0;

    for (uint16_t row_idx = 0; row_idx < num_rows_; row_idx++)
    {
        table_widget_->item(row_idx, 1)->setText("");
    }
}

std::map<std::string, std::string> CanObjectPropertiesWidget::formatObjectDataAsTable(
    const msg_live_addon::msg::MsgCanObjType& object)
{
    std::map<std::string, std::string> table_data;

    table_data.insert({"crc_obj_data", std::to_string(object.crc_obj_data)});
    table_data.insert({"mc_obj_data", std::to_string(object.mc_obj_data)});
    table_data.insert({"object_id", std::to_string(object.object_id)});
    table_data.insert({"object_fu_sa_level", std::to_string(object.object_fu_sa_level)});
    table_data.insert({"object_meas_status", std::to_string(object.object_meas_status)});
    table_data.insert({"object_confidence", std::to_string(object.object_confidence)});
    table_data.insert({"object_age", std::to_string(object.object_age)});
    table_data.insert({"object_motion_st", std::to_string(object.object_motion_st)});

    table_data.insert({"object_distance_x", std::to_string(object.object_distance_x)});
    table_data.insert({"object_distance_std_dev_x", std::to_string(object.object_distance_std_dev_x)});
    table_data.insert({"object_distance_y", std::to_string(object.object_distance_y)});
    table_data.insert({"object_distance_std_dev_y", std::to_string(object.object_distance_std_dev_y)});
    table_data.insert({"object_distance_cov_xy", std::to_string(object.object_distance_cov_xy)});

    table_data.insert({"object_rel_velocity_x", std::to_string(object.object_rel_velocity_x)});
    table_data.insert({"object_rel_velocity_std_dev_x", std::to_string(object.object_rel_velocity_std_dev_x)});
    table_data.insert({"object_rel_velocity_y", std::to_string(object.object_rel_velocity_y)});
    table_data.insert({"object_rel_velocity_std_dev_y", std::to_string(object.object_rel_velocity_std_dev_y)});
    table_data.insert({"object_rel_velocity_cov_xy", std::to_string(object.object_rel_velocity_cov_xy)});

    table_data.insert({"object_rel_acceleration_x", std::to_string(object.object_rel_acceleration_x)});
    table_data.insert({"object_rel_acceleration_std_dev_x", std::to_string(object.object_rel_acceleration_std_dev_x)});
    table_data.insert({"object_rel_acceleration_y", std::to_string(object.object_rel_acceleration_y)});
    table_data.insert({"object_rel_acceleration_std_dev_y", std::to_string(object.object_rel_acceleration_std_dev_y)});
    table_data.insert({"object_rel_acceleration_cov_xy", std::to_string(object.object_rel_acceleration_cov_xy)});

    table_data.insert({"object_ref_point", std::to_string(object.object_ref_point)});

    table_data.insert({"object_yaw_angle", std::to_string(object.object_yaw_angle)});
    table_data.insert({"object_yaw_angle_std_dev", std::to_string(object.object_yaw_angle_std_dev)});
    table_data.insert({"object_yaw_rate", std::to_string(object.object_yaw_rate)});
    table_data.insert({"object_yaw_rate_std_dev", std::to_string(object.object_yaw_rate_std_dev)});

    table_data.insert({"object_width", std::to_string(object.object_width)});
    table_data.insert({"object_width_std_dev", std::to_string(object.object_width_std_dev)});
    table_data.insert({"object_width_st", std::to_string(object.object_width_st)});

    table_data.insert({"object_length", std::to_string(object.object_length)});
    table_data.insert({"object_length_std_dev", std::to_string(object.object_length_std_dev)});
    table_data.insert({"object_length_st", std::to_string(object.object_length_st)});

    table_data.insert({"object_class", std::to_string(object.object_class)});
    table_data.insert({"object_class_confidence", std::to_string(object.object_class_confidence)});
    table_data.insert({"object_rcs", std::to_string(object.object_rcs)});
    table_data.insert({"object_over_under_drivable", std::to_string(object.object_over_under_drivable)});
    table_data.insert({"object_over_under_driveable_conf", std::to_string(object.object_over_under_driveable_conf)});
    table_data.insert({"scan_id", std::to_string(object.scan_id)});
    table_data.insert({"mac_object_data", std::to_string(object.mac_object_data)});

    return table_data;
}
} // namespace rviz_plugin_swc_live_addon