#include "rviz_plugin_swc_live_addon/object_selection_handler.hpp"

namespace rviz_plugin_swc_live_addon
{
ObjectSelectionHandler::ObjectSelectionHandler(rviz_common::DisplayContext* context) : SelectionHandler(context)
{
}

ObjectSelectionHandler::~ObjectSelectionHandler()
{
}

void ObjectSelectionHandler::onSelect(const rviz_common::interaction::Picked& obj)
{
    auto aabbs = getAABBs(obj);

    if (!aabbs.empty())
    {
        Ogre::AxisAlignedBox combined;
        for (const auto& aabb : aabbs)
        {
            combined.merge(aabb);
        }

        createBox(Handles(obj.handle, 0ULL), combined, "RVIZ/Cyan");
    }

    object_selected_ = true;
}

void ObjectSelectionHandler::onDeselect(const rviz_common::interaction::Picked& obj)
{
    destroyBox(Handles(obj.handle, 0ULL));

    object_selected_ = false;
}

bool ObjectSelectionHandler::isObjectSelected()
{
    return object_selected_;
}

} // namespace rviz_plugin_swc_live_addon