
#include "RosParams.h"

namespace ROS_PARAM_NAMES
{

const std::string RADAR_IP_ADDRESS{"radar_ip_address"};
const std::string RADAR_SCAN_RATE{"radar_scan_rate_micro_secs"};
const std::string RADAR_SCAN_LOOP{"radar_scan_loop_count"};
const std::string RADAR_SCAN_PRESET_1{"radar_scan_preset_1"};
const std::string RADAR_SCAN_PRESET_2{"radar_scan_preset_2"};
const std::string RADAR_ANTENNA_CONFIG_1{"radar_antenna_config_1"};
const std::string RADAR_ANTENNA_CONFIG_2{"radar_antenna_config_2"};
const std::string RADAR_DETN_THRESH_PRESET{"radar_detection_threshold_preset"};

const std::string SENSOR_MOUNT_POS_X_PARAM{"sensor_position_x"};
const std::string SENSOR_MOUNT_POS_Y_PARAM{"sensor_position_y"};
const std::string SENSOR_MOUNT_POS_Z_PARAM{"sensor_position_z"};
const std::string SENSOR_MOUNT_YAW_PARAM{"sensor_yaw"};
const std::string SENSOR_MOUNT_PITCH_PARAM{"sensor_pitch"};
const std::string SENSOR_MOUNT_ROLL_PARAM{"sensor_roll"};

} // namespace ROS_PARAM_NAMES