#include "UhdpClientLib.hpp"
#include <string.h>

UhdpClientLib::UhdpClientLib(RraCallbackFctPtr_t& callbacks,
                             RraProperties_t& properties)
{
  Callbacks = callbacks;
  Parameter = properties;
}

UhdpClientLib::~UhdpClientLib()
{
  if (uhdp_client_initialized_)
  {
    UhdpInterface.Stop();
    UhdpInterface.Disconnect();
  }
}

Result_t UhdpClientLib::Init()
{
  Result_t res = UhdpInterface.Init(Callbacks, &Parameter);
  if (res != ER_NOERROR)
  {
    return res;
  }

  uhdp_client_initialized_ = true;

  return ER_NOERROR;
}

Result_t UhdpClientLib::Connect()
{
  Result_t res = UhdpInterface.Connect();
  if (res != ER_NOERROR)
  {
    return res;
  }

  const char* srsVersion = UhdpInterface.GetSrsVersion();
  if (!srsVersion)
  {
    return ER_NO_CONNECTION;
  }

  const char* rraVersion = UhdpInterface.GetRraVersion();
  if (!rraVersion)
  {
    return ER_NO_CONNECTION;
  }

  return res;
}

Result_t UhdpClientLib::Disconnect() { return UhdpInterface.Disconnect(); }

Result_t UhdpClientLib::Start()
{
  timeval time;
  gettimeofday(&time, NULL);
  Result_t res = UhdpInterface.Start(time);
  if (res != ER_NOERROR)
  {
    return res;
  }

  return ER_NOERROR;
}

Result_t UhdpClientLib::Stop() { return UhdpInterface.Stop(); }

Result_t UhdpClientLib::Receive()
{
  Result_t res = UhdpInterface.Receive();
  return res;
}

Result_t UhdpClientLib::SendTelemetry(Telemetry_t& telemetry)
{
  return UhdpInterface.SendTelemetry(telemetry);
}

const char* UhdpClientLib::get_srs_version()
{
  return UhdpInterface.GetSrsVersion();
}

const char* UhdpClientLib::get_rra_version()
{
  return UhdpInterface.GetRraVersion();
}