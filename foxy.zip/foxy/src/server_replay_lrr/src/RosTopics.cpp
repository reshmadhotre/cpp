#include "RosTopics.h"

namespace ROS_PUBLISHER_TOPICS
{
const std::string TOPIC_LRR_DETECTION_LIST_UHDP = "topic_detection_list_uhdp";
const std::string TOPIC_LRR_POINT_CLOUD = "topic_point_cloud";
const std::string TOPIC_LRR_POINT_CLOUD_FLOAT = "topic_point_cloud_float";

} // namespace ROS_PUBLISHER_TOPICS

namespace ROS_SUBSCRIBER_TOPICS
{

const std::string TOPIC_LRR_TELEMETRY_UHDP =
    "/topic_lrr_telemetry_uhdp"; // Topic name has '/' to make it global. Irrespective of the namespace the node is
                                 // launched in, the topic is always /topic_telemetry_uhdp. Without a '/', the namespace
                                 // of the node would get appended. For eg., /foo/topic_telemetry_uhdp

} // namespace ROS_SUBSCRIBER_TOPICS
