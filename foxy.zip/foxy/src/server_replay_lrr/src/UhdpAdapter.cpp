#include "UhdpAdapter.h"
#include "RosTopics.h"

std::string UhdpAdapter::trigger_master_name_ = "server_replay_lrr";
std::string UhdpAdapter::node_namespace_ = "";
bool UhdpAdapter::scan_complete_ = false;
uint16_t UhdpAdapter::num_valid_detections_ = 0;
uint32_t UhdpAdapter::scan_sequence_number_ = 0;
std::shared_ptr<Magna2RosConverter> UhdpAdapter::magna_ros_converter_;
std::shared_ptr<ServerReplayLRR_Node> UhdpAdapter::lrr_uhdp_server_node_;
std::shared_ptr<UhdpClientLib> UhdpAdapter::uhdp_client_lib_;
std::shared_ptr<rclcpp::Node> UhdpAdapter::node_;

UhdpAdapter::UhdpAdapter(std::shared_ptr<rclcpp::Node> node)
{
    node_ = node;
    magna_ros_converter_ = std::make_shared<Magna2RosConverter>();
    GetNodeNamespace();
    InitSubscribers();
}

void UhdpAdapter::GetNodeNamespace()
{
    node_namespace_ = node_->get_namespace();
    if (node_namespace_.length() <= 1)
    {
        node_namespace_ = "/map";
    }
}

void UhdpAdapter::InitSubscribers()
{
    telemetry_subscriber_ = node_->create_subscription<server_replay_lrr::msg::MsgTelemetryUhdp>(
        ROS_SUBSCRIBER_TOPICS::TOPIC_LRR_TELEMETRY_UHDP, 1,
        std::bind(&UhdpAdapter::TelemetryCallback, this, std::placeholders::_1));
}

void UhdpAdapter::TelemetryCallback(server_replay_lrr::msg::MsgTelemetryUhdp::SharedPtr msg)
{
    rclcpp::Time msg_receive_time = node_->get_clock()->now();
    rclcpp::Time telemetry_meas_time = msg->meas_time; // This is the time when the measurement was taken.
    uint32_t meas_age_micro_secs =
        static_cast<uint32_t>((msg_receive_time.nanoseconds() - telemetry_meas_time.nanoseconds()) * 1e-3);
    RCLCPP_INFO(node_->get_logger(), "Received Telemetry with meas time : %lld",
                (long long)telemetry_meas_time.nanoseconds());

    RCLCPP_INFO(node_->get_logger(), "Sending telemetry with age : %f micro seconds", (float)meas_age_micro_secs);
    Telemetry_t telemetry;
    telemetry.age = meas_age_micro_secs;
    telemetry.vx = msg->vx;
    telemetry.vy = msg->vy;
    telemetry.vz = msg->vz;

    if (uhdp_client_lib_)
    {
        uhdp_client_lib_->SendTelemetry(telemetry);
    }
}

void UhdpAdapter::SetRadarUhdpServerNode(std::shared_ptr<ServerReplayLRR_Node> lrr_uhdp_server_node)
{
    lrr_uhdp_server_node_ = lrr_uhdp_server_node;
}

void UhdpAdapter::SetUhdpClientLib(std::shared_ptr<UhdpClientLib> uhdp_client_lib)
{
    uhdp_client_lib_ = uhdp_client_lib;
}

bool UhdpAdapter::ScanComplete()
{
    return scan_complete_;
}

int64_t UhdpAdapter::GetStreamTimeCbk()
{
    scan_complete_ = false;
    return 0;
}

Result_t UhdpAdapter::SetScanSynchTimeCbk()
{
    return 0;
}

Result_t UhdpAdapter::TransmitDataCbk(eProvidedDataID id, DataMemory_t mem)
{
    if (uhdp_client_lib_ && lrr_uhdp_server_node_)
    {
        if (id == PD_UhdpScanParameter)
        {
            std::shared_ptr<server_replay_lrr::msg::MsgScanParamUhdp> ros_scan_param_uhdp =
                std::make_shared<server_replay_lrr::msg::MsgScanParamUhdp>();
            UhdpScanParameter scan_param_uhdp = *((UhdpScanParameter*)(mem.pSrc));
            magna_ros_converter_->ConvertMessage(scan_param_uhdp, ros_scan_param_uhdp.get());
            num_valid_detections_ = ros_scan_param_uhdp->scan_info.num_detections;
            scan_sequence_number_ = ros_scan_param_uhdp->scan_info.scan_sequence_number;
        }

        else if (id == PD_DetnListUhdp)
        {
            std::shared_ptr<server_replay_lrr::msg::MsgDetectionListUhdp> ros_detection_data =
                std::make_shared<server_replay_lrr::msg::MsgDetectionListUhdp>();
            ros_detection_data->header.stamp = node_->get_clock()->now();
            ros_detection_data->header.frame_id = node_namespace_;

            MAGNA::DetectionData* detectionPtr = (MAGNA::DetectionData*)(mem.pSrc);
            magna_ros_converter_->ConvertMessage(detectionPtr, ros_detection_data.get(), num_valid_detections_,
                                                 scan_sequence_number_);
            lrr_uhdp_server_node_->SetMsgDetectionListUhdp(ros_detection_data);
        }

        else if (id == PD_PntCloudUhdp)
        {
            MAGNA::PointCloudData* pointCloudDataPtr = (MAGNA::PointCloudData*)(mem.pSrc);
            std::shared_ptr<server_replay_lrr::msg::MsgPointCloudUhdp> ros_point_cloud_uhdp =
                std::make_shared<server_replay_lrr::msg::MsgPointCloudUhdp>();
            magna_ros_converter_->ConvertMessage(pointCloudDataPtr, ros_point_cloud_uhdp.get());
            lrr_uhdp_server_node_->SetMsgPointCloudUhdp(ros_point_cloud_uhdp);
        }

        else if (id == PD_PntCloud)
        {
            PointCloudStatAllocType pointCloudStatAllocType = *((PointCloudStatAllocType*)(mem.pSrc));
            std::shared_ptr<server_replay_lrr::msg::MsgPointCloud> ros_point_cloud =
                std::make_shared<server_replay_lrr::msg::MsgPointCloud>();
            ros_point_cloud->header.stamp = node_->get_clock()->now();
            ros_point_cloud->header.frame_id = node_namespace_;
            magna_ros_converter_->ConvertMessage(pointCloudStatAllocType, ros_point_cloud.get());
            lrr_uhdp_server_node_->SetMsgPointCloud(ros_point_cloud);
        }

        else if (id == PD_ScanComplete)
        {
            scan_complete_ = true;
        }
    }

    return 0;
}

Result_t UhdpAdapter::TransmitDataChunkCbk(eProvidedDataID id, DataMemoryChunk_t mem)
{
    return 0;
}

Result_t UhdpAdapter::SetSignalRegistryValuesCbk(double sigValBuf[])
{
    return ER_NOERROR;
}