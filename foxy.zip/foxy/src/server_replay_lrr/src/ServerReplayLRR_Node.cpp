#include "ServerReplayLRR_Node.h"
#include "RosTopics.h"

ServerReplayLRR_Node::ServerReplayLRR_Node(std::shared_ptr<rclcpp::Node> node) : node_(node)
{
    frames_transform_util_ = std::make_shared<TfFramesTransformUtil>(node);
    static_broadcaster_ = std::make_shared<tf2_ros::StaticTransformBroadcaster>(node);

    InitPublishers();
    GetNodeNamespace();
    PublishStaticTransform();
}

void ServerReplayLRR_Node::PublishStaticTransform()
{
    geometry_msgs::msg::TransformStamped transform_stamped = frames_transform_util_->GetFrameTransform();
    static_broadcaster_->sendTransform(transform_stamped);
}

void ServerReplayLRR_Node::InitPublishers()
{
    using namespace ROS_PUBLISHER_TOPICS;
    detection_list_publisher_ =
        node_->create_publisher<server_replay_lrr::msg::MsgDetectionListUhdp>(TOPIC_LRR_DETECTION_LIST_UHDP, 1000);
    point_cloud_float_publisher_ =
        node_->create_publisher<server_replay_lrr::msg::MsgPointCloud>(TOPIC_LRR_POINT_CLOUD_FLOAT, 1000);
    point_cloud_uhdp_publisher_ =
        node_->create_publisher<server_replay_lrr::msg::MsgPointCloudUhdp>(TOPIC_LRR_POINT_CLOUD, 1000);
}

void ServerReplayLRR_Node::GetNodeNamespace()
{
    node_namespace_ = node_->get_namespace();
    if (node_namespace_.length() <= 1)
    {
        node_namespace_ = "/map";
    }
}

void ServerReplayLRR_Node::PublishData()
{
    if (ros_detection_data_ != nullptr)
    {
        detection_list_publisher_->publish(*ros_detection_data_.get());
    }

    if (ros_point_cloud_ != nullptr)
    {
        point_cloud_float_publisher_->publish(*ros_point_cloud_.get());
    }
    if (ros_point_cloud_uhdp_ != nullptr)
    {
        point_cloud_uhdp_publisher_->publish(*ros_point_cloud_uhdp_.get());
    }
}

void ServerReplayLRR_Node::SetMsgDetectionListUhdp(
    std::shared_ptr<server_replay_lrr::msg::MsgDetectionListUhdp> ros_detection_data)
{
    ros_detection_data_ = ros_detection_data;
}

void ServerReplayLRR_Node::SetMsgPointCloudUhdp(
    std::shared_ptr<server_replay_lrr::msg::MsgPointCloudUhdp> ros_point_cloud_uhdp)
{
    ros_point_cloud_uhdp_ = ros_point_cloud_uhdp;
}

void ServerReplayLRR_Node::SetMsgPointCloud(std::shared_ptr<server_replay_lrr::msg::MsgPointCloud> ros_point_cloud)
{
    ros_point_cloud_ = ros_point_cloud;
}
