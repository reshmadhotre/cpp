#include "RraPropertiesUtil.h"

RraPropertiesUtil::RraPropertiesUtil(std::shared_ptr<rclcpp::Node> node) noexcept : node_(node)
{
    ros_param_util_ = std::make_shared<RosParamUtil>(node_);
    InitRosParams();
}

void RraPropertiesUtil::InitRosParams()
{
    using namespace ROS_PARAM_NAMES;
    ros_param_util_->DeclareParameter(RADAR_IP_ADDRESS, DEFAULT_LRR_CONFIG.radar_ip_address);
    ros_param_util_->DeclareParameter(RADAR_SCAN_RATE, DEFAULT_LRR_CONFIG.scan_rate);
    ros_param_util_->DeclareParameter(RADAR_SCAN_LOOP, DEFAULT_LRR_CONFIG.scan_loop_count);
    ros_param_util_->DeclareParameter(RADAR_SCAN_PRESET_1, DEFAULT_LRR_CONFIG.scan_preset_1);
    ros_param_util_->DeclareParameter(RADAR_SCAN_PRESET_2, DEFAULT_LRR_CONFIG.scan_preset_2);
    ros_param_util_->DeclareParameter(RADAR_ANTENNA_CONFIG_1, DEFAULT_LRR_CONFIG.antenna_cfg_1);
    ros_param_util_->DeclareParameter(RADAR_ANTENNA_CONFIG_2, DEFAULT_LRR_CONFIG.antenna_cfg_2);
    ros_param_util_->DeclareParameter(RADAR_DETN_THRESH_PRESET, DEFAULT_LRR_CONFIG.detn_thresh_preset);
}
void RraPropertiesUtil::UpdateProperties(RraProperties_t& rra_properties)
{
    rra_properties.sBase.strServerIP = GetRadarIPAddress();
    rra_properties.sBase.nScanInterval = GetRadarScanRate();

    rra_properties.sScanCtrl.sCaptureControl.bEnableDetections = true;
    rra_properties.sScanCtrl.sCaptureControl.bEnablePointCloud = true;
    rra_properties.sScanCtrl.sCaptureControl.bEnableClutterImage = false;
    rra_properties.sScanCtrl.detThreshPreset = GetRadarDetectionThreshPreset();
    rra_properties.sScanCtrl.scanLoopCount = GetRadarScanLoopCount();

    rra_properties.sScanCtrl.radarType = RadarHwEnum::RH_FRR;

    rra_properties.sScanCtrl.scan[eScanNum::SCAN1] = GetRadarScanPreset1();

    rra_properties.sScanCtrl.antennaCfg_FRR[eScanNum::SCAN1] = GetAntennaCfg1();

    // Get SCAN2 parameters
    if (rra_properties.sScanCtrl.scanLoopCount == 2)
    {
        rra_properties.sScanCtrl.scan[eScanNum::SCAN2] = GetRadarScanPreset2();
        rra_properties.sScanCtrl.antennaCfg_FRR[eScanNum::SCAN2] = GetAntennaCfg2();
    }

    rra_properties.bSerializeScanObj = true;
    rra_properties.bUseDirectMemoryAccess = false;
    rra_properties.sFileLogger.bUhnderLog = false;
}

const char* const RraPropertiesUtil::GetRadarIPAddress() const noexcept
{
    static std::string radar_ip_address;
    radar_ip_address = ros_param_util_->GetParameter(ROS_PARAM_NAMES::RADAR_IP_ADDRESS).as_string();

    if (radar_ip_address.empty())
    {
        radar_ip_address = DEFAULT_LRR_CONFIG.radar_ip_address;
        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved Radar IP Address : %s."
                    "Setting to default : %s",
                    "", radar_ip_address.c_str());
    }

    return radar_ip_address.c_str();
}

uint32_t RraPropertiesUtil::GetRadarScanRate() const
{
    uint32_t scan_rate;
    try
    {
        scan_rate = static_cast<uint32_t>(ros_param_util_->GetParameter(ROS_PARAM_NAMES::RADAR_SCAN_RATE).as_int());
    }
    catch (const std::exception& e)
    {
        uint32_t default_scan_rate = DEFAULT_LRR_CONFIG.scan_rate;
        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved radar scan rate : %d invalid. Setting to default "
                    "value : %d",
                    scan_rate, default_scan_rate);
        scan_rate = default_scan_rate;
    }

    return scan_rate;
}

int RraPropertiesUtil::GetRadarScanLoopCount() const noexcept
{
    uint8_t scan_loop_count;
    try
    {
        scan_loop_count =
            static_cast<uint8_t>(ros_param_util_->GetParameter(ROS_PARAM_NAMES::RADAR_SCAN_LOOP).as_int());
        if (scan_loop_count != 1 && scan_loop_count != 2)
        {
            uint8_t default_scan_loop_count = DEFAULT_LRR_CONFIG.scan_loop_count;

            RCLCPP_WARN(node_->get_logger(),
                        "Retrieved Radar Scan Loop count : %d invalid!!!. Setting to "
                        "default value : %d",
                        scan_loop_count, default_scan_loop_count);
            scan_loop_count = default_scan_loop_count;
        }
    }

    catch (const std::exception& e)
    {
        uint8_t default_scan_loop_count = DEFAULT_LRR_CONFIG.scan_loop_count;

        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved Radar Scan Loop count : %d invalid!!!. Setting to "
                    "default value : %d",
                    scan_loop_count, default_scan_loop_count);
        scan_loop_count = default_scan_loop_count;
    }
    return scan_loop_count;
}

MAGNA::RDC_ScanPresetEnum RraPropertiesUtil::GetRadarScanPreset1() const noexcept
{
    std::string scan_preset;
    try
    {
        scan_preset = ros_param_util_->GetParameter(ROS_PARAM_NAMES::RADAR_SCAN_PRESET_1).as_string();
        return GetScanPresetEnum(scan_preset);
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        return GetScanPresetEnum(DEFAULT_LRR_CONFIG.scan_preset_1);
    }
}

MAGNA::RDC_ScanPresetEnum RraPropertiesUtil::GetRadarScanPreset2() const noexcept
{
    std::string scan_preset;
    try
    {
        scan_preset = ros_param_util_->GetParameter(ROS_PARAM_NAMES::RADAR_SCAN_PRESET_2).as_string();
        return GetScanPresetEnum(scan_preset);
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        return GetScanPresetEnum(DEFAULT_LRR_CONFIG.scan_preset_2);
    }
}

MagnaAntennaConfigEnum RraPropertiesUtil::GetAntennaCfg1() const noexcept
{
    std::string antenna_config;
    try
    {
        antenna_config = ros_param_util_->GetParameter(ROS_PARAM_NAMES::RADAR_ANTENNA_CONFIG_1).as_string();
        return GetAntennaConfigEnum(antenna_config);
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        return GetAntennaConfigEnum(DEFAULT_LRR_CONFIG.antenna_cfg_1);
    }
}

MagnaAntennaConfigEnum RraPropertiesUtil::GetAntennaCfg2() const noexcept
{
    std::string antenna_config;
    try
    {
        antenna_config = ros_param_util_->GetParameter(ROS_PARAM_NAMES::RADAR_ANTENNA_CONFIG_2).as_string();
        return GetAntennaConfigEnum(antenna_config);
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        return GetAntennaConfigEnum(DEFAULT_LRR_CONFIG.antenna_cfg_2);
    }
}

MAGNA::ThresholdPresetEnum RraPropertiesUtil::GetRadarDetectionThreshPreset() const noexcept
{
    std::string detn_thresh;
    try
    {
        detn_thresh = ros_param_util_->GetParameter(ROS_PARAM_NAMES::RADAR_DETN_THRESH_PRESET).as_string();
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        const std::string& default_detn_thresh_preset = DEFAULT_LRR_CONFIG.detn_thresh_preset;
        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved Radar Detection Threshold Preset: %s invalid!!. "
                    "Setting to default : %s",
                    detn_thresh.c_str(), default_detn_thresh_preset.c_str());
        detn_thresh = default_detn_thresh_preset;
    }

    auto iter = DETN_THRESH_PRESET_ENUM_MAP.find(detn_thresh);
    if (iter != DETN_THRESH_PRESET_ENUM_MAP.end())
    {
        return iter->second;
    }
    else
    {
        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved Radar Detection Threshold Preset: %s invalid!!. "
                    "Setting to default : %s",
                    detn_thresh.c_str(), DEFAULT_LRR_CONFIG.detn_thresh_preset.c_str());
        return DETN_THRESH_PRESET_ENUM_MAP.find(DEFAULT_LRR_CONFIG.detn_thresh_preset)->second;
    }
}

MAGNA::RDC_ScanPresetEnum RraPropertiesUtil::GetScanPresetEnum(const std::string& scan_preset_string) const noexcept
{
    auto iter = SCAN_PRESET_ENUM_MAP.find(scan_preset_string);

    if (iter != SCAN_PRESET_ENUM_MAP.end())
    {
        return iter->second;
    }

    else
    {
        std::string default_scan_preset = DEFAULT_LRR_CONFIG.scan_preset_1;
        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved Scan Preset: %s invalid!!. "
                    "Setting to default : %s",
                    scan_preset_string.c_str(), default_scan_preset.c_str());

        iter = SCAN_PRESET_ENUM_MAP.find(default_scan_preset);
        return iter->second;
    }
}

MagnaAntennaConfigEnum RraPropertiesUtil::GetAntennaConfigEnum(const std::string& frr_antenna_cfg_string) const noexcept
{
    auto iter = FRR_ANTENNA_CONFIG_ENUM_MAP.find(frr_antenna_cfg_string);
    if (iter != FRR_ANTENNA_CONFIG_ENUM_MAP.end())
    {
        return iter->second;
    }

    else
    {
        const std::string& default_frr_antenna_config = DEFAULT_LRR_CONFIG.antenna_cfg_1;

        RCLCPP_WARN(node_->get_logger(),
                    "Retrieved FRR Antenna Config: %s invalid!!. "
                    "Setting to default : %s",
                    frr_antenna_cfg_string.c_str(), default_frr_antenna_config.c_str());

        iter = FRR_ANTENNA_CONFIG_ENUM_MAP.find(default_frr_antenna_config);
        return iter->second;
    }
}
