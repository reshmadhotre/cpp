#include "RraPropertiesUtil.h"
#include "TfFramesTransformUtil.h"
#include "UhdpAdapter.h"
#include "UhdpClientLib.hpp"
#include "rclcpp/rclcpp.hpp"
#include <csignal>

std::shared_ptr<UhdpClientLib> UhdppClientLibPtr;
void sigint_handler(int sig_num)
{
    if (UhdppClientLibPtr != nullptr)
    {
        UhdppClientLibPtr->Disconnect();
        UhdppClientLibPtr->Stop();
        UhdppClientLibPtr.reset();
    }
    rclcpp::shutdown();

    exit(sig_num);
}

int main(int argc, char* argv[])
{
    std::signal(SIGINT, sigint_handler);
    rclcpp::InitOptions options = rclcpp::InitOptions();
    options.shutdown_on_sigint = false;
    rclcpp::init(argc, argv, options);

    auto node = std::make_shared<rclcpp::Node>("server_replay_lrr_node");

    auto uhdp_adapter = std::make_shared<UhdpAdapter>(node);
    auto lrr_uhdp_server_node = std::make_shared<ServerReplayLRR_Node>(node);
    uhdp_adapter->SetRadarUhdpServerNode(lrr_uhdp_server_node);

    auto rra_properties_util = std::make_shared<RraPropertiesUtil>(node);
    RraProperties_t rra_properties;
    rra_properties_util->UpdateProperties(rra_properties);

    RraCallbackFctPtr_t callbacks = {uhdp_adapter->GetStreamTimeCbk, uhdp_adapter->SetScanSynchTimeCbk,
                                     uhdp_adapter->TransmitDataCbk, uhdp_adapter->TransmitDataChunkCbk,
                                     uhdp_adapter->SetSignalRegistryValuesCbk};

    UhdppClientLibPtr = std::make_shared<UhdpClientLib>(callbacks, rra_properties);
    uhdp_adapter->SetUhdpClientLib(UhdppClientLibPtr);

    if (UhdppClientLibPtr->Init() != ER_NOERROR)
    {
        RCLCPP_ERROR(node->get_logger(), "Could not initialize connection to the Radar. "
                                         "Please connect the "
                                         "radar/simulator and relaunch the ros nodes!!!");
    }

    else
    {
        auto connect_result = UhdppClientLibPtr->Connect();
        if (connect_result != ER_NOERROR)
        {
            RCLCPP_ERROR(node->get_logger(), "Could not connect to the Radar. Please connect the "
                                             "radar/simulator "
                                             "and relaunch the ros nodes!!!");
            RCLCPP_ERROR(node->get_logger(), std::to_string(static_cast<int>(connect_result)).c_str());
        }
        else
        {
            RCLCPP_INFO(node->get_logger(), "Connected to the radar/simulator.");
            RCLCPP_INFO(node->get_logger(), "SRS version: %s", UhdppClientLibPtr->get_srs_version());
            RCLCPP_INFO(node->get_logger(), "RRA version: %s", UhdppClientLibPtr->get_rra_version());

            // Trigger Radar for first scan
            UhdppClientLibPtr->Start();
            UhdppClientLibPtr->Receive();
        }
    }

    rclcpp::Rate loop_rate(100); // 100Hz

    while (rclcpp::ok())
    {
        rclcpp::spin_some(node);

        if (uhdp_adapter->ScanComplete())
        {
            lrr_uhdp_server_node->PublishData();
            UhdppClientLibPtr->Receive();
        }
    }
    UhdppClientLibPtr->Disconnect();
    UhdppClientLibPtr->Stop();
    UhdppClientLibPtr.reset();
    rclcpp::shutdown();

    return 0;
}
