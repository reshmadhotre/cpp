#include "Magna2RosConverter.h"

// UhdpScanParameter Convert
void Magna2RosConverter::ConvertMessage(const UhdpScanParameter& scan_param_uhdp,
                                        server_replay_lrr::msg::MsgScanParamUhdp* ros_scan_param_uhdp) noexcept
{
    // Fill ScanInformation
    ros_scan_param_uhdp->scan_info.activation_filter_snr = scan_param_uhdp.scanInfo.activation_filter_snr;
    ros_scan_param_uhdp->scan_info.analog_die_temp_c = scan_param_uhdp.scanInfo.analog_die_temp_C;
    ros_scan_param_uhdp->scan_info.angle_wrap_flags = scan_param_uhdp.scanInfo.angle_wrap_flags;
    ros_scan_param_uhdp->scan_info.antenna_config_id = scan_param_uhdp.scanInfo.antenna_config_id;
    ros_scan_param_uhdp->scan_info.az_uniform_vrx = scan_param_uhdp.scanInfo.az_uniform_vrx;
    ros_scan_param_uhdp->scan_info.az_vrx_spacing_lambda = scan_param_uhdp.scanInfo.az_vrx_spacing_lambda;
    ros_scan_param_uhdp->scan_info.azimuth_nyquist_oversampling_factor =
        scan_param_uhdp.scanInfo.azimuth_nyquist_oversampling_factor;

    ros_scan_param_uhdp->scan_info.board_t3_temp_c = scan_param_uhdp.scanInfo.board_T3_temp_C;

    ros_scan_param_uhdp->scan_info.carrier_frequency = scan_param_uhdp.scanInfo.carrier_frequency;
    ros_scan_param_uhdp->scan_info.chip_temp_c = scan_param_uhdp.scanInfo.chip_temp_C;
    ros_scan_param_uhdp->scan_info.chip_time = scan_param_uhdp.scanInfo.chip_time;
    ros_scan_param_uhdp->scan_info.chips_per_pulse = scan_param_uhdp.scanInfo.chips_per_pulse;
    ros_scan_param_uhdp->scan_info.ci_bytes_per_pixel = scan_param_uhdp.scanInfo.CI_bytes_per_pixel;
    ros_scan_param_uhdp->scan_info.ci_doppler_height = scan_param_uhdp.scanInfo.CI_doppler_height;
    ros_scan_param_uhdp->scan_info.ci_doppler_width = scan_param_uhdp.scanInfo.CI_doppler_width;
    ros_scan_param_uhdp->scan_info.ci_format = scan_param_uhdp.scanInfo.CI_format;
    ros_scan_param_uhdp->scan_info.ci_height = scan_param_uhdp.scanInfo.CI_height;
    ros_scan_param_uhdp->scan_info.ci_pixel_size_in_meters = scan_param_uhdp.scanInfo.CI_pixel_size_in_meters;
    ros_scan_param_uhdp->scan_info.ci_width = scan_param_uhdp.scanInfo.CI_width;
    ros_scan_param_uhdp->scan_info.clock_tick_denominator = scan_param_uhdp.scanInfo.clock_tick_denominator;
    ros_scan_param_uhdp->scan_info.clock_tick_numerator = scan_param_uhdp.scanInfo.clock_tick_numerator;
    ros_scan_param_uhdp->scan_info.clutter_image_exponent = scan_param_uhdp.scanInfo.clutter_image_exponent;
    ros_scan_param_uhdp->scan_info.code_type = scan_param_uhdp.scanInfo.code_type;
    ros_scan_param_uhdp->scan_info.complex_rdc3 = scan_param_uhdp.scanInfo.complex_rdc3;
    ros_scan_param_uhdp->scan_info.connection_uhdp_version = scan_param_uhdp.scanInfo.connection_uhdp_version;
    ros_scan_param_uhdp->scan_info.current_time = scan_param_uhdp.scanInfo.current_time;

    // TODO{@ANURAG}
    // std::copy(std::begin(scan_param_uhdp.scanInfo.dc_bias),
    // std::end(scan_param_uhdp.scanInfo.dc_bias),
    //           std::begin(ros_scan_param_uhdp->scan_info.dc_bias));

    ros_scan_param_uhdp->scan_info.sensor_id = scan_param_uhdp.scanInfo.sensor_id;
    ros_scan_param_uhdp->scan_info.dop_rotator_shift = scan_param_uhdp.scanInfo.dop_rotator_shift;
    ros_scan_param_uhdp->scan_info.doppler_bin_width = scan_param_uhdp.scanInfo.doppler_bin_width;

    ros_scan_param_uhdp->scan_info.ego_angular_velocity_x = scan_param_uhdp.scanInfo.ego_angular_velocity_X;
    ros_scan_param_uhdp->scan_info.ego_angular_velocity_y = scan_param_uhdp.scanInfo.ego_angular_velocity_Y;
    ros_scan_param_uhdp->scan_info.ego_angular_velocity_z = scan_param_uhdp.scanInfo.ego_angular_velocity_Z;
    ros_scan_param_uhdp->scan_info.ego_linear_velocity_x = scan_param_uhdp.scanInfo.ego_linear_velocity_X;
    ros_scan_param_uhdp->scan_info.ego_linear_velocity_y = scan_param_uhdp.scanInfo.ego_linear_velocity_Y;
    ros_scan_param_uhdp->scan_info.ego_linear_velocity_z = scan_param_uhdp.scanInfo.ego_linear_velocity_Z;
    ros_scan_param_uhdp->scan_info.el_uniform_vrx = scan_param_uhdp.scanInfo.el_uniform_vrx;
    ros_scan_param_uhdp->scan_info.el_vrx_spacing_lambda = scan_param_uhdp.scanInfo.el_vrx_spacing_lambda;
    ros_scan_param_uhdp->scan_info.elevation_nyquist_oversampling_factor =
        scan_param_uhdp.scanInfo.elevation_nyquist_oversampling_factor;
    ros_scan_param_uhdp->scan_info.estimated_ego_flag = scan_param_uhdp.scanInfo.estimated_ego_flag;
    ros_scan_param_uhdp->scan_info.estimated_ego_velocity_x = scan_param_uhdp.scanInfo.estimated_ego_velocity_X;
    ros_scan_param_uhdp->scan_info.estimated_ego_velocity_y = scan_param_uhdp.scanInfo.estimated_ego_velocity_Y;
    ros_scan_param_uhdp->scan_info.estimated_ego_velocity_z = scan_param_uhdp.scanInfo.estimated_ego_velocity_Z;
    ros_scan_param_uhdp->scan_info.extrapolated_ego_velocity_x = scan_param_uhdp.scanInfo.extrapolated_ego_velocity_X;
    ros_scan_param_uhdp->scan_info.extrapolated_ego_velocity_y = scan_param_uhdp.scanInfo.extrapolated_ego_velocity_Y;
    ros_scan_param_uhdp->scan_info.extrapolated_ego_velocity_z = scan_param_uhdp.scanInfo.extrapolated_ego_velocity_Z;

    ros_scan_param_uhdp->scan_info.num_angle_noise_floor_groups = scan_param_uhdp.scanInfo.num_angle_noise_floor_groups;
    ros_scan_param_uhdp->scan_info.num_azimuth_angles = scan_param_uhdp.scanInfo.num_azimuth_angles;
    ros_scan_param_uhdp->scan_info.num_beamforming_angles = scan_param_uhdp.scanInfo.num_beamforming_angles;
    ros_scan_param_uhdp->scan_info.num_channelizer_doppler_bins = scan_param_uhdp.scanInfo.num_channelizer_doppler_bins;
    ros_scan_param_uhdp->scan_info.num_channelizer_iters = scan_param_uhdp.scanInfo.num_channelizer_iters;
    ros_scan_param_uhdp->scan_info.num_detections = scan_param_uhdp.scanInfo.num_detections;
    ros_scan_param_uhdp->scan_info.num_elevation_angles = scan_param_uhdp.scanInfo.num_elevation_angles;
    ros_scan_param_uhdp->scan_info.num_music_instances = scan_param_uhdp.scanInfo.num_music_instances;
    ros_scan_param_uhdp->scan_info.num_pulses = scan_param_uhdp.scanInfo.num_pulses;
    ros_scan_param_uhdp->scan_info.num_range_bins = scan_param_uhdp.scanInfo.num_range_bins;
    ros_scan_param_uhdp->scan_info.num_rd_above_cutoff = scan_param_uhdp.scanInfo.num_RD_above_cutoff;
    ros_scan_param_uhdp->scan_info.num_rd_lower = scan_param_uhdp.scanInfo.num_RD_lower;
    ros_scan_param_uhdp->scan_info.num_rd_upper = scan_param_uhdp.scanInfo.num_RD_upper;
    ros_scan_param_uhdp->scan_info.num_tx_prn = scan_param_uhdp.scanInfo.num_tx_prn;
    ros_scan_param_uhdp->scan_info.number_of_radars = scan_param_uhdp.scanInfo.number_of_radars;
    ros_scan_param_uhdp->scan_info.num_histograms = scan_param_uhdp.scanInfo.num_histograms;

    ros_scan_param_uhdp->scan_info.overflow_underflow_flags = scan_param_uhdp.scanInfo.overflow_underflow_flags;

    ros_scan_param_uhdp->scan_info.peak_detector_output = scan_param_uhdp.scanInfo.peak_detector_output;
    ros_scan_param_uhdp->scan_info.preset_applied = scan_param_uhdp.scanInfo.preset_applied;
    ros_scan_param_uhdp->scan_info.preset_diff_flags = scan_param_uhdp.scanInfo.preset_diff_flags;
    ros_scan_param_uhdp->scan_info.pulse_time = scan_param_uhdp.scanInfo.pulse_time;

    ros_scan_param_uhdp->scan_info.radar_status_bitmap = scan_param_uhdp.scanInfo.radar_status_bitmap;
    ros_scan_param_uhdp->scan_info.range_bin_start = scan_param_uhdp.scanInfo.range_bin_start;
    ros_scan_param_uhdp->scan_info.range_bin_width = scan_param_uhdp.scanInfo.range_bin_width;
    ros_scan_param_uhdp->scan_info.rb_combine = scan_param_uhdp.scanInfo.rb_combine;
    ros_scan_param_uhdp->scan_info.rdc1_full_scale_value = scan_param_uhdp.scanInfo.rdc1_full_scale_value;
    ros_scan_param_uhdp->scan_info.rdc1_software_exponent = scan_param_uhdp.scanInfo.rdc1_software_exponent;
    ros_scan_param_uhdp->scan_info.rdc2_full_scale_value = scan_param_uhdp.scanInfo.rdc2_full_scale_value;
    ros_scan_param_uhdp->scan_info.rdc2_software_exponent = scan_param_uhdp.scanInfo.rdc2_software_exponent;
    ros_scan_param_uhdp->scan_info.rdc2_zd_rb_center = scan_param_uhdp.scanInfo.rdc2_zd_rb_center;
    ros_scan_param_uhdp->scan_info.rdc2_zd_rb_halfwidth = scan_param_uhdp.scanInfo.rdc2_zd_rb_halfwidth;
    ros_scan_param_uhdp->scan_info.rdc2ch_full_scale_value = scan_param_uhdp.scanInfo.rdc2ch_full_scale_value;
    ros_scan_param_uhdp->scan_info.rdc3_full_scale_value = scan_param_uhdp.scanInfo.rdc3_full_scale_value;
    ros_scan_param_uhdp->scan_info.rdc3_software_exponent = scan_param_uhdp.scanInfo.rdc3_software_exponent;

    ros_scan_param_uhdp->scan_info.reserved_u16 = scan_param_uhdp.scanInfo.reserved_u16;
    std::copy(std::begin(scan_param_uhdp.scanInfo.reserved_u32), std::end(scan_param_uhdp.scanInfo.reserved_u32),
              std::begin(ros_scan_param_uhdp->scan_info.reserved_u32));

    ros_scan_param_uhdp->scan_info.sample_rate = scan_param_uhdp.scanInfo.sample_rate;
    ros_scan_param_uhdp->scan_info.scan_id_number = scan_param_uhdp.scanInfo.scan_ID_number;
    ros_scan_param_uhdp->scan_info.scan_loop_idx = scan_param_uhdp.scanInfo.scan_loop_idx;
    ros_scan_param_uhdp->scan_info.scan_loop_size = scan_param_uhdp.scanInfo.scan_loop_size;
    ros_scan_param_uhdp->scan_info.scan_sequence_number = scan_param_uhdp.scanInfo.scan_sequence_number;
    ros_scan_param_uhdp->scan_info.scan_time = scan_param_uhdp.scanInfo.scan_time;
    ros_scan_param_uhdp->scan_info.scan_timestamp = scan_param_uhdp.scanInfo.scan_timestamp;
    ros_scan_param_uhdp->scan_info.ss_doppler_0_only = scan_param_uhdp.scanInfo.ss_doppler_0_only;
    ros_scan_param_uhdp->scan_info.ss_size_a = scan_param_uhdp.scanInfo.SS_size_A;
    ros_scan_param_uhdp->scan_info.ss_size_d = scan_param_uhdp.scanInfo.SS_size_D;
    ros_scan_param_uhdp->scan_info.ss_size_r = scan_param_uhdp.scanInfo.SS_size_R;
    ros_scan_param_uhdp->scan_info.system_exponent = scan_param_uhdp.scanInfo.system_exponent;

    ros_scan_param_uhdp->scan_info.total_points = scan_param_uhdp.scanInfo.total_points;
    ros_scan_param_uhdp->scan_info.total_vrx = scan_param_uhdp.scanInfo.total_vrx;
    ros_scan_param_uhdp->scan_info.tx_power_map = scan_param_uhdp.scanInfo.tx_power_map;
    ros_scan_param_uhdp->scan_info.tx_prn_map = scan_param_uhdp.scanInfo.tx_prn_map;
    ros_scan_param_uhdp->scan_info.tx_prn_map_multi_roc = scan_param_uhdp.scanInfo.tx_prn_map_multi_roc;

    ros_scan_param_uhdp->scan_info.user_data = scan_param_uhdp.scanInfo.user_data;
    ros_scan_param_uhdp->scan_info.user_frame_delay_us = scan_param_uhdp.scanInfo.user_frame_delay_us;

    ros_scan_param_uhdp->scan_info.vrx_position_offset_x = scan_param_uhdp.scanInfo.vrx_position_offset_X;
    ros_scan_param_uhdp->scan_info.vrx_position_offset_y = scan_param_uhdp.scanInfo.vrx_position_offset_Y;
    ros_scan_param_uhdp->scan_info.vrx_position_offset_z = scan_param_uhdp.scanInfo.vrx_position_offset_Z;

    // Fill Angle Bins
    for (int i = 0; i < ros_scan_param_uhdp->angle_bins.size(); i++)
    {
        ros_scan_param_uhdp->angle_bins.at(i).angle_noise_floor_q8 =
            scan_param_uhdp.angleBins[0][i].angle_noise_floorQ8;
        ros_scan_param_uhdp->angle_bins.at(i).azimuth = scan_param_uhdp.angleBins[0][i].azimuth;
        ros_scan_param_uhdp->angle_bins.at(i).elevation = scan_param_uhdp.angleBins[0][i].elevation;
    }
}

// Detection Data Convert
void Magna2RosConverter::ConvertMessage(MAGNA::DetectionData* detection_data_ptr,
                                        server_replay_lrr::msg::MsgDetectionListUhdp* ros_detection_list,
                                        uint16_t num_valid_detections, uint32_t scan_sequence_number) noexcept
{
    if (detection_data_ptr != NULL_PTR)
    {
        ros_detection_list->num_valid_detections = num_valid_detections;
        ros_detection_list->scan_sequence_number = scan_sequence_number;

        for (uint16_t i = 0; i < num_valid_detections; i++)
        {
            ros_detection_list->list.at(i).range = detection_data_ptr[i].range;
            ros_detection_list->list.at(i).azimuth = detection_data_ptr[i].azimuth;
            ros_detection_list->list.at(i).elevation = detection_data_ptr[i].elevation;
            ros_detection_list->list.at(i).doppler = detection_data_ptr[i].doppler;
            ros_detection_list->list.at(i).magnitude = detection_data_ptr[i].magnitude;
            ros_detection_list->list.at(i).snr = detection_data_ptr[i].snr;
            ros_detection_list->list.at(i).rcs = detection_data_ptr[i].rcs;
            ros_detection_list->list.at(i).pos_x = detection_data_ptr[i].pos_x;
            ros_detection_list->list.at(i).pos_y = detection_data_ptr[i].pos_y;
            ros_detection_list->list.at(i).pos_z = detection_data_ptr[i].pos_z;
            ros_detection_list->list.at(i).flags = detection_data_ptr[i].flags;
        }
    }
}

// PointCloud Data convert
void Magna2RosConverter::ConvertMessage(const MAGNA::PointCloudData* point_cloud_data_ptr,
                                        server_replay_lrr::msg::MsgPointCloudUhdp* ros_point_cloud_uhdp) noexcept
{
    if (point_cloud_data_ptr != NULL_PTR)
    {
        for (int i = 0; i < ros_point_cloud_uhdp->point_cloud_array.size(); i++)
        {
            ros_point_cloud_uhdp->point_cloud_array.at(i).azimuth_fbin = point_cloud_data_ptr[i].azimuth_fbin;
            ros_point_cloud_uhdp->point_cloud_array.at(i).doppler_bin = point_cloud_data_ptr[i].doppler_bin;
            ros_point_cloud_uhdp->point_cloud_array.at(i).elevation_fbin = point_cloud_data_ptr[i].elevation_fbin;
            ros_point_cloud_uhdp->point_cloud_array.at(i).exponent = point_cloud_data_ptr[i].exponent;
            ros_point_cloud_uhdp->point_cloud_array.at(i).flags = point_cloud_data_ptr[i].flags;
            ros_point_cloud_uhdp->point_cloud_array.at(i).mag_i = point_cloud_data_ptr[i].mag_i;
            ros_point_cloud_uhdp->point_cloud_array.at(i).mag_q = point_cloud_data_ptr[i].mag_q;
            ros_point_cloud_uhdp->point_cloud_array.at(i).range = point_cloud_data_ptr[i].range;
            ros_point_cloud_uhdp->point_cloud_array.at(i).snr_db = point_cloud_data_ptr[i].snr_dB;
        }
    }
}

// ClutterImage Convert
void Magna2RosConverter::ConvertMessage(const ClutterImageListType& clutter_image_list,
                                        server_replay_lrr::msg::MsgClutterImgUhdp* ros_clutter_image_uhdp) noexcept
{

    ros_clutter_image_uhdp->bytes_per_pixel = clutter_image_list.BytesPerPixel;
    std::copy(std::begin(clutter_image_list.ClutImgArr), std::end(clutter_image_list.ClutImgArr),
              std::begin(ros_clutter_image_uhdp->clut_img_arr));
    ros_clutter_image_uhdp->depth = clutter_image_list.Depth;
    ros_clutter_image_uhdp->height = clutter_image_list.Height;
    ros_clutter_image_uhdp->pixel_size_in_meters = clutter_image_list.PixelSizeInMeters;
    ros_clutter_image_uhdp->scan_sequence_number = clutter_image_list.ScanSequenceNumber;
    ros_clutter_image_uhdp->width = clutter_image_list.Width;
}

// Point cloud float
void Magna2RosConverter::ConvertMessage(const PointCloudStatAllocType& point_cloud_static_alloc_type,
                                        server_replay_lrr::msg::MsgPointCloud* ros_point_cloud) noexcept
{
    ros_point_cloud->version = point_cloud_static_alloc_type.Version;
    ros_point_cloud->scan_sequence_num = point_cloud_static_alloc_type.ScanSequenceNum;
    ros_point_cloud->num_points = point_cloud_static_alloc_type.NumPoints;

    uint32 num_valid_points = point_cloud_static_alloc_type.NumPoints;

    for (uint32 i = 0; i < num_valid_points; i++)
    {
        ros_point_cloud->points.at(i).azimuth = point_cloud_static_alloc_type.Points[i].Azimuth;
        ros_point_cloud->points.at(i).cluster_id = point_cloud_static_alloc_type.Points[i].ClusterID;
        ros_point_cloud->points.at(i).doppler = point_cloud_static_alloc_type.Points[i].Doppler;
        ros_point_cloud->points.at(i).elevation = point_cloud_static_alloc_type.Points[i].Elevation;
        ros_point_cloud->points.at(i).flags = point_cloud_static_alloc_type.Points[i].Flags;
        ros_point_cloud->points.at(i).mag_i = point_cloud_static_alloc_type.Points[i].Mag_i;
        ros_point_cloud->points.at(i).mag_q = point_cloud_static_alloc_type.Points[i].Mag_q;
        ros_point_cloud->points.at(i).mag_snr = point_cloud_static_alloc_type.Points[i].Mag_snr;
        ros_point_cloud->points.at(i).range = point_cloud_static_alloc_type.Points[i].Range;
    }
}
