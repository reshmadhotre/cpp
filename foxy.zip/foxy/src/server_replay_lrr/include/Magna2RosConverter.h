#ifndef MAGNA_2_ROS_CONVERTER_H
#define MAGNA_2_ROS_CONVERTER_H

#include "PointCloudUtils.hpp"
#include "server_replay_lrr/msg/msg_clutter_img_uhdp.hpp"
#include "server_replay_lrr/msg/msg_detection_list_uhdp.hpp"
#include "server_replay_lrr/msg/msg_point_cloud.hpp"
#include "server_replay_lrr/msg/msg_point_cloud_uhdp.hpp"
#include "server_replay_lrr/msg/msg_radar_data_uhdp.hpp"
#include "server_replay_lrr/msg/msg_scan_param_uhdp.hpp"
#include "rdc-structs_stub.h"
#include "uhdp-msg-structs_stub.h"

class Magna2RosConverter final
{
  public:
    void ConvertMessage(const UhdpScanParameter& scan_param_uhdp,
                        server_replay_lrr::msg::MsgScanParamUhdp* ros_scan_param_uhdp) noexcept;
    void ConvertMessage(MAGNA::DetectionData* detection_data_ptr,
                        server_replay_lrr::msg::MsgDetectionListUhdp* ros_detection_list, uint16_t num_valid_detections,
                        uint32_t scan_sequence_number) noexcept;
    void ConvertMessage(const MAGNA::PointCloudData* point_cloud_data_ptr,
                        server_replay_lrr::msg::MsgPointCloudUhdp* ros_point_cloud_uhdp) noexcept;
    void ConvertMessage(const ClutterImageListType& clutter_image_list,
                        server_replay_lrr::msg::MsgClutterImgUhdp* ros_clutter_image_uhdp) noexcept;
    void ConvertMessage(const PointCloudStatAllocType& point_cloud_static_alloc_type,
                        server_replay_lrr::msg::MsgPointCloud* ros_point_cloud) noexcept;
};

#endif // MAGNA2_ROS_CONVERTER_H
