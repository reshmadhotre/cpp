#ifndef RRA_PROPERTIES_UTIL_H
#define RRA_PROPERTIES_UTIL_H

#include "RosParamUtil.hpp"
#include "RosParams.h"
#include "RraClientParameter.hpp"
#include "rclcpp/rclcpp.hpp"

static const struct default_radar_config
{
    std::string radar_ip_address{"127.0.0.1"};
    int scan_rate{0};
    int scan_loop_count{1};
    std::string detn_thresh_preset{"LOW_SENSITIVITY"};
    std::string scan_preset_1{"VP104"};
    std::string scan_preset_2{"VP104"};
    std::string antenna_cfg_1{"LowerTxAzimuth"};
    std::string antenna_cfg_2{"LowerTxAzimuth"};
} DEFAULT_LRR_CONFIG;

static const std::map<std::string, MAGNA::ThresholdPresetEnum> DETN_THRESH_PRESET_ENUM_MAP = {
    {"FRR_B1", MAGNA::ThresholdPresetEnum::FRR_B1},
    {"LOW_SENSITIVITY", MAGNA::ThresholdPresetEnum::LOW_SENSITIVITY},
    {"HIGH_SENSITIVITY", MAGNA::ThresholdPresetEnum::HIGH_SENSITIVITY},
    {"HIDT_HISLR", MAGNA::ThresholdPresetEnum::HIDT_HISLR},
    {"LODT_HISLR", MAGNA::ThresholdPresetEnum::LODT_HISLR},
    {"HIDT_LOSLR", MAGNA::ThresholdPresetEnum::HIDT_LOSLR},
    {"LODT_LOSLR", MAGNA::ThresholdPresetEnum::LODT_LOSLR},
};

static const std::map<std::string, MAGNA::RDC_ScanPresetEnum> SCAN_PRESET_ENUM_MAP = {
    {"VP104", MAGNA::RDC_ScanPresetEnum::VP104},     {"VP105", MAGNA::RDC_ScanPresetEnum::VP105},
    {"VP104HP", MAGNA::RDC_ScanPresetEnum::VP104HP}, {"VP105HP", MAGNA::RDC_ScanPresetEnum::VP105HP},
    {"VP150", MAGNA::RDC_ScanPresetEnum::VP150},     {"VP160", MAGNA::RDC_ScanPresetEnum::VP160},
    {"VP140N", MAGNA::RDC_ScanPresetEnum::VP140N},   {"VP141N", MAGNA::RDC_ScanPresetEnum::VP141N},
};

static const std::map<std::string, MagnaAntennaConfigEnum> FRR_ANTENNA_CONFIG_ENUM_MAP = {
    {"LowerTxAzimuth", MagnaAntennaConfigEnum::MAC_AZIMUTH},
    {"AllTxElevation", MagnaAntennaConfigEnum::MAC_ELEVATION},
    {"AllTxAzimuth", MagnaAntennaConfigEnum::MAC_AZIMUTH_12TX},
};

class RraPropertiesUtil final
{
  public:
    explicit RraPropertiesUtil(std::shared_ptr<rclcpp::Node> node) noexcept;
    void UpdateProperties(RraProperties_t& rra_properties);

  private:
    void InitRosParams();
    const char* const GetRadarIPAddress() const noexcept;
    uint32_t GetRadarScanRate() const;
    int GetRadarScanLoopCount() const noexcept;
    MAGNA::RDC_ScanPresetEnum GetRadarScanPreset1() const noexcept;
    MAGNA::RDC_ScanPresetEnum GetRadarScanPreset2() const noexcept;
    MagnaAntennaConfigEnum GetAntennaCfg1() const noexcept;
    MagnaAntennaConfigEnum GetAntennaCfg2() const noexcept;
    MAGNA::ThresholdPresetEnum GetRadarDetectionThreshPreset() const noexcept;

    void ReadROSParams();
    std::string GetROSParamValue(const std::string& ros_param) const;

    // Return Magna Type Enums
    MAGNA::RDC_ScanPresetEnum GetScanPresetEnum(const std::string& scan_preset_string) const noexcept;
    MagnaAntennaConfigEnum GetAntennaConfigEnum(const std::string& frr_antenna_cfg_string) const noexcept;

    std::shared_ptr<rclcpp::Node> node_;
    std::shared_ptr<RosParamUtil> ros_param_util_;
};

#endif // RRA_PROPERTIES_UTIL_H
