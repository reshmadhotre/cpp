//--------------------------------------------------------------------------
/// @file UhdpClientLib.hpp
/// @brief
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _UHDP_CLIENTLIB_HPP_
#define _UHDP_CLIENTLIB_HPP_

#ifdef __linux__
#include <sys/time.h>
#elif _WIN32
#include "TimerNTP.hpp"
#endif

#include "RraClientCallback.hpp"
#include "RraClientExportIntf.h"
#include "UhdpClientIntf.hpp"

class UhdpClientLib
{
public:
  explicit UhdpClientLib(RraCallbackFctPtr_t& callbacks,
                         RraProperties_t& properties);
  ~UhdpClientLib();

  Result_t Init();
  Result_t Connect();
  Result_t Disconnect();
  Result_t Start();
  Result_t Stop();
  Result_t Receive();
  Result_t SendTelemetry(Telemetry_t& telemetry);
  const char* get_srs_version();
  const char* get_rra_version();
  static bool CancelControl;

private:
  RraCallbackFctPtr_t Callbacks;
  RraProperties_t Parameter;
  cRraClientIntf UhdpInterface;
  bool uhdp_client_initialized_{false};
};

#endif //_UHDP_CLIENTLIB_HPP_
