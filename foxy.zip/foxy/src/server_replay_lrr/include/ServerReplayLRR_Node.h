#ifndef RADAR_UHDP_SERVER_NODE_H
#define RADAR_UHDP_SERVER_NODE_H

#include "TfFramesTransformUtil.h"
#include "server_replay_lrr/msg/msg_clutter_img_uhdp.hpp"
#include "server_replay_lrr/msg/msg_detection_list_uhdp.hpp"
#include "server_replay_lrr/msg/msg_point_cloud.hpp"
#include "server_replay_lrr/msg/msg_point_cloud_uhdp.hpp"
#include "server_replay_lrr/msg/msg_radar_data_uhdp.hpp"
#include "server_replay_lrr/msg/msg_scan_param_uhdp.hpp"
#include "server_replay_lrr/msg/msg_telemetry_uhdp.hpp"
#include "rclcpp/rclcpp.hpp"
#include <tf2_ros/static_transform_broadcaster.h>

class ServerReplayLRR_Node
{
  public:
    explicit ServerReplayLRR_Node(std::shared_ptr<rclcpp::Node> node);

    void SetMsgDetectionListUhdp(std::shared_ptr<server_replay_lrr::msg::MsgDetectionListUhdp> ros_detection_data);
    void SetMsgPointCloudUhdp(std::shared_ptr<server_replay_lrr::msg::MsgPointCloudUhdp> ros_point_cloud_uhdp);
    void SetMsgPointCloud(std::shared_ptr<server_replay_lrr::msg::MsgPointCloud> ros_point_cloud);

    void PublishData();

  private:
    void InitPublishers();
    void PublishStaticTransform();
    void GetNodeNamespace();

    bool scan_complete_{false};
    std::shared_ptr<rclcpp::Node> node_;
    std::string node_namespace_;
    std::shared_ptr<tf2_ros::StaticTransformBroadcaster> static_broadcaster_;
    std::shared_ptr<TfFramesTransformUtil> frames_transform_util_;

    std::shared_ptr<server_replay_lrr::msg::MsgDetectionListUhdp> ros_detection_data_;
    std::shared_ptr<server_replay_lrr::msg::MsgPointCloudUhdp> ros_point_cloud_uhdp_;
    std::shared_ptr<server_replay_lrr::msg::MsgPointCloud> ros_point_cloud_;

    // Publishers
    rclcpp::Publisher<server_replay_lrr::msg::MsgDetectionListUhdp>::SharedPtr detection_list_publisher_;
    rclcpp::Publisher<server_replay_lrr::msg::MsgPointCloud>::SharedPtr point_cloud_float_publisher_;
    rclcpp::Publisher<server_replay_lrr::msg::MsgPointCloudUhdp>::SharedPtr point_cloud_uhdp_publisher_;
};

#endif