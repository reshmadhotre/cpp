#ifndef _UHDP_ADAPTER_H_
#define _UHDP_ADAPTER_H_

#include "ServerReplayLRR_Node.h"
#include "Magna2RosConverter.h"
#include "UhdpClientLib.hpp"

class UhdpAdapter
{
  public:
    UhdpAdapter(std::shared_ptr<rclcpp::Node> node);

    static int64_t GetStreamTimeCbk();
    static Result_t SetScanSynchTimeCbk();
    static Result_t TransmitDataCbk(eProvidedDataID id, DataMemory_t mem);
    static Result_t TransmitDataChunkCbk(eProvidedDataID id, DataMemoryChunk_t mem);
    static Result_t SetSignalRegistryValuesCbk(double sigValBuf[]);

    static bool ScanComplete();

    void SetRadarUhdpServerNode(std::shared_ptr<ServerReplayLRR_Node> lrr_uhdp_server_node);
    void SetUhdpClientLib(std::shared_ptr<UhdpClientLib> uhdp_client_lib);

  private:
    void GetNodeNamespace();
    void InitSubscribers();
    void TelemetryCallback(server_replay_lrr::msg::MsgTelemetryUhdp::SharedPtr msg);

    static std::string node_namespace_;
    static std::string trigger_master_name_;
    static uint16_t num_valid_detections_;
    static uint32_t scan_sequence_number_;
    static std::shared_ptr<rclcpp::Node> node_;
    rclcpp::Subscription<server_replay_lrr::msg::MsgTelemetryUhdp>::SharedPtr telemetry_subscriber_;
    static std::shared_ptr<Magna2RosConverter> magna_ros_converter_;
    static std::shared_ptr<ServerReplayLRR_Node> lrr_uhdp_server_node_;
    static std::shared_ptr<UhdpClientLib> uhdp_client_lib_;
    static bool scan_complete_;
};
#endif