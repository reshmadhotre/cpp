#ifndef ROS_PARAMS_H
#define ROS_PARAMS_H

#include <string>

namespace ROS_PARAM_NAMES
{

extern const std::string RADAR_IP_ADDRESS;
extern const std::string RADAR_SCAN_RATE;
extern const std::string RADAR_SCAN_LOOP;
extern const std::string RADAR_SCAN_PRESET_1;
extern const std::string RADAR_SCAN_PRESET_2;
extern const std::string RADAR_ANTENNA_CONFIG_1;
extern const std::string RADAR_ANTENNA_CONFIG_2;
extern const std::string RADAR_DETN_THRESH_PRESET;

extern const std::string SENSOR_MOUNT_POS_X_PARAM;
extern const std::string SENSOR_MOUNT_POS_Y_PARAM;
extern const std::string SENSOR_MOUNT_POS_Z_PARAM;
extern const std::string SENSOR_MOUNT_YAW_PARAM;
extern const std::string SENSOR_MOUNT_PITCH_PARAM;
extern const std::string SENSOR_MOUNT_ROLL_PARAM;

} // namespace ROS_PARAM_NAMES
#endif