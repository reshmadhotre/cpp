#ifndef ROS_TOPICS_H
#define ROS_TOPICS_H

#include <string>

namespace ROS_PUBLISHER_TOPICS
{

extern const std::string TOPIC_LRR_DETECTION_LIST_UHDP;
extern const std::string TOPIC_LRR_POINT_CLOUD;
extern const std::string TOPIC_LRR_POINT_CLOUD_FLOAT;

} // namespace ROS_PUBLISHER_TOPICS

namespace ROS_SUBSCRIBER_TOPICS
{

extern const std::string TOPIC_LRR_TELEMETRY_UHDP;

} // namespace ROS_SUBSCRIBER_TOPICS
#endif