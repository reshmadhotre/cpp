#
# \file launch_server_replay_lrr.py
#
# \author Magna Electronics Europe GmbH & Co. OHG,
#         63877 Sailauf, Germany
#
# Copyright 2019 - 2021 Magna Electronics Europe GmbH & Co. OHG
# All rights exclusively reserved for Magna Electronics Europe GmbH & Co. OHG,
# unless expressly agreed to otherwise.

from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python import get_package_share_directory
import os


def generate_launch_description():

    radar_name = "radar_center"

    sensor_position_x = 3.0  # Radar mounting pos x in m
    sensor_position_y = 0.0  # Radar mounting pos y in m
    sensor_position_z = 0.0  # Radar mounting pos z in m
    sensor_pitch = 0.0       # Radar mounting pitch in deg
    sensor_roll = 0.0        # Radar mounting roll in deg
    sensor_yaw = 0.0         # Radar mounting yaw in deg

    lrr_node = Node(
        package="server_replay_lrr",
        executable="server_replay_lrr_node",
        name="server_replay_lrr_node",
        output="screen",
        namespace=radar_name,
        parameters=[
            {"radar_ip_address": "127.0.0.1"},
            {"radar_scan_rate_micro_secs": 60000},
            {"radar_scan_loop_count": 2},  # 1 | 2
            {"radar_scan_preset_1": "VP104"},  # VP104 | VP105 | VP104HP | VP105HP
            {"radar_scan_preset_2": "VP105"},  # SVP104 | VP105 | VP104HP | VP105HP

            # LOW_SENSITIVITY|HIGH_SENSITIVITY|HIDT_HISLR|HIDT_LOSLR|LODT_HISLR|FRR_B1
            {"radar_detection_threshold_preset": "LOW_SENSITIVITY"},

            {"radar_antenna_config_1": "LowerTxAzimuth"},  # LowerTxAzimuth | AllTxElevation | AllTxAzimuth
            {"radar_antenna_config_2": "AllTxElevation"},  # LowerTxAzimuth | AllTxElevation | AllTxAzimuth
            {"sensor_pitch": sensor_pitch},
            {"sensor_roll": sensor_roll},
            {"sensor_yaw": sensor_yaw},
            {"sensor_position_x": sensor_position_x},
            {"sensor_position_y": sensor_position_y},
            {"sensor_position_z": sensor_position_z},
        ]
    )

    can_to_telemetry_node = Node(
        package="can_to_telemetry",
        executable="can_to_telemetry_node",
        name="can_to_telemetry_node",
        output="screen",
        namespace=radar_name,
        parameters=[
            {"use_peak_can": False},
            {"can_device": "can0"},  # Only applicable when use_peak_can is set to False.
            {"dbc_filepath": "DBC_FILEPATH_HERE"},
            {"sensor_position_x": sensor_position_x},
            {"sensor_position_y": sensor_position_y},
            {"sensor_position_z": sensor_position_z},
            {"sensor_yaw": sensor_yaw},
        ]
    )

    return LaunchDescription([
        lrr_node,
        can_to_telemetry_node
    ])
