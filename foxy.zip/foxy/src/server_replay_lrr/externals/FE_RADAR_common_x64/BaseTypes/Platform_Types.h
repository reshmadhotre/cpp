/**
 *  \file Platform_Types.h
 *
 *  @author     Rony Liemmukda
 *  @date       Jan 18th, 2017
 *  @version    1.0
 *
 */


#ifndef PLATFORM_TYPES_H
#define PLATFORM_TYPES_H

#include <stdint.h>

#define PLATFORM_SW_MAJOR_VERSION   (1U)
#define PLATFORM_SW_MINOR_VERSION   (0U)
#define PLATFORM_SW_PATCH_VERSION   (0U)

#define PLATFORM_AR_MAJOR_VERSION       (4U)
#define PLATFORM_AR_MINOR_VERSION       (2U)
#define PLATFORM_AR_REVISION_VERSION    (2U)


#ifndef TRUE
    #define TRUE    (0x01U)
#endif

#ifndef FALSE
    #define FALSE   (0x00U)
#endif

/** \brief type definition for pointer to void */
typedef void * VoidPtr;
#ifndef VOID
typedef void 				VOID;       /*!< */
#endif

typedef unsigned char       uint8;      /*!< */
typedef unsigned short      uint16;     /*!< */


typedef unsigned int        uint32;     /*!< */

typedef unsigned long long  uint64;     /*!< */
typedef signed char         sint8;      /*!< */
typedef signed short        sint16;     /*!< */


typedef signed int          sint32;     /*!< */

typedef signed long long    sint64;     /*!< */

typedef float               float32;    /*!< */
typedef double              float64;    /*!< */

typedef uint8   uint8_least;    /*!< */
typedef uint16  uint16_least;   /*!< */
typedef uint32  uint32_least;   /*!< */

typedef sint8   sint8_least;    /*!< */
typedef sint16  sint16_least;   /*!< */
typedef sint32  sint32_least;   /*!< */

typedef uint8   boolean;        /*!< */


#define CPU_TYPE_8      (8U)        /*!< */
#define CPU_TYPE_16     (16U)       /*!< */
#define CPU_TYPE_32     (32U)       /*!< */

#define MSB_FIRST       (0U)        /*!< */
#define LSB_LAST        (1U)        /*!< */
    
#define HIGH_BYTE_FIRST (0U)        /*!< */
#define LOW_BYTE_FIRST  (1U)        /*!< */

/* r5f-core - little endian */
#define CPU_TYPE        CPU_TYPE_32     /*!< */
#define CPU_BIT_ORDER   LSB_FIRST       /*!< */
#define CPU_BYTE_ORDER  LOW_BYTE_FIRST  /*!< */


#if defined(_MSC_VER)
    #define __attribute__(arg)
#endif


#endif



