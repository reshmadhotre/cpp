/**
 *  \file Std_Types.h
 *
 *  @author     Rony Liemmukda
 *  @date       Jan 18th, 2017
 *  @version    1.0
 *
 */


#ifndef STD_TYPES_H
#define STD_TYPES_H

#include "Platform_Types.h"
#include "Compiler.h"

#define STD_TYPES_SW_MAJOR_VERSION   (1U)
#define STD_TYPES_SW_MINOR_VERSION   (0U)
#define STD_TYPES_SW_PATCH_VERSION   (0U)

#define STD_TYPES_AR_MAJOR_VERSION      (4U)
#define STD_TYPES_AR_MINOR_VERSION      (2U)
#define STD_TYPES_AR_REVISION_VERSION   (2U)


typedef uint8   Std_ReturnType; /*<! */

#ifndef E_OK
#ifdef __cpluspus
#define E_OK static_cast<Std_ReturnType>(0U)
#else
#define E_OK        ((Std_ReturnType) 0U)
#endif
#endif
#ifndef E_NOT_OK
#ifdef __cpluspus
#define E_NOT_OK static_cast<Std_ReturnType>(1U)
#else
#define E_NOT_OK    ((Std_ReturnType) 1U)
#endif
#endif
#ifndef STATUSTYPEDEFINED
#define STATUSTYPEDEFINED
typedef uint8   StatusType; /*!< */
#endif



#if ((!defined(E_NOT_VALID)) && (!defined(E_VALID)) )

#ifdef __cpluspus
#define E_NOT_VALID    (static_cast<Std_ReturnType>(2U))
#else
#define E_NOT_VALID    ((Std_ReturnType)(2U))
#endif
#ifdef __cpluspus
#define E_VALID (static_cast<Std_ReturnType>(3U))
#else
#define E_VALID ((Std_ReturnType)(3U))
#endif
#endif // !E_NOT_VALID && !E_VALID

/**
 *  \struct S_VER_INF
 *
 */
typedef struct  S_VER_INF {
    VAR( uint16, AUTOMATIC )    vendorID;   /*!< */
    VAR( uint16, AUTOMATIC )    moduleID;   /*!< */
    VAR( uint8, AUTOMATIC )     sw_major_version;   /*!< */
    VAR( uint8, AUTOMATIC )     sw_minor_version;   /*!< */
    VAR( uint8, AUTOMATIC )     sw_patch_version;   /*!< */
} Std_VersionInfoType;  /*!< S_VER_INF */


#ifndef STD_HIGH
    #define STD_HIGH    (0x01U) /*!< */
#endif

#ifndef STD_LOW
    #define STD_LOW     (0x00U) /*!< */
#endif


#ifndef STD_ACTIVE
    #define STD_ACTIVE  (0x01U) /*!< */
#endif

#ifndef STD_IDLE
    #define STD_IDLE    (0x00U) /*!< */
#endif


#ifndef STD_ON
    #define STD_ON      (0x01U) /*!< */
#endif

#ifndef STD_OFF
    #define STD_OFF     (0x00U) /*!< */
#endif





#endif




