/**
 *  \file   ME_Custom.h
 *
 *
 *  @date   Apr, 29th 2019
 *  @author Rony Liemmukda
 *  @version    1.0.0
 *
 *  Global definitions for the Elektrobit stack.<br/>
 *  As for memcpy: we differ not for M0(+) and R5(F). 
 *  For the 32-Bit cores our implementation is used, 
 *  for the 16-Bit cores the GHS implementation is used (for now).
 *
 *
 */


#ifndef ME_CUSTOM_H
#define ME_CUSTOM_H

#include <stdint.h>

#define COMPILERCFG_EXTENSION_FILE  (1U)        /*!< to include OUR INT_Compiler_Cfg.h */
#define COMPILERCFG_EXTENSION_MCAL_FILE (1U)    /*!< to replace the NULL_PTR macro */

#if (!defined(ATOMICS_USE_GENERIC_IMPL))
    #define ATOMICS_USE_GENERIC_IMPL    (1U)    
#endif

#define TS_ARCH_FAMILY      (31U)   /*!< EB -> TS_ARM */
#define TS_ARCH_DERIVATE            /*!< left empty on purpose */


#if defined(__cplusplus)
    extern "C" {
#endif

#include <string.h>

#define TS_MemCpy   memcpy

#define roundf(x) ((x < 0) ? (ceil((x)-0.5)) : (floor((x)+0.5)))
#define truncf(x) ((x > 0) ? floor(x) : ceil(x))



typedef unsigned int  os_uint32_t;    /*!< */

typedef os_uint32_t os_tick_t;

typedef struct os_timestamp_s os_timestamp_t;

struct os_timestamp_s {
#if MSB_FIRST == CPU_BIT_ORDER 
    /* Big Endian */   
    os_uint32_t tsHi;
    os_uint32_t tsLo;
#else
    os_uint32_t tsLo;
    os_uint32_t tsHi;
#endif
};

/**
 *
 * <code>OS_TimeGetHi()</code> returns the low word of a given timestamp value
 *
 */
#define OS_TimeGetLo( t ) \
    ((t).tsLo)

/**
 *
 * <code>OS_TimeGetHi()</code> returns the high word of a given timestamp value *
 *
 */
#define OS_TimeGetHi( t ) \
    ((t).tsHi)


#define OS_TimeSetLo(t,v)   do { (t).tsLo = (v); } while (0)
#define OS_TimeSetHi(t,v)   do { (t).tsHi = (v); } while (0)

#if defined(_MSC_VER)
#define inline __inline
#endif
/**
 *
 *  OS_TimeSub64() calculates the difference    (<code>newTime</code> - <code>oldTime</code>)
 *  (i.e. the duration of the interval that starts at
 *  <code>oldTime</code> and ends at <code>newTime</code>).
 *  The two input values are variables provided by
 *  the caller whose addresses are passed as parameters. The result is placed into
 *  the variable whose address is specified by the <code>diffTime</code>
 *  parameter. The caller must have permission to modify this variable.
 */
static inline void  OS_TimeSub64(
                        os_timestamp_t  *diffTime,
                        const os_timestamp_t *newTime,
                        const os_timestamp_t *oldTime
                    ) {

    (diffTime)->tsHi = (newTime)->tsHi - (oldTime)->tsHi;

    if ( (oldTime)->tsLo > (newTime)->tsLo ) {                               
        (diffTime)->tsHi -= 1;          
    } else {
        ;
    }
    (diffTime)->tsLo = (newTime)->tsLo - (oldTime)->tsLo;
}


/**
 *
 * Saturated 32-bit difference of two timestamps.
 *
 * This function calculates the 32-bit difference Of two timestamps.
 * If the result would not fit in a 32-bit value, the maximum 32-bit
 * value is returned.
 * 
 */
static inline   os_tick_t   OS_DiffTime32(
                                const os_timestamp_t *newTime, 
                                const os_timestamp_t *oldTime
                            ) {

    os_timestamp_t  diffTime;

    OS_TimeSub64(&diffTime, newTime, oldTime);

    if ( 0 != OS_TimeGetHi(diffTime) ) {
        OS_TimeSetLo(diffTime,0xffffffffu);
    } else {
        ;
    }

    return OS_TimeGetLo(diffTime);
}

extern  void    OS_GetTimeStamp( os_timestamp_t *t );

#if defined(__cplusplus)
    }   /* extern "C" */
#endif

#endif  /* ME_CUSTOM_H */


