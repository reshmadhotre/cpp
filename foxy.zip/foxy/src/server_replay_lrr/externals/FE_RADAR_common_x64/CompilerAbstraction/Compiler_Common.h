#if (!defined COMPILER_COMMON_H)
#define COMPILER_COMMON_H


/*==================[end of file]============================================*/
#endif /* if !defined( COMPILER_COMMON_H ) */
