//--------------------------------------------------------------------------
/// @file IDataProviderMidW_Uhdp.h
/// @brief Contains

/// IDataProviderXxx is an interface used by the algorithm to access Data.
/// The Interface declares functions to access the data which is actually needed
/// by the algorithm. Implementation is delegated to a DataProvider which is
/// component/module specific and belongs to the framework implementation.
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------

#ifndef IDATAADAPTERMIDW_H_
#define IDATAADAPTERMIDW_H_

#include "MediaSampleTypesMidw.h"
#include "rdc-structs_stub.h"


typedef uint8 Adtf_ScanVariantType;

struct Adtf_Velocity3DType
{
    float32 VX;
    float32 VY;
    float32 VZ;
} ;

struct Adtf_ScanInfoType
{
    uint32 ScanSequenceNumber;
    Adtf_ScanVariantType ScanVariant;
    uint32 ScanTimestamp;
    uint32 CurrentTime;
    uint8 ScanType;
    Adtf_Velocity3DType EgoRdr;
    Adtf_Velocity3DType EgoRdrEstimd;
};

struct Adtf_CoorPolarType
{
    float32 Range;
    float32 Azimuth;
    float32 Elevation;
};

struct Adtf_DetnHeaderType
{
    uint16 NumDetnStatic;
    uint16 NumDetnDynamic;
};

 struct Adtf_DetnType
{
    Adtf_CoorPolarType CoorPolar;
    float32 Doppler;
    float32 Magnitude;
    float32 SigToNoiseRat;
    float32 RdrCrossSectn;
    uint32 Flags;
    uint16 ClusterId;
};

typedef Adtf_DetnType Adtf_DetnArrType[1000];

typedef struct 
{
    Adtf_DetnHeaderType Header;
    Adtf_DetnArrType DetnArr;
} Adtf_DetnListType;


struct Adtf_MediaSampleDataGeneric
{
    uint32_t size;
    uint8_t* pData;
};


class IDataAdapter_UhdpMidw
{
public:

    IDataAdapter_UhdpMidw() {}
	
    //! The Function sets up the particular data type as it was designed
    //! in the respective middleware version.
    //!
    //! It returns a pointer to struct containing size and data buffer. 
    //! The pointer to this data buffer is valid for the life time of this
    //! instance. Data is valid untill the next scan is received. Pointer
    //! is NULL in case of an error.
    //!
    //! @param[in] i_scanInfo            scan info
    //! @param[in] i_version             interface version
    virtual Adtf_MediaSampleDataGeneric* GetVersionedScanInfo(
        const UhdpScanInformation& i_scanInfo, 
        const uint32_t i_version) = 0;
	
    //! The Function sets up the particular data type as it was designed
    //! in the respective middleware version.
    //!
    //! It returns a pointer to struct containing size and data buffer. 
    //! The pointer to this data buffer is valid for the life time of this
    //! instance. Data is valid untill the next scan is received. Pointer
    //! is NULL in case of an error.
    //!
    //! @param[in] i_detections         detection list
    //! @param[in] _version             interface version
	virtual const Adtf_MediaSampleDataGeneric* GetVersionedDetectionList(
        const Detections* i_detections, 
        const uint32_t i_version) = 0;

    //! The Function sets up the particular data type as it was designed
    //! in the respective middleware version.
    //!
    //! It returns a pointer to struct containing size and data buffer. 
    //! The pointer to this data buffer is valid for the life time of this
    //! instance. Data is valid untill the next scan is received. Pointer
    //! is NULL in case of an error.
    //!
    //! @param[in] i_points              point cloud
    //! @param[in] i_numPoints           number of points
    //! @param[in] i_version             interface version
    const Adtf_MediaSampleDataGeneric* GetVersionedPointList(
        const PointCloudData* i_points,
        const uint32_t i_numPoints,
        const uint32_t i_version);

};

#endif // IDATAADAPTERMIDW_H_
