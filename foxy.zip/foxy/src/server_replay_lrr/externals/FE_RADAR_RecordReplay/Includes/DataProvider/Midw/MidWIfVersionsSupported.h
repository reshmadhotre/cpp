//--------------------------------------------------------------------------
/// @file MidWIfVersionsSupported.h
/// @brief Contains

/// Contains supported interface versions
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------

#ifndef _IF_VERSIONSSUPPORTED_H_
#define _IF_VERSIONSSUPPORTED_H_

const uint32_t c_MidWIfVersion_000100 = 0x000100;  //!< version format: <Patch,Minor,Major> 
const uint32_t c_MidWIfVersion_000200 = 0x000200;  //!< version format: <Patch,Minor,Major> 
const uint32_t c_MidWIfVersion_000300 = 0x000300;  //!< version format: <Patch,Minor,Major> 
const uint32_t c_MidWIfVersion_000400 = 0x000400;  //!< version format: <Patch,Minor,Major> 

const int c_MidWScanInfoSize_000200 = 48;        //! size in bytes
const int c_MidWScanInfoSize_000300 = 44;        //! size in bytes
const int c_MidWScanInfoSize_000300_1ByteAligned = 38;  //! size in bytes

const int c_MidWDetnListSize_000200 = 48008;     //! size in bytes
const int c_MidWDetnListSize_000300 = 36004;     //! size in bytes
const int c_MidWDetnListSize_000300_1ByteAligned = 34004;  //! size in bytes

const int c_MidWClusterDataSize_000300 = 16004;  //! size in bytes
const int c_MidWClusterDataSize_000400 = 24004;  //! size in bytes
const int c_MidWClusterDataSize_000401 = 2404;   //! size in bytes

const int c_RemObjectListSize_000200 = 44016;    //! size in bytes
const int c_RemObjectListSize_000300 = 5388;     //! size in bytes
const int c_RemObjectListSize_000301 = 6156;     //! size in bytes
const int c_RemObjectListSize_000400 = 6668;     //! size in bytes

const uint32_t c_EmeIfVersion_000300 = 0x000300;  //!< version format: <Patch,Minor,Major> 

#endif // #ifndef MIDWIF_VERSIONSSUPPORTED_H_
