
#ifndef _MEDIA_SAMPLE_TYPES_MIDW_
#define _MEDIA_SAMPLE_TYPES_MIDW_

#ifdef CONST
#undef CONST // Compiler.h defines CONST for some reason which is also defined in windef.h
#endif
#include "Platform_Types.h"


struct Adtf_TimerValuesType
{
    uint32 Version;
    sint64 QPC_Time;
    uint64 NTP_Time;
    sint64 ADTF_Time;
    sint64 ADTF_StreamTime;
};


#if(!LEGACY_RTE_TYPE_COMPATIBILITY)

#ifndef ADTF_TYPE_MEEgoMtnEstimn_VDataType
#define ADTF_TYPE_MEEgoMtnEstimn_VDataType
struct Adtf_MEEgoMtnEstimn_VDataType
{
    uint32 Version;
    MEEgoMtnEstimn_VDataType MEEgoMtnEstimn_VData;
};
#endif

#ifndef RTE_TYPE_MEEgoMtnEstimn_VEstimnStType
#define RTE_TYPE_MEEgoMtnEstimn_VEstimnStType
typedef VAR(uint8, TYPEDEF) MEEgoMtnEstimn_VEstimnStType;
#endif

struct Adtf_MEEgoMtnEstimn_VEstimnStType
{
    uint32 Version;
    MEEgoMtnEstimn_VEstimnStType MEEgoMtnEstimn_VestimnStType;
};

#else

#ifndef RTE_TYPE_Gen_Velocity3DType
#define RTE_TYPE_Gen_Velocity3DType
typedef struct 
{
    float32 VX;
    float32 VY;
    float32 VZ;
} Gen_Velocity3DType;
#endif

#ifndef RTE_TYPE_MEEgoMtnEstimn_VDataType
#define RTE_TYPE_MEEgoMtnEstimn_VDataType
struct MEEgoMtnEstimn_VDataType
{
    Gen_Velocity3DType V;
    Gen_Velocity3DType VStdDe;
};
#endif

#ifndef ADTF_TYPE_MEEgoMtnEstimn_VDataType
#define ADTF_TYPE_MEEgoMtnEstimn_VDataType
struct Adtf_MEEgoMtnEstimn_VDataType
{
    uint32 Version;
    MEEgoMtnEstimn_VDataType MEEgoMtnEstimn_VData;
};
#endif

#ifndef RTE_TYPE_MEEgoMtnEstimn_VEstimnStType
#define RTE_TYPE_MEEgoMtnEstimn_VEstimnStType
typedef uint8 MEEgoMtnEstimn_VEstimnStType;
#endif

struct Adtf_MEEgoMtnEstimn_VEstimnStType
{
    uint32 Version;
    MEEgoMtnEstimn_VEstimnStType MEEgoMtnEstimn_VestimnStType;
};

#endif // #if(!INCLUDE_RTE_TYPE_COMPATIBILITY)

#endif // _MEDIA_SAMPLE_TYPES_
