// ---------------------------------------------------------------------------
/// @file IDataProviderMidW_Rte.h
/// @brief Contains

/// IDataProviderXxx is an interface used by the algorithm to access Data.
/// The Interface declares functions to access the data which is actually needed
/// by the algorithm. Implementation is delegated to a DataProvider which is
/// component/module specific and belongs to the framework implementation.
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------

#ifndef IDATAPROVIDER_EME_H_
#define IDATAPROVIDER_EME_H_

#include "MediaSampleTypesMidw.h"


#ifndef M_PI
#define M_PI        3.14159265358979323846264338327950288F
#endif

inline float DegToRad(float deg)
{
    return deg * M_PI / 180.0f;
}

class IDataProvider_Eme // : public IDataProvider
{
public:

    struct tPropertiesVehicleParams
    {
        float fRdrDistToRearAxle;
        float fSensorHeight;
        float fSensorLatDisp;
        float fSensorAzAngle;

        tPropertiesVehicleParams()
        {
            fRdrDistToRearAxle = 3.6f;
            fSensorHeight = 0.8f;
            fSensorLatDisp = 0.0f;
            fSensorAzAngle = 0.0f;
        }
    };

    IDataProvider_Eme() {}

    //! This setter function sets the vehicle parameter 
    //!
    //! @param[in] i_pVehPar          vehicle parameter
    virtual void SetVehicleParameter(tPropertiesVehicleParams const * const i_pVehPar) = 0;

    //! The Function sets up the designated data type as designed in the 
    //! latest middleware version.
    //!
    //! Returns a pointer to a data buffer with the latest data layout.
    //! The pointer to this data buffer is valid for the life time of this
    //! instance. It is NULL in case of an error. Data is valid until
    //! the next media sample is received.
    //!
    //! @param[in] i_pEmeVDataType  Ego Motion Estimation velocity data type
    //! @param[in] i_Size           size of received media sample in bytes
    virtual const Adtf_MEEgoMtnEstimn_VDataType* GetLatestEgoMtnEstimn(
        const Adtf_MEEgoMtnEstimn_VDataType* i_pEmeVData,
        const int i_Size) = 0;
};

#endif // IDATAPROVIDER_EME_H_
