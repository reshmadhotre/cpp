//--------------------------------------------------------------------------
/// @file UhdpClientIntf.hpp
/// @brief
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _UHDP_CLIENTINTF_HPP_
#define _UHDP_CLIENTINTF_HPP_

#include "RraClientCallback.hpp"
#include "RraClientCallbackFctPtr.h"
#include "RraClientParameter.hpp"


class cRraClientIntf : public IRraClientCallback
{
public:

    cRraClientIntf();

    cRraClientIntf(IRraClientCallback* pCbk, RraProperties_t& sSra);

    ~cRraClientIntf();

    Result_t Init(RraCallbackFctPtr_t& callbacks, RraProperties_t* properties = NULL);

    Result_t Connect();

    Result_t Start(timeval& baseTime);

    Result_t Stop();

    Result_t Disconnect();

    Result_t Receive();

    Result_t SendTelemetry(Telemetry_t& telemetry);

    const char* GetSrsVersion();

    const char* GetRraVersion();

    uint32_t GetNumAntennaConfigs();

    const char* GetAntennaConfigName(uint32_t antCfg_ID);

    const char* GetLogNameAndReset();

    void SetInterfaceVersion(const uint32_t version);

    virtual int64_t GetStreamTimeCbk(void) override;

    virtual Result_t SetScanSynchTimeCbk(void) override;

    virtual Result_t TransmitDataCbk(
        eProvidedDataID id, DataMemory_t mem) override;

    virtual Result_t TransmitDataChunkCbk(
        eProvidedDataID id, DataMemoryChunk_t mem) override;

private:
    std::string m_Version;
    RraCallbackFctPtr_t m_CbkFctPtr;
    RraProperties_t m_Properties;
    RraProperties_t* m_PropertiesPtr;

    struct UhdpIntf;
    UhdpIntf* m_UhdpIntf;
};

#endif

