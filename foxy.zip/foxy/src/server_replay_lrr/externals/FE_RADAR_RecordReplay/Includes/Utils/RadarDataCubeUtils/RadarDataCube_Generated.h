#ifndef __EGOVEHDATA_HEADER__
#define __EGOVEHDATA_HEADER__

#pragma pack(push, 4)
typedef struct
{
    tUInt32 Version;
    tFloat32 YawRate; // signal=ESP_A4.VehYawRate_Raw;
    tFloat32 VehSpeed; // signal=ESP_A8.VEH_SPEED;
    tUInt8 MotionState; // signal=TCM_A7.CurrentGear;
    tFloat32 WhlRpm_FL; // signal=ESP_A6.WhlRPM_FL;
    tFloat32 WhlRpm_FR; // signal=ESP_A6.WhlRPM_FR;
    tFloat32 WhlRpm_RL; // signal=ESP_A6.WhlRPM_RL;
    tFloat32 WhlRpm_RR; // signal=ESP_A6.WhlRPM_RR;
} o_EgoVehData;

#pragma pack(pop)

#endif // __EGOVEHDATA_HEADER__
