#ifndef __RADARDATACUBE_CFG_HEADER__
#define __RADARDATACUBE_CFG_HEADER__


#define USE_MAX_FOW_ANGLE (0)      ///< (1): enables restriction of field of view

#endif
