//--------------------------------------------------------------------------
/// @file ValueStatistic.hpp
/// @brief Utility class
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _CVALUESTATISTIC_HPP_
#define _CVALUESTATISTIC_HPP_

#include <list>
#include <limits>

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif


template<class T>
class cValueStatistic
{
    static_assert(std::is_arithmetic<T>::value, "T should be a arithmetic type!");
private:
    std::list<T> Values;
    T Min;
    T Max;
    T Sum;

public:
    cValueStatistic()
    {
        this->Reset();
    }

    ~cValueStatistic()
    {
    }

    void Reset()
    {
        Values.clear();
        Min = (std::numeric_limits<T>::max)();
        Max = (std::numeric_limits<T>::lowest)();  //Note: min() return wrong value for float
        Sum = 0;
    }

    void AddValue(const T& fValue)
    {
        Values.push_back(fValue);
        Min = min(Min, fValue);
        Max = max(Max, fValue);
        Sum += fValue;
    }

    int GetValueCount() const
    {
        return int(Values.size());
    }

    T GetLastValue() const
    {
        if (Values.size() == 0)
        {
            return (T)-1;
        }
        else
        {
            return Values.back();
        }
    }

    T GetMin() const
    {
        return Min;
    }

    T GetMax() const
    {
        return Max;
    }

    T GetSum() const
    {
        return Sum;
    }

    T GetAvg() const
    {
        if (Values.empty())
        {
            return 0;
        }
        return this->GetSum() / Values.size();
    }
};

#endif //_CVALUESTATISTIC_HPP_
