//--------------------------------------------------------------------------
/// @file ColorMisc.hpp
/// @brief Contains /todo
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef COORDINATETRANSFORMATION_HPP
#define COORDINATETRANSFORMATION_HPP

#include "SensorPositionTypes.hpp"
#include "stdint.h"


class cCoordinateTransformer
{

private:

    static const int ROW_COUNT = 3;
    static const int COLUMN_COUNT = 3;

    tSensorInformation m_sSensorInformation;

    double m_aRotationPitch[3][3];
    double m_aRotationRoll[3][3];
    double m_aRotationYaw[3][3];

    double m_p3d[3];

    cCoordinateTransformer()
    {
        this->Init(0.f, 0.f, 0.f, 0.f, 0.f, 0.f);
    }

    //#############################################################################
    cCoordinateTransformer(const tSensorInformation& sSensorInformation)
        : m_sSensorInformation(sSensorInformation)
    {
        //init
        this->Init(
            sSensorInformation.fPosX,
            sSensorInformation.fPosY,
            sSensorInformation.fPosZ,
            sSensorInformation.fRoll,
            sSensorInformation.fPitch,
            sSensorInformation.fHeading
        );
    }

    //#############################################################################
    bool HasTransformationImpact()
    {
        return (m_sSensorInformation.fPosX == 0.f)
            || (m_sSensorInformation.fPosY == 0.f)
            || (m_sSensorInformation.fPosZ == 0.f)
            || (m_sSensorInformation.fRoll == 0.f)
            || (m_sSensorInformation.fPitch == 0.f)
            || (m_sSensorInformation.fHeading == 0.f);
    }

    //#############################################################################
    tVoid Init(const double& fDx, const double& fDy, const double& fDz,
        const double& fRoll, const double& fPitch, const double& fHeading)
    {
        //rotation matrix pitch
        double R_pitch[3][3] = { { cos(fPitch),           0, sin(fPitch)},
                                  {          0,           1,          0},
                                  {-sin(fPitch),           0, cos(fPitch)} };
        std::copy(&R_pitch[0][0], &R_pitch[0][0] + 3 * 3, &m_aRotationPitch[0][0]);

        //rotation matrix roll
        double R_roll[3][3] = { {          1,           0,          0},
                                  {          0,   cos(fRoll), -sin(fRoll)},
                                  {          0,   sin(fRoll),  cos(fRoll)} };
        std::copy(&R_roll[0][0], &R_roll[0][0] + 3 * 3, &m_aRotationRoll[0][0]);

        //rotation matrix yaw
        double R_yaw[3][3] = { {   cos(fHeading),   -sin(fHeading),          0},
                                  {   sin(fHeading),    cos(fHeading),          0},
                                  {          0,           0,          1} };
        std::copy(&R_yaw[0][0], &R_yaw[0][0] + 3 * 3, &m_aRotationYaw[0][0]);
    }

    //#############################################################################
    tVoid RadarToUSK(const double& fRadarX, const double& fRadarY, const double& fRadarZ,
        double& fUskX, double& fUskY, double& fUskZ)
    {
        //init
        m_p3d[0] = 0;
        m_p3d[1] = 0;
        m_p3d[2] = 0;

        //rotate with R_roll
        for (int i = 0; i < 3; i++)
        {
            m_p3d[i] = fRadarX * m_aRotationRoll[i][0] + fRadarY * m_aRotationRoll[i][1] + fRadarZ * m_aRotationRoll[i][2];
        }
        fUskX = m_p3d[0];
        fUskY = m_p3d[1];
        fUskZ = m_p3d[2];

        //rotate with R_pitch
        for (int i = 0; i < 3; i++)
        {
            m_p3d[i] = fUskX * m_aRotationPitch[i][0] + fUskY * m_aRotationPitch[i][1] + fUskZ * m_aRotationPitch[i][2];
        }
        fUskX = m_p3d[0];
        fUskY = m_p3d[1];
        fUskZ = m_p3d[2];

        //rotate with R_yaw
        for (int i = 0; i < 3; i++)
        {
            m_p3d[i] = fUskX * m_aRotationYaw[i][0] + fUskY * m_aRotationYaw[i][1] + fUskZ * m_aRotationYaw[i][2];
        }
        fUskX = m_p3d[0];
        fUskY = m_p3d[1];
        fUskZ = m_p3d[2];

        //translate
        fUskX += m_sSensorInformation.fPosX;
        fUskY += m_sSensorInformation.fPosY;
        fUskZ += m_sSensorInformation.fPosZ;
    }
};

#endif
