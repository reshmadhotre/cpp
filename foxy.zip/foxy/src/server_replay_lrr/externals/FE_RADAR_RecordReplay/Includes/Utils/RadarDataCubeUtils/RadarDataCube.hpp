/// @file PointCloudUtils.hpp
/// @brief Interface to the module responsible for processing all relevant
/// input signals in order to provide the respective ego vehicle dynamic 
/// signal of sufficiant quality.
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.

#ifndef _RADARDATACUBE_HPP_
#define _RADARDATACUBE_HPP_

#include "RadarDataCubeTypes.h"
#include "RadarDataCubeParam.h"
#include "RadarDataCubeCfg.h"


//----------------------------------------------------------------------------
/// @class RadarDataCube
/// @brief Radar Data Cube utility class
/// 
/// 
//  --------------------------------------------------------------------------
class RadarDataCube
{
public:

    virtual ~RadarDataCube() {}

};

#endif
