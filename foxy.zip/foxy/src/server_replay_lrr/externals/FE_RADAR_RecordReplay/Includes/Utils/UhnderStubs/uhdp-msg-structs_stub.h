// Copyright (C) Uhnder, Inc. All rights reserved. Confidential and Proprietary - under NDA.
// Refer to SOFTWARE_LICENSE file for details
#ifndef SRS_HDR_UHDP_MSG_STRUCTS_STUB_H
#define SRS_HDR_UHDP_MSG_STRUCTS_STUB_H 1

#include "uhtypes_stub.h"


#if defined (RECORD_REPLAY)
namespace MAGNA
{
#endif /* RECORD_REPLAY */
    /*! priority level of each log message */
    enum LogLevelEnum
    {
        LL_PEDANTIC,  //! noise, usually filtered
        LL_DEBUG,     //! only enabled by developers
        LL_VERBOSE,   //! only enabled by testers, integrators
        LL_INFO,      //! informational details (normal operations, default)
        LL_WARN,      //! exceptional occurances
        LL_ERROR,     //! breakages great and small
        LL_ALWAYS,    //! never filtered
        LL_PROFILE,   //! used by profile events

        NUM_LOG_LEVELS
    };

    /* Mode tells the radar what logging mode to operate in */
    enum DataLogModeEnum
    {
        DL_NORMAL = 0,
        DL_INCIDENT = 1,  // No longer supported, will be deleted
        DL_IDLE = 2,
    };

    typedef struct /* UHDP_TYPE_SCAN_INFORMATION */
    {
        uint64_t   rdc1_full_scale_value;   //!< full scale value of RDC1 (all HW and SW exponents applied)
        uint64_t   rdc2_full_scale_value;   //!< full scale value of RDC2 (all HW and SW exponents applied)
        uint64_t   rdc2ch_full_scale_value; //!< full scale value of RDC2 channelizer outputs (all expts)
        uint64_t   rdc3_full_scale_value;   //!< full scale value of RDC3 (all HW and SW exponents applied)

        uint32_t   scan_sequence_number;    //!< UHDP sequence number (enumerates scans sent over UhDP)
        uint32_t   scan_ID_number;          //!< RHAL sequence number (enumerates scans run by the radar)

        /// hardware clock value at the time of scan end
        //
        /// For use by RRA internally to synchronize clocks and determine scan time
        /// with high accuracy. The units of this clock change from release to
        /// release and wraps at different values on different architectures.
        uint32_t   scan_timestamp;

        /// hardware clock value at the time this message was assembled
        //
        /// For use by RRA internally to synchronize clocks and determine scan time
        /// with high accuracy. The units of this clock change from release to
        /// release and wraps at different values on different architectures.
        uint32_t   current_time;

        /// The ego linear velocity estimated from RDC3 analysis. Only valid if
        /// estimated_ego_flag is 1 or 2. X component
        float      estimated_ego_velocity_X;
        float      estimated_ego_velocity_Y; //!< ego linear vel estimated from RDC3 analysis, Y component
        float      estimated_ego_velocity_Z; //!< ego linear vel estimated from RDC3 analysis, Z component

        /// The ego linear velocity extrapolated from INS measurements to the center
        /// of the scan dwell time. X component
        float      ego_linear_velocity_X;
        float      ego_linear_velocity_Y;   //!< Y component of extrapolated velocity
        float      ego_linear_velocity_Z;   //!< Z component of extrapolated velocity

        uint32_t   sensor_id;               //!< Always set to 0 by the radar, host software is allowed to modify
        float      scan_time;               //!< dwell time (length of scan) in seconds
        float      pulse_time;              //!< Pulse Repetition Interval time in seconds
        float      chip_time;               //!< chip time in seconds
        float      sample_rate;             //!< sample rate in Hz
        float      doppler_bin_width;       //!< doppler bin (RDC2 and RDC3) width in mps
        float      range_bin_width;         //!< range bin width in meters
        int32_t    chips_per_pulse;         //!< length of PRI in chips (LC)

        uint16_t   num_tx_prn;              //!< number of tx codes that were active in this scan
                                            //!< note: receiver count can be derived from total_vrx / num_tx_prn

        uint8_t    preset_applied;          //!< RDC_ScanPresetEnum value passed to set_defaults() or apply_preset()
        uint8_t    preset_diff_flags;       //!< bitmap of differences made to RDC_ScanDescriptor from preset or defaults
                                            //!< bit 0 = preset diffs, bit 1 = non-preset diffs

        int16_t    code_type;               //!< RDC_PeriodicCodeType of this scan
        uint16_t   total_vrx;               //!< VRX dimension of RDC1 and RDC2
                                            //!< note: receiver count can be derived from total_vrx / num_tx_prn

        uint16_t   num_range_bins;          //!< range dimension of RDC1, RDC2, and RDC3
        uint16_t   num_pulses;              //!< time dimension of RDC1 and doppler dimenson of RDC2 and RDC3

        uint16_t   num_channelizer_iters;   //!< number of channelizer iterations (See MUSIC)
        uint16_t   num_channelizer_doppler_bins; //!< num_pulses / num_channelizer_iters

        uint16_t   num_beamforming_angles;  //!< Total number of angle-bins including padding (ss2_num_angles)
                                            //!< angle dimension of RDC3 (static slice and activations)

        uint16_t   num_azimuth_angles;      //!< Number of in-use (valid) azimuth angles
                                            //!< Total in-use angles (num_angles) = num_azimuth_angles * num_elevation_angles

        /// Number of angle noise floor groups. Generally 1, but can be more
        /// than 1 in cases where CIU is pumped more than once with different
        /// range bin groups (nuking scans)
        uint8_t    num_angle_noise_floor_groups;
        uint8_t    azimuth_nyquist_oversampling_factor;
        uint8_t    elevation_nyquist_oversampling_factor;
        uint8_t    angle_wrap_flags;

        int16_t    rdc1_software_exponent;
        int16_t    rdc2_software_exponent;
        int16_t    rdc3_software_exponent;
        int16_t    system_exponent;

        uint16_t   overflow_underflow_flags;
        uint16_t   num_detections;          // number of output detections
        uint16_t   total_points;            // number of output point cloud points TBD
        uint16_t   num_music_instances;     // number of SVD and COV outputs

        uint16_t   SS_size_R;
        uint16_t   SS_size_A;
        uint16_t   SS_size_D;
        uint16_t   CI_width;
        uint16_t   CI_height;
        uint16_t   CI_format;
        uint16_t   CI_doppler_width;
        uint16_t   CI_doppler_height;
        uint16_t   CI_bytes_per_pixel;
        int16_t    clutter_image_exponent;
        float      CI_pixel_size_in_meters; //!< range scale of the polar clutter image (range_bin_width)

        float      chip_temp_C;             //!< PVT reported D-Die temperature in degrees C
        float      analog_die_temp_C;       //!< analog probe measured A-Die temperature in degrees C
        float      board_T3_temp_C;         //!< board temperature in degrees C, from MCU or I2C

        /// if zero doppler range bins were computed for this scan, this represents
        /// the center range bin of the computed ZD
        uint16_t   rdc2_zd_rb_center;

        /// if zero doppler range bins were computed for this scan, this represents
        /// the half with. The zero-doppler will have 2 * rdc2_zd_rb_halfwidth + 1
        /// range bins and total_vrx samples per range bin
        uint16_t   rdc2_zd_rb_halfwidth;

        /// The last DC bias correction made by DC microcal before this scan. Only
        /// the active receivers can have corrections.
        float     dc_bias[2][2][8];          // 1D, 2D. For all 8 RX

        /// RDC3 activations are filtered to achieve a maximum count, to clamp the
        /// detection computation load. This is the magnitude (dB) of lowest
        /// magnitude activation after filtering.
        float      activation_filter_snr;

        /// The current StateManager state mask at the time the scan was output by UhDP
        /// The bits are defined by enum SystemStateAttributes
        uint32_t   radar_status_bitmap;

        /// The antenna configuration selected for this scan. This identifier is
        /// specific to radars antenna module type. In other words, a Wanquan
        /// antenna config 0 is very different from a Changhua antenna config 0.
        /// The antenna config indirectly determines the number of VRX and all of
        /// the beamforming parameters
        uint32_t   antenna_config_id;

        /// Range bin combine ratio, this determines the number of chips included in
        /// each range bin. Range bin with is increased, range bin count is decreased
        uint8_t    rb_combine;

        /// RDC_rdc3_complex bits
        //
        /// bit 0 - RDC3_COMPLEX_SS  : the static slice is complex
        /// bit 1 - RDC3_COMPLEX_ACT : the activations are complex
        uint8_t    complex_rdc3;

        /// Only the center static slice bin was captured. When this is non-zero it
        /// indicates the captured static slice is a single doppler bin wide instead
        /// of SS_size_D.  SS_size_D always represents the size of the static slice
        /// on the radar (which is important when interpreting the doppler clutter
        /// image)
        uint8_t    ss_doppler_0_only;

        /// number of valid elevation angles, counterpart of num_azimuth_angles
        /// num_elevation_angles will be 1 for all 2DMIMO scans and greater than
        /// 1 for all 3DMIMO scans
        uint8_t    num_elevation_angles;

        /// offset added to every RX and TX position to center the virtual array
        /// around the origin of the coordinate system. X component
        float      vrx_position_offset_X;
        float      vrx_position_offset_Y; //!< Y component of vrx offset
        float      vrx_position_offset_Z; //!< Z component of vrx offset

        /// The carrier frequency at which the radar was operating during this scan's
        /// dwell time
        float      carrier_frequency;

        /// bitmap of which TX were powered on in HW12 order; 1 bit means ON
        uint16_t   tx_power_map;

        /// bitmap of which Local TX were assigned PRN codes, in HW12 order.
        /// 1 bit means ON
        uint16_t   tx_prn_map;

        /// If a TX peak detection was performed this scan, this is the output value
        float      peak_detector_output;

        /// If a doppler rotation (shift) was applied during the scan dwell, this is
        /// the amount of shift in meters per second
        float      dop_rotator_shift;

        /// The number of scans in the current frame loop (deterministic scan loop)
        /// Valid values are 1, 2, or 3. If scan loop size is 0, this scan was
        /// captured before this field was supported by SRS (0.7.5 or earlier)
        uint8_t    scan_loop_size;

        /// The index of this scan within the frame, it will have a value between
        /// 0 and scan_loop_size - 1.
        uint8_t    scan_loop_idx;

        /// The number of activations in the lower bucket prior to refiltering.
        /// The lower bucket threshold level is determined by a PID controller,
        /// which attempts to keep the lower bucket half-full of mostly noise
        uint16_t   num_RD_lower;

        /// On SabineB modules in latest releases, clock_tick_numerator and
        /// clock_tick_denominator map from hardware clocks to microseconds.
        /// us = float(clocks) * clock_tick_numerator / clock_tick_denominator
        uint16_t   clock_tick_numerator;

        /// On SabineB modules in latest releases, clock_tick_numerator and
        /// clock_tick_denominator map from hardware clocks to microseconds.
        /// us = float(clocks) * clock_tick_numerator / clock_tick_denominator
        uint16_t   clock_tick_denominator;

        /// The number of activations in the upper bucket prior to refiltering.
        /// The upper bucket has a fixed threshold of 25dB SNR
        uint16_t   num_RD_upper;

        /// The total number of activations after refiltering. See also
        /// activation_filter_snr
        uint16_t   num_RD_above_cutoff;

        /// The angular velocity at scan time, extrapolated from most recent external
        /// INS measurements. The angular velocity is not used by the radar to place
        /// the static slice or any other function.  It is passed through so that the
        /// user can use this value to interpolate between scans. X component
        float      ego_angular_velocity_X;
        float      ego_angular_velocity_Y; //!< Y component of angular velocity
        float      ego_angular_velocity_Z; //!< Z component of angular velocity

        /// ego linear velocity estimation status flag
        //
        /// value 1 or 2 indicates that the estimated_ego_velocity_XYZ fields are
        /// valid, that ego velocity was estimated from RDC3 analysis. If the
        /// estimated ego velocity is valid, then it might have been used to determine
        /// stationary detection status (RDC_DET_FLAG_STATIC), in lieu of the
        /// extrapolated ego velocity.
        ///
        /// value 0 indicates no estimation was attempted
        /// value 1 indicates a static slice histogram was used (OK)
        /// value 2 indicates RANSAC was used (OK)
        /// value 3 indicates RANSAC was attempted but did not converge
        /// value 4 indicates RANSAC could not be used for lack of detections
        uint8_t    estimated_ego_flag;

        /// The UhDP version that was negotiated with the host for this scan
        /// capture. Some data formats can change based on this version
        uint8_t    connection_uhdp_version;

        /// Number of radars that contributed transmitters to the count of virtual
        /// receivers.  Generally this will be 1.
        uint8_t    number_of_radars;

        /// Spatial distance, in range bins, of the first range bin in this scan.
        /// This offset has to be added to all hardware range bin based distances
        uint8_t    range_bin_start;

        /// The spacing of virtual receivers in the azimuth dimension, in units of
        /// lambda. This determines the field of view and steering angles.
        float      az_vrx_spacing_lambda;

        /// The spacing of virtual receivers in the elevation dimension, in units of
        /// lambda. This determines the field of view and steering angles.
        float      el_vrx_spacing_lambda;

        /// the number of virtual receivers with uniform spacing at the center of the
        /// virtual array, along the azimuth dimension. This determines the field of
        /// view and steering angles.
        uint16_t   az_uniform_vrx;

        /// the number of virtual receivers with uniform spacing at the center of the
        /// virtual array, along the elevation dimension. This determines the field of
        /// view and steering angles.
        uint16_t   el_uniform_vrx;

        /// The ego linear velocity used to determine the curve of the static slice,
        /// it is either extrapolated from previous INS measurements or extrapolated
        /// from previous internal measurements (RDC3 analysis).
        float      extrapolated_ego_velocity_X;
        float      extrapolated_ego_velocity_Y; //!< Y component
        float      extrapolated_ego_velocity_Z; //!< Z component

        /// Custom user_data copied from RDC_ScanDescriptor, to aid in the
        /// identification of the scan configuration that generated this scan
        /// Note: scan_loop_size and scan_loop_idx can also be used
        uint32_t   user_data;

        uint32_t   user_frame_delay_us;         //!< amount of time the scans in this frame were delayed for the
                                                //!< purposes of interference mitigation

        /// bitmap of which TX were assigned PRN codes, in HW48 order.
        /// 1 bit means ON
        uint64_t   tx_prn_map_multi_roc;

        uint16_t   num_histograms;              //!< number of HW DLCR histograms
        uint16_t   reserved_u16;

        uint32_t   reserved_u32[41];
        // Note!  This structure must be a multiple of 64 bits!

        // followed on the wire by:
        // * the currently active RDC_ThresholdControl
        // * uint8_t vrx_map[total_vrx];  map from HW RX major order to +Y spatial
        // * vec3f_t rx_pos[8];           physical position of receivers
        // * vec3f_t tx_pos[num_tx_prn];  physical position of transmitters
}  UhdpScanInformation;

typedef struct  /* UHDP_TYPE_ANGLE_BINS */
    {
        float   azimuth;
        float   elevation;
        int32_t angle_noise_floorQ8;
} UhdpAngleBinInfo; // [num_angle_groups][num_beamforming_angles];

    enum { MAX_ROUGH_ANGLES = 192 };

    enum { NUM_ANGLE_GROUPS = 1 };

    typedef UhdpAngleBinInfo UhdpAngleBinInfoArr[NUM_ANGLE_GROUPS][MAX_ROUGH_ANGLES];

#if defined (RECORD_REPLAY)
}
#endif /* RECORD_REPLAY */

// Output Pin: o_ScanParamUhdp 
#if defined(RECORD_REPLAY)
typedef struct
{
  MAGNA::UhdpScanInformation scanInfo;
  MAGNA::UhdpAngleBinInfoArr angleBins;
} UhdpScanParameter;
#else
typedef struct
{
  UhdpScanInformation scanInfo;
  UhdpAngleBinInfoArr angleBins;
} UhdpScanParameter;
#endif /* RECORD_REPLAY */


typedef int16_t fixed_point_t;

enum FIXED_POINT_FRACTIONAL_BITS {
    FIXED_POINT_FRACTIONAL_BITS_Q16,
    FIXED_POINT_FRACTIONAL_BITS_Q15,
    FIXED_POINT_FRACTIONAL_BITS_Q14,
    FIXED_POINT_FRACTIONAL_BITS_Q13,
    FIXED_POINT_FRACTIONAL_BITS_Q12,
    FIXED_POINT_FRACTIONAL_BITS_Q11,
    FIXED_POINT_FRACTIONAL_BITS_Q10,
    FIXED_POINT_FRACTIONAL_BITS_Q09,
    FIXED_POINT_FRACTIONAL_BITS_Q08,
    FIXED_POINT_FRACTIONAL_BITS_Q07,
    FIXED_POINT_FRACTIONAL_BITS_Q06,
    FIXED_POINT_FRACTIONAL_BITS_Q05,
    FIXED_POINT_FRACTIONAL_BITS_Q04,
    FIXED_POINT_FRACTIONAL_BITS_Q03,
    FIXED_POINT_FRACTIONAL_BITS_Q02,
    FIXED_POINT_FRACTIONAL_BITS_Q01,
};

#endif
