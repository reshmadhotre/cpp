#ifndef __RADARDATACUBE_PARAMETER_H__
#define __RADARDATACUBE_PARAMETER_H__

#include "MathMisc.hpp"
#include <stdint.h>


struct SensorMountingPosition_t
{
    float DistToRearAxle;
    float Height;
    float LatDisp;
    float AzAngle;

    SensorMountingPosition_t()
    {
        DistToRearAxle = 3.6f;
        Height = 0.8f;
        LatDisp = 0.0f;
        AzAngle = 0.0f;
    }
};

struct RdcParams_t
{
    bool bRemoveFlagged;

    RdcParams_t()
    {
        bRemoveFlagged = true;
    }
};

#endif
  