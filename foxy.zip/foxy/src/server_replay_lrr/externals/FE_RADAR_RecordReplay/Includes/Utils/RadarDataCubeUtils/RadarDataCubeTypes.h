#ifndef _RADARDATACUBE_TYPES_H_
#define _RADARDATACUBE_TYPES_H_

#ifdef CONST
#undef CONST // Compiler.h defines CONST for some reason which is also defined in windef.h
#endif
#include <stdint.h>
#include <vector>


struct Filter_t
{
    float fPosX1;
    float fPosX2;
    float fPosY1;
    float fPosY2;
    float fPosZ1;
    float fPosZ2;
    float fSnr1dSta;
    float fSnr1dDyn;
    float fSnr2dSta;
    float fSnr2dDyn;

    Filter_t()
    {
        fPosX1 = -320.0f;
        fPosX2 = 320.0f;
        fPosY1 = -320.0f;
        fPosY2 = 320.0f;
        fPosZ1 = 320.0f;
        fPosZ2 = -320.0f;
        fSnr1dSta = 0.0f;
        fSnr1dDyn = 1000.0f;
        fSnr2dSta = 1000.0f;
        fSnr2dDyn = 1000.0f;
    }
};

typedef struct {
    float X;
    float Y;
    float Z;
} Point_t;

struct Detection_t
{
    int64_t TimeStamp;
    float Azimuth;
    float Elevation;
    float Range;
    float Magnitude;
    float Doppler;
    float Rcs;
    float Velocity;
    float Snr;
    uint32_t Flags;
    uint16_t ClusterId;
    Point_t Point;
};

struct  DetectionList_t
{
    int LateralScale;
    uint32_t NumPoints;
    uint32_t NumVelAttr;
    Filter_t FilterEvent;
    std::vector<Detection_t> Detections;
};

#endif
