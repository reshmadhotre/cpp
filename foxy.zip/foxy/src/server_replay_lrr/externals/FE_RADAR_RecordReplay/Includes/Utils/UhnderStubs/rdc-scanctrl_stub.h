// Copyright (C) Uhnder, Inc. All rights reserved. Confidential and Proprietary - under NDA.
// Refer to SOFTWARE_LICENSE file for details
#ifndef SRS_HDR_RDC_SCAN_CTRL_STUB_H
#define SRS_HDR_RDC_SCAN_CTRL_STUB_H 1
#include "uhstdint_stub.h"

namespace MAGNA
{
    extern const CHAR* rdc_preset_descriptions[];

    enum RDC_ScanPresetEnum
    {
        VP101, // VP1a with 256 range bins
        VP201, // VP1a with 256 range bins, 2GHz Sampling rate
        VP102, // City
        VP202, // City, 2GHz Sampling rate
        VP103, // Highway
        VP203, // Highway, 2GHz Sampling rate
        VP104, // Highway-2
        VP105, // City-1
        VP211, // 1 Giga chip rate variable mode scan
        CP101, // CP1a with 256 range bins
        CP201, // CP1a with 256 range bins, 2GHz Sampling rate
        CP102, // CpCity
        CP202, // CpCity, 2GHz Sampling rate
        CP103, // Highway, CP Mode - cooked up scan, for first bringup using digital loopback
        CP203, // Highway, CP Mode - cooked up scan, for first bringup using digital loopback, 2GHz Sampling rate
        CP104, // Basic scan to run @ 1G Sampling rate
        CP210, // 1 Giga chip rate continuous power mode scan
        VP114, // Like VP101, but fewer pings
        VP114U, // Like VP114, but correlating all pings
        VP104N, // VP104 scan with nuking targets
        VP105N, // VP105 scan with nuking targets
        VP204, // Highway-2, 2GHz Sampling Rate
        VP205, // City-1, 2GHz Sampling Rate
        VP110,      //!< 1 GCPS 1 GSPS VP scan
        VP210,      //!< 2 GCPS 2 GSPS VP scan
        VP110T,     //!< Same as VP110, but with 10 instead of 44 correlated pings per PRI
        VP112,      //!< 1 GCPS 1 GSPS VP scan to see 80m
        IS101,      //!< Interference detection scan
        IS102,      //!< Interference detection scan with CIU correlation
        VP140N,     //!< MRR front-corner far range scan with nuking
        VP150,      //!< MRR front-corner short range scan
        VP141N,     //!< MRR front-center far range scan with nuking
        VP160,      //!< MRR front-center short range scan

        // Add new presets HERE ^^^^.
        // Whenever a new preset is added, the following steps should be taken to expose
        // the new preset throughout SRS and RRA:
        //      1. Add the preset to the strings table rdc_preset_descriptions[] in engine/scp-src/eng-api/string-tables.h
        //      2. Add the preset in RRA:  radar-remote-api/python/sip/rdc_scancontrol.sip
        VP104HP,
        VP105HP,

        NUM_PRESETS
    };

} // namespace MAG

#endif // SRS_HDR_RDC_SCAN_CTRL_STUB_H
