/// @file RadarDataCubeUtils.h
/// @brief This file provides cdecl interfaces to support portable shared
/// library build
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.

#ifndef _RADARDATACUBE_H_
#define _RADARDATACUBE_H_

#include "RadarDataCubeParam.h"
#include "Angles_FRR.h"


// Cdecl interface to facilitate portable shared library use
extern "C"
{

/// Returns a pointer to an instance of the respective utility class.
/// Use this function in case RdcParams_t don't have to be changed and
/// the angles defined in Angles_FRR.h shall be used.
///
class PointCloudUtils* GetPointCloudUtilsInst();

/// Returns a pointer to an instance of the respective utility class.
/// Use this function in case RdcParams_t have to be changed by user code
/// and the angles defined in Angles_FRR.h shall be used.
/// WARNING: Consumer needs to take care of deletion. 
///          TODO fix this, use smart pointer
///
/// @param[in] rdcPar             radar data cube parameter
///
class PointCloudUtils* GetPointCloudUtilsInst_P(const RdcParams_t& rdcParams);

/// Returns a pointer to an instance of the respective utility class.
/// Use this function in case RdcParams_t don't have to be changed and the
/// angles can be provided.
/// WARNING: Consumer needs to take care of deletion.
///          TODO fix this, use smart pointer
///
/// @param[in] rdcParams             radar data cube parameter
/// @param[in] angleBins             raw angles to translate from rdc domain
///
#if defined (RECORD_REPLAY)
class PointCloudUtils* GetPointCloudUtilsInst_A(
    const MAGNA::UhdpAngleBinInfoArr& angleBins);
#else
class PointCloudUtils* GetPointCloudUtilsInst_A(
        const UhdpAngleBinInfoArr& angleBins);
#endif

/// Returns a pointer to an instance of the respective utility class.
/// Use this function in case RdcParams_t have to be changed by user code
/// and the angles can be provided.
/// WARNING: Consumer needs to take care of deletion.
///          TODO fix this, use smart pointer
///
/// @param[in] rdcParams             radar data cube parameter
/// @param[in] angleBins             raw angles to translate from rdc domain
///
#if defined (RECORD_REPLAY)
class PointCloudUtils* GetPointCloudUtilsInst_PA(
    const RdcParams_t& rdcParams, 
    const MAGNA::UhdpAngleBinInfoArr& angleBins);
#else
class PointCloudUtils* GetPointCloudUtilsInst_PA(
    const RdcParams_t& rdcParams, 
    const UhdpAngleBinInfoArr& angleBins);
#endif
/// Returns a cstring describing the revision of the module
const char* GetEgoVehDynVersionStr();

}

#endif
