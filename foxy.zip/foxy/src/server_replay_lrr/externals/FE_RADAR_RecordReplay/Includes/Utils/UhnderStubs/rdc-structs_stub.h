// Copyright (C) Uhnder, Inc. All rights reserved. Confidential and Proprietary - under NDA.
// Refer to SOFTWARE_LICENSE file for details
#ifndef SRS_HDR_RDC_STRUCTS_STUB_H
#define SRS_HDR_RDC_STRUCTS_STUB_H 1

#include "uhtypes_stub.h"
#include <stdint.h>

#if defined(RECORD_REPLAY)
namespace MAGNA
{
#endif /* RECORD_REPLAY  */

    enum RDC_WindowType
    {
        WINDOW_BOXCAR,
        WINDOW_HANN,
        WINDOW_HAMMING,
        WINDOW_GAUSS,
        WINDOW_BLACKMAN,
        WINDOW_BLACKMAN_NUTTALL,
        WINDOW_BLACKMAN_HARRIS,
        WINDOW_CHEBYSHEV_30,
        WINDOW_REMEZ,
        WINDOW_TAYLOR_30,
        WINDOW_CHEBYSHEV_45,
        WINDOW_CHEBYSHEV_60,
        WINDOW_TAYLOR_55,

        // Beamforming-only window options
        WINDOW_SVA,
        MAX_WINDOW_TYPE
    };

    enum RDC_clutter_image_format
    {
        // Format:  M#[CP]{H#[CP]}{D#[CP]}
        // #: Number of bits
        // M: Magnitude
        // H: Height image
        // D: Doppler image
        // C: Cartesian (x,y)
        // Z: Cartesian (x,y,z)  "Stereo mode"
        // P: Polar Azimuth (r,az)
        // PP: Polar Azimuth And Elevation (r,az,el)

        // PS: DO NOT REARRANGE THESE ENUMS
        CIMG_DEFAULT = 0,        // allow RDC layer to use defaults

        // For Azimuth-only scans:
        CIMG_M8C = 1,        //                                                                          (Unsupported)
        CIMG_M8P = 2,        //                                                                          (Unsupported)
        CIMG_M16C = 3,        // 16-bit Magnitude Cartesian 2D image (X,Y)                                (OLD)
        CIMG_M16P = 4,        // 16-bit Magnitude Polar     2D image (R,A)
        CIMG_M16C_D8C = 5,        // 16-bit Magnitude Cartesian 2D image (X,Y), with Cartesian Doppler image
        CIMG_M16C_D7P = 6,        // 16-bit Magnitude Cartesian 2D image (X,Y), with Polar     Doppler image
        CIMG_M16P_D7P = 7,        // 16-bit Magnitude Polar     2D image (R,A), with Polar     Doppler image

        // For Azimuth+Elevation scans:
        CIMG_M16Z = 21,       // 16-bit Magnitude Cartesian 3D voxel cuboid                               (OLD)
        CIMG_M16Z_D7P = 22,       // 16-bit Magnitude Cartesian 3D voxel cuboid, with Polar Doppler image     (Unsupported)
        CIMG_M16C_H8C_D8C = 23,       // 16-bit Magnitude Cartesian, with 8-bit Height and Doppler Polar images
        CIMG_M16C_H7P_D7P = 24,       // 16-bit Magnitude Cartesian, with 7-bit Height and Doppler Polar images   (NEW)
        CIMG_M16P_H7P_D7P = 25,       // 16-bit Magnitude Polar,     with 7-bit Height and Doppler Polar images
        CIMG_M16PP_D7PP = 26,       // 16-bit Magnitude Polar Azimuth and Polar Elevation, with 7-bit Doppler Polar/Polar image

        MAX_CIMG_FORMAT
    };

    enum { PC_MAX_NUM_POINTS = 2048 };

    // Output Pin: o_PointCloudUhdp 
#if defined(RECORD_REPLAY)
typedef struct 
    {
        enum { PC_AZIMUTH_FRAC_BITS = 8 };

        enum { PC_ELEVATION_FRAC_BITS = 8 };

        enum { PC_SNR_FRAC_BITS = 8 };

        uint16_t                range;          //!< distance in units of range bin widths
        uint16_t                azimuth_fbin;   //!< interpolated fractional azimuth bin ID
        uint16_t                elevation_fbin; //!< interpolated fractional elevation bin ID
        uint16_t                doppler_bin;    //!< doppler bin
        uint16_t                snr_dB;         //!< snr in decibels with fractional bits
        int16_t                 mag_i;          //!< I-component of signal magnitude mantissa, without exponents (OPTIONAL)
        int16_t                 mag_q;          //!< Q-component of signal magnitude mantissa, without exponents (OPTIONAL)
        int8_t                  exponent;       //!< (hardware + software) for mag_i and mag_q
        uint8_t                 flags;
} PointCloudData;
#else
enum { PC_AZIMUTH_FRAC_BITS = 8 };
enum { PC_ELEVATION_FRAC_BITS = 8 };
enum { PC_SNR_FRAC_BITS = 8 };

typedef struct 
{
    uint16_t                range;          //!< distance in units of range bin widths
    uint16_t                azimuth_fbin;   //!< interpolated fractional azimuth bin ID
    uint16_t                elevation_fbin; //!< interpolated fractional elevation bin ID
    uint16_t                doppler_bin;    //!< doppler bin
    uint16_t                snr_dB;         //!< snr in decibels with fractional bits
    int16_t                 mag_i;          //!< I-component of signal magnitude mantissa, without exponents (OPTIONAL)
    int16_t                 mag_q;          //!< Q-component of signal magnitude mantissa, without exponents (OPTIONAL)
    int8_t                  exponent;       //!< (hardware + software) for mag_i and mag_q
    uint8_t                 flags;
} PointCloudData;
#endif

    typedef PointCloudData PointCloudArrType[PC_MAX_NUM_POINTS];

    typedef struct 
    {
        uint16_t NumPoints;
    } PointCloudHeaderType;

    typedef struct 
    {
        PointCloudHeaderType Header;
        PointCloudArrType PointCloudArrPtr;
    } PointCloudListType;

    typedef struct
    {
        float                   range;      // range (meters)
        float                   azimuth;    // azimuth angle (radians)
        float                   elevation;  // elevation angle (radians)
        float                   doppler;    // Doppler velocity (meters/second)
        float                   magnitude;  // signal power (dBFS)
        float                   snr;        // signal to noise ratio (dB)
        float                   rcs;        // RCS (dBsm)
        float                   pos_x;      // position (meters), radar relative SAE coord. system
        float                   pos_y;      // position (meters), radar relative SAE coord. system
        float                   pos_z;      // position (meters), radar relative SAE coord. system
        uint32_t                flags;      // enum RDC_detection_flags
    }DetectionData;

#if defined(RECORD_REPLAY)
} // namespace MAGNA
#endif /* RECORD_REPLAY */

#pragma pack(push,4)
typedef struct 
{
    uint16_t NumPoints;
    uint16_t Padding;
} Rdc_PointCloudHeaderType_4ByteAligned;

typedef struct 
{
    uint16_t range;
    uint16_t azimuth_fbin;
    uint16_t elevation_fbin;
    uint16_t doppler_bin;
    uint16_t snr_dB;
    int16_t mag_i;
    int16_t mag_q;
    int8_t exponent;
    uint8_t flags;
} Rdc_PointCloudType_4ByteAligned;

#if defined(RECORD_REPLAY)
typedef Rdc_PointCloudType_4ByteAligned Rdc_PointCloudArrType_4ByteAligned[MAGNA::PC_MAX_NUM_POINTS];
#else
typedef Rdc_PointCloudType_4ByteAligned Rdc_PointCloudArrType_4ByteAligned[PC_MAX_NUM_POINTS];
#endif

typedef struct 
{
    Rdc_PointCloudHeaderType_4ByteAligned Header;
    Rdc_PointCloudArrType_4ByteAligned PointCloudArr;
} Rdc_PointCloudListType_4ByteAligned;
#pragma pack(pop)


enum { CI_IMG_SIZE = 256 * 256 };
typedef uint16_t ClutterImageArrayType[CI_IMG_SIZE];

// Output Pin: o_ClutterImgUhdp 
typedef struct
{
	uint32_t ScanSequenceNumber;
	uint16_t Height;
	uint16_t Width;
	uint16_t Depth;
	uint8_t BytesPerPixel;
	float PixelSizeInMeters;
	ClutterImageArrayType ClutImgArr;
} ClutterImageListType;

// Output Pin: o_DetnListUhdp 
#if defined(RECORD_REPLAY)
typedef MAGNA::DetectionData DetectionDataArrType[1000];
#else
typedef DetectionData DetectionDataArrType[1000];
#endif

typedef struct 
{
    uint16_t maxSNRIndx;
    uint16_t ClusterSize;
    uint16_t MinRangeIndx;
    uint16_t StartingPointIndx;
} ClusterInfoType;
typedef ClusterInfoType ClusterInfoArrType[128];

typedef uint16_t ClusterDataIndicesType[2048];
typedef uint16_t ClusterDataClusterIDsType[2048];
typedef struct 
{
    ClusterInfoArrType ClusterInfo;
    ClusterDataIndicesType Indices;
    ClusterDataClusterIDsType ClusterIDs;
    uint16_t NumClusters;
    uint16_t NumExpandedClusters;
} ClusterDataType;

#endif // SRS_HDR_RDC_STRUCTS_H
