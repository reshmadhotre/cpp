/// @file PointCloudUtils.hpp
/// @brief Interface to the module responsible for processing all relevant
/// input signals in order to provide the respective ego vehicle dynamic 
/// signal of sufficiant quality.
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.

#ifndef _POINTCLOUDUTILS_HPP_
#define _POINTCLOUDUTILS_HPP_

#include <vector>
#include "RadarDataCubeTypes.h"
#include "RadarDataCubeParam.h"
#include "RadarDataCubeCfg.h"
#include "rdc-structs_stub.h"
#include "Angles_FRR.h"
#include "Platform_Types.h"

enum { MAX_NUM_POINTS_POINT_CLOUD = 2 * 1024 };

/// @struct PointType
/// @brief Structure of the floating point representation of one single point
/// 
struct PointType
{
    float32    Range;        //!< meters
    float32    Doppler;      //!< mps
    float32    Azimuth;      //!< radians from boresight
    float32    Elevation;    //!< radians from boresight
    float32    Mag_snr;      //!< decibels
    float32    Mag_i;        //!< full scale magnitude, 0 if unsupported
    float32    Mag_q;        //!< full scale magnitude, 0 if unsupported
    uint32     Flags;
    uint16     ClusterID;
};

/// @struct PointCloudTypeFloat
/// @brief Structure of the floting point representation of the cloud
///        Point array is dynamically allocated (std::vector)
/// 
struct PointCloudTypeFloat
{
    uint32 Version;
    uint32 NumPoints;
    uint32 ScanSequenceNum;
    std::vector<PointType> Points;

    PointCloudTypeFloat()
    {
        Version = 0x000100;
        NumPoints = 0u;
        ScanSequenceNum = 0u;
    }
};

/// @struct PointCloudType
/// @brief Structure of the floting point representation of the cloud.
///        Point array is statically allocated
/// 
struct PointCloudStatAllocType
{
    uint32 Version;
    uint32 NumPoints;
    uint32 ScanSequenceNum;
    PointType Points[MAX_NUM_POINTS_POINT_CLOUD];

    PointCloudStatAllocType()
    {
        Version = 0x000100;
        NumPoints = 0u;
        ScanSequenceNum = 0u;
    }
};

/// @class PointCloudUtils
/// @brief Interface to utility functions for point cloud interpretation
/// 
class PointCloudUtils
{
public:

    virtual ~PointCloudUtils() {}

    /// Convert point cloud from fixed point (radar data cube domain) into 
    /// floating point (polar coordinates). See RadarDataCubeUtils.h for 
    /// information on how to instantiate and configure PointCloudUtils
    ///
    /// Returns zero in case of success. 
    ///
    /// @param [in]     scanInfo          scan parameter received via ethernet
    /// @param [in]     pointCloudFxPnt   fixed point point cloud (rdc domain)
    /// @param [in]     clusterData       clustering ID's and indices
    /// @param [out]    pointCloud        floating point point cloud
    /// 
    /// @return	none
    ///
#ifdef RECORD_REPLAY
    virtual int ConvertToFloatingPoint(
        const MAGNA::UhdpScanInformation& scanInfo,
        const ClusterDataType& clusterData,
        const MAGNA::PointCloudListType& pointCloudFxPnt,
        PointCloudTypeFloat& pointCloud
    ) = 0;
#endif

    /// Convert point cloud from fixed point (radar data cube domain) into 
    /// floating point (polar coordinates). See RadarDataCubeUtils.h for 
    /// information on how to instantiate and configure PointCloudUtils
    ///
    /// Returns zero in case of success. 
    ///
    /// @param [in]     scanInfo          scan parameter received via ethernet
    /// @param [in]     pointCloudFxPnt   fixed point point cloud (rdc domain)
    /// @param [out]    pointCloud        floating point point cloud
    /// 
    /// @return	none
    ///
    virtual int ConvertToFloatingPoint(
#ifdef RECORD_REPLAY
        const MAGNA::UhdpScanInformation& scanInfo,
        const MAGNA::PointCloudArrType& pointCloudFxPnt,
#else
        const UhdpScanInformation& scanInfo,
        const PointCloudArrType& pointCloudFxPnt,
#endif
        PointCloudStatAllocType& pointCloud
    ) = 0;
};

#endif
