#ifndef __KFILTER_HEADER__
#define __KFILTER_HEADER__

#include "EgoVehParam.h"
#include "mecl/core/Matrix.h"
#include "mecl/core/Vector.h"
#include <stdlib.h>


namespace kalman
{

    typedef mecl::core::Matrix<float32_t, 4, 4> Matrix4x4_t;
    typedef mecl::core::Matrix<float32_t, 2, 2> Matrix2x2_t;

    static bool_t calcInverse(const Matrix2x2_t& i_M, Matrix2x2_t& o_Mi)
    {
        bool_t retVal = false;

        float32_t d = (i_M(0) * i_M(3)) - (i_M(1) * i_M(2));

        if (abs(d) > 1e-15f)
        {
            Matrix2x2_t tmp;
            tmp(0) = i_M(3);
            tmp(1) = -i_M(1);
            tmp(2) = -i_M(2);
            tmp(3) = i_M(0);

            o_Mi = tmp.mul(1.f / d);

            retVal = true;
        }
        else
        {
            retVal = false;
        }

        return retVal;
    }

    static bool_t calcInverse(const Matrix4x4_t& i_M, Matrix4x4_t& o_Mi)
    {
        float32_t m[16];
        float32_t calcInverse[16];

        for (uint32_t i = 0; i < i_M.channels; i++) m[i] = i_M(i);

        calcInverse[0] = m[5] * m[10] * m[15] -
            m[5] * m[11] * m[14] -
            m[9] * m[6] * m[15] +
            m[9] * m[7] * m[14] +
            m[13] * m[6] * m[11] -
            m[13] * m[7] * m[10];

        calcInverse[4] = -m[4] * m[10] * m[15] +
            m[4] * m[11] * m[14] +
            m[8] * m[6] * m[15] -
            m[8] * m[7] * m[14] -
            m[12] * m[6] * m[11] +
            m[12] * m[7] * m[10];

        calcInverse[8] = m[4] * m[9] * m[15] -
            m[4] * m[11] * m[13] -
            m[8] * m[5] * m[15] +
            m[8] * m[7] * m[13] +
            m[12] * m[5] * m[11] -
            m[12] * m[7] * m[9];

        calcInverse[12] = -m[4] * m[9] * m[14] +
            m[4] * m[10] * m[13] +
            m[8] * m[5] * m[14] -
            m[8] * m[6] * m[13] -
            m[12] * m[5] * m[10] +
            m[12] * m[6] * m[9];

        calcInverse[1] = -m[1] * m[10] * m[15] +
            m[1] * m[11] * m[14] +
            m[9] * m[2] * m[15] -
            m[9] * m[3] * m[14] -
            m[13] * m[2] * m[11] +
            m[13] * m[3] * m[10];

        calcInverse[5] = m[0] * m[10] * m[15] -
            m[0] * m[11] * m[14] -
            m[8] * m[2] * m[15] +
            m[8] * m[3] * m[14] +
            m[12] * m[2] * m[11] -
            m[12] * m[3] * m[10];

        calcInverse[9] = -m[0] * m[9] * m[15] +
            m[0] * m[11] * m[13] +
            m[8] * m[1] * m[15] -
            m[8] * m[3] * m[13] -
            m[12] * m[1] * m[11] +
            m[12] * m[3] * m[9];

        calcInverse[13] = m[0] * m[9] * m[14] -
            m[0] * m[10] * m[13] -
            m[8] * m[1] * m[14] +
            m[8] * m[2] * m[13] +
            m[12] * m[1] * m[10] -
            m[12] * m[2] * m[9];

        calcInverse[2] = m[1] * m[6] * m[15] -
            m[1] * m[7] * m[14] -
            m[5] * m[2] * m[15] +
            m[5] * m[3] * m[14] +
            m[13] * m[2] * m[7] -
            m[13] * m[3] * m[6];

        calcInverse[6] = -m[0] * m[6] * m[15] +
            m[0] * m[7] * m[14] +
            m[4] * m[2] * m[15] -
            m[4] * m[3] * m[14] -
            m[12] * m[2] * m[7] +
            m[12] * m[3] * m[6];

        calcInverse[10] = m[0] * m[5] * m[15] -
            m[0] * m[7] * m[13] -
            m[4] * m[1] * m[15] +
            m[4] * m[3] * m[13] +
            m[12] * m[1] * m[7] -
            m[12] * m[3] * m[5];

        calcInverse[14] = -m[0] * m[5] * m[14] +
            m[0] * m[6] * m[13] +
            m[4] * m[1] * m[14] -
            m[4] * m[2] * m[13] -
            m[12] * m[1] * m[6] +
            m[12] * m[2] * m[5];

        calcInverse[3] = -m[1] * m[6] * m[11] +
            m[1] * m[7] * m[10] +
            m[5] * m[2] * m[11] -
            m[5] * m[3] * m[10] -
            m[9] * m[2] * m[7] +
            m[9] * m[3] * m[6];

        calcInverse[7] = m[0] * m[6] * m[11] -
            m[0] * m[7] * m[10] -
            m[4] * m[2] * m[11] +
            m[4] * m[3] * m[10] +
            m[8] * m[2] * m[7] -
            m[8] * m[3] * m[6];

        calcInverse[11] = -m[0] * m[5] * m[11] +
            m[0] * m[7] * m[9] +
            m[4] * m[1] * m[11] -
            m[4] * m[3] * m[9] -
            m[8] * m[1] * m[7] +
            m[8] * m[3] * m[5];

        calcInverse[15] = m[0] * m[5] * m[10] -
            m[0] * m[6] * m[9] -
            m[4] * m[1] * m[10] +
            m[4] * m[2] * m[9] +
            m[8] * m[1] * m[6] -
            m[8] * m[2] * m[5];

        bool_t retVal;
        float32_t d;
        d = m[0] * calcInverse[0] + m[1] * calcInverse[4] + m[2] * calcInverse[8] + m[3] * calcInverse[12];

        if (abs(d) > 1e-15f)
        {
            d = 1.f / d;

            for (int i = 0; i < o_Mi.channels; i++) o_Mi(i) = calcInverse[i] * d;

            retVal = true;
        }
        else
        {
            retVal = false;
        }

        return retVal;
    };

    typedef enum
    {
        e_Default = 0,
        e_Fusion,
    } KalmanType_e;

    // todo: move into class
    enum KalmanFlags_e
    {
        DummyNum1 = 1 << 0,
        DummyNum2 = 1 << 1,
    };

    inline KalmanFlags_e operator|(KalmanFlags_e a, KalmanFlags_e b)
    {
        return static_cast<KalmanFlags_e>(static_cast<int>(a) | static_cast<int>(b));
    }

    inline KalmanFlags_e operator&(KalmanFlags_e a, KalmanFlags_e b)
    {
        return static_cast<KalmanFlags_e>(static_cast<int>(a)& static_cast<int>(b));
    }

    //----------------------------------------------------------------------------
    /// @class cKalmanFilter
    /// @brief todo
    ///
    /// @description     todo
    //  --------------------------------------------------------------------------
    template<typename T, uint32_t x_m, uint32_t z_m, KalmanType_e Ktype = e_Default>
    class cKalmanFilter
    {

    public:

        cKalmanFilter()
            : x()
            , z()
            , P(mecl::core::Matrix<float32_t, x_m, x_m>::eye())
            , Q(mecl::core::Matrix<float32_t, x_m, x_m>::eye())
            , R(mecl::core::Matrix<float32_t, z_m, z_m>::eye())
            , K()
            , I(mecl::core::Matrix<float32_t, x_m, x_m>::eye())
        {
            // todo: make dynamic model configurable it configurable -> KalmanFlags_e
            A(0, 0) = 1.f;
            A(0, 1) = c_CycleTime;
            A(1, 0) = 0.f;
            A(1, 1) = 1.f;

            // todo: make it configurable -> KalmanFlags_e for configuration of 
            // state-to-measurement space transformation
            mecl::core::Matrix<float32_t, z_m, 1> col;
            col.setOnes();
            H.setCol(0, col);
            col.setZeros();
            H.setCol(1, col);
        }

        virtual ~cKalmanFilter()
        {
        }

        void Init(const mecl::core::Vector<T, x_m>& i_x)
        {
            for (int i = 0; i < x_m; i++) x(i) = i_x(i);
        }

        void Predict(const mecl::core::Vector<T, x_m>& i_ProcNoiseVar_rs)
        {
            // x = A * x
            x = A.mmul(x);

            // set up the process noise covariance matrix
            for (int i = 0; i < x_m; i++) Q(i, i) = i_ProcNoiseVar_rs(i);

            // P = A*P*A.T + Q
            mecl::core::Matrix<float32_t, 2, 2> APAt = A.mmul(P);
            APAt = APAt.mmul(A.t());
            P = APAt.add(Q);
        }

        void Update(const mecl::core::Vector<T, z_m>& i_Meas_rs,
            const mecl::core::Vector<T, z_m>& i_MeasNoiseVar_rs)
        {
            // set up the measurement noise matrix
            for (int i = 0; i < z_m; i++) R(i, i) = i_MeasNoiseVar_rs(i);

            // K = P*Ht * (H*P*Ht + R)^-1
            mecl::core::Matrix<float32_t, x_m, z_m> PHt = P.mmul(H.t());        // P*Ht
            mecl::core::Matrix<float32_t, z_m, z_m> HPHt = H.mmul(PHt);         // H*P*Ht
            mecl::core::Matrix<float32_t, z_m, z_m> HPHt_R = HPHt.add(R);       // H*P*Ht + 
            mecl::core::Matrix<float32_t, z_m, z_m> S;
            kalman::calcInverse(HPHt_R, S);
            K = PHt.mmul(S);

            // set up measurement vector
            for (int i = 0; i < z_m; i++) z(i, 0) = i_Meas_rs(i);

            // x = x + K(z - (H*x))
            mecl::core::Matrix<float32_t, z_m, 1> Hx = H.mmul(x);     // (H*x)
            mecl::core::Matrix<float32_t, z_m, 1> y = z.sub(Hx);      // (z - (H*x))
            mecl::core::Matrix<float32_t, x_m, 1> xd = K.mmul(y);     // (K*(z - (H*x)))
            x += xd;

            // P = (I - (K*H)) * P
            mecl::core::Matrix<float32_t, x_m, x_m> KH = K.mmul(H);         // (K*H)
            mecl::core::Matrix<float32_t, x_m, x_m> I_KH = I.sub(KH);       // (I - (K*H))
            mecl::core::Matrix<float32_t, x_m, x_m> I_KHP = I_KH.mmul(P);   // (I - (K*H)) * P
            P = I_KHP;
        }

        void Reset(void)
        {
            P.setEye();
            K.setZeros();
        }

        const mecl::core::Vector<float32_t, x_m> GetStateVector(void) const
        {
            return x;
        }

        const mecl::core::Matrix<float32_t, x_m, x_m> GetCovarianceMatrix(void) const
        {
            return P;
        }

        const mecl::core::Matrix<float32_t, x_m, z_m>& GetKMatrix(void) const
        {
            return K;
        }

    private:

        mecl::core::Vector<float32_t, x_m> x;
        mecl::core::Matrix<float32_t, x_m, x_m> A;
        mecl::core::Matrix<float32_t, x_m, x_m> P;
        mecl::core::Matrix<float32_t, x_m, x_m> Q;

        mecl::core::Vector<float32_t, z_m> z;
        mecl::core::Matrix<float32_t, z_m, z_m> R;
        mecl::core::Matrix<float32_t, z_m, x_m> H;
        mecl::core::Matrix<float32_t, x_m, z_m> K;
        mecl::core::Matrix<float32_t, x_m, x_m> I;

    };

} // namespace kalman

#endif // __KFILTER_HEADER__

