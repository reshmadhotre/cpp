//--------------------------------------------------------------------------
/// @file Miscellaneous.hpp
/// @brief Contains /todo
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef MATHMISC_HPP
#define MATHMISC_HPP


#include <math.h>


#ifndef M_PI
#define M_PI       3.14159265358979323846
#endif

namespace Utils
{
    static const char c_MaxUint8 = 255u;
    static const float c_MsToKph = 3.6f;
    const float c_MinToSecFactor_f32 = 60.0f;

    struct Point3_t
    {
        float x;
        float y;
        float z;
    };

    //--------------------------------------------------------------------------
    /// @brief Calculates the exponential moving average
    ///
    /// @param [in] /todo
    /// 
    /// @return	Moving average
    ///
    // --------------------------------------------------------------------------
    template <unsigned N>
    static float calcExpMovAverage(const float i_NewVal, float io_Average)
    {
        io_Average -= io_Average / N;
        io_Average += i_NewVal / N;

        return io_Average;
    }

    //###################################################################
    static float GetDistance(const Point3_t& pt1, const Point3_t& pt2)
    {
        return sqrtf(((pt1.x - pt2.x) * (pt1.x - pt2.x))
            + ((pt1.y - pt2.y) * (pt1.y - pt2.y)));
    }

    //--------------------------------------------------------------------------
    /// @brief Generate a value projection from a source metric to target metric.
    ///
    /// @param srcMin [in] The source min value.
    /// @param srcMax [in] The source max value.
    /// @param srcValue [in] The source value.
    /// @param trgMin [in] The target min value.
    /// @param trgMax [in] The target max value.
    /// @param trgValue [out] The result target value.
    ///
    // --------------------------------------------------------------------------
    template<typename T>
    static void Projection(const T& srcMin, const T& srcMax, const T& srcValue,
        const T& trgMin, const T& trgMax, T& trgValue)
    {
        trgValue = trgMin + ((trgMax - trgMin) * ((srcValue - srcMin)
            / (srcMax - srcMin)));
    };

    //--------------------------------------------------------------------------
    //! Convert cartesian to polar coordinates.
    //! @param x [in] The cartesian x direction source.
    //! @param y [in] The cartesian y direction source.
    //! @param r [out] The polar distance target.
    //! @param phi [out] The polar angle target.
    //--------------------------------------------------------------------------
    static void Cartesian2Polar(const double& x, const double& y, double& r, double& phi)
    {
        r = sqrt((x * x) + (y * y));
        phi = atan2(y, x);
    }

    //--------------------------------------------------------------------------
    //! Convert cartesian to polar coordinates.
    //! @param r [in] The polar distance target..
    //! @param phi [in] The polar angle target.
    //! @param x [out] The cartesian x direction source.
    //! @param y [out] The cartesian y direction source.
    //--------------------------------------------------------------------------
    static void Polar2Cartesian(const double& r, const double& phi, double& x, double& y)
    {
        x = r * cos(phi);
        y = r * sin(phi);
    }

    //--------------------------------------------------------------------------
    //! Normalize rad angle between 0 and 2PI.
    //! @param rad [in,out] The radian to normalize
    //--------------------------------------------------------------------------
    static void normalizeRad(double& rad)
    {
        if (rad < 0)
        {
            rad += (2 * M_PI);
            normalizeRad(rad);
        }
        else if (rad >= (2 * M_PI))
        {
            rad -= (2 * M_PI);
            normalizeRad(rad);
        }
    }
}

#endif
