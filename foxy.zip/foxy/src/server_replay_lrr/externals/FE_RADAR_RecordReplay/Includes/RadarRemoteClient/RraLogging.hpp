//--------------------------------------------------------------------------
/// @file RraLogging.hpp
/// @brief Utility classes for logging functionality
///
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------

#ifndef _RRA_LOGGING_H_
#define _RRA_LOGGING_H_

#include "threading.h"
#include <string>
#include <iomanip>
#include <ctime>
#include <cstdio>

#if (__MSVC__ <= 16)
#include "MsvcCompat.h"
#endif


#ifndef __GNUC__
class ConsoleLogger : public UserLogAgent
{
   void radar_print_message(ICCQTargetEnum cpu, const char* message)
   {
      printf("%s-UHP: %s\n", cpu_names[cpu], message);
   }

   void radar_log_message(ICCQTargetEnum cpu, LogLevelEnum level, const char* message)
   {
      if (level >= LL_INFO)
      {
         printf("%s-LOG: %s\n", cpu_names[cpu], message);
      }
   }

   void received_control_message(uint32_t t, const char* message,
           uint32_t msg_len)
   {
      printf("[Received user control message of type %d, length %d]\n", (int)t, msg_len);
   }
};


class cRraFileLogger : public UserLogAgent
{
public:
    cRraFileLogger(const std::string& sensorID, bool logSwitch,
        bool consoleLogSwitch, LogLevelEnum logLevel)
        : m_SensorPositionName(sensorID)
        , m_logSwitch(logSwitch)
        , m_consoleLogSwitch(consoleLogSwitch)
        , m_logLevel(logLevel)
    {
        if (m_logSwitch)
        {
            const size_t size = 40;
            char date_time[size];
            get_date_time(date_time, size);
            m_SrsLogFileName = date_time;

            m_SrsLogFileName.append("_");

            m_SrsLogFileName.append(m_SensorPositionName);

            m_SrsLogFileName.append("_uh.log");

            m_SrsLogFile = fopen(m_SrsLogFileName.c_str(), "w");
        }
    }

    ~cRraFileLogger()
    {
        if (m_logSwitch)
        {
            fclose(m_SrsLogFile);
        }
    }

    void flush_logfile()
    {
        if (m_oMutex.try_acquire() != 0)
        {
            fflush(m_SrsLogFile);

            m_oMutex.release();
        }
    }

    const char* reset_and_get_logfile_name()
    {
        static std::string oldLogFileName(m_SrsLogFileName);

        m_oMutex.acquire();

        fclose(m_SrsLogFile);

        m_SrsLogFileName.clear();

        const size_t size = 40;
        char date_time[size];
        get_date_time(date_time, size);
        m_SrsLogFileName = date_time;

        m_SrsLogFileName.append("_");

        m_SrsLogFileName.append(m_SensorPositionName);

        m_SrsLogFileName.append("_uh.log");

        m_SrsLogFile = fopen(m_SrsLogFileName.c_str(), "w");

        m_oMutex.release();

        return oldLogFileName.c_str();
    }

    void get_date_time(char date_time[], size_t size)
    {
        SYSTEMTIME system_time;
        GetSystemTime(&system_time);

#if defined(_MSC_VER) && (__MSVC__ <= 16)  // VS2010
        sprintf(date_time, "%d%.2d%.2d_%.2d%.2d%.2d_%.3d",
            system_time.wYear,
            system_time.wMonth,
            system_time.wDay,
            system_time.wHour,
            system_time.wMinute,
            system_time.wSecond,
            system_time.wMilliseconds
#else
        snprintf(date_time, size, "%d%.2d%.2d_%.2d%.2d%.2d_%.3d",
            system_time.wYear,
            system_time.wMonth,
            system_time.wDay,
            system_time.wHour,
            system_time.wMinute,
            system_time.wSecond,
            system_time.wMilliseconds
#endif
        );
    }

    void radar_print_message(ICCQTargetEnum cpu, const char* message)
    {
        if (m_logSwitch)
        {
            if (m_oMutex.try_acquire() != 0)
            {
                fprintf(m_SrsLogFile, "%s-UHP: %s\n", cpu_names[cpu], message);

                m_oMutex.release();
            }
        }
    }

    void radar_log_message(ICCQTargetEnum cpu, LogLevelEnum level, const char* message)
    {
        if (m_logSwitch && level >= m_logLevel)
        {
            if (m_oMutex.try_acquire() != 0)
            {
                fprintf(m_SrsLogFile, "%s-LOG: %s\n", cpu_names[cpu], message);

                m_oMutex.release();
            }
        }

        if (m_consoleLogSwitch == true)
        {
            if (level > m_logLevel)
            {
                if (level <= LL_INFO)
                {
                    printf("UHDP - %s-LOG: %s", cpu_names[cpu], message);
                }
                else if (level == LL_WARN)
                {
                    printf("UHDP - %s-LOG: %s", cpu_names[cpu], message);
                }
                else if (level == LL_ERROR)
                {
                    printf("UHDP - %s-LOG: %s", cpu_names[cpu], message);
                }
            }
        }
    }

    void received_control_message(uint32_t t, const char* message, uint32_t msg_len)
    {
        if (m_logSwitch)
        {
            if (m_oMutex.try_acquire() != 0)
            {
                fprintf(m_SrsLogFile, "[Received user control message of type %d, length %d]\n", (int)t, msg_len);

                m_oMutex.release();
            }
        }
    }

private:
    std::string m_SensorPositionName;
    std::string m_SrsLogFileName;
    FILE* m_SrsLogFile;
    bool m_logSwitch;
    bool m_consoleLogSwitch;
    LogLevelEnum m_logLevel;
    Mutex m_oMutex;
};

class cFileLogger
{
public:
    const size_t Sz;
    char Msg[120];

    cFileLogger()
        : Sz(120)
        , m_SensorPositionName("")
        , Msg()
        , m_logSwitch(true)
    {
        const size_t size = 40;
        char date_time[size];
        GetDateTime(date_time, size);
        m_LogFileName = date_time;

        m_LogFileName.append("_mag.log");

        m_LogFile = fopen(m_LogFileName.c_str(), "w");
    }

    cFileLogger(const std::string& sensorID, bool logSwitch)
        : Sz(120)
        , m_SensorPositionName(sensorID)
        , m_logSwitch(logSwitch)
        , m_LogFile(NULL)
    {
        if (m_logSwitch)
        {
            const size_t size = 40;
            char date_time[size];
            GetDateTime(date_time, size);
            m_LogFileName = date_time;

            m_LogFileName.append("_mag.log");

            m_LogFile = fopen(m_LogFileName.c_str(), "w");
        }
    }

    ~cFileLogger()
    {
        if (m_logSwitch)
        {
            fclose(m_LogFile);
        }
    }

    void FlushLogFile()
    {
        if (m_oMutex.try_acquire() != 0)
        {
            fflush(m_LogFile);

            m_oMutex.release();
        }
    }

    const char* ResetAndGetLogFileName()
    {
        static std::string oldLogFileName(m_LogFileName);

        m_oMutex.acquire();

        fclose(m_LogFile);

        m_LogFileName.clear();

        const size_t size = 40;
        char date_time[size];
        GetDateTime(date_time, size);
        m_LogFileName = date_time;

        m_LogFileName.append("_mag.log");

        m_LogFile = fopen(m_LogFileName.c_str(), "w");

        m_oMutex.release();

        return oldLogFileName.c_str();
    }

    void GetDateTime(char date_time[], size_t size)
    {
        SYSTEMTIME system_time;
        GetSystemTime(&system_time);

#if defined(_MSC_VER) && (__MSVC__ <= 16)  // VS2010
        sprintf(date_time, "%d%.2d%.2d_%.2d%.2d%.2d_%.3d",
            system_time.wYear,
            system_time.wMonth,
            system_time.wDay,
            system_time.wHour,
            system_time.wMinute,
            system_time.wSecond,
            system_time.wMilliseconds
#else
        snprintf(date_time, size, "%d%.2d%.2d_%.2d%.2d%.2d_%.3d",
            system_time.wYear,
            system_time.wMonth,
            system_time.wDay,
            system_time.wHour,
            system_time.wMinute,
            system_time.wSecond,
            system_time.wMilliseconds
#endif
        );
    }

    void Write(const char* message)
    {
        if (m_logSwitch)
        {
            if (m_oMutex.try_acquire() != 0)
            {
                fprintf(m_LogFile, "UHDP: %s\n", message);

                m_oMutex.release();
            }
        }
    }

private:
    std::string m_SensorPositionName;
    std::string m_LogFileName;
    FILE* m_LogFile;
    bool m_logSwitch;
    Mutex m_oMutex;
};
#endif //__GNUC__

#endif
