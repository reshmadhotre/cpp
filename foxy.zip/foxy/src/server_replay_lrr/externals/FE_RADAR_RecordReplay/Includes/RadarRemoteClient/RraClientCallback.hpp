//--------------------------------------------------------------------------
/// @file RraClientCallback.hpp
/// @brief
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _RRA_CLIENT_CALLBACK_HPP_
#define _RRA_CLIENT_CALLBACK_HPP_

#include "RraClientTypes.hpp"
#include "RraClientErrorTypes.hpp"


class IRraClientCallback
{
public:
    virtual int64_t GetStreamTimeCbk(void) = 0;
    virtual Result_t SetScanSynchTimeCbk(void) = 0;
    virtual Result_t TransmitDataCbk(
        eProvidedDataID id, DataMemory_t mem) = 0;
    virtual Result_t TransmitDataChunkCbk(
        eProvidedDataID id, DataMemoryChunk_t mem) = 0;

    virtual Result_t SetSignalRegistryValuesCbk(double sigValBuf[])
    {
        return ER_NOERROR;
    }
};

#endif //_RRA_CLIENT_CALLBACK_HEADER_
