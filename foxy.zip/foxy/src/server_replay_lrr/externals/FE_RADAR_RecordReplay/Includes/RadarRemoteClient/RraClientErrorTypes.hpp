//--------------------------------------------------------------------------
/// @file RraClientErrorTypes.hpp
/// @brief
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _RRA_CLIENTERRORTYPES_HPP_
#define _RRA_CLIENTERRORTYPES_HPP_

#include <stdint.h>


typedef int32_t Result_t;
#define ER_NOERROR            (0)
#define ER_NO_CONNECTION      (-102)
#define ER_NO_SCANNING        (-103)
#define ER_COMMUNICATION      (-104)
#define ER_RDC_NOT_INIT       (-105)
#define ER_RDC_NOT_INIT_THROW (-106)
#define ER_ADI_SYNCH_THROW    (-107)
#define ER_NO_VRX_ALIGN       (-108)
#define ER_NO_VRX_ALIGN_THROW (-109)
#define ER_NO_VRX_ALIGN_RESET (-110)
#define ER_ANTENNACFG_INVALID (-111)
#define ER_SCAN_INVALID       (-112)
#define ER_CALLBACKS_ALREADY_SET  (-113)
#define ER_PROPERTIES_NOT_SET (-114)
#define ER_NO_RRA_INSTANCE    (-115)
#define ER_NO_NETWORK_THREAD  (-116)


#endif
