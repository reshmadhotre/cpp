//--------------------------------------------------------------------------
/// @file RraScanConfigurations.h
/// @brief Contains /todo

/// /todo
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef SCANCONFIGURATIONS_HEADER
#define SCANCONFIGURATIONS_HEADER
#include "rdc-scanctrl_stub.h"


enum eScanNum
{ 
    SCAN1 = 0,
    SCAN2,
    SCAN3,
    MAX_NUM_SCANS,
};

inline eScanNum& operator++(eScanNum& sn)
{
    return sn = (sn == SCAN3)
        ? SCAN1 : static_cast<eScanNum>(static_cast<int>(sn) + 1);
}

static const char* scanPresetNames[MAGNA::NUM_PRESETS] =
{
    "VP101", // VP1a with 256 range bins
    "VP201", // VP1a with 256 range bins, 2GHz Sampling rate
    "VP102", // City
    "VP202", // City, 2GHz Sampling rate
    "VP103", // Highway
    "VP203", // Highway, 2GHz Sampling rate
    "VP104", // Highway-2
    "VP105", // City-1
    "VP211", // 1 Giga chip rate variable mode scan
    "CP101", // CP1a with 256 range bins
    "CP201", // CP1a with 256 range bins, 2GHz Sampling rate
    "CP102", // CpCity
    "CP202", // CpCity, 2GHz Sampling rate
    "CP103", // Highway, CP Mode - cooked up scan, for first bringup using digital loopback
    "CP203", // Highway, CP Mode - cooked up scan, for first bringup using digital loopback, 2GHz Sampling rate
    "CP104", // Basic scan to run @ 1G Sampling rate
    "CP210", // 1 Giga chip rate continuous power mode scan
    "VP114", // Like VP101, but fewer pings
    "VP114U", // Like VP114, but correlating all pings
    "VP104N", // VP104 scan with nuking targets
    "VP105N", // VP105 scan with nuking targets
    "VP204", // Highway-2, 2GHz Sampling Rate
    "VP205", // City-1, 2GHz Sampling Rate

    /*-- Magna Electronics addon  --*/
    "VP104HP", // Davide Amato case
    "VP105HP", // Davide Amato case
};

enum eDetThreshMode
{
    DT_Preset = 0,
    DT_Manual,
    NumDetThreshModes,
};

enum eScanCfgMode
{
    SCM_Preset = 0,
    SCM_Manual,
    NumScanCfgModes,
};

#endif //SCANCONFIGURATIONS_HEADER
