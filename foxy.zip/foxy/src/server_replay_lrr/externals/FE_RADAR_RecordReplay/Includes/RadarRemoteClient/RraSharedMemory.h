#pragma once

#include "RraScanConfigurations.h"
#include "RraAntennaConfigurations.h"
#include "RraLogging.hpp"
#include "RraClientTypes.hpp"
#include <vector>


enum eAccessCtrl
{
    eStop = 0,
    eStart = 1
};

enum SupportedAntCfgEnum
{
    SUP_ADB_TRAD_1D,
    SUP_ADB_TRAD_2D,
    SUP_ADB_LONE_TX,
    SUP_RAC_TRAD_1D,
    SUP_RAC_TRAD_2D,
    SUP_RAC_LONE_TX,
    SUP_TAC_LRR_AZIMUTH,
    SUP_TAC_LRR_ELEVATION,
    SUP_TAC_MRR_AZIMUTH,
    SUP_TAC_MRR_ELEVATION,

    NUM_ANTENNA_CONFIGS,
    INVALID_ANTENNA_CFG
};

static const CHAR* AntennaConfigStr[NUM_ANTENNA_CONFIGS] =
{
    "ADB Trad 1D",
    "ADB Trad 2D",
    "ADB Lone TX",
    "RAC Trad 1D",
    "RAC Trad 2D",
    "RAC Lone TX",
    "TAC LRR Az",
    "TAC LRR El",
    "TAC MRR Az",
    "TAC MRR El",
};

struct tScanDescriptor
{
    SupportedAntCfgEnum antCfg;
    RDC_ScanPresetEnum scanId;
    uint16_t nNumRngBins;
    float fRngBinWidth;
    float fRng;
    bool bIsTwoD;

    tScanDescriptor()
    {
        antCfg = INVALID_ANTENNA_CFG;
        scanId = NUM_PRESETS;
        nNumRngBins = 0;
        fRngBinWidth = 0.0f;
        fRng = 0.0f;
        bIsTwoD = false;
    }
};

struct tShrdMemScanInfo
{
    bool bComplete;
    std::vector<tScanDescriptor> Descriptors;

    tShrdMemScanInfo()
    {
        bComplete = false;
        Descriptors.reserve(MAX_NUM_SCANS);
    }
};

struct tShrdMemScanSerializer
{
    char* buffer;
    MemorySerializer* pMemSer;
    eAccessCtrl AccessCtrl;

    tShrdMemScanSerializer()
    {
        buffer = NULL;
        pMemSer = NULL;
        AccessCtrl = eStop;
    }
};

//! Adapter class to use MemorySerializer for one scan only. No ring buffer
//! functionality. Only the first scan scan table will be used. With every
//! new scan, memory will be overwritten and the respective write pointers 
//! will not be increased. 
class cAdtfScanSerializer : public MemorySerializer
{
public:
    cAdtfScanSerializer(char* buffer, size_t buffer_sizebytes)
        : MemorySerializer(buffer, buffer_sizebytes)
        , m_nSizeBytes(0)
    {
    }

    virtual ~cAdtfScanSerializer() {}

    virtual bool begin_write_scan(uint32_t scan_sequence_number) override
    {
        scan_table[write_cur_scan].state = ScanTable::IDLE;

        bool ok = MemorySerializer::begin_write_scan(scan_sequence_number);

        return ok;
    }

    virtual void end_write_scan(bool aborted) override
    {
        if (aborted)
        {
            printf("UHDP AdtfScanSerializer - Scan %d aborted!",
                scan_table[write_cur_scan].sequence_number);
        }

        scan_table[write_cur_scan].state = ScanTable::COMPLETE;

        // memory will be reused, so reset the write pointer and don't
        // increase write_cur_scan, but save the size in bytes of the
        // already used memory
        m_nSizeBytes = write_ptr;
        write_ptr = scan_table[write_cur_scan].dtype_table_offset;
    }
    
    virtual void end_read_scan()
    {
        scan_table[read_cur_scan].state = ScanTable::IDLE;
        read_cur_scan = 0u;
    }

    size_t GetSize(void)
    {
        return m_nSizeBytes;
    }

    void ResetState(void)
    {
        scan_table[write_cur_scan].state = ScanTable::IDLE;
    }

private:
    size_t m_nSizeBytes;
};
