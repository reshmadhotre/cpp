//--------------------------------------------------------------------------
/// @file RraClientParameter.hpp
/// @brief
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _SRA_CLIENT_PRM_HEADER_
#define _SRA_CLIENT_PRM_HEADER_

#include "IDataProvider_Eme.h"
#include "RraAntennaConfigurations.h"
#include "RraScanConfigurations.h"
#include "uhdp-msg-structs_stub.h"
#include "rdc-threshctrl_stub.h"
#include "rdc-structs_stub.h"
#include <string>


enum eSensorPosition
{
    SP_FrontLeft = 0,
    SP_FrontMid,
    SP_FrontRight,
};

struct PropertiesBase_t
{
    const char* strServerIP;
    uint16_t nReadPort;
    int32_t nNumberOfScansToExecute;
    uint8_t nMode;
    uint32_t nConTimeout;
    uint32_t nScanInterval;
    bool bResetVrxaFail;
    bool bNoInitVrxaFail;
    const char* strSraVersion;

    PropertiesBase_t()
    {
        strServerIP = "127.0.0.1";
        nReadPort = 5051u;
        nNumberOfScansToExecute = -1;
        nMode = MAGNA::DL_NORMAL;
        nConTimeout = 4u;
        nScanInterval = 0u;
        bResetVrxaFail = false;
        bNoInitVrxaFail = false;
        const char* strSraVersion = "";
    }
};

struct PropertiesCaptureControl_t
{
    bool bEnableADC;
    bool bEnableRDC1;
    bool bEnableRDC2;
    bool bEnableRDC3;
    bool bEnableSparseRDC3;
    bool bEnableStaticSlice;
    bool bEnableDetections;
    bool bEnableClutterImage;
    bool bEnableCANMessageRx;
    bool bEnableCANMessageTx;
    bool bEnableApplicationData;
    bool bEnableRdcEgoVelData;
    bool bEnablePointCloud;
    bool bReplayMode;

    PropertiesCaptureControl_t()
    {
        bEnableADC = false;
        bEnableRDC1 = false;
        bEnableRDC2 = false;
        bEnableRDC3 = false;
        bEnableSparseRDC3 = false;
        bEnableStaticSlice = false;
        bEnableDetections = true;
        bEnableClutterImage = true;
        bEnableCANMessageRx = false;
        bEnableCANMessageTx = false;
        bEnableApplicationData = false;
        bEnableRdcEgoVelData = false;
        bEnablePointCloud = true;
        bReplayMode = false;
    }
};

struct ManualScanCfg_t
{
    int16_t rx_early_unsquelch;
    uint32_t ss_doppler;
    uint16_t ChipRate;
    uint32_t ChipPerPulse;
    uint32_t NumberPulses;
    uint8_t  ChanRatio;
    uint16_t RangeBins;
    uint16_t RangeBinStart;
    uint16_t RangeBinCombined;
    uint8_t RDC1Shared;
    uint8_t MIMOMode;
    uint8_t CorrLenght;
    uint16_t ChipPerPing;
    uint16_t RxChipsPerPing;
    uint16_t TxChipsPerPing;
    MAGNA::RDC_WindowType AngleWindow;
    MAGNA::RDC_WindowType DopplerWindow;

    ManualScanCfg_t()
    {
        rx_early_unsquelch = 1024;
        ss_doppler = 7u;
        ChipRate = 4u;
        ChipPerPulse = 300u;
        NumberPulses = 630u;
        ChanRatio = 1u;
        RangeBins = 256u;
        RangeBinStart = 0u;
        RangeBinCombined = 1u;
        RDC1Shared = 0u; // multi_buffer
        MIMOMode = 0u;   // MIMO_PRBS
        CorrLenght = 6u;
        ChipPerPing = 300u;
        RxChipsPerPing = 150u;
        TxChipsPerPing = 148u;
        AngleWindow = MAGNA::WINDOW_SVA;
        DopplerWindow = MAGNA:: WINDOW_TAYLOR_55;
    }
};

struct PropertiesScanCtrl_t
{
    int16_t   scan_count;
    bool      two_D;
    bool      alternate_1D_2D;
    RadarHwEnum radarType;
    int scanLoopCount;
    int antennaCfg[MAX_NUM_SCANS];
    int antennaCfg_KENPO[MAX_NUM_SCANS];
    int antennaCfg_FRR[MAX_NUM_SCANS];
    int antennaCfg_MRR[MAX_NUM_SCANS];
    int antennaCfg_MRR_EVK[MAX_NUM_SCANS];
    MAGNA::RDC_ScanPresetEnum scan[MAX_NUM_SCANS];
    eScanCfgMode scanCfgMode[MAX_NUM_SCANS];
    ManualScanCfg_t manCfgScan[MAX_NUM_SCANS];
    eDetThreshMode detThreshMode;
    MAGNA::ThresholdPresetEnum detThreshPreset;
    PropertiesCaptureControl_t sCaptureControl;
    MAGNA::RDC_ThresholdControl detThresholds;

    PropertiesScanCtrl_t()
    {
        two_D = false;
        alternate_1D_2D = false;
        radarType = RH_FRR;
        scanLoopCount = 1;
        antennaCfg[SCAN1] = ADB_TRADITIONAL_1D;
        antennaCfg[SCAN2] = ADB_TRADITIONAL_2D;
        antennaCfg[SCAN3] = ADB_TRADITIONAL_1D;
        antennaCfg_KENPO[SCAN1] = TAC_LRR_AZIMUTH;
        antennaCfg_KENPO[SCAN2] = TAC_LRR_ELEVATION;
        antennaCfg_KENPO[SCAN3] = TAC_LRR_AZIMUTH;
        antennaCfg_FRR[SCAN1] = MAC_AZIMUTH;
        antennaCfg_FRR[SCAN2] = MAC_AZIMUTH;
        antennaCfg_FRR[SCAN3] = MAC_AZIMUTH;
        antennaCfg_MRR[SCAN1] = MRR_AllTxSetRxMode;
        antennaCfg_MRR[SCAN2] = MRR_AllTxSetRxMode;
        antennaCfg_MRR[SCAN3] = MRR_AllTxSetRxMode;
        antennaCfg_MRR_EVK[SCAN1] = EVK_12TxLNA0;
        antennaCfg_MRR_EVK[SCAN2] = EVK_12TxLNA0;
        antennaCfg_MRR_EVK[SCAN3] = EVK_12TxLNA0;
        scan[SCAN1] = MAGNA::VP104;
        scan[SCAN2] = MAGNA::VP105;
        scan[SCAN3] = MAGNA::VP104;
        scanCfgMode[SCAN1] = SCM_Preset;
        scanCfgMode[SCAN2] = SCM_Preset;
        scanCfgMode[SCAN3] = SCM_Preset;
        detThreshMode = DT_Preset;
        detThreshPreset = MAGNA::FRR_B1;
        detThresholds.defaults();
    }
};

struct PropertiesPointCloud_t
{
    float threshold;

    PropertiesPointCloud_t()
    {
        threshold = 13.0f;
    }
};

struct PropertiesFileLogger_t
{
    MAGNA::LogLevelEnum logLevel;
    bool bMagnaLog;
    bool bUhnderLog;

    PropertiesFileLogger_t()
    {
        logLevel = MAGNA::LL_INFO;
        bMagnaLog = false;
        bUhnderLog = false;
    }
};

struct PropertiesConsoleLogger_t
{
    bool bUhnderLogToConsole;

    PropertiesConsoleLogger_t()
    {
        bUhnderLogToConsole = false;
    }
};

struct PropertiesVehicleCfg_t
{
    eSensorPosition sensorPosition;
    
    PropertiesVehicleCfg_t()
    {
        sensorPosition = SP_FrontMid;
    }
};

struct RraProperties_t
{
    PropertiesBase_t sBase;
    PropertiesScanCtrl_t sScanCtrl;
    PropertiesPointCloud_t sPointCloud;
    PropertiesFileLogger_t sFileLogger;
    PropertiesConsoleLogger_t sConsoleLogger;
    PropertiesVehicleCfg_t sVehCfg;
    /////////////////////////////////////////////////////////
    // TODO remove these temporary filter properties as soon
    // as either EME is working or the vehicle input adapter
    // provides generic interface
    IDataProvider_Eme::tPropertiesVehicleParams sVehPar;
    //////////////////////////////////////////////////////////
    bool bSignalRegistration;
    bool bSerializeScanObj;
    bool bSendTimerValues;
    bool bUseDirectMemoryAccess;

    RraProperties_t()
    {
        bSignalRegistration = false;
        bSerializeScanObj = false;
        bSendTimerValues = false;
        bUseDirectMemoryAccess = true;
    }
};

#endif //_SRA_CLIENT_PRM_HEADER_
