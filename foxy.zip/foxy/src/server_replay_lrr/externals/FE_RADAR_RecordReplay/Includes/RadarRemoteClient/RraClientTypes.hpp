//--------------------------------------------------------------------------
/// @file RraClientTypes.hpp
/// @brief
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _RRA_CLIENT_TYPES_HEADER_
#define _RRA_CLIENT_TYPES_HEADER_
#include <stdint.h>


enum eProvidedDataID
{
  PD_UhdpScanParameter = 0,
  PD_DetnListUhdp,
  PD_PntCloudUhdp,
  PD_ClutterImgUhdp,
  PD_ScanDataUhdp,
  PD_TimerValues,
  PD_ScanInfo,
  PD_DetnList,
  PD_EmeHist,
  PD_PntCloud,
  PD_AngleBins,
  PD_RangeBins,
  PD_ScanComplete,
  PD_NumProvidedDataIDs,
};

enum eProvidedSignalsID
{
    PS_ScanSeqNum = 0,
    PS_ScanTimeStamp,
    PS_EgoVelX,
    PS_EstEgoVelX,
    PS_EgoVelY,
    PS_EstEgoVelY,
    PS_RadarChipTemp,
    PS_NumProvidedSigIDs,
};

enum eDetFlags
{
    DF_Static = (1 << 0),
    DF_Filtered = (1 << 1),
    DF_Reinterpolate = (1 << 2),
    DF_FromStaticSlice = (1 << 3),
};

static const char* ProvidedDataNames[PD_NumProvidedDataIDs] = {
  "UhdpScanParameter", "DetnListUhdp", "PointCloudUhdp", "ClutterImgUhdp",
  "ScanDataUhdp",  "TimerValues",  "ScanInfo",       "DetnList",
  "EmeHist",       "PntCloud",     "AngleBins",      "RangeBins",
  "ScanComplete"
};

struct DataMemory_t
{
    void* pSrc;
    int nMaxSize;
};

struct DataMemoryChunk_t
{
    void* pSrc1;
    void* pSrc2;
    int nCount1;
    int nCount2;
    int nSrcOffset1;
    int nSrcOffset2;
    int nDestOffset1;
    int nDestOffset2;
    int nMaxSize;
};

struct Telemetry_t
{
    float vx, vy, vz;
    uint32_t  age;

    Telemetry_t()
    {
        vx = vy = vz = 0.0f;
        age = 0u;
    }
};

#endif //_RRA_CLIENT_TYPES_HEADER_
