//--------------------------------------------------------------------------
/// @file SharedLibIntfCustom.hpp
/// @brief TestRunner to a software component
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _SHAREDLIBINTFCUSTOM_HPP_
#define _SHAREDLIBINTFCUSTOM_HPP_

#include "SharedLibAdapter.hpp"
#include "SharedLibIntf.hpp"
#include "SharedLibIntfCfg.hpp"
#include "RraClientErrorTypes.hpp"


//! TestRunner to a software component
//! \warning not thread safe yet!
class cSharedLibIntfCustom
    : public cSharedLibIntf
{
public:

    //! call in cFilter::Init(), case: StageNormal
    virtual signed long long Load(
        std::wstring& sharedLibRelPath, 
        void* exceptionPtr = NULL) override
    {
        signed long long res = cSharedLibAdapter::Load(sharedLibRelPath, exceptionPtr);

        setImportInterface();

        return res;
    }

    //! Returns zero in case of success. See error handling of the respecive
    //! software component.
    //! @param[in] callbacks
    //! @param[in] parameter
    //! TODO type check
    template<typename T, typename U> 
    Result_t Init(T* callbacks, U* properties) const
    {
        FctPtr_Init_t FctPtr_Init = 
            reinterpret_cast<FctPtr_Init_t>(Runnables[RNBL_Init]);

        return FctPtr_Init(callbacks, properties);
    }

    //! Returns zero in case of success. See error handling of the respecive
    //! software component.
    //! @param[in] void
    Result_t Connect() const
    {
        FctPtr_Connect_t FctPtr_Connect = 
            reinterpret_cast<FctPtr_Connect_t>(Runnables[RNBL_Connect]);

        return FctPtr_Connect();
    }

    //! Returns zero in case of success. See error handling of the respecive
    //! software component.
    //! @param[in] timeval
    //! TODO type check
    template<typename T> 
    Result_t Start(T& timeval) const
    {
        FctPtr_Start_t FctPtr_Start = 
            reinterpret_cast<FctPtr_Start_t>(Runnables[RNBL_Start]);

        return FctPtr_Start(timeval);
    }

    //! Returns zero in case of success. See error handling of the respecive
    //! software component.
    //! @param[in] void
    Result_t Stop() const
    {
        // TODO use static cast
        FctPtr_Stop_t FctPtr_Stop = 
            reinterpret_cast<FctPtr_Stop_t>(Runnables[RNBL_Stop]);

        return FctPtr_Stop();
    }

    //! Returns zero in case of success. See error handling of the respecive
    //! software component.
    //! @param[in] void
    Result_t Disconnect() const
    {
        FctPtr_Disconnect_t FctPtr_Disconnect = 
            reinterpret_cast<FctPtr_Disconnect_t>(Runnables[RNBL_Disconnect]);

        return FctPtr_Disconnect();
    }

    //! Returns zero in case of success. See error handling of the respecive
    //! software component.
    //! @param[in] void
    Result_t Receive() const
    {
        FctPtr_Receive_t FctPtr_Receive = 
            reinterpret_cast<FctPtr_Receive_t>(Runnables[RNBL_Receive]);

        return FctPtr_Receive();
    }

    //! Returns zero in case of success. See error handling of the respecive
    //! software component.
    //! @param[in] timeval
    //! TODO type check
    template<typename T> 
    Result_t SendTelemetry(T& timeval) const
    {
        FctPtr_SendTelemetry_t FctPtr_SendTelemetry = 
            reinterpret_cast<FctPtr_SendTelemetry_t>(Runnables[RNBL_SendTelemetry]);

        return FctPtr_SendTelemetry(timeval);
    }

    //! Returns software version
    //! @param[in] void
    //! TODO type check
    template<typename T> 
    T GetSrsVersion() const
    {
        FctPtr_GetSrsVersion_t FctPtr_GetSrsVersion = 
            reinterpret_cast<FctPtr_GetSrsVersion_t>(
            Runnables[RNBL_GetSrsVersion]);

        T version = FctPtr_GetSrsVersion();

        return version;
    }

    //! Returns software version
    //! @param[in] void
    //! TODO type check
    template<typename T> 
    T GetRraVersion() const
    {
        FctPtr_GetRraVersion_t FctPtr_GetRraVersion = 
            reinterpret_cast<FctPtr_GetRraVersion_t>(
            Runnables[RNBL_GetRraVersion]);

        T version = FctPtr_GetRraVersion();

        return version;
    }

    //! Returns number of supported antenna configurations
    //! @param[in] void
    //! TODO type check
    template<typename T> 
    T GetNumAntennaConfigs() const
    {
        FctPtr_GetNumAntennaConfigs_t FctPtr_GetNumAntennaConfigs = 
            reinterpret_cast<FctPtr_GetNumAntennaConfigs_t>(
            Runnables[RNBL_GetNumAntennaConfigs]);

        T num = FctPtr_GetNumAntennaConfigs();

        return num;
    }

    //! Returns the name of the antenna configuration corresponding
    //! to the number given as function argument
    //! @param[in] num
    //! TODO type check
    template<typename T, typename U> 
    T GetAntennaConfigName(U num) const
    {
        FctPtr_GetAntennaConfigName_t FctPtr_GetAntennaConfigName = 
            reinterpret_cast<FctPtr_GetAntennaConfigName_t>(
            Runnables[RNBL_GetAntennaConfigName]);

        T name = FctPtr_GetAntennaConfigName(num);

        return name;
    }

    //! Returns the name of the current log file and initiates a reset
    //! in file logging and starts with a new log file
    //! @param[in] void
    //! TODO type check
    template<typename T> 
    T GetLogNameAndReset() const
    {
        FctPtr_GetLogNameAndReset_t FctPtr_GetLogNameAndReset = 
            reinterpret_cast<FctPtr_GetLogNameAndReset_t>(
            Runnables[RNBL_GetLogNameAndReset]);

        T name = FctPtr_GetLogNameAndReset();

        return name;
    }

    //! Returns void. Sets the interface version number
    //! @param[in] version number
    //! TODO type check
    template<typename T> 
    void SetInterfaceVersion(T version) const
    {
        FctPtr_SetInterfaceVersion_t FctPtr_SetInterfaceVersion = 
            reinterpret_cast<FctPtr_SetInterfaceVersion_t>(
                Runnables[RNBL_SetInterfaceVersion]);

        FctPtr_SetInterfaceVersion(version);
    }

public:
    void* RPorts[RP_NumPorts];
    void* PPorts[PP_NumPorts];

private:
    FctPtrCdecl Runnables[RNBL_NumRunnables];

    void setImportInterface()
    {
        for (int i = 0; i < RP_NumPorts; i++)
        {
            RPorts[i] = GetSymbol(RequiredPortNames[i]);
        }

        for (int i = 0; i < PP_NumPorts; i++)
        {
            PPorts[i] = GetSymbol(ProvidedPortNames[i]);
        }

        for (int i = 0; i < RNBL_NumRunnables; i++)
        {
            Runnables[i] = reinterpret_cast<FctPtrCdecl>(
                GetSymbol(RunnableNames[i]));
        }
    }
};

#endif
