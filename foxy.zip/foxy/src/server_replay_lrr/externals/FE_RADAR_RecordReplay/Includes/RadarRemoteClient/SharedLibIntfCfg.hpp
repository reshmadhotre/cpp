//--------------------------------------------------------------------------
/// @file SharedLibIntfCfg.hpp
/// @brief TestRunner types for software component
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _SHAREDLIBINTFCFG_HPP_
#define _SHAREDLIBINTFCFG_HPP_

#include "VersionTypes.hpp"
#include "RraClientTypes.hpp"
#include "RraClientParameter.hpp"
#include "RraClientCallbackFctPtr.h"
#include "RraClientExportIntf.h"


typedef uint8_t Std_ReturnType;
typedef Result_t   ReturnType;
typedef void (__cdecl *FctPtrCdecl)(void);
#if (STANDALONE_MIDW)
typedef ReturnType(__cdecl* FctPtr_Init_t)(RraCallbackFctPtr_t*,
    PropertiesUhdp_t*);
#else
typedef ReturnType (__cdecl *FctPtr_Init_t)(RraCallbackFctPtr_t*, 
    RraProperties_t*);
#endif
typedef ReturnType (__cdecl *FctPtr_Connect_t)(void);
typedef ReturnType (__cdecl *FctPtr_Start_t)(timeval&);
typedef ReturnType (__cdecl *FctPtr_Stop_t)(void);
typedef ReturnType (__cdecl *FctPtr_Disconnect_t)(void);
typedef ReturnType (__cdecl *FctPtr_Receive_t)(void);
typedef ReturnType (__cdecl *FctPtr_SendTelemetry_t)(Telemetry_t&);
typedef const char* (__cdecl *FctPtr_GetSrsVersion_t)(void);
typedef const char* (__cdecl *FctPtr_GetRraVersion_t)(void);
typedef uint32_t (__cdecl *FctPtr_GetNumAntennaConfigs_t)(void);
typedef const char* (__cdecl *FctPtr_GetAntennaConfigName_t)(uint32_t);
typedef const char* (__cdecl *FctPtr_GetLogNameAndReset_t)(void);
typedef void (__cdecl *FctPtr_SetInterfaceVersion_t)(const uint32_t);

typedef const VersionInfo_t* (__cdecl *tFctPtr_VersionType)();

enum eRunnables
{
    RNBL_Init,
    RNBL_Cyclic,
    RNBL_Connect,
    RNBL_Start,
    RNBL_Stop,
    RNBL_Disconnect,
    RNBL_Receive,
    RNBL_SendTelemetry,
    RNBL_GetSrsVersion,
    RNBL_GetRraVersion,
    RNBL_GetNumAntennaConfigs,
    RNBL_GetAntennaConfigName,
    RNBL_GetLogNameAndReset,
    RNBL_SetInterfaceVersion,
    RNBL_NumRunnables,
};

enum eRequiredPorts
{
    RP_None,
    RP_NumPorts,
};

enum eProvidedPorts
{
    PP_None,
    PP_NumPorts,
};


static const char* RunnableNames[RNBL_NumRunnables] =
{
    "Init",
    "Cyclic",
    "Connect",
    "Start",
    "Stop",
    "Disconnect",
    "Receive",
    "SendTelemetry",
    "GetSrsVersion",
    "GetRraVersion",
    "GetNumAntennaConfigs",
    "GetAntennaConfigName",
    "GetLogNameAndReset",
    "SetInterfaceVersion",
};

static const char* ProvidedPortNames[PP_NumPorts] =
{
    "None",
};

static const char* RequiredPortNames[RP_NumPorts] =
{
    "None",
};

template<typename T> 
void TypeCheck_Enumerate(T& portId)
{
    static_assert(is_same<T, Rdc_DetnIteratorType>::value,
        "Enumerate() requires Rdc_DetnIteratorType as type of function parameter");
}

template<typename T> 
void TypeCheck_GetVersionInfo(T portId)
{
    static_assert(is_same<T, MERdrDataCubeMidW_VersionInfoType>::value,
        "Enumerate() requires return tpye MERdrDataCubeMidW_VersionInfoType");
}
#endif
