//--------------------------------------------------------------------------
/// @file MERdr_AntennaConfigurations.h
/// @brief Contains /todo

/// /todo
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef ANTENNACONFIGURATIONS_HEADER
#define ANTENNACONFIGURATIONS_HEADER

enum RadarHwEnum
{
    RH_FRR,
    RH_MRR,
    RH_MRR_EVK,

    RH_NUM_RADAR_TYPES,
};

enum MRRAntennaConfigEnum
{
    MRR_AllTxSetRxMode,
    MRR_Azimuth_1D_ULA,
    MRR_AzimuthElevation_2D_URA,
    MRR_Azimuth_1D_ULA_Comb,
    MRR_AzimuthElevation_2D_URA_Comb,

    MRR_NUM_ANTENNA_CONFIGS,
};

static const char* antenna_config_names_MRR[MRR_NUM_ANTENNA_CONFIGS] =
{
    "MRR - All Tx/Set-1 Rx Mode",
    "MRR - Azimuth 1D ULA",
    "MRR - Azimuth/Elevation 2D URA",
    "MRR - Azimuth 1D ULA (combined)",
    "MRR - Azimuth/Elevation 2D URA (combined)",
};

enum EVKAntennaConfigEnum
{
    EVK_12TxLNA0,
    EVK_12TxLNA1,
    EVK_Tx0OnlyLNA0,
    EVK_Tx0OnlyLNA1,
    EVK_NoTxLNA0,
    EVK_NoTxLNA1,
    EVK_Tx0126711LNA064VRx,
    EVK_Tx0126711LNA164VRx,

    EVK_NUM_ANTENNA_CONFIGS,
};

static const char* antenna_config_names_MRR_EVK[EVK_NUM_ANTENNA_CONFIGS] =
{
    "EVK 12-Tx LNA-0",
    "EVK 12-Tx LNA-1",
    "EVK Tx0-only LNA-0",
    "EVK Tx0-only LNA-1",
    "EVK No-Tx  LNA-0",
    "EVK No-Tx  LNA-1",
    "EVK Tx0,1,2,6,7,11 LNA-0 64-VRx",
    "EVK Tx0,1,2,6,7,11 LNA-1 64-VRx",
};

enum ADBAntennaConfigEnum
{
    ADB_TRADITIONAL_1D,
    ADB_TRADITIONAL_2D,
    ADB_LONE_TX,
    ADB_LONE_RX,
    ADB_LONE_RX2,
    ADB_COMB,
    ADB_WIDE,
    ADB_2D_WITH_TX_3_10,
    ADB_2D_WITH_TX_4_4,
    ADB_1D_DUPS,
    ADB_CORNER_WITH_TX_3_10,
    ADB_CORNER_WITH_TX_4_4,
    ADB_VRX_ALIGN_SPAN_SET,

    // Note: all the antenna configs above this line are referenced in
    // calibration keys, and as such they cannot be re-ordered. antenna configs
    // below this point have a bit more flexibility

    ADB_1D_FULL_ARRAY,
    ADB_1D_FULL_ARRAY_DUPS,
    ADB_PHASED_ARRAY_AZ_8,
    ADB_PHASED_ARRAY_AZ_11,
    ADB_PHASED_ARRAY_2D_8,
    ADB_PHASED_ARRAY_2D_11,
    ADB_PHASED_ARRAY_EL_8,
    ADB_PHASED_ARRAY_EL_11,

    ADB_NUM_ANTENNA_CONFIGS,
};

static const char* antenna_config_names_ADB[ADB_NUM_ANTENNA_CONFIGS] =
{
    "ADB Traditional 1D",
    "ADB Traditional 2D",
    "ADB Lone TX",
    "ADB Lone RX",
    "ADB Lone RX2",
    "ADB Comb",
    "ADB Wide (TX_4x4Y)",
    "ADB 2D with TX_3_10Y",
    "ADB 2D with TX_4x4Y",
    "ADB Azimuth only with dups",
    "ADB Corner with TX_3_10Y",
    "ADB Corner with TX_4x4Y",
    "ADB VRX Align Spanning Set (internal use only)",

    "ADB Azimuth only full array",
    "ADB Azimuth only full array with dups",
    "ADB Phased Array Azimuth Only 8TX",
    "ADB Phased Array Azimuth Only 11TX",
    "ADB Phased Array 2D 8TX",
    "ADB Phased Array 2D 11TX",
    "ADB Phased Array Elevation Only 8TX",
    "ADB Phased Array Elevation Only 11TX",
};

enum TuragAntennaConfigEnum
{
    TAC_LRR_AZIMUTH,
    TAC_LRR_ELEVATION,
    TAC_MRR_AZIMUTH,
    TAC_MRR_ELEVATION,
    TAC_SPANNING_SET2,

    TAC_NUM_ANTENNA_CONFIGS
};

static const char* antenna_config_names_KENPO[TAC_NUM_ANTENNA_CONFIGS] =
{
    "Turag LRR-Azimuth",                               // TAC_LRR_AZIMUTH
    "Turag LRR-Elevation",                             // TAC_LRR_ELEVATION
    "Turag MRR-Azimuth",                               // TAC_MRR_AZIMUTH
    "Turag MRR-Elevation",                             // TAC_MRR_ELEVATION
    "Turag MRR-Elevation with TX 11 (Vrx Alignment)",  // TAC_SPANNING_SET2
};

enum MagnaAntennaConfigEnum
{
    MAC_AZIMUTH,
    MAC_ELEVATION,
    MAC_AZIMUTH_12TX,

    MAC_NUM_ANTENNA_CONFIGS
};

static const char* antenna_config_names_FRR[MAC_NUM_ANTENNA_CONFIGS] =
{
    "Cervelo Lower TX Azimuth",
    "Cervelo All Tx Elevation",
    "Cervelo All Tx Azimuth(VRX)",
};


#endif //ANTENNACONFIGURATIONS_HEADER
