//--------------------------------------------------------------------------
/// @file RraClientExportIntf.h
/// @brief
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _RRACLIENTEXPORTINTF_H
#define _RRACLIENTEXPORTINTF_H

#include "RraClientTypes.hpp"
#include "RraClientErrorTypes.hpp"
#include "RraClientCallbackFctPtr.h"
#include "RraClientParameter.hpp"
#ifndef __GNUC__
#include <Windows.h>
#endif


#if defined(__cplusplus)
extern "C" {
#endif

    extern Result_t Init(RraCallbackFctPtr_t& callbacks, RraProperties_t* properties);

    extern Result_t Connect();

    extern Result_t Start(timeval& baseTime);

    extern Result_t Stop();

    extern Result_t Disconnect();

    extern Result_t Receive();

    extern Result_t SendTelemetry(Telemetry_t& telemetry);

    extern const char* GetSrsVersion();

    extern uint32_t GetNumAntennaConfigs();

    extern const char* GetAntennaConfigName(uint32_t antCfg_ID);

    extern const char* GetLogNameAndReset();

    extern void SetInterfaceVersion(const uint32_t version);

#if defined(__cplusplus)
}
#endif


#endif

