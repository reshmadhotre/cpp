//--------------------------------------------------------------------------
/// @file RraClientCallbackFctPtr.hpp
/// @brief
/// --------------------------------------------------------------------------
/// @copyright MAGNA Electronics - C O N F I D E N T I A L <br>
/// This document in its entirety is CONFIDENTIAL and may not be disclosed,
/// disseminated or distributed to parties outside MAGNA Electronics
/// without written permission from MAGNA Electronics.
///
//  --------------------------------------------------------------------------
#ifndef _RRA_CLIENTCALLBACK_FCTPTR_H
#define _RRA_CLIENTCALLBACK_FCTPTR_H

#include "RraClientTypes.hpp"
#include "RraClientErrorTypes.hpp"


#if defined(__cplusplus)
extern "C" {
#endif

    struct RraCallbackFctPtr_t
    {
        int64_t(*GetStreamTime)(void);
        Result_t(*SetScanSynchTime)(void);
        Result_t(*TransmitData)( eProvidedDataID id, DataMemory_t mem);
        Result_t(*TransmitDataChunk)( eProvidedDataID id, DataMemoryChunk_t mem);
        Result_t(*SetSignalRegistryValuesCbk)(double sigValBuf[]);
    };

#if defined(__cplusplus)
}
#endif

#endif

