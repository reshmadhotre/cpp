#include <iostream>
#include <thread>
#include <mutex>
#include <atomic>
#include <condition_variable>

// shared variables between threads
struct data
{
    int a{0};
    int b{100};
    bool a_ready = false;
}data;

std::mutex mtx;
std::condition_variable cv;

struct data shared_data;

constexpr int MAX=10000;

void produce_a()
{
    int i=0;
    while(i<MAX)
    {
        std::unique_lock<std::mutex> ul(mtx);

        //produce
        ++shared_data.a;
        ++i;
        shared_data.a_ready = true;
        
        ul.unlock();
        cv.notify_one();
        ul.lock();
        cv.wait(ul, []() { return shared_data.a_ready == false; });
    }
}

void consume()
{
    int i=0;
    while(i<MAX)
    {
        std::unique_lock<std::mutex> ul(mtx);
        cv.wait(ul, [] { return shared_data.a_ready ; });
        shared_data.a_ready = false;

        //processing
        ++shared_data.b;
        std::cout<<"a "<<shared_data.a<<" b "<<shared_data.b
        <<" sum "<<shared_data.a + shared_data.b<<std::endl;

        ++i;
        cv.notify_one();
    }
}

/*
void consume()
{
    static int i=0;
    for (; i<MAX; )
    {
        std::unique_lock<std::mutex> ul(mtx);
        cv.wait(ul, [] { return shared_data.b_ready ; });
        shared_data.b_ready = false;
        {
            printf("The multi-threaded i %d a was %d, b was %d\n",i, shared_data.a, shared_data.b);
            std::cout<<"sum "<<shared_data.a+shared_data.b<<std::endl;
            //std::this_thread::yield();
        }
        i++;
        ul.unlock();
    }
}
*/

int main() {

   std::thread t1(produce_a);
   std::thread t2(consume);
   //std::thread t3(consume);
   
   t1.join();
   t2.join();
   //t3.join();


    return 0;
}
