#include<iostream>
#include<mutex>
#include<condition_variable>
#include<queue>
#include<iostream>
#include<atomic>
#include<thread>
#include<memory>

std::mutex mtx;
std::condition_variable cv;

std::atomic<bool> ready{false};

class car
{
    std::string car_name;

public:

    explicit car(std::string name) noexcept
    : car_name(name)
    {
        std::cout << "constructor" << std::endl;
    }

    std::string getname() const
    {
        return car_name;
    }

    car(const car &) = delete;
    car& operator=(const car &) = delete;

    car(const car &&) = delete;
    car& operator=(const car &&) = delete;

    void *operator new(size_t size)
    {
        std::cout << "new operator overloaded" << std::endl;
        void *p = malloc(size);
        return p;
    }

    void operator delete(void *ptr)
    {
        std::cout << "delete operator overloaded" << std::endl;
        free(ptr);
    }

    ~car() 
    {
        std::cout << "destructor" << std::endl;
    } 
};
std::queue<std::unique_ptr<car>> cars_queue;

const std::string bmwcar_name="bmw";
const std::string mercar_name="mercedes";

const int MAX{2};

void producer()
{
 //producing cars   
  int i=0;
  while(i<MAX)
  {
    {
        std::unique_lock<std::mutex> ul(mtx);
        std::string car_brand = (i!=1) ? bmwcar_name: mercar_name;
        std::unique_ptr<car> c = std::make_unique<car>(car_brand);
        cars_queue.push(std::move(c));
        std::cout<<"produced "<< car_brand<<std::endl;
    }
    ++i;    
    ready = true;
    cv.notify_one();
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
  }
}

void consumer()
{
    int i{0};
    while(i<MAX)
    {
        //ignore rest except mercedes
        std::unique_lock<std::mutex> ul(mtx);
        cv.wait(ul, [](){ return ready && !cars_queue.empty(); });
        while( !cars_queue.empty())
        {
            std::unique_ptr<car> c = std::move(cars_queue.front());
            cars_queue.pop();
            if (  c->getname() == mercar_name )
                std::cout<<"Mercedes" <<std::endl;
            else
                std::cout<<c->getname() <<std::endl;
        }
        ++i;
        ready = false;
    }
}

int main()
{
    std::thread t1(producer);
    std::thread t2(consumer);

    t1.join();
    t2.join();
}


