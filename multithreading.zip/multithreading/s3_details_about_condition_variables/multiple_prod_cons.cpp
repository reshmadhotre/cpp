#include <condition_variable>
#include <iostream>
#include <thread>
#include <queue>
#include <algorithm>
#include <atomic>

std::mutex mutex;
std::condition_variable cv; 

std::atomic<int> ready{0};
std::queue<int> queue;

constexpr int MAX{2};

void producer()
{
    int i{0};
    while (i <MAX)
    {
        {
            std::lock_guard<std::mutex> lg(mutex);
            queue.push(i+1);
            std::cout << "[tid=" << std::this_thread::get_id() << "] pushing " << i+1 << " add sleep for 10 ms"<< std::endl;
        }
        ++i;
        cv.notify_all();
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    std::cout <<"producer b4 decr "<< ready<<std::endl;
    --ready;
    std::cout <<"producer after decr "<< ready<<std::endl;
    cv.notify_all();
}

void consumer()
{
    while (true)
    {
        std::unique_lock<std::mutex> ul(mutex);
        std::cout  <<"consumer b4 wait "<< ready<<std::endl;
        cv.wait(ul, [] { return !ready || !queue.empty(); }); // spurious wakeup protection, i.e:
        int i {0} ;
        int a{0}, b{0};
        while (!queue.empty())
        {
            if (i == 0)
                a=queue.front();
            else
                b=queue.front();
            std::cout << "[tid=" << std::this_thread::get_id() << "] consuming " << a+b <<" a "<<a <<" b "<<b<< std::endl;
            queue.pop();
            ++i;
        }
        std::cout <<"consumer "<< ready<<std::endl;
        if (ready == 0)
            break;
    }
}

int main()
{
    ++ready;
    std::thread t1(producer);
    ++ready;
    std::thread t2(producer);

    std::thread cons(consumer);

    t1.join();
    t2.join();
    cons.join();

    std::cout << "Completed!" << std::endl;

    return 0;
}
