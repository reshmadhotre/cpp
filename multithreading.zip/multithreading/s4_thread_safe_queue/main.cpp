#include "thread_safe_queue.h"


int main()
{
	return 0;
}