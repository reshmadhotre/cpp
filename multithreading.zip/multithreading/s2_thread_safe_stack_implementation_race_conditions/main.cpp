
#include <iostream>

#include "thread_safe_stack.h"

int main()
{
	return 0;
}