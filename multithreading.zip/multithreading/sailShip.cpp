#include<iostream>
#include<thread>
#include<memory>

class thread_guard{
  std::thread &t;
  bool joinability;
public:
  explicit thread_guard(bool _joinability, std::thread &_t)
  : t(_t),
  joinability(_joinability)
  {}
  ~thread_guard()
  {
      if (t.joinable())
      {
          if (joinability)
            t.join();
          else
            t.detach();
      }
  }
  thread_guard (const thread_guard &t) = delete;
  thread_guard& operator= (const thread_guard &t) = delete;
};

enum class Command: std::uint16_t
{
    INVALID_COMMAND,
    CLEAN=1,
    FULL_SPEED=2,
    STOP_ENGINE=3,
    PROGRAM_EXIT=100
};
Command InttoCommand(std::uint16_t input)
{
    Command retVal = Command::INVALID_COMMAND;
    switch(static_cast<Command>(input))
    {
        case Command::CLEAN:
            retVal = Command::CLEAN;
            break;
        case Command::FULL_SPEED:
            retVal = Command::FULL_SPEED;
            break;
        case Command::STOP_ENGINE:
            retVal = Command::STOP_ENGINE;
            break;
        case Command::PROGRAM_EXIT:
            retVal = Command::PROGRAM_EXIT;
            break;
        default: retVal = Command::INVALID_COMMAND;
            break;
    }
    return retVal;
}

void cleanShip()
{
    std::cout<<"Cleaning the ship id"<<std::this_thread::get_id()<<"\n";
    std::this_thread::sleep_for(std::chrono::milliseconds(5000));
    std::cout<<"Cleaning the ship done "<<"\n";
}

void fullSpeed()
{
    std::cout<<"Ship on Full speed - id "<<std::this_thread::get_id()<<"\n";
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    std::cout<<" Ship changed the speed done "<<"\n";
}

void stopEngine()
{
    std::cout<<"Stop the Engine - id "<<std::this_thread::get_id()<<"\n";
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    std::cout<<" Stop the Engine done "<<"\n";
}

class Captain
{
public:
    Captain()
    {}
    bool issueCommand(const Command& command)
    {
      switch(command)
      {
          case Command::CLEAN:
              {
                std::thread crew_thread(cleanShip);
                bool joinability = false;
                thread_guard crew_tg(joinability, crew_thread);
              }    
            return true;
          case Command::FULL_SPEED:
              {
                std::thread full_speed_thread(fullSpeed);
                bool joinability = true;
                thread_guard full_speed_tg(joinability, full_speed_thread);
              }
            return true;
          case Command::STOP_ENGINE:
              {
                std::thread stop_engine_thread(stopEngine);
                bool joinability = true;
                thread_guard stop_engine_tg(joinability, stop_engine_thread);
              }
            return true;
          case Command::PROGRAM_EXIT:
              std::cout<<"Main: Docking the ship\n";
              return false;
          case Command::INVALID_COMMAND:
          default: std::cout<<"Invalid order\n";
              return true;
      }
     }
};
void provideTheCommandCaptain()
{
    std::cout<<"Captain please issue the command\n" 
    "1: Clean the ship\n"
    "2: Full speed sailing\n"
    "3: Stop the ship\n"
    "100: End the program ship\n";
}

int main()
{
    auto captain = std::make_unique<Captain>();
    provideTheCommandCaptain();
    
    bool isSailing = true;
    while(isSailing)
    {
        std::cout<<"Captian : Please give the command\n";
        std::uint16_t input;
        std::cin>>input;
        
        const auto& command = InttoCommand(input);
        isSailing = captain->issueCommand(command);
    }
    return 0;
}


/*


32-bits Unsigned Integers are represented as stop bit encoded entities.
The stop bit decoding process of integer fields is:
1.  Determine the length by the stop bit algorithm.
2.  Remove stop bit from each byte.
3.  Combine 7-bit words (without stop bits) to determine actual integer.

  Stop bit encoded value        0 0 0 0 0 0 0 1   0 0 0 1 1 0 1 0   1 0 0 1 0 0 1 0
Integer stop bit decoded value  0 0 0 0 0 0 1     0 0 1 1 0 1 0     0 0 0 1 0 0 1 0 
      Actual value                         1001101 00010010 = 19730

1 0 0 0 0 0 0 1


#include <iostream>
#include<stdint.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

std::uint64_t decode(const char* stream, size_t len)
{
    std::vector<char> buffer(len, (char)'0');
    int count{0};
    for (int i{0}, j{0}; i<len; ++i)
    {
        if ((i==0)  || ((i%8) == 0))
        {
           if (stream[i] == (char)'1')
           {
                buffer[j++] = stream[i] ^ 1;
           }
           else
           {
              ++count;
           }
        }
        else
        {
          buffer[j++] = stream[i];
        }
    }

  buffer.resize(len-count);
  std::string result{buffer.begin(), buffer.end()};
  std::uint64_t int_result = stol(result, 0, 2);

  return int_result;
}

int main()
{
    //const char* input{"100000001001101010010010"};
    //const char* input{"000000000001101010010010"};
    //const char* input{"10000000"};
    const char* input{"000000010001101010010010"};

    size_t length{strlen(input)};
    std::uint64_t result{decode(input, length)};

    std::cout<<"Result "<<result<<std::endl;
}
*/