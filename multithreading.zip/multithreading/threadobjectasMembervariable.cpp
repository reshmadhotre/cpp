//To make thread object as member variable of class
#include <iostream>
#include <thread>
#include <vector>
#include <iostream>
#include <assert.h>
#include <chrono>

using namespace std;

class ThreadTest
{
    std::thread m_threadObj;
    bool m_joinable{true};
public:
        ThreadTest(const ThreadTest&) = delete;
        ThreadTest& operator=(const ThreadTest&) = delete;

        ThreadTest(std::function<void()> func, bool joinable)
        : m_threadObj(func)
        , m_joinable(joinable) {}

        //move constructor
        ThreadTest(ThreadTest&& obj)
        {
    		cout<<" move constructor "<<endl;
    		m_threadObj = std::move(obj.m_threadObj);
	}

        //move assignment operator
        ThreadTest& operator=(ThreadTest&& obj)
        {
	    cout<<" move assignment operator "<<endl;
	    if(m_threadObj.joinable())
		m_threadObj.join();
	    m_threadObj = std::move(obj.m_threadObj);
	    return *this;
	}

        //Destructor
        ~ThreadTest()
        {
	    if(m_threadObj.joinable())
	    	if (m_joinable)
		   m_threadObj.join();
		else
		   m_threadObj.detach();
	}
};

int main()
{
    std::vector<ThreadTest> threadVec;
    std::function<void()> func = [](){
        cout<<" lambda func and "<<endl;
        cout << " Thread id is " << std::this_thread::get_id() << endl;
    };


    ThreadTest threadObj1(func);//will call callback function i.e.
                                //lambda function
                                //as soon as thread object is created
    ThreadTest threadObj2(func);
    ThreadTest threadObj3(func);
    ThreadTest threadObj4(func);

    threadVec.push_back(std::move(threadObj1));//will call move constructor
    threadVec.push_back(std::move(threadObj2));
    threadVec.push_back(std::move(threadObj3));

    threadVec[2] = std::move(threadObj4);//here
                            //move assignment operator
                            //is called

    //threadVec.push_back(std::move(ThreadTest threadObj3(func)));
    return 0;
}
