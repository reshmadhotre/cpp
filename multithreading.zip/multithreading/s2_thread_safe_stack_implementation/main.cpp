
#include <iostream>

#include "trivial_stack.h"

int main()
{
	return 0;
}