#include "circle_widget.h"
#include <QPainter>

//CircleWidget::CircleWidget(QWidget *parent) : QWidget(parent)
//{

//}

//void CircleWidget::paintEvent(QPaintEvent * ev)
//{
//    QPainter painter( this );

//    painter.setRenderHint( QPainter::Antialiasing );

//    painter.setPen(QColor(255, 0, 0));
//    painter.setBrush(QColor(255, 0, 0));
//    painter.drawEllipse(0, 0, 20, 20);
//}
