import sys, time
from PySide6.QtWidgets import *
from PySide6.QtGui import *
from PySide6.QtCore import *

class sliderdemo(QWidget):
   def __init__(self, parent = None):
      super(sliderdemo, self).__init__(parent)

      self.setFixedSize(200, 100)
      layout = QVBoxLayout()
      self.l1 = QLabel("Hello")
      self.l1.setAlignment(Qt.AlignCenter)
      layout.addWidget(self.l1)
		
      self.sl = QSlider(Qt.Horizontal)
      self.sl.setMinimum(10)
      self.sl.setMaximum(30)
      self.sl.setValue(20)
      self.sl.setTickPosition(QSlider.TicksBelow)
      self.sl.setTickInterval(5)
		
      layout.addWidget(self.sl)
      self.sl.valueChanged.connect(self.valuechange)
      self.setLayout(layout)
      self.setWindowTitle("SpinBox demo")

   def valuechange(self):
      size = self.sl.value()
      self.l1.setFont(QFont("Arial",size))
      
class Slider(QSlider):
    minimumChanged = Signal(int)
    maximumChanged = Signal(int)

    def setMinimum(self, minimum):
        self.minimumChanged.emit(minimum)
        super(Slider, self).setMinimum(minimum)

    def setMaximum(self, maximum):
        self.maximumChanged.emit(maximum)
        super(Slider, self).setMaximum(maximum)
        
class Example(QWidget):
    
    def __init__(self):
        super(Example, self).__init__()
        self.initUI()

    def initUI(self):
        self.label = QLabel(alignment=Qt.AlignCenter)

        self.slider = Slider(tickPosition=QSlider.TicksLeft,
            orientation=Qt.Horizontal)
        slider_vbox = QVBoxLayout()
        slider_hbox = QHBoxLayout()
        slider_hbox.setContentsMargins(0, 0, 0, 0)
        slider_vbox.setContentsMargins(0, 0, 0, 0)
        slider_vbox.setSpacing(0)
        label_minimum = QLabel(alignment=Qt.AlignLeft)
        self.slider.minimumChanged.connect(label_minimum.setNum)
        label_maximum = QLabel(alignment=Qt.AlignRight)
        self.slider.maximumChanged.connect(label_maximum.setNum)
        slider_vbox.addWidget(self.slider)
        slider_vbox.addLayout(slider_hbox)
        slider_hbox.addWidget(label_minimum, Qt.AlignLeft)
        slider_hbox.addWidget(label_maximum, Qt.AlignRight)
        slider_vbox.addStretch()

        self.slider.setMinimum(0)
        self.slider.setMaximum(100)
        self.slider.setTickInterval(100/5)
        self.slider.setTickPosition(QSlider.TicksBelow)
        #self.slider.setSingleStep(1)
        #self.slider.valueChanged.connect(self.onValueChange)
        #self.slider.setTracking(True)



        vbox = QVBoxLayout(self)
        vbox.addLayout(slider_vbox)
        vbox.addWidget(self.label)
        self.setGeometry(300, 300, 300, 150)
        #self.slider.valueChanged.connect(self.label.setNum)
        
        
        self.label.setText("Hello world")
        
        self.timer = QTimer()
        self.number_of_times = 1
        self.timer.timeout.connect(self.updateSlider)
        self.timer.start(100)
        self.show()

   
    def updateSlider(self):
         if self.number_of_times != 100:
            #self.slider.blockSignals(True);
            self.slider.setValue(int(self.number_of_times))
            #self.slider.blockSignals(False);
            self.label.clear()
            slider_value = "{}".format(self.slider.value())
            #print(f"updateSlider {self.number_of_times} {self.slider.value()}, {slider_value}")
            self.label.setText(f"{slider_value}")
            self.number_of_times = self.number_of_times + 1
         else:
            self.label.setText("Done processing")

    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Quit',
                                     "Quit exit?",
                                     QMessageBox.Yes | QMessageBox.No,
                                     QMessageBox.No)

        if reply != QMessageBox.Cancel:
            response = True if reply == QMessageBox.Yes else  False
            event.accept()
        else:
            event.ignore()

class Filter(QWidget):
    """Common base for all filters"""
    defaultK = 3
    filterCount = 0

    def __init__(self):
        super(Filter, self).__init__()
        lay = QVBoxLayout(self)

        # Variable for the constant of the OpenCV filter
        self.k = 3

        # Label for the slider
        self.k_lbl = QLabel(str(self.k))

        # Increase the number of filters created
        Filter.filterCount += 1

        # Slider for the first OpenCV filter, with min, max, default and step values
        self.thresh_sld = QSlider(Qt.Horizontal, self)
        self.thresh_sld.setFocusPolicy(Qt.NoFocus)
        self.thresh_sld.setMinimum(3)
        self.thresh_sld.setMaximum(51)
        self.thresh_sld.setValue(self.k)
        self.thresh_sld.setSingleStep(2)
        self.thresh_sld.valueChanged.connect(self.changeValue)

        lay.addWidget(self.k_lbl)
        lay.addWidget(self.thresh_sld)

    def changeValue(self, value):
        # Function for setting the value of k1

        print(value)

        if value % 2 == 1:
            self.k = value
        else:
            self.k = value + 1

        self.thresh_sld.setValue(self.k)
        self.k_lbl.setText(str(self.k))

class MainWindow(QWidget):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.filter1 = Filter()
        self.filter2 = Filter()

        # Creates the main layout (vertical)
        v_main_lay = QVBoxLayout()
        # Adds the sliders and their labels to the bottom of the main layout
        v_main_lay.addWidget(self.filter1)
        v_main_lay.addWidget(self.filter2)

        # Sets the main layout
        self.setLayout(v_main_lay)

        # Sets the geometry, position, window title and window default mode
        self.setGeometry(300, 300, 350, 300)
        self.setWindowTitle('Review')
        self.show()
        
def main():
   app = QApplication(sys.argv)
   #ex = sliderdemo()
   ex = Example()
   #ex = MainWindow()
   ex.show()
   sys.exit(app.exec())
	
if __name__ == '__main__':
   main()
