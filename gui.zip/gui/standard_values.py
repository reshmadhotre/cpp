
from PySide6.QtWidgets import ( 
QApplication,QMainWindow,QMessageBox,QFrame,
QVBoxLayout,QScrollArea,QPushButton,QTreeWidget,
QTabWidget,QWidget,QHBoxLayout,QLabel,QTreeWidgetItem )

from PySide6.QtCore import  Qt,QSize

import sys

class Standard(QMainWindow):
    def __init__(self, parent = None):
        super(Standard, self).__init__(parent)

        self.setWindowTitle("Mf4 Replay Tool")

        ''' central widget '''
        self.centralwidget = QWidget()
        self.pagelayout = QHBoxLayout()
        
        self.leftFrame = self.createFrame()
        self.verticalLayout1 = QVBoxLayout(self.leftFrame)

        treeWidget1 = self.createTreeWidget()
        treeWidget2 = self.createTreeWidget()
        label=QLabel("Some text goes here in left frame")
        exit_button=self.createButton("Exit", "Closes the App")
        self.verticalLayout1.addWidget(treeWidget1)
        self.verticalLayout1.addWidget(treeWidget2)
        self.verticalLayout1.addWidget(label)
        self.verticalLayout1.addWidget(exit_button)
        
        self.midFrame = self.createFrame()
        labelmid=QLabel("Some text goes here in mid frame")
        labelmid1=QLabel("GITHUB")
        self.verticalLayout2 = QVBoxLayout(self.midFrame)
        self.verticalLayout2.addWidget(labelmid)
        self.verticalLayout2.addWidget(labelmid1)
        
        self.rightFrame = self.createFrame()
        labelmid=QLabel("Some text goes here in right frame")
        self.verticalLayout3 = QVBoxLayout(self.rightFrame)
        self.verticalLayout3.addWidget(labelmid)

        self.pagelayout.addWidget(self.leftFrame)
        self.pagelayout.addWidget(self.midFrame)
        self.pagelayout.addWidget(self.rightFrame)
        
        self.setCentralWidget(self.centralwidget)
        self.pagelayout.addStretch()
        self.centralwidget.setLayout(self.pagelayout)
        self.show()
        
    def createFrame(self):
        frame = QFrame()
        frame.setFrameShape(QFrame.StyledPanel)
        frame.setFrameShadow(QFrame.Raised)
        return frame
        
    def createTreeWidget(self):
        treeWidget = QTreeWidget()
        treeWidget.setFixedSize(QSize(300,70))
        treeWidget.setColumnCount(1)
        treeWidget.setHeaderLabels(["Drop Menu"])
        treewidget_header = treeWidget.header()
        #treewidget_header.setStretchLastSection(True)
        #treewidget_header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        
        submenu = "Submenu"
        button1 = QPushButton()
        button1.setText("Submenu1")
        button1.clicked.connect(lambda checked: self.button1Clicked())
        
        button2 = QPushButton()
        button2.setText("Submenu2")
        button2.clicked.connect(lambda checked: self.button2Clicked())

        level1 = QTreeWidgetItem(treeWidget, [submenu])
        level1.setText(0, submenu)
        level1.setFlags(Qt.ItemIsEnabled)

        child1 = QTreeWidgetItem(level1, [submenu])
        child1.setText(0,submenu)
        treeWidget.setItemWidget(child1, 0, button1)
        
        child2 = QTreeWidgetItem(level1, [submenu])
        child2.setText(0,submenu)
        treeWidget.setItemWidget(child2, 0, button2)
        return treeWidget
        
    def button1Clicked(self):
        print("button1 clicked")
        
    def button2Clicked(self):
        print("button2 clicked")
        
    def createButton(text, tooltip):
        button =  QPushButton()
        button.setText(text)
        button.setToolTip(tooltip)
    #    button.setDisabled(False)

def main():
    app = QApplication(sys.argv)
    window = Standard()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
    
    
