from yaml_utils import *
from ament_index_python.packages import get_package_share_directory, get_package_prefix
import os


class NodeConfigUtil():

    """
    Parse the params.yaml and params_info.yaml from the config folder of ros packages
    """

    def getConfig(self, package_name: str, file_name: str):

        try:

            package_share_dir = get_package_share_directory(package_name)

            config_file_path = os.path.join(
                package_share_dir, "config", file_name)
            return parseYamlFile(config_file_path)

        except Exception as e:
            print(f"Error getting config info for package: {package_name}, filename : {file_name}")
            return None
