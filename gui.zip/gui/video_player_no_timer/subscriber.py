from video_replay_server.msg import MsgVideoReplayStatus

import rclpy
from rclpy.node import Node

from PySide6.QtCore import QTimer

class Subscriber(Node):
    def __init__(self, status_view):
        super(Subscriber, self).__init__('video_player_subscriber_node_gui')

        self.status_view = status_view
        self.createFeedbackSubscriber()
        
        # self.timer = QTimer()
        # self.timer.timeout.connect(self.spinOnce)

    def createFeedbackSubscriber(self):
            self.feedback_subscriber = self.create_subscription(
            MsgVideoReplayStatus, '/topic_video_replay_server_status', self.nodeFeedbackCB, 1)
        
    def nodeFeedbackCB(self, msg):
        print(f"CB node_msg: {msg}")
        self.node_feedback = msg
        print(f"CB node_feedback.status: {self.node_feedback.status}")
        self.status_view.getNodeFeedback(self.node_feedback)

    def getNodeFeedback(self):
        return self.node_feedback
    
    def spinOnce(self):
        print(f"spin started")
        rclpy.spin_once(self, timeout_sec=60)

    def startSpinOnceTimer(self, value):
        #rclpy.init()
        self.timer.start(value)
        
    def stopSpinOnceTimer(self):
        print(f"spin stopped")
        self.timer.stop()
        #rclpy.shutdown()

