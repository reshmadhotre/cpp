import yaml

def parseYamlFile(file_path):
    try:
        with open(file_path, 'r') as file:
            return yaml.safe_load(file)
    except BaseException:
        print(f"Cannot parse {file_path} as yaml!")
        return dict()

def writeYamlFile(file_path, yaml_data):
    yaml.Dumper.ignore_aliases = lambda *args: True
    try:
        with open(file_path, 'w') as file:
            yaml.dump(yaml_data, file, sort_keys=False)
            return True
    except Exception as e:
        print(e)
        print(f"Error saving replay config at : {file_path}")
        return False
