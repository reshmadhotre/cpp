# This Python file uses the following encoding: utf-8

from frames.splash_screen import SplashScreen
from app_controller import AppController
from frames.app_view import AppView
from signal_wakeup_handler import SignalWakeupHandler

from PySide6.QtWidgets import QApplication

import rclpy, sys, signal
from rclpy.executors import ExternalShutdownException

from subscriber import Subscriber

def main():
    rclpy.init()
    app = QApplication(sys.argv)
    SignalWakeupHandler(app)
    signal.signal(signal.SIGINT, lambda sig,_: app.quit())

    try:
        
        #window = SplashScreen()
        app_view = AppView()
        print(f"appview done")
        video_subscriber = Subscriber(app_view.status_frame_dialog)
        print(f"video_subscriber done")
        while(1):
            app.processEvents()
            #rclpy.spin_once(video_subscriber)
            #sys.exit(app.exec())
      
    except ExternalShutdownException:
        sys.exit(1)
    except BaseException:
        print(f"App Closed {sys.stderr}")
        raise
    finally:
        print(f"App Closed Finally {sys.stderr}")

if __name__ == "__main__":
    main()
