import os, subprocess, signal

class SubprocessUtil:

    def __init__(self, cmd: list):
        self.process = None
        self.cmd = cmd

    def launch(self):
        try:
            self.process = subprocess.Popen(self.cmd,
                                            stderr=subprocess.STDOUT,
                                            preexec_fn=os.setsid)
            print(f" launched process self.cmd:{self.cmd}")
            return True

        except Exception as e:
            print(e)
            print(f"Could not launch process : {self.cmd}")

            return False

    def stop(self):
        if self.process:
            self.process.poll()
        if self.process.returncode is None:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
                print(f" killed process self.process.pid:{self.process.pid}")
                return True
            except BaseException:
                print(f"Error : Process with pid - "
                       "{self.process.pid} could not be killed")

                return False

        return True
