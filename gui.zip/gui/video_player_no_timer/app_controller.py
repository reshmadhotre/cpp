from node_config_util import NodeConfigUtil
from subprocess_util import SubprocessUtil
from ros_launch_generator import RosLaunchGenerator
from yaml_utils import *

import subprocess, os, shutil
from pathlib import Path


class AppController():

    def __init__(self):
        super(AppController, self).__init__()

        self.node_config_util = NodeConfigUtil()
        
        self.rviz_launched = False
        self.subprocesses_launched = []
                
        self.ros_launch_process = None

        self.app_config = parseYamlFile("app.settings")
        self.TMP_FOLDER_PATH = Path(self.app_config['TMP_FOLDER_PATH'])
        self.PARAMS_FILE_NAME = self.app_config['PARAMS_FILE_NAME']
        self.PARAMS_INFO_FILE_NAME = self.app_config['PARAMS_INFO_FILE_NAME']
        self.VIDEO_ROS_PACKAGE = self.app_config['VIDEO_ROS_PACKAGE']
        self.VIDEO_ROS_NODE_NAME = self.app_config['VIDEO_ROS_NODE_NAME']

        self.createTmpFolder()

    def createTmpFolder(self):
        """Create a /tmp folder to store logs and launch files"""
        try:

            if not os.path.exists(self.TMP_FOLDER_PATH):
                os.mkdir(self.TMP_FOLDER_PATH)
            os.environ['ROS_LOG_DIR'] = os.path.abspath(self.TMP_FOLDER_PATH)
        except BaseException as e:
            print(e)
            print("Error : Cannot create /tmp folder. Cannot store launch data!")

    def deleteTmpFolder(self):
        if os.path.exists(self.TMP_FOLDER_PATH):

            try:
                shutil.rmtree(self.TMP_FOLDER_PATH)
            except BaseException:
                print(
                    f"Error : Cannot delete {self.TMP_FOLDER_PATH} directory!!")

    def getReplayConfig(self):
        config = []

        video_params_config = self.node_config_util.getConfig(
        package_name=self.VIDEO_ROS_PACKAGE, file_name="params.yaml")
        video_params_info_config = self.node_config_util.getConfig(
            package_name=self.VIDEO_ROS_PACKAGE,
            file_name=self.PARAMS_INFO_FILE_NAME)

        if (video_params_config and video_params_info_config):
            video_config = {}
            video_config['ros_package'] = self.VIDEO_ROS_PACKAGE
            video_config['ros_node_name'] = self.VIDEO_ROS_NODE_NAME
            video_config['params_config'] = video_params_config
            video_config['params_info_config'] = video_params_info_config
            config.append(video_config)
        return config
    
    def onQuit(self, delete_tmp_folder=True):
        for process in self.subprocesses_launched:
            process.stop()
        if delete_tmp_folder:
            self.deleteTmpFolder()
            
    def launch(self, replay_config):
        if replay_config:
            if not self.rviz_launched and not self.isRvizRunning():
                rviz_launch_cmd = ['rviz2']
                rviz_process = SubprocessUtil(rviz_launch_cmd)
                rviz_process.launch()
                self.subprocesses_launched.append(rviz_process)
                self.rviz_launched = True

            ros_launch_generator = RosLaunchGenerator(replay_config)
            launch_file_path = os.path.abspath(
                self.TMP_FOLDER_PATH / "roslaunch_video_player.py")
            ros_launch_generator.generateLaunchFile(launch_file_path)

            cmd = ['ros2', 'launch', launch_file_path]

            self.ros_launch_process = SubprocessUtil(cmd)
            return self.ros_launch_process.launch()

        return False
    
    def stop(self):
        #print(f"contoller stopped status: {self.node_feedback.status} ")
        if self.ros_launch_process:
            return self.ros_launch_process.stop()
        return True

    def isRvizRunning(self):
        process = subprocess.Popen(['ros2', 'node', 'list'],
                                   stdout=subprocess.PIPE,
                                   universal_newlines=True,
                                   bufsize=1)

        while True:
            line = process.stdout.readline()
            if not line:
                break

            node_name = line.rstrip()

            if node_name == '/rviz':
                return True

        return False
