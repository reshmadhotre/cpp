from subscriber import Subscriber

import rclpy
from PySide6.QtCore import QTimer

class SubcriberHandler():
    def __init__(self, status_view):
        super(SubcriberHandler, self).__init__()
        
        self.status_view = status_view
        self.subscriber = Subscriber(self.status_view)
        
    def subscriberStart(self):
        print(f"sub start")
        #rclpy.init()
        
        #rclpy.spin_once(self.subscriber, timeout_sec=100)
        print(f"sub start end")
        
    def subscriberStop(self):
        # Destroy the node explicitly
        # (optional - otherwise it will be done automatically
        # when the garbage collector destroys the node object)
        print(f"sub stop")
        self.subscriber.destroy_node()
        #rclpy.shutdown()
        print(f"sub stop end")
