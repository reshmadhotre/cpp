from PySide6.QtWidgets import( 
    QVBoxLayout, QFormLayout, QMessageBox,
    QLabel, QWidget, QFrame, QProgressBar)
from PySide6.QtCore import QTimer, Qt

from frames.common_widget import *

from video_replay_server.msg import MsgVideoReplayStatus

class StatusFrame(QWidget):

    def __init__(self, app_view, controller):
        super(StatusFrame, self).__init__()

        self.app_view = app_view
        self.main_layout = self.app_view.main_layout
        self.controller = controller

        self.create_rosbag_flag = self.app_view.video_parameters_frame.isChecked('record_rosbags')
        self.rosbag_path = self.app_view.getRosbagPathFolder()
        self.video_finished = False

        ''' Main layout'''
        self.frame = QFrame()

        self.verticalLayout2 = QVBoxLayout()
        self.verticalLayout2.setAlignment(Qt.AlignCenter)
        
        self.formlayout = self.createStatusFrame()
        self.verticalLayout2.addLayout(self.formlayout)
        
        self.createProgressBarFrame()
        self.verticalLayout2.addWidget(self.progress_bar)
        
        self.frame.setLayout(self.verticalLayout2)

        self.main_layout.addWidget(self.frame)

        # self.timer = QTimer()
        # self.timer.timeout.connect(self.update)

    def createStatusFrame(self):

        formlayout = QFormLayout()

        if self.create_rosbag_flag:
            self.setGeometry(10, 10, 740, 180)
            rosbag_path_lbl = createLabel(label_text="Rosbag Path:")

            self.rosbag_path_value = createLabel(label_text=self.rosbag_path)
            self.rosbag_path_value.setWordWrap(True)

            formlayout.addRow(rosbag_path_lbl, self.rosbag_path_value)
        else:
            self.setGeometry(10, 10, 740, 150)

        processing_file_lbl = createLabel(label_text="Processing File : ")

        self.processing_file_value = createLabel(label_text="")
        self.processing_file_value.setFixedHeight(80)
        self.processing_file_value.setWordWrap(True)

        formlayout.addRow(processing_file_lbl, self.processing_file_value)

        timestamp_lbl = createLabel(label_text="Timestamp : ")

        self.timestamp_value = createLabel(label_text="")
        self.timestamp_value.setWordWrap(True)

        formlayout.addRow(timestamp_lbl, self.timestamp_value)

        return formlayout

    def createProgressBarFrame(self):
        self.progress_bar = QProgressBar()
        ''' Progress bar for event with unknown duration'''
        self.progress_bar.setMinimum(0)
        self.progress_bar.setMaximum(0)

    def update(self):
        print(f"update")
        self.getNodeFeedback()

    def getNodeFeedback(self, node_feedback):
        print(f"getNodeFeedback")
        #node_feedback: MsgVideoReplayStatus = self.controller.getNodeFeedback()
        print(f"node_feedback.status: {node_feedback.status}")
        if node_feedback.status == MsgVideoReplayStatus.FINISHED:
            self.video_finished = node_feedback.status
            #self.stopTimers()
            rosbag_text = ""
            if self.create_rosbag_flag:

                rosbag_text = f"\nRosbag saved to : {self.rosbag_path}"

            QMessageBox.information(self, "Rosbag",
                                    f"Finished processing all files. {rosbag_text}",
                                    QMessageBox.Ok)
            self.statusFrameShowHide(False)
            self.app_view.video_parameters_frame.player_frame.stopClicked()
            self.processing_file_value.clear()

        else:
            mf4_file = str(node_feedback.file_under_process)
            if self.processing_file_value.text() != mf4_file:
                self.processing_file_value.clear()
                self.processing_file_value.setText(f"{node_feedback.file_under_process}")

            if self.create_rosbag_flag:
                rosbag_path = str(self.rosbag_path)
                if self.rosbag_path_value.text() != rosbag_path: 
                    self.rosbag_path_value.clear()
                    self.rosbag_path_value.setText(f"{rosbag_path}")
            
            self.timestamp_value.setText(f"{node_feedback.video_timestamp}")

            #status = f"{node_feedback.file_under_process}"
            #self.processing_file_value.setText(status)

    # def stopTimers(self):
    #     print(f"Timers stopped")
    #     # if self.timer.isActive():
    #     #     print(f"update Timers stopped")
    #     #     self.timer.stop()
          

    #     if self.controller.isActiveSpinOnceTimer():
    #         self.controller.stopSpinOnceTimer()
            
    # def startTimers(self, value):
    #     print(f"Timers started")
    #     self.controller.startSpinOnceTimer(value)
    #     #self.updateTimerStart(value)

    def isVideoFinished(self):
        return self.video_finished
    
    def updateTimerStart(self, value):
        print(f"update Timers started")
        self.timer.start(value)

    def statusFrameShowHide(self, value):
        if value:
            self.frame.show()
        else:
            self.frame.hide()
            QTimer.singleShot(0,self.app_view.adjustSize)
