from frames.common_widget import *
from yaml_utils import *

from frames.status_frame import StatusFrame
from .video_parameters_frame import VideoParametersFrame
from app_controller import AppController
from subscriber_handler import SubcriberHandler

from PySide6.QtWidgets import (
    QMessageBox, QVBoxLayout, QMainWindow, 
    QWidget)

class AppView(QMainWindow):

    def __init__(self, parent=None):
        super(AppView, self).__init__(parent)

        self.controller = AppController()
        
        self.setWindowIcon(QIcon('icon.png'))

        replay_config = self.controller.getReplayConfig()
        
        self.input_frames = []
        self.createMainFrame()

        self.createInputFrame(replay_config)
        self.status_frame_dialog = StatusFrame(app_view=self,
                                               controller=self.controller)

        self.status_frame_dialog.statusFrameShowHide(False)

    def createInputFrame(self, replay_config):

        if len(replay_config) == 0:
            QMessageBox.critical(self,
                                 "Config Error", 
                                 "Error parsing node config files. Is the terminal sourced?")

        self.VIDEO_ROS_PACKAGE = "video_replay_server"
        for node_config in replay_config:
            node_package_name = node_config['ros_package']

            if node_package_name == self.VIDEO_ROS_PACKAGE:
                self.video_parameters_frame = VideoParametersFrame(self,
                                                                   node_config=node_config)
                self.input_frames.append(self.video_parameters_frame)

    def resetInputFrame(self, replay_config):
        if len(replay_config) == 0:
            QMessageBox.critical(self,
                                 "Config Error", 
                                 "Error parsing node config files. Is the terminal sourced?")

        for node_config in replay_config:
            if node_config['ros_package'] == self.VIDEO_ROS_PACKAGE:
                self.video_parameters_frame.resetInputFrame(node_config=node_config)

    def generateReplayConfig(self):
        replay_config = []

        for frame in self.input_frames:
            config = frame.getConfig()
            if config is None:
                return None
            replay_config.append(config)

        return replay_config

    def play(self):
        ''' Get current set of values from param frames'''
        replay_config = self.generateReplayConfig()
        if replay_config is not None and len(replay_config) > 0:
            print(f"Launch process")
            if self.controller.launch(replay_config):
                #self.status_frame_dialog.startTimers(0)
                self.subcriber_handle = SubcriberHandler(self.status_frame_dialog)
                self.subcriber_handle.subscriber.startSpinOnceTimer(200)

                self.status_frame_dialog.statusFrameShowHide(True)
                return True
        return False

    def stopClicked(self):
        self.subcriber_handle.subscriber.stopSpinOnceTimer()
        self.subcriber_handle.subscriberStop()
        if self.controller.stop() == False:
            QMessageBox.critical(self, "Stop Error",
                                 "Error stopping replay nodes.",
                                 QMessageBox.Ok)

    def checkIfVideoFinished(self):
        return self.status_frame_dialog.isVideoFinished()
    
    # def getNodeFeedback(self):
    #     return self.controller.getNodeFeedback()

    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Quit',
                                     "Delete /tmp folder with logs on exit?",
                                     QMessageBox.Yes | QMessageBox.No |
                                     QMessageBox.Cancel,
                                     QMessageBox.No)

        if reply != QMessageBox.Cancel:
            response = True if reply == QMessageBox.Yes else False
            event.accept()
            self.controller.onQuit(response)
        else:
            event.ignore()

    def getRosbagPathFolder(self):
        return self.video_parameters_frame.getRosbagPathFolder()
            
    def createMainFrame(self):

        self.setWindowTitle('Video Player')
        self.setWindowIcon(QIcon('icon.png'))
        self.setStyleSheet(u"QMainWindow {background: transparent; }\n"
        "QToolTip {\n"
        "	color: #ffffff;\n"
        "	background-color: rgba(27, 29, 35, 160);\n"
        "	border: 1px solid rgb(40, 40, 40);\n"
        "	border-radius: 2px;\n"
        "}"
        "QWidget {	\n"
        "	background-color: rgb(57, 65, 80);\n"
        "	color: #ffffff;\n"
        "   border :2px rgb(57, 65, 80);"
        "   border-top-left-radius :5px;"
        "   border-top-right-radius : 5px; "
        "   border-bottom-left-radius : 5px; "
        "   border-bottom-right-radius : 5px"
        "}\n"
        "QWidget:hover {\n"
        "	background-color: rgb(57, 65, 80);\n"
        "	border: 2px solid rgb(61, 70, 86);\n"
        "}\n"
        "QWidget:pressed {	\n"
        "	background-color: rgb(85, 170, 255);\n"
        "}"
        "/* SCROLL BARS */\n"
        "QScrollBar:horizontal {\n"
        "    border: none;\n"
        "    background: rgb(52, 59, 72);\n"
        "    height: 14px;\n"
        "    margin: 0px 21px 0 21px;\n"
        "	border-radius: 0px;\n"
        "}\n"
        "QScrollBar::handle:horizontal {\n"
        "    background: rgb(85, 170, 255);\n"
        "    min-width: 25px;\n"
        "	border-radius: 5px\n"
        "}\n"
        "QScrollBar::handle:horizontal {\n"
        "    background: rgb(85, 170, 255);\n"
        "    min-width: 25px;\n"
        "	border-radius: 5px\n"
        "}\n"
        "QScrollBar::add-line:horizontal {\n"
        "    border: none;\n"
        "    background: rgb(55, 63, 77);\n"
        "    width: 20px;\n"
        "	border-top-right-radius: 7px;\n"
        "    border-bottom-right-radius: 7px;\n"
        "    subcontrol-position: right;\n"
        "    subcontrol-origin: margin;\n"
        "}\n"
        "QScrollBar::sub-line:horizontal {\n"
        "    border: none;\n"
        "    background: rgb(55, 63, 77);\n"
        "    width: 20px;\n"
        ""
        "    border-top-left-radius: 5px;\n"
        "    border-bottom-left-radius: 5px;\n"
        "    subcontrol-position: left;\n"
        "    subcontrol-origin: margin;\n"
        "}\n"
        "QScrollBar::up-arrow:horizontal, QScrollBar::down-arrow:horizontal\n"
        "{\n"
        "     background: none;\n"
        "}\n"
        "QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal\n"
        "{\n"
        "     background: none;\n"
        "}\n"
        " QScrollBar:vertical {\n"
        "    border: none;\n"
        "    background: rgb(52, 59, 72);\n"
        "    width: 14px;\n"
        "    margin: 21px 0 21px 0;\n"
        "    border-radius: 0px;\n"
        " }\n"
        " QScrollBar::handle:vertical {	\n"
        "    background: rgb(85, 170, 255);\n"
        "    min-height: 25px;\n"
        "    border-radius: 5px\n"
        " }\n"
        " QScrollBar::add-line:vertical {\n"
        "    border: none;\n"
        "    background: rgb(55, 63, 77);\n"
        "    height: 20px;\n"
        "    border-bottom-left-radius: 5px;\n"
        "    border-bottom-right-radius: 5px;\n"
        "    subcontrol-position: bottom;\n"
        "    subcontrol-origin: margin;\n"
        " }\n"
        " QScrollBar::sub-line:vertical {\n"
        "    border: none;\n"
        "    background: rgb(55, 63"
        ", 77);\n"
        "     height: 20px;\n"
        "     border-top-left-radius: 5px;\n"
        "     border-top-right-radius: 5px;\n"
        "     subcontrol-position: top;\n"
        "     subcontrol-origin: margin;\n"
        " }\n"
        " QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {\n"
        "     background: none;\n"
        " }\n"
        "\n"
        " QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {\n"
        "     background: none;\n"
        " }\n"
        "\n")
        
        self.centralwidget = QWidget()

        ''' Main layout'''
        self.main_layout = QVBoxLayout()

        self.setCentralWidget(self.centralwidget)
        self.centralwidget.setLayout(self.main_layout)
