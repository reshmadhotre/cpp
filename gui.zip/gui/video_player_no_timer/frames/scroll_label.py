from PySide6.QtWidgets import (
    QVBoxLayout, QLabel,
    QWidget, QScrollArea)
from PySide6.QtCore import Qt,QSize

class ScrollLabel(QScrollArea):

    def __init__(self, *args, **kwargs):
        QScrollArea.__init__(self, *args, **kwargs)

        self.setWidgetResizable(True)

        # making qwidget object
        content = QWidget(self)
        ''' rounded frame'''
        content.setStyleSheet(u"QWidget {	\n"
        "	background-color: rgb(27, 29, 35);\n"
        "   border :2px rgb(27, 29, 35);"
        "   border-top-left-radius :5px;"
        "   border-top-right-radius : 5px; "
        "   border-bottom-left-radius : 5px; "
        "   border-bottom-right-radius : 5px"
        "}\n"
        "QWidget:hover {\n"
        "	background-color: rgb(57, 65, 80);\n"
        "	border: 2px solid rgb(61, 70, 86);\n"
        "}\n"
        "QWidget:pressed {	\n"
        "	background-color: rgb(85, 170, 255);\n"
        "}"
        "/* SCROLL BARS */\n"
        "QScrollBar:horizontal {\n"
        "    border: none;\n"
        "    background: rgb(52, 59, 72);\n"
        "    height: 14px;\n"
        "    margin: 0px 21px 0 21px;\n"
        "	border-radius: 0px;\n"
        "}\n"
        "QScrollBar::handle:horizontal {\n"
        "    background: rgb(85, 170, 255);\n"
        "    min-width: 25px;\n"
        "	border-radius: 5px\n"
        "}\n"
        "QScrollBar::handle:horizontal {\n"
        "    background: rgb(85, 170, 255);\n"
        "    min-width: 25px;\n"
        "	border-radius: 5px\n"
        "}\n"
        "QScrollBar::add-line:horizontal {\n"
        "    border: none;\n"
        "    background: rgb(55, 63, 77);\n"
        "    width: 20px;\n"
        "	border-top-right-radius: 7px;\n"
        "    border-bottom-right-radius: 7px;\n"
        "    subcontrol-position: right;\n"
        "    subcontrol-origin: margin;\n"
        "}\n"
        "QScrollBar::sub-line:horizontal {\n"
        "    border: none;\n"
        "    background: rgb(55, 63, 77);\n"
        "    width: 20px;\n"
        ""
        "    border-top-left-radius: 5px;\n"
        "    border-bottom-left-radius: 5px;\n"
        "    subcontrol-position: left;\n"
        "    subcontrol-origin: margin;\n"
        "}\n"
        "QScrollBar::up-arrow:horizontal, QScrollBar::down-arrow:horizontal\n"
        "{\n"
        "     background: none;\n"
        "}\n"
        "QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal\n"
        "{\n"
        "     background: none;\n"
        "}\n"
        " QScrollBar:vertical {\n"
        "    border: none;\n"
        "    background: rgb(52, 59, 72);\n"
        "    width: 14px;\n"
        "    margin: 21px 0 21px 0;\n"
        "    border-radius: 0px;\n"
        " }\n"
        " QScrollBar::handle:vertical {	\n"
        "    background: rgb(85, 170, 255);\n"
        "    min-height: 25px;\n"
        "    border-radius: 5px\n"
        " }\n"
        " QScrollBar::add-line:vertical {\n"
        "    border: none;\n"
        "    background: rgb(55, 63, 77);\n"
        "    height: 20px;\n"
        "    border-bottom-left-radius: 5px;\n"
        "    border-bottom-right-radius: 5px;\n"
        "    subcontrol-position: bottom;\n"
        "    subcontrol-origin: margin;\n"
        " }\n"
        " QScrollBar::sub-line:vertical {\n"
        "    border: none;\n"
        "    background: rgb(55, 63"
        ", 77);\n"
        "     height: 20px;\n"
        "     border-top-left-radius: 5px;\n"
        "     border-top-right-radius: 5px;\n"
        "     subcontrol-position: top;\n"
        "     subcontrol-origin: margin;\n"
        " }\n"
        " QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {\n"
        "     background: none;\n"
        " }\n"
        "\n"
        " QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {\n"
        "     background: none;\n"
        " }\n"
        "\n")
        
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        self.setWidget(content)

        lay = QVBoxLayout(content)
 
        self.label = QLabel(content)
        self.label.setDisabled(False)
        self.label.setStyleSheet(u"color: #ffffff;\n")

        self.label.setAlignment(Qt.AlignLeft)
        self.label.setAlignment(Qt.AlignTop)

        # making label multi-line
        self.label.setWordWrap(True)

        lay.addWidget(self.label)

    def setText(self, text):
        self.label.setText(text)

    def clear(self):
        self.label.clear()

    def setSize(self, height, width):
        self.label.setFixedSize(QSize(height, width))
