from .app_view import AppView

from PySide6.QtWidgets import QMainWindow, QGraphicsDropShadowEffect
from PySide6.QtCore import  QTimer,  Qt, QFile, QIODevice
from PySide6.QtGui import  QIcon, QColor
from PySide6.QtUiTools import QUiLoader

import sys


#Globals
counter = 0
jumper = 0
index = 0


## SPLASH SCREEN WINDOW
class SplashScreen(QMainWindow):
    #def __init__(self, controller):
    def __init__(self):
        QMainWindow.__init__(self)
        
        #self.controller = controller
        ui_file_name = "frames/splash_progress_bar.ui"
        ui_file = QFile(ui_file_name)
        
        if not ui_file.open(QIODevice.ReadOnly):
            print(f"cannot open {ui_file_name}: {ui_file.errorString()}")
            sys.exit(-1)
            
        loader = QUiLoader()
        self.ui = loader.load(ui_file)
        ui_file.close()
        
        if not self.ui:
            print(f" loader : {loader.errorString()}")
            sys.exit(-1)

        #set initial progress bar to 0
        self.progressBarValue(0)

        #Remove title bar 
        self.ui.setWindowFlags(Qt.Window | Qt.FramelessWindowHint)
        #Set background to translucent
        self.ui.setAttribute(Qt.WA_TranslucentBackground)
        
        self.ui.setWindowIcon(QIcon('icon.png'))

        #Apply drop shadow effect
        self.ui.shadow = QGraphicsDropShadowEffect(self)
        self.ui.shadow.setBlurRadius(20)
        self.ui.shadow.setXOffset(0)
        self.ui.shadow.setYOffset(0)
        self.ui.shadow.setColor(QColor(0,0,0,120))

        #self.main = AppView(self.controller)
        self.main = AppView()
        
        self.timer = QTimer()
        self.timer.timeout.connect(self.progress)
        self.timer.start(15)

        self.ui.show()

    def progress(self):
        global counter
        global jumper
        global index

        value = counter

        htmlText = """ <p><span style=" font-size:68pt;">{VALUE}</span><span style=" font-size:48pt; vertical-align:super;">%</span></p>
        """

        newHtml = htmlText.replace("{VALUE}", str(jumper))

        if (value>jumper) :
            self.ui.labelPercentage.setText(newHtml)
            index += 1
            jumper += 10

        if value >= 100: value = 1.000
        self.progressBarValue(value)

        if counter > 100 :

            self.timer.stop()
            self.main.show()
            self.ui.hide()
            self.close()

        counter += 1

    def progressBarValue(self, value):

        styleSheet = """ 
        QFrame{
            border-radius: 150px;
            background-color: qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:{STOP_1} rgba(255,0,127,0), stop:0.750  rgba(85,170,255,255));
        }
        """

        progress = (100 - value) / 100.0

        stop_1 = str(progress - 0.001)
        stop_2 = str(progress)

        newStylesheet = styleSheet.replace("{STOP_1}", stop_1).replace("{STOP_2}", stop_2)
        self.ui.circularProgress.setStyleSheet(newStylesheet)

    def closeEvent(self, event):
        event.accept()
 