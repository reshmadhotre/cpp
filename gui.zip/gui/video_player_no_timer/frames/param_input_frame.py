from .common_widget import *
from .scroll_label import ScrollLabel
from PySide6.QtWidgets import QMainWindow, QMessageBox

import ast

class ParamInputFrame(QMainWindow):
    def __init__(self, param_name, param_value, 
                 value_type="string", value_options=[]):
        super(ParamInputFrame, self).__init__()
        
        self.param_name = param_name
        self.param_value = param_value
        self.value_type = value_type
        self.value_options = value_options
        self.user_entry = str(self.param_name)

    def get(self):
        user_input = self.user_entry
        if user_input == 0 :
            QMessageBox.critical(self, "Value Error",
                                 f"Please enter a value for param"
                                 ": {self.param_name}")
            return None

        elif self.value_type == "double":
            try:
                user_input = float(self.param_value)
            except ValueError:
                QMessageBox.critical(self,"Value Error",
                                     f"Expected a double for param"
                                     ": {self.param_name}")
                return None
        elif self.value_type == "int":
            try:
                user_input = int(self.param_value)
            except ValueError:
                QMessageBox.critical(self,"Value Error",
                                     f"Expected an integer for param"
                                     ": {self.param_name}")
                return None
        elif self.value_type == "bool":
            ''' animated checkbox is_check()'''
            self.param_value = self.check_box.is_checked()
            user_input = self.param_value
            
        elif self.value_type == 'string_array':
            user_input = self.param_value
        else:
            try:
                user_input = str(self.param_value)
            except ValueError:
                QMessageBox.critical(self,"Value Error",
                                     f"Expected a string for param"
                                     ": {self.param_name}")
                return None
        return user_input

    def createInputFrame(self, combo_box = False, 
                         check_box = False, scroll_box = False,
                         spin_box = False, double_spin_box = False,
                         text_box = False, check_box_object = None):
        label = createLabel(self.param_name)
        if combo_box:
            self.combo_box = createComboBox(self.param_name, 
                                            self.param_value,
                                            self.value_options)
            self.box_type = "combobox"
            return label, self.combo_box
        elif check_box:
            if (isinstance(self.param_value, str)):
                checkedState=ast.literal_eval(self.param_value)
            elif (isinstance(self.param_value, bool)):
                checkedState = self.param_value
            self.box_type = "checkbox"

            if check_box_object == None:
                self.check_box, window = createCheckBox(text=self.param_name,
                                                checkedState=checkedState)
            else:
                self.check_box = check_box_object
                window = None

            return self.check_box, window
        elif scroll_box:
            self.scroll_box = ScrollLabel()
            self.box_type = "scrollbox"
            return label, self.scroll_box
        elif spin_box:
            self.spin_box = createSpinBox(self.param_value)
            self.spin_box.valueChanged.connect(lambda: self.spin_box_value())
            self.box_type = "spinbox"
            return label, self.spin_box
        elif double_spin_box:
            self.double_spin_box = createDoubleSpinBox(self.param_value)
            self.double_spin_box.valueChanged.connect(lambda: self.double_spin_box_value())
            self.box_type = "double_spinbox"
            return label, self.double_spin_box
        elif text_box:
            self.text_box = createText(text=self.param_value)
            self.box_type = "text_box"
            return label, self.text_box

    def resetInputFrame(self, param_name, param_value,
                        value_type, value_options):
        self.param_name = param_name
        self.param_value = param_value
        self.value_type = value_type
        self.value_options = value_options
        self.user_entry = str(self.param_name)
        
        if self.box_type == "combobox":
            self.combo_box.blockSignals(True)
            self.combo_box.clear()
            if len(self.value_options):
                self.combo_box.addItems(value_options)
            else:
                self.combo_box.addItem(str(param_value))
            self.combo_box.setCurrentText(str(param_value))

            self.combo_box.blockSignals(False)
        elif self.box_type == "checkbox":
            self.check_box.setChecked(param_value)
        elif self.box_type == "spinbox":
            self.spin_box.blockSignals(True)
            self.spin_box.setValue(param_value)
            self.spin_box.blockSignals(False)
        elif self.box_type == "double_spinbox":
            self.double_spin_box.blockSignals(True)
            self.double_spin_box.setValue(param_value)
            self.double_spin_box.blockSignals(False)
        elif self.box_type == 'text_box':
            self.text_box.setText(param_value)

    def resetCombobox(self, update_value):
        self.param_value = update_value
        self.user_entry = str(self.param_value)
        
        if self.box_type == "combobox":
            self.combo_box.blockSignals(True)
            self.combo_box.clear()
            self.combo_box.addItem(str(update_value))
            self.combo_box.blockSignals(False)
        elif self.box_type == "checkbox":
            self.check_box.setChecked(update_value)
        elif self.box_type == "scrollbox":
            self.scroll_box.setText(update_value)
        elif self.box_type == "spinbox":
            self.spin_box.blockSignals(True)
            self.spin_box.setValue(update_value)
            self.spin_box.blockSignals(False)
        elif self.box_type == "double_spinbox":
            self.double_spin_box.blockSignals(True)
            self.double_spin_box.setValue(update_value)
            self.double_spin_box.blockSignals(False)
        elif self.box_type == 'text_box':
            self.text_box.setText(update_value)

    def spin_box_value(self):
        self.param_value = self.spin_box.value()

    def double_spin_box_value(self):
        self.param_value = self.double_spin_box.value()
