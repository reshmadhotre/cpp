from .animated_checkbox import AnimatedCheckbox

from PySide6.QtWidgets import (
QLabel, QComboBox, QPushButton,
QHBoxLayout,QRadioButton,QWidget,
QFrame,QTabWidget,QSpinBox, QDoubleSpinBox,
QScrollArea, QLineEdit, QStyleOptionTab,
QTabBar,QStyle,QStylePainter)

from PySide6.QtGui import (
QBrush, QColor, QPalette, QFont, QIcon,QPainter)

from PySide6.QtCore import QSize, Qt

'''This combo box scrolls only if opened before.
if the mouse is over the combobox and the mousewheel is turned,
the mousewheel event of the scrollWidget is triggered'''
class ScrollHandleQComboBox(QComboBox):
    def __init__(self, scrollWidget=None, *args, **kwargs):
        super(ScrollHandleQComboBox, self).__init__(*args, **kwargs)  
        self.scrollWidget=scrollWidget
        self.setFocusPolicy(Qt.StrongFocus)
        self.setStyleSheet("/* COMBOBOX */\n"
"QComboBox{\n"
"	background-color: rgb(27, 29, 35);\n"
"	border-radius: 5px;\n"
"	border: 2px solid rgb(27, 29, 35);\n"
"	padding: 5px;\n"
"	padding-left: 10px;\n"
"}\n"
"QComboBox:hover{\n"
"	border: 2px solid rgb(64, 71, 88);\n"
"}\n"
"QComboBox::drop-down {\n"
"	subcontrol-origin: padding;\n"
"	subcontrol-position: top right;\n"
"	width: 25px; \n"
"	border-left-width: 3px;\n"
"	border-left-color: rgba(39, 44, 54, 150);\n"
"	border-left-style: solid;\n"
"	border-top-right-radius: 5px;\n"
"	border-bottom-right-radius: 5px;	\n"
"	background-image: url(:/16x16/icons/16x16/cil-arrow-bottom.png);\n"
"	background-position: center;\n"
"	background-repeat: no-reperat;\n"
" }\n"
"QComboBox QAbstractItemView {\n"
"	color: rgb(85, 170, 255);	\n"
"	background-color: rgb(27, 29, 35);\n"
"	padding: 10px;\n"
"	selection-background-color: rgb(39, 44, 54);\n"
"}\n")

    def wheelEvent(self, event):
        if self.hasFocus():
            return QComboBox.wheelEvent(self, event)
        else:
            return event.ignore()

def createLabel(label_text):
    label = QLabel()
    label.setText(label_text)
    label.setTextInteractionFlags(Qt.TextSelectableByMouse)
    return label

def createText(text=""):
    text_item = QLineEdit()
    text_item.setText(str(text))
    text_item.setStyleSheet(u"/* LINE EDIT */\n"
    "QLineEdit {\n"
    "	background-color: rgb(27, 29, 35);\n"
    "	border-radius: 5px;\n"
    "	border: 2px solid rgb(27, 29, 35);\n"
    "	padding-left: 10px;\n"
    "}\n"
    "QLineEdit:hover {\n"
    "	border: 2px solid rgb(64, 71, 88);\n"
    "}\n"
    "QLineEdit:focus {\n"
    "	border: 2px solid rgb(91, 101, 124);\n"
    "}\n")

    return text_item

def createComboBox(name, textvar, options):
    scrollArea = QScrollArea()
    frmScroll = QFrame(scrollArea)
    combo_box = ScrollHandleQComboBox(frmScroll)
    combo_box.setEditable(True)
    combo_box.setAccessibleName(name)

    if len(options):
        combo_box.addItems(options)
    elif textvar != "":
        combo_box.addItem(str(textvar))
    
    combo_box.setCurrentText(str(textvar))

    return combo_box

def createButton(text, tooltip,icon_flag=False):
    button =  QPushButton()
    button.setText(text)
    button.setToolTip(tooltip)
    
    font = QFont()
    font.setFamily(u"Segoe UI")
    font.setPointSize(9)
    
    button.setMinimumSize(QSize(150, 30))
    button.setFont(font)
    button.setStyleSheet(u"QPushButton {\n"
"	border: 2px solid rgb(52, 59, 72);\n"
"	border-radius: 5px;	\n"
"	background-color: rgb(52, 59, 72);\n"
"   color: #ffffff;\n"
"}\n"
"QPushButton:hover {\n"
"	background-color: rgb(57, 65, 80);\n"
"	border: 2px solid rgb(61, 70, 86);\n"
"}\n"
"QPushButton:pressed {	\n"
"	background-color: rgb(35, 40, 49);\n"
"	border: 2px solid rgb(43, 50, 61);\n"
"}"
"QPushButton::disabled {"
"    background-color: rgb(54, 5d, 5c)"
"    background:  rgb(54, 5d, 5c)"
"}")
    if icon_flag:
        icon = QIcon()
        icon.addFile(u":/16x16/icons/16x16/cil-folder-open.png", QSize(), QIcon.Normal, QIcon.Off)
        button.setIcon(icon)

    return button

def createCheckBox(text, checkedState=False,
                   disabledState=False, label_side='right'):
    check_box = createAnimatedCheckbox(text, 
                                       checkedState,
                                        disabledState)

    lbl = createLabel(text)
    lbl.setStyleSheet(u"   color: #ffffff;\n")
    window = QWidget()
    layout = QHBoxLayout()
    # layout.setSpacing(0)
    # layout.setContentsMargins(0,0,0,0)
    window.setLayout(layout)

    if  label_side == 'right':
        window.layout().addWidget(check_box)
        window.layout().addWidget(lbl)
    elif label_side == 'left':
        window.layout().addWidget(lbl, Qt.AlignTop)
        window.layout().addWidget(check_box, Qt.AlignBottom | Qt.AlignBaseline)

    #window.layout().setContentsMargins(0,0,0,0)
    ''' compactly arrange the widgets in it'''
    layout.insertStretch(-1,1)

    return check_box, window

def createAnimatedCheckbox(text, checkedState=False,
                            disabledState=False):
    check_box = AnimatedCheckbox(
        checked_color="#34AAFF",
        pulse_checked_color="#55AAFF")
    #check_box = QCheckBox()
    #check_box.setFixedSize(check_box.sizeHint())
    #check_box.setFixedSize(30, 27)
    #check_box.setFixedSize(33, 18)
    check_box.setFixedSize(35, 15)
    # print(f" height of check_box: {check_box.height()}")
    # print(f" width of check_box: {check_box.width()}")

    check_box.setText(text)
    check_box.setAccessibleName(text)
    check_box.setAutoFillBackground(False)
    check_box.setDisabled(disabledState)
    check_box.setChecked(checkedState)
    return check_box
    
def createRadioButton(text):
    radio_button = QRadioButton()
    radio_button.setText(text)
    radio_button.setStyleSheet(
"/* RADIO BUTTON */\n"
"QRadioButton::indicator {\n"
"   border: 5px solid rgb(52, 59, 72);\n"
"	width: 15px;\n"
"	height: 15px;\n"
"	border-radius: 5px;\n"
"   background: rgb(44, 49, 60);\n"
"}\n"
"QRadioButton::indicator:hover {\n"
"    border: 5px solid rgb(58, 66, 81);\n"
"}\n"
"QRadioButton::indicator:checked {\n"
"    background: 5px solid rgb(94, 106, 130);\n"
"	border: 5px solid rgb(52, 59, 72);	\n"
"}\n")
    BUTTON_SIZE = QSize(170, 35);
    radio_button.setChecked(False)
    radio_button.setFixedSize(BUTTON_SIZE)
    return radio_button

''' set the tab color of tabwidget'''
class FingerTabBar(QTabBar):
    def __init__(self, *args, **kwargs):
        #self.tabSize = QSize(kwargs.pop('width'), kwargs.pop('height'))
        super(FingerTabBar, self).__init__(*args, **kwargs)

    def paintEvent(self, event):
        style_painter = QStylePainter(self)
        painter = QPainter(self)
        option = QStyleOptionTab()
        style = self.style()

        for index in range(self.count()):
            self.initStyleOption(option, index)
            tabRect = self.tabRect(index)
            tabRect.moveLeft(10)
            ftcolor = QColor(52,59,72)
            bgcolor = QColor(74,91,132 )
            option.palette.setColor(QPalette.Window, bgcolor)
            option.palette.setColor(QPalette.Button, ftcolor)
            style_painter.drawControl(QStyle.CE_TabBarTabShape, option)
            style_painter.drawText(tabRect, Qt.AlignVCenter |\
                             Qt.TextDontClip, \
                             self.tabText(index));
            # style.drawControl(QStyle.CE_TabBarTab, option, painter)

    def tabSizeHint(self,index):
        #return self.tabSize
        return QSize(280,30)

def createTabWidget():
    tabWidget = QTabWidget()
    tabWidget.setTabBar(FingerTabBar())
    tabWidget.setTabPosition(QTabWidget.West)
    tabWidget.setStyleSheet(u"QTabWidget {	\n"
    "	border: 2px solid rgb(52, 59, 72);\n"
    "	border-radius: 5px;	\n"
    "	background-color: rgb(52, 59, 72);\n"
    "}\n"
    "QTabWidget:hover {\n"
    "	background-color: rgb(52, 59, 72);\n"
    "}\n"
    "QTabWidget:pressed {	\n"
    "	background-color: rgb(85, 170, 255);\n"
    "}"
    "QTabWidget:pane {	\n"
    "	border: 3px solid rgb(39, 44, 54); "
    "   border-radius: 5px;"
    "}"
    "QTabBar::tab:!selected {"
    "   background-color: rgb(27, 29, 35)"
     "	border-top-right-radius: 5px;\n"
    "	border-top-left-radius: 5px;\n"
     "	border-bottom-right-radius: 5px;\n"
    "	border-bottom-left-radius: 5px;\n"
    "}"
    "QTabBar::tab:selected {"
    "   background-color: rgb(85, 170, 255)"
     "	border-top-right-radius: 5px solid  rgb(00, 00, 00);\n"
    "	border-top-left-radius: 5px solid  rgb(00, 00, 00);\n"
     "	border-bottom-right-radius: 5px solid  rgb(00, 00, 00);\n"
    "	border-bottom-left-radius: 5px solid  rgb(00, 00, 00);\n"
    "}" )
    return tabWidget

def createPalette():
    palette = QPalette()
    brush = QBrush(QColor(255, 255, 255, 255))
    brush.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.WindowText, brush)
    brush1 = QBrush(QColor(0, 0, 0, 0))
    brush1.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.Button, brush1)
    brush2 = QBrush(QColor(66, 73, 90, 255))
    brush2.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.Light, brush2)
    brush3 = QBrush(QColor(55, 61, 75, 255))
    brush3.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.Midlight, brush3)
    brush4 = QBrush(QColor(22, 24, 30, 255))
    brush4.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.Dark, brush4)
    brush5 = QBrush(QColor(29, 32, 40, 255))
    brush5.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.Mid, brush5)
    brush6 = QBrush(QColor(210, 210, 210, 255))
    brush6.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.Text, brush6)
    palette.setBrush(QPalette.Active, QPalette.BrightText, brush)
    palette.setBrush(QPalette.Active, QPalette.ButtonText, brush)
    palette.setBrush(QPalette.Active, QPalette.Base, brush1)
    palette.setBrush(QPalette.Active, QPalette.Window, brush1)
    brush7 = QBrush(QColor(0, 0, 0, 255))
    brush7.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.Shadow, brush7)
    brush8 = QBrush(QColor(85, 170, 255, 255))
    brush8.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.Highlight, brush8)
    palette.setBrush(QPalette.Active, QPalette.Link, brush8)
    brush9 = QBrush(QColor(255, 0, 127, 255))
    brush9.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.LinkVisited, brush9)
    palette.setBrush(QPalette.Active, QPalette.AlternateBase, brush4)
    brush10 = QBrush(QColor(44, 49, 60, 255))
    brush10.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Active, QPalette.ToolTipBase, brush10)
    palette.setBrush(QPalette.Active, QPalette.ToolTipText, brush6)
    brush11 = QBrush(QColor(210, 210, 210, 128))
    brush11.setStyle(Qt.NoBrush)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
    palette.setBrush(QPalette.Active, QPalette.PlaceholderText, brush11)
#endif
    palette.setBrush(QPalette.Inactive, QPalette.WindowText, brush)
    palette.setBrush(QPalette.Inactive, QPalette.Button, brush1)
    palette.setBrush(QPalette.Inactive, QPalette.Light, brush2)
    palette.setBrush(QPalette.Inactive, QPalette.Midlight, brush3)
    palette.setBrush(QPalette.Inactive, QPalette.Dark, brush4)
    palette.setBrush(QPalette.Inactive, QPalette.Mid, brush5)
    palette.setBrush(QPalette.Inactive, QPalette.Text, brush6)
    palette.setBrush(QPalette.Inactive, QPalette.BrightText, brush)
    palette.setBrush(QPalette.Inactive, QPalette.ButtonText, brush)
    palette.setBrush(QPalette.Inactive, QPalette.Base, brush1)
    palette.setBrush(QPalette.Inactive, QPalette.Window, brush1)
    palette.setBrush(QPalette.Inactive, QPalette.Shadow, brush7)
    palette.setBrush(QPalette.Inactive, QPalette.Highlight, brush8)
    palette.setBrush(QPalette.Inactive, QPalette.Link, brush8)
    palette.setBrush(QPalette.Inactive, QPalette.LinkVisited, brush9)
    palette.setBrush(QPalette.Inactive, QPalette.AlternateBase, brush4)
    palette.setBrush(QPalette.Inactive, QPalette.ToolTipBase, brush10)
    palette.setBrush(QPalette.Inactive, QPalette.ToolTipText, brush6)
    brush12 = QBrush(QColor(210, 210, 210, 128))
    brush12.setStyle(Qt.NoBrush)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
    palette.setBrush(QPalette.Inactive, QPalette.PlaceholderText, brush12)
#endif
    palette.setBrush(QPalette.Disabled, QPalette.WindowText, brush4)
    palette.setBrush(QPalette.Disabled, QPalette.Button, brush1)
    palette.setBrush(QPalette.Disabled, QPalette.Light, brush2)
    palette.setBrush(QPalette.Disabled, QPalette.Midlight, brush3)
    palette.setBrush(QPalette.Disabled, QPalette.Dark, brush4)
    palette.setBrush(QPalette.Disabled, QPalette.Mid, brush5)
    palette.setBrush(QPalette.Disabled, QPalette.Text, brush4)
    palette.setBrush(QPalette.Disabled, QPalette.BrightText, brush)
    palette.setBrush(QPalette.Disabled, QPalette.ButtonText, brush4)
    palette.setBrush(QPalette.Disabled, QPalette.Base, brush1)
    palette.setBrush(QPalette.Disabled, QPalette.Window, brush1)
    palette.setBrush(QPalette.Disabled, QPalette.Shadow, brush7)
    brush13 = QBrush(QColor(51, 153, 255, 255))
    brush13.setStyle(Qt.SolidPattern)
    palette.setBrush(QPalette.Disabled, QPalette.Highlight, brush13)
    palette.setBrush(QPalette.Disabled, QPalette.Link, brush8)
    palette.setBrush(QPalette.Disabled, QPalette.LinkVisited, brush9)
    palette.setBrush(QPalette.Disabled, QPalette.AlternateBase, brush10)
    palette.setBrush(QPalette.Disabled, QPalette.ToolTipBase, brush10)
    palette.setBrush(QPalette.Disabled, QPalette.ToolTipText, brush6)
    brush14 = QBrush(QColor(210, 210, 210, 128))
    brush14.setStyle(Qt.NoBrush)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
    palette.setBrush(QPalette.Disabled, QPalette.PlaceholderText, brush14)
#endif
    return palette

def createFont(size, bold=False):
    font = QFont()
    font.setFamily(u"Segoe UI")
    font.setPointSize(size)
    font.setBold(bold)
    return font

def createFrame(parent, object_name):
    frame_top = QFrame(parent)
    frame_top.setObjectName(object_name)
    frame_top.setMinimumSize(QSize(0, 65))
    frame_top.setMaximumSize(QSize(16777215, 65))
    frame_top.setStyleSheet(u"background-color: transparent;")
    frame_top.setFrameShape(QFrame.NoFrame)
    frame_top.setFrameShadow(QFrame.Raised)
    
def createSpinBox(value):
    spinbox = QSpinBox()
    spinbox.setValue(value)
    spinbox.setStyleSheet("QSpinBox"
        "{ "
        "	background-color: rgb(27, 29, 35);\n"
        "	border-radius: 5px;\n"
        "	border: 2px solid rgb(27, 29, 35);\n"
        "	padding: 5px;\n"
        "	padding-left: 10px;\n}"
        "QSpinBox::hover"
        "{ border: 2px solid rgb(64, 71, 88) }")
        # "QSpinBox::up-arrow"
        # "{border : 1px solid black;}"
        # "QSpinBox::down-arrow"
        # "{border : 1px solid black;}")
  
    return spinbox

def createDoubleSpinBox(value):
    spinbox = QDoubleSpinBox()
    spinbox.setValue(value)
    spinbox.setStyleSheet("QDoubleSpinBox"
        "{ "
        "	background-color: rgb(27, 29, 35);\n"
        "	border-radius: 5px;\n"
        "	border: 2px solid rgb(27, 29, 35);\n"
        "	padding: 5px;\n"
        "	padding-left: 10px;\n}"
        "QDoubleSpinBox::hover"
        "{ border: 2px solid rgb(64, 71, 88) }"
        "QDoubleSpinBox::up-arrow"
        "{border : 1px solid white;}"
        "QDoubleSpinBox::down-arrow"
        "{border : 1px solid white;}")
    return spinbox
