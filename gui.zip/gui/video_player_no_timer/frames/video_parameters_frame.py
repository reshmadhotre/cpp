from .param_input_frame import ParamInputFrame
from .filepath_button import FilepathButton
from .scroll_label import ScrollLabel
from .common_widget import *
from  yaml_utils import *
from .player_frame import PlayerFrame

from subprocess_util import SubprocessUtil

from PySide6.QtWidgets import ( 
QGridLayout, QWidget, QMessageBox, QSpacerItem, QSizePolicy)
from PySide6.QtCore import Qt

import ast

class VideoParametersFrame(QWidget):
    def __init__(self, appview, node_config=None):
        super(VideoParametersFrame, self).__init__()

        self.appview = appview
        self.controller = appview.controller
        self.node_config = node_config
        self.node_name = node_config['ros_node_name']

        self.user_entries = {}

        self.main_layout = self.appview.main_layout

        self.createInputFrame()

    def createInputFrame(self):

        ''' Layout for labels/button'''
        gridlayout = QGridLayout()
        hori_lay_chkbox = QHBoxLayout()
        hori_lay_chkbox.addSpacerItem(QSpacerItem(50, 10, QSizePolicy.Minimum, QSizePolicy.Expanding))

        select_mf4_video_button = createButton(text="  Open Mf4 Video file(s)",
                                               tooltip="Choose the Mf4 Video files",
                                               icon_flag=True)
        gridlayout.addWidget(select_mf4_video_button, 1, 0, Qt.AlignLeft | Qt.AlignHCenter)

        select_mf4_video_file_input = ScrollLabel(self)
        select_mf4_video_file_input.setFixedHeight(80)
        gridlayout.addWidget(select_mf4_video_file_input,2,0,3,2)

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            value_options = self.getValueOptionsFromInfoConfig(param_name)

            if param_name == 'replay_mf4_video_filepaths':
                self.mf4_video_filepath_frame = FilepathButton(select_mf4_video_file_input,
                                  select_mf4_video_button, self.user_entries, "mf4", param_name,
                                  param_value)
                self.user_entries[param_name] = self.mf4_video_filepath_frame

            else:
                param_input_frame = ParamInputFrame(param_name, param_value, 
                                                    value_type, value_options)
                self.user_entries[param_name] = param_input_frame

                if value_type == 'bool':
                    check_box, window = param_input_frame.createInputFrame(check_box=True)
                    check_box.stateChanged.connect(lambda text,
                                           param=param_name: self.checkbox_state_changed(text, param))
                    if param_name == 'standalone_mode':
                        ''' hide it on app view, it is always true'''
                        check_box.setChecked(True)
                        window.setVisible(False)
                        
                    if param_name == 'pause_playback':
                        window.setVisible(False)

                    hori_lay_chkbox.addWidget(window)

        self.main_layout.addLayout(gridlayout)
        self.main_layout.addLayout(hori_lay_chkbox)
        
        self.player_frame = PlayerFrame(self)

        '''compactly arrange all the widgets '''
        #self.main_layout.insertStretch(-1,1)

    def resetInputFrame(self,node_config):
        self.node_config = node_config.copy()

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            value_options = self.getValueOptionsFromInfoConfig(param_name)
            
            if param_name == 'replay_mf4_video_filepaths':
                self.mf4_video_filepath_frame.addFilepathsToEntry(file_paths = param_value)
                self.user_entries[param_name] = self.mf4_video_filepath_frame
            else:
                param_input_frame = self.user_entries[param_name]
                param_input_frame.resetInputFrame(param_name, 
                                                  param_value, 
                                                  value_type,
                                                  value_options)
                self.user_entries[param_name] = param_input_frame

    def getValueTypeFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['type']

        return "string"

    def getValueOptionsFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['values']

        return []

    def getConfig(self):
        if self.updateConfig():
            return self.node_config.copy()
        return None

    def setConfig(self, node_config):
        self.node_config = node_config.copy()
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name in params_config[node_name]['ros__parameters'].keys():
            if param_name != 'replay_mf4_video_filepaths':
                self.user_entries[param_name].set(params_config[node_name]['ros__parameters'][param_name])

    def updateConfig(self):
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]
        for param_name in params_config[node_name]['ros__parameters'].keys():
            user_value = self.user_entries[param_name].get()
            if user_value is None:
                return False
            elif user_value == "":
                QMessageBox.critical(self, "Value Error", f"Expected a value for param : {param_name}")
                return False
            self.node_config['params_config'][node_name]['ros__parameters'][param_name] = user_value
        return True

    def isChecked(self, flag_to_be_checked):
        param_name = flag_to_be_checked
        param_input_frame = self.user_entries[param_name]
        return param_input_frame.check_box.isChecked()
    
    def getRosbagPathFolder(self):
        return self.mf4_video_filepath_frame.getFolderpath()

    def launchSetParameterCommand(self, param_name, is_checked):
        node_name = self.node_name
       
        if (isinstance(is_checked, str)):
            check_value = is_checked
        elif (isinstance(is_checked, int)):
            check_value = 'False' if is_checked == 0 else 'True'

        cmd = ['ros2', 'param', 'set', node_name,
                param_name, check_value]
        print(" cmd: {0}".format(cmd))
        self.ros_launch_set_parameter = SubprocessUtil(cmd)
        self.ros_launch_set_parameter.launch()
        
    def checkbox_state_changed(self, text, param_name):
        if param_name == 'show_timestamp':
            self.launchSetParameterCommand(param_name, text)
    