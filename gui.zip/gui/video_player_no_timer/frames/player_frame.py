from frames.common_widget import *

from video_replay_server.msg import MsgTriggerSingleFrame

from PySide6.QtWidgets import(
    QVBoxLayout, QMessageBox,
    QHBoxLayout, QSpacerItem, QSizePolicy)

from threading import Thread
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node


class PlayerFrame(Node):

    def __init__(self, video_view):
        super(PlayerFrame, self).__init__('video_player_publisher_node_gui')

        self.appview = video_view.appview
        #self.appview.status_frame_dialog.status_frame_window_closed.connect(self.stopClicked)
        self.video_view = video_view
        self.main_layout = video_view.main_layout

        self.controller = video_view.controller

        self.player_mode = "STOP"

        self.createPlayerButtonsFrame()
        self.createPausePlaybackPublisher()
        
        self.executor = MultiThreadedExecutor()

        self.main_layout.addLayout(self.vertical_layout_main)

    def createPlayerButtonsFrame(self):
        ''' Main layout'''
        self.vertical_layout_main = QVBoxLayout()
        self.vertical_layout_main.setSpacing(0)
        self.vertical_layout_main.setContentsMargins(0, 0, 0, 0)

        ''' Layout for button'''
        self.horizontal_layout_btn = QHBoxLayout()
        self.horizontal_layout_btn.setSpacing(0)
        self.horizontal_layout_btn.setContentsMargins(0, 0, 0, 0)

        self.play_pause_btn = createButton(text="  Play",
                                          tooltip="Play/Pause the Video")
        icon = QIcon()
        icon.addFile(u":/16x16/icons/16x16/cil-media-play.png", QSize(), QIcon.Normal, QIcon.Off)
        self.play_pause_btn.setIcon(icon)

        self.next_frame_btn = createButton(text="  Next Frame",
                                           tooltip="Choose the next frame of the Video")
        self.next_frame_btn.setDisabled(True)
        icon1 = QIcon()
        icon1.addFile(u":/20x20/icons/20x20/cil-list.png", QSize(), QIcon.Normal, QIcon.Off)
        self.next_frame_btn.setIcon(icon1)
        
        self.stop_btn = createButton(text="  Stop",
                                           tooltip="Stop the Video player")
        self.stop_btn.setDisabled(True)
        icon2 = QIcon()
        icon2.addFile(u":/20x20/icons/20x20/cil-list.png", QSize(), QIcon.Normal, QIcon.Off)
        self.stop_btn.setIcon(icon2)

        self.play_pause_btn.clicked.connect(lambda checked: self.playPauseClicked())
        self.next_frame_btn.clicked.connect(lambda checked: self.nextFrameClicked())
        self.stop_btn.clicked.connect(lambda checked: self.stopClicked())

        self.horizontal_layout_btn.addWidget(self.play_pause_btn)
        self.horizontal_layout_btn.addSpacerItem(QSpacerItem(10, 0, QSizePolicy.Minimum, QSizePolicy.Minimum))
        self.horizontal_layout_btn.addWidget(self.next_frame_btn)
        self.horizontal_layout_btn.addSpacerItem(QSpacerItem(10, 0, QSizePolicy.Minimum, QSizePolicy.Minimum))
        self.horizontal_layout_btn.addWidget(self.stop_btn)
        
        self.vertical_layout_main.addLayout(self.horizontal_layout_btn)

    def playPauseClicked(self):
        if self.player_mode == "STOP":
            config = self.getRosbagPath()
            if config is None:
                return
            
            ''' start the player client'''
            if self.appview.play():
                self.enablePauseMode()

        elif self.player_mode == "PLAY":
            self.enablePauseMode()
            self.video_view.launchSetParameterCommand(param_name="pause_playback",
                                                      is_checked='False')
            '''start all timers in play state''' 
            #self.appview.subcriber_handle.subscriber.startSpinOnceTimer(0)
        elif self.player_mode == "PAUSE":
            self.enablePlayMode()
            self.video_view.launchSetParameterCommand(param_name="pause_playback",
                                                      is_checked='True')
            '''stop all timers in pause state''' 
            #self.appview.subcriber_handle.subscriber.stopSpinOnceTimer()

    def stopClicked(self):
        self.player_mode = "STOP"
        self.appview.stopClicked()
        self.enableStopMode()
        self.appview.status_frame_dialog.statusFrameShowHide(False)

    def nextFrameClicked(self):
        self.disableWidget(self.next_frame_btn)

        if self.player_mode == "PLAY":

            param_name = 'pause_playback'
            pausePlayValue = self.video_view.isChecked(param_name)
            self.publish_msg = MsgTriggerSingleFrame()
            self.publish_msg.publish_image = pausePlayValue

            result = f'{ "pauseplayvalue :"} {pausePlayValue}'
            self.get_logger().info(result)
            self.next_frame_publisher.publish(self.publish_msg)
        self.enableWidget(self.next_frame_btn)
        self.enableWidget(self.play_pause_btn)
        self.enableWidget(self.stop_btn)

    def enablePlayMode(self):
        self.player_mode = "PLAY"
        self.play_pause_btn.setText("Play")
        self.enableWidget(self.stop_btn)
        self.enableWidget(self.next_frame_btn)

    def enablePauseMode(self):
        self.player_mode = "PAUSE"
        self.play_pause_btn.setText("Pause")
        self.enableWidget(self.stop_btn)
        self.disableWidget(self.next_frame_btn)

    def enableStopMode(self):
        self.player_mode = "STOP"
        self.play_pause_btn.setText("Play")
        self.disableWidget(self.stop_btn)
        self.disableWidget(self.next_frame_btn)

    def enableWidget(self, widget):
        widget.setDisabled(False)

    def disableWidget(self, widget):
        widget.setDisabled(True)

    def getRosbagPath(self):
        return self.video_view.getRosbagPathFolder()

    def createPausePlaybackPublisher(self):
        self.next_frame_publisher = self.create_publisher(MsgTriggerSingleFrame, 
                                                          '/topic_trigger_video_next_frame',
                                                          10)
