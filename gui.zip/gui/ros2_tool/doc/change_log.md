# Revision logs
***Official release: 2.2.2***<br/>
*Last time release: 17-Nov-2022*<br/>
*Last update: 17-Nov-2022*<br/>
<br/>
<br/>

### VERSION 2.2.2
---
- Update LineEdit to setText
- Add validators for ip_address and double values
### VERSION 2.2.1
---
- Add MidWDetectionList topic to RosbagWriter
### VERSION 2.2.0
---
- Enable recoding of rosbags in live mode.
### VERSION 2.1.1
---
- Fix initialization of UDP Receivers.
### VERSION 2.1.0
---
- Update Midw_1d, Midw_2d, Objects_data checkbox values using Ros2 parameters set.
  
 <br/> 

