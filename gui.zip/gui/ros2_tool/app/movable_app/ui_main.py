from app.movable_app.ui_styles import Style
from app.frames.common_widget import *
from PySide6.QtCore import (QCoreApplication,
                            QMetaObject, QSize, Qt)
from PySide6.QtGui import (QIcon)
from PySide6.QtWidgets import *

from .files_rc import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1000, 720)
        MainWindow.setMinimumSize(QSize(1000, 720))

        font = createFont(10)
        MainWindow.setFont(font)
        MainWindow.setStyleSheet(Style.style_mainwindow)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setStyleSheet(Style.style_centralwidget)

        self.hori_layout_central_widget = createHorizontalLayout(self.centralwidget,
                                                                 10, 10, 10, 10)

        self.frame_main = createFrame(parent=self.centralwidget,
                                      style=Style.style_mainframe)
        self.ver_lay_frame_main = createVerticalLayout(self.frame_main)

        self.frame_top = createFrame(self.frame_main, size=True,
                                     style=Style.style_frame_transparent)
        self.hori_layout_frame_top = createHorizontalLayout(self.frame_top)

        self.frame_toggle = createFrame(parent=self.frame_top)
        self.frame_toggle.setMaximumSize(QSize(70, 16777215))
        self.frame_toggle.setStyleSheet(u"background-color: rgb(27, 29, 35);")
        self.ver_lay_frame_toggle = createVerticalLayout(self.frame_toggle)
        self.btn_toggle_menu = createTitlePushButton(parent=self.frame_toggle,
                                                     style=Style.style_toggle_pushbutton,
                                                     size=False,
                                                     hori_policy=QSizePolicy.Expanding)
        self.ver_lay_frame_toggle.addWidget(self.btn_toggle_menu)
        self.hori_layout_frame_top.addWidget(self.frame_toggle)

        self.frame_top_right = createFrame(parent=self.frame_top)
        self.frame_top_right.setStyleSheet(u"background: transparent;")
        self.ver_lay_frame_top_right = createVerticalLayout(parent=self.frame_top_right)

        self.frame_top_btns = createFrame(self.frame_top_right)
        self.frame_top_btns.setMaximumSize(QSize(16777215, 42))
        self.frame_top_btns.setStyleSheet(u"background-color: rgba(27, 29, 35, 200)")
        self.hori_lay_frame_top_btns = createHorizontalLayout(parent=self.frame_top_btns)

        self.frame_label_top_btns = createFrame(parent=self.frame_top_btns)
        sizePolicy1 = createSizePolicy(widget=self.frame_label_top_btns,
                                       ver_policy=QSizePolicy.Preferred)
        self.frame_label_top_btns.setSizePolicy(sizePolicy1)

        self.hori_lay_frame_label_top_btns = createHorizontalLayout(self.frame_label_top_btns,
                                                                    left=5, right=10)
        self.frame_icon_top_bar = createFrame(parent=self.frame_label_top_btns,
                                              style=Style.style_frame_top_bar)
        self.frame_icon_top_bar.setMaximumSize(QSize(30, 30))
        self.frame_icon_top_bar.setFrameShape(QFrame.StyledPanel)
        self.hori_lay_frame_label_top_btns.addWidget(self.frame_icon_top_bar)

        self.label_title_bar_top = CreateFontLabel(parent=self.frame_label_top_btns,
                                                   point=12, style=u"background: transparent;\n""")

        self.hori_lay_frame_label_top_btns.addWidget(self.label_title_bar_top)
        self.hori_lay_frame_top_btns.addWidget(self.frame_label_top_btns)

        self.frame_btns_right = createFrame(self.frame_top_btns)
        sizePolicy1.setHeightForWidth(self.frame_btns_right.sizePolicy().hasHeightForWidth())
        self.frame_btns_right.setSizePolicy(sizePolicy1)
        self.frame_btns_right.setMaximumSize(QSize(120, 16777215))

        self.hori_lay_frame_btns_right = createHorizontalLayout(self.frame_btns_right)
        self.btn_minimize = createTitlePushButton(parent=self.frame_btns_right,
                                                  icon_png=u":/16x16/icons/16x16/cil-window-minimize.png",
                                                  style=Style.style_minimise_button)

        self.hori_lay_frame_btns_right.addWidget(self.btn_minimize)

        self.btn_maximize_restore = createTitlePushButton(parent=self.frame_btns_right,
                                                          icon_png=u":/16x16/icons/16x16/cil-window-maximize.png",
                                                          style=Style.style_maximise_button)
        self.hori_lay_frame_btns_right.addWidget(self.btn_maximize_restore)

        self.btn_close = createTitlePushButton(parent=self.frame_btns_right,
                                               icon_png=u":/16x16/icons/16x16/cil-x.png",
                                               style=Style.style_close_button)
        self.hori_lay_frame_btns_right.addWidget(self.btn_close)

        self.hori_lay_frame_top_btns.addWidget(self.frame_btns_right, 0, Qt.AlignRight)
        self.ver_lay_frame_top_right.addWidget(self.frame_top_btns)

        self.frame_top_info = createFrame(parent=self.frame_top_right,
                                          style=u"background-color: rgb(39, 44, 54);")
        self.hori_lay_frame_top_info = createHorizontalLayout(self.frame_top_info,
                                                              left=10, right=10)
        self.label_top_desc = CreateFontLabel(parent=self.frame_top_info, point=13)
        self.hori_lay_frame_top_info.addWidget(self.label_top_desc)

        self.label_top_page = CreateFontLabel(parent=self.frame_top_info, size=False,
                                              point=10)
        self.label_top_page.setAlignment(Qt.AlignRight | Qt.AlignTrailing)

        self.hori_lay_frame_top_info.addWidget(self.label_top_page)
        self.ver_lay_frame_top_right.addWidget(self.frame_top_info)
        self.hori_layout_frame_top.addWidget(self.frame_top_right)
        self.ver_lay_frame_main.addWidget(self.frame_top)

        self.frame_center = createFrame(parent=self.frame_main,
                                        style=u"background-color: rgb(40, 44, 52);")
        sizePolicy = createSizePolicy(self.frame_center)
        self.frame_center.setSizePolicy(sizePolicy)

        self.horizontalLayout_2 = createHorizontalLayout(self.frame_center)
        self.frame_left_menu = createFrame(parent=self.frame_center,
                                           style=u"background-color: rgb(27, 29, 35);")
        sizePolicy3 = createSizePolicy(widget=self.frame_left_menu,
                                       hori_policy=QSizePolicy.Preferred,
                                       ver_policy=QSizePolicy.Preferred)
        self.frame_left_menu.setSizePolicy(sizePolicy3)
        self.frame_left_menu.setMinimumSize(QSize(70, 0))
        self.frame_left_menu.setMaximumSize(QSize(70, 16777215))
        self.frame_left_menu.setLayoutDirection(Qt.LeftToRight)

        self.verticalLayout_5 = createVerticalLayout(self.frame_left_menu)
        self.frame_menus = createFrame(parent=self.frame_left_menu)
        self.layout_menus = createVerticalLayout(self.frame_menus)
        self.verticalLayout_5.addWidget(self.frame_menus, 0, Qt.AlignTop)

        self.frame_extra_menus = createFrame(parent=self.frame_left_menu)
        sizePolicy4 = createSizePolicy(widget=self.frame_extra_menus,
                                       hori_policy=QSizePolicy.Preferred,
                                       ver_policy=QSizePolicy.Preferred)
        self.frame_extra_menus.setSizePolicy(sizePolicy4)
        self.layout_menu_bottom = createVerticalLayout(self.frame_extra_menus, bottom=25)

        self.verticalLayout_5.addWidget(self.frame_extra_menus, 0, Qt.AlignBottom)
        self.horizontalLayout_2.addWidget(self.frame_left_menu)

        self.frame_content_right = createFrame(parent=self.frame_center,
                                               style=u"background-color: rgb(44, 49, 60);")

        self.verticalLayout_4 = createVerticalLayout(self.frame_content_right)
        self.frame_content = createFrame(parent=self.frame_content_right)
        self.verticalLayout_9 = createVerticalLayout(self.frame_content, left=5, top=5,
                                                     right=5, bottom=5)
        self.stackedWidget = QStackedWidget(self.frame_content)
        self.stackedWidget.setStyleSheet(u"background: transparent;")

        self.verticalLayout_9.addWidget(self.stackedWidget)
        self.verticalLayout_4.addWidget(self.frame_content)

        self.frame_grip = createFrame(parent=self.frame_content_right,
                                      style=u"background-color: rgb(33, 37, 43);")
        self.frame_grip.setMinimumSize(QSize(0, 25))
        self.frame_grip.setMaximumSize(QSize(16777215, 25))
        self.horizontalLayout_6 = createHorizontalLayout(self.frame_grip, right=2)

        self.frame_label_bottom = createFrame(parent=self.frame_grip)
        self.horizontalLayout_7 = createHorizontalLayout(self.frame_label_bottom, left=10, right=10)
        self.horizontalLayout_6.addWidget(self.frame_label_bottom)

        self.frame_size_grip = createFrame(parent=self.frame_grip,
                                           style=Style.style_frame_size_grip)
        self.frame_size_grip.setMaximumSize(QSize(20, 20))

        self.horizontalLayout_6.addWidget(self.frame_size_grip)
        self.verticalLayout_4.addWidget(self.frame_grip)
        self.horizontalLayout_2.addWidget(self.frame_content_right)
        self.ver_lay_frame_main.addWidget(self.frame_center)
        self.hori_layout_central_widget.addWidget(self.frame_main)

        MainWindow.setCentralWidget(self.centralwidget)
        QWidget.setTabOrder(self.btn_minimize, self.btn_maximize_restore)
        QWidget.setTabOrder(self.btn_maximize_restore, self.btn_close)
        QWidget.setTabOrder(self.btn_close, self.btn_toggle_menu)

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(0)
        QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.btn_toggle_menu.setText("")
        self.label_title_bar_top.setText(QCoreApplication.translate("MainWindow", u"Ros2 Tools", None))

        self.btn_minimize.setToolTip(QCoreApplication.translate("MainWindow", u"Minimize", None))
        self.btn_minimize.setText("")
        self.btn_maximize_restore.setToolTip(QCoreApplication.translate("MainWindow", u"Maximize", None))
        self.btn_maximize_restore.setText("")
        self.btn_close.setToolTip(QCoreApplication.translate("MainWindow", u"Close", None))
        self.btn_close.setText("")

        self.label_top_desc.setText(QCoreApplication.translate("MainWindow", u"Home", None))
        self.label_top_page.setText(QCoreApplication.translate("MainWindow", u"| Home", None))
