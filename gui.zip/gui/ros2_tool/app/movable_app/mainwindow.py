
from app.mf4_replay_tool.mf4_replay import Mf4Replay
from app.live_adapter_tool.live_adapter import LiveAdapter
from app.rosbag_replay_tool.rosbag import RosbagReplay

from .ui_main import Ui_MainWindow
from .ui_styles import Style
from app.frames.common_widget import *

from PySide6 import QtCore, QtGui
from PySide6.QtCore import(QPropertyAnimation,
                           QSize, Qt)
from PySide6.QtGui import (QColor, QFont, QIcon)
from PySide6.QtWidgets import *
import rclpy

class MainWindow(QMainWindow):

    def __init__(self, ros2_node_controller):
        QMainWindow.__init__(self)

        QtGui.QFontDatabase.addApplicationFont('fonts/segoeui.ttf')
        QtGui.QFontDatabase.addApplicationFont('fonts/segoeuib.ttf')

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowIcon(QIcon('doc/images/icon.png'))
        self.ros2_node_controller = ros2_node_controller

        UIFunctions.removeTitleBar(True)

        self.setWindowTitle('Ros2 - Tools')
        UIFunctions.labelTitle(self, 'Ros2 Tools')
        UIFunctions.labelDescription(self, 'Home')

        startSize = QSize(1000, 720)
        self.resize(startSize)
        self.setMinimumSize(startSize)
        #UIFunctions.enableMaximumSize(self, 500, 720)

        self.ui.btn_toggle_menu.clicked.connect(lambda: UIFunctions.toggleMenu(self, 220, True))

        self.subprocesses_launched = []
        # ==> ADD CUSTOM MENUS
        self.ui.stackedWidget.setMinimumWidth(20)
        self.home_btn = UIFunctions.addNewMenu(self, "Home", "home_btn",
                                               "url(:/16x16/icons/16x16/cil-home.png)", True)
        self.ethernet_live_btn = UIFunctions.addNewMenu(self, "Ethernet Live", "ethernet_live_btn",
                                                        "url(:/16x16/icons/16x16/cil-ethernet.png)", True)
        self.mf4_replay_btn = UIFunctions.addNewMenu(self, "Mf4 Replay", "mf4_replay_btn",
                                                     "url(:/16x16/icons/16x16/cil-action-redo.png)", True)
        self.can_live_btn = UIFunctions.addNewMenu(self, "Can Live", "can_live_btn",
                                                    "url(:/16x16/icons/16x16/cil-cast.png)", True)
        self.rosbag_btn = UIFunctions.addNewMenu(self, "Rosbag Replay", "rosbag_btn",
                                "url(:/16x16/icons/16x16/cil-reload.png)", False)

        # START MENU => SELECTION
        UIFunctions.selectStandardMenu(self, "home_btn")

        # ==> MOVE WINDOW / MAXIMIZE / RESTORE
        def moveWindow(event):
            # IF MAXIMIZED CHANGE TO NORMAL
            if UIFunctions.returStatus() == 1:
                UIFunctions.maximize_restore(self)

            # MOVE WINDOW
            if event.buttons() == Qt.LeftButton:
                self.move(self.pos() + event.globalPos() - self.dragPos)
                self.dragPos = event.globalPos()
                event.accept()

        # WIDGET TO MOVE
        self.ui.frame_label_top_btns.mouseMoveEvent = moveWindow
        self.ui.btn_close.clicked.connect(lambda: self.close())

        UIFunctions.uiDefinitions(self)

    ########################################################################
    # MENUS ==> DYNAMIC MENUS FUNCTIONS
    ########################################################################

    def Button(self):
        btnWidget = self.sender()
        btnWidget.setStyleSheet(UIFunctions.selectMenu(btnWidget.styleSheet()))

        if btnWidget.objectName() == "home_btn":
            self.ui.stackedWidget.setCurrentWidget(self.home_window)
            UIFunctions.resetStyle(self, "home_btn")
            UIFunctions.labelPage(self, "Home")
            UIFunctions.labelDescription(self, "Home")

        if btnWidget.objectName() == "ethernet_live_btn":
            self.ui.stackedWidget.setCurrentWidget(self.live_adapter_window)
            UIFunctions.resetStyle(self, "ethernet_live_btn")
            UIFunctions.labelPage(self, "Ethernet Live Adapter")
            UIFunctions.labelDescription(self, "Ethernet Live")
            self.subProcessLaunched()
            self.app_controller = self.live_adapter.getAppController()

        if btnWidget.objectName() == "mf4_replay_btn":
            self.ui.stackedWidget.setCurrentWidget(self.mf4_replay_window)
            UIFunctions.resetStyle(self, "mf4_replay_btn")
            UIFunctions.labelPage(self, "Mf4 Replay")
            UIFunctions.labelDescription(self, "Mf4 Replay")
            self.subProcessLaunched()
            self.app_controller = self.mf4_replay.getAppController()

        if btnWidget.objectName() == "can_live_btn":
            self.ui.stackedWidget.setCurrentWidget(self.can_live_adapter_window)
            UIFunctions.resetStyle(self, "can_live_btn")
            UIFunctions.labelPage(self, "Can Live Adapter")
            UIFunctions.labelDescription(self, "Can Live")
            self.subProcessLaunched()
            self.app_controller = self.can_live_adapter.getAppController()

        if btnWidget.objectName() == "rosbag_btn":
            self.ui.stackedWidget.setCurrentWidget(self.rosbag_window)
            UIFunctions.resetStyle(self, "rosbag_btn")
            UIFunctions.labelPage(self, "Rosbag Replay")
            UIFunctions.labelDescription(self, "Rosbag Replay")
            self.subProcessLaunched()
            self.app_controller = self.rosbag_replay.getAppController()

    def subProcessLaunched(self):
        if self.app_controller.subprocesses_launched and not self.subprocesses_launched:
            self.subprocesses_launched = self.app_controller.subprocesses_launched

    def mousePressEvent(self, event):
        self.dragPos = event.globalPos()

    def resizeEvent(self, event):
        return super(MainWindow, self).resizeEvent(event)

    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Quit',
                                     "Delete /tmp folder with logs on exit?",
                                     QMessageBox.Yes | QMessageBox.No |
                                     QMessageBox.Cancel,
                                     QMessageBox.No)

        if reply != QMessageBox.Cancel:
            response = True if reply == QMessageBox.Yes else False
            event.accept()
            if self.subprocesses_launched:
                self.app_controller.subprocesses_launched = self.subprocesses_launched
            self.app_controller.onQuit(response)
            rclpy.shutdown()
        else:
            event.ignore()

    ''' divide the work so that it can be shown
    in progress bar '''

    def createToolWindows(self, index):
        if index == 0:
            self.home_window = self.createHomePanel()
            self.ui.stackedWidget.addWidget(self.home_window)

        elif index == 2:
            self.live_adapter = LiveAdapter()
            self.live_adapter_window = self.live_adapter.liveAdapterView()
            self.app_controller = self.live_adapter.getAppController()
            self.ui.stackedWidget.addWidget(self.live_adapter_window)

        elif index == 4:
            self.app_controller = self.ros2_node_controller
            ''' app config is common so used the same as live adapter'''
            self.mf4_replay = Mf4Replay(self.live_adapter_window.app_config,
                                        self.app_controller)
            self.mf4_replay_window = self.mf4_replay.mf4ReplayView()
            self.ui.stackedWidget.addWidget(self.mf4_replay_window)

        elif index == 6:
            self.can_live_adapter = LiveAdapter(can_live=True)
            self.can_live_adapter_window = self.can_live_adapter.liveAdapterView()
            self.app_controller = self.can_live_adapter.getAppController()
            self.ui.stackedWidget.addWidget(self.can_live_adapter_window)

        elif index == 8:
            self.app_controller = self.ros2_node_controller
            ''' app config is common so used the same as live adapter'''
            self.rosbag_replay = RosbagReplay(self.app_controller)
            self.rosbag_window = self.rosbag_replay.rosbagReplay()
            self.ui.stackedWidget.addWidget(self.rosbag_window)

        elif index == 10:
            self.ui.stackedWidget.setCurrentWidget(self.home_window)
            self.live_adapter_window.live_adapter_window_launch_stop_clicked.connect(self.liveAdapterLaunchStopClicked)
            self.mf4_replay_window.mf4_replay_window_launch_stop_clicked.connect(self.mf4ReplayLaunchStopClicked)
            self.can_live_adapter_window.live_adapter_window_launch_stop_clicked.connect(self.canLiveAdapterLaunchStopClicked)
            self.rosbag_window.rosbag_window_launch_stop_clicked.connect(self.rosbagReplayLaunchStopClicked)

    def liveAdapterLaunchStopClicked(self, clicked_value:bool):
        if clicked_value:
            self.home_btn.setDisabled(True)
            self.mf4_replay_btn.setDisabled(True)
            self.can_live_btn.setDisabled(True)
            self.rosbag_btn.setDisabled(True)
        else:
            self.home_btn.setDisabled(False)
            self.mf4_replay_btn.setDisabled(False)
            self.can_live_btn.setDisabled(False)
            self.rosbag_btn.setDisabled(False)

    def canLiveAdapterLaunchStopClicked(self, clicked_value:bool):
        if clicked_value:
            self.home_btn.setDisabled(True)
            self.mf4_replay_btn.setDisabled(True)
            self.ethernet_live_btn.setDisabled(True)
            self.rosbag_btn.setDisabled(True)
        else:
            self.home_btn.setDisabled(False)
            self.mf4_replay_btn.setDisabled(False)
            self.ethernet_live_btn.setDisabled(False)
            self.rosbag_btn.setDisabled(False)

    def rosbagReplayLaunchStopClicked(self, clicked_value:bool):
        if clicked_value:
            self.home_btn.setDisabled(True)
            self.mf4_replay_btn.setDisabled(True)
            self.ethernet_live_btn.setDisabled(True)
            self.can_live_btn.setDisabled(True)
        else:
            self.home_btn.setDisabled(False)
            self.mf4_replay_btn.setDisabled(False)
            self.ethernet_live_btn.setDisabled(False)
            self.can_live_btn.setDisabled(False)

    def mf4ReplayLaunchStopClicked(self, clicked_value:bool):
        if clicked_value:
            self.home_btn.setDisabled(True)
            self.ethernet_live_btn.setDisabled(True)
            self.can_live_btn.setDisabled(True)
            self.rosbag_btn.setDisabled(True)
        else:
            self.home_btn.setDisabled(False)
            self.ethernet_live_btn.setDisabled(False)
            self.can_live_btn.setDisabled(False)
            self.rosbag_btn.setDisabled(False)

    def createHomePanel(self):
        home_window = QWidget()
        layout = createHorizontalLayout(home_window)
        label = CreateFontLabel(label_text="Coming soon", point=14, 
                                style=u"color: rgb(210, 210, 210); ")
        label.setMaximumSize(QSize(16777215, 35))
        layout.setContentsMargins(400,40,0,0)
        layout.addWidget(label, Qt.AlignHCenter|Qt.AlignCenter)
        return home_window

    ''' open further windows at center'''
    def center(self):
        qr = self.frameGeometry()
        cp = QWidget().QScreen().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())


from .mainwindow import MainWindow

# ==> GLOBALS
GLOBAL_STATE = 0
GLOBAL_TITLE_BAR = True

count = 1


class UIFunctions(MainWindow):

    GLOBAL_STATE = 0
    GLOBAL_TITLE_BAR = True

    # ==> MAXIMIZE/RESTORE
    ########################################################################
    def maximize_restore(self):
        global GLOBAL_STATE
        status = GLOBAL_STATE
        if status == 0:
            self.showMaximized()
            GLOBAL_STATE = 1
            self.ui.hori_layout_central_widget.setContentsMargins(0, 0, 0, 0)
            self.ui.btn_maximize_restore.setToolTip("Restore")
            self.ui.btn_maximize_restore.setIcon(QtGui.QIcon(u":/16x16/icons/16x16/cil-window-restore.png"))
            self.ui.frame_top_btns.setStyleSheet("background-color: rgb(27, 29, 35)")
            self.ui.frame_size_grip.hide()
        else:
            GLOBAL_STATE = 0
            self.showNormal()
            self.resize(self.width() + 1, self.height() + 1)
            self.ui.hori_layout_central_widget.setContentsMargins(10, 10, 10, 10)
            self.ui.btn_maximize_restore.setToolTip("Maximize")
            self.ui.btn_maximize_restore.setIcon(QtGui.QIcon(u":/16x16/icons/16x16/cil-window-maximize.png"))
            self.ui.frame_top_btns.setStyleSheet("background-color: rgba(27, 29, 35, 200)")
            self.ui.frame_size_grip.show()

    def returStatus():
        return GLOBAL_STATE

    def setStatus(status):
        global GLOBAL_STATE
        GLOBAL_STATE = status

    # ==> ENABLE MAXIMUM SIZE
    # def enableMaximumSize(self, width, height):
    #     if width != '' and height != '':
    #         self.setMaximumSize(QSize(width, height))
    #         self.ui.frame_size_grip.hide()
    #         self.ui.btn_maximize_restore.hide()

    # ==> TOGGLE MENU

    def toggleMenu(self, maxWidth, enable):
        if enable:
            # GET WIDTH
            width = self.ui.frame_left_menu.width()
            maxExtend = maxWidth
            standard = 70

            # SET MAX WIDTH
            if width == 70:
                widthExtended = maxExtend
            else:
                widthExtended = standard

            # ANIMATION
            self.animation = QPropertyAnimation(self.ui.frame_left_menu, b"minimumWidth")
            self.animation.setDuration(300)
            self.animation.setStartValue(width)
            self.animation.setEndValue(widthExtended)
            self.animation.setEasingCurve(QtCore.QEasingCurve.InOutQuart)
            self.animation.start()

    def removeTitleBar(status):
        global GLOBAL_TITLE_BAR
        GLOBAL_TITLE_BAR = status

    def labelTitle(self, text):
        self.ui.label_title_bar_top.setText(text)

    def labelDescription(self, text):
        self.ui.label_top_desc.setText(text)

    # ==> DYNAMIC MENUS
    ########################################################################
    def addNewMenu(self, name, objName, icon, isTopMenu, toDisable=False):
        font = QFont()
        font.setFamily(u"Segoe UI")
        button = QPushButton(str(count), self)
        button.setObjectName(objName)
        sizePolicy3 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(button.sizePolicy().hasHeightForWidth())
        button.setSizePolicy(sizePolicy3)
        button.setMinimumSize(QSize(0, 70))
        button.setLayoutDirection(Qt.LeftToRight)
        button.setFont(font)
        button.setStyleSheet(Style.style_bt_standard.replace('ICON_REPLACE', icon))
        button.setText(name)
        button.setToolTip(name)
        button.clicked.connect(self.Button)
        button.setDisabled(toDisable)

        if isTopMenu:
            self.ui.layout_menus.addWidget(button)
        else:
            self.ui.layout_menu_bottom.addWidget(button)

        return button

    def selectMenu(getStyle):
        select = getStyle + ("QPushButton { border-right: 7px solid rgb(44, 49, 60); }")
        return select

    def deselectMenu(getStyle):
        deselect = getStyle.replace("QPushButton { border-right: 7px solid rgb(44, 49, 60); }", "")
        return deselect

    # ==> START SELECTION
    def selectStandardMenu(self, widget):
        for w in self.ui.frame_left_menu.findChildren(QPushButton):
            if w.objectName() == widget:
                w.setStyleSheet(UIFunctions.selectMenu(w.styleSheet()))

    # ==> RESET SELECTION
    def resetStyle(self, widget):
        for w in self.ui.frame_left_menu.findChildren(QPushButton):
            if w.objectName() != widget:
                w.setStyleSheet(UIFunctions.deselectMenu(w.styleSheet()))

    # ==> CHANGE PAGE LABEL TEXT
    def labelPage(self, text):
        newText = '| ' + text.upper()
        self.ui.label_top_page.setText(newText)

    def uiDefinitions(self):
        def dobleClickMaximizeRestore(event):
            # IF DOUBLE CLICK CHANGE STATUS
            if event.type() == QtCore.QEvent.MouseButtonDblClick:
                QtCore.QTimer.singleShot(250, lambda: UIFunctions.maximize_restore(self))

        # REMOVE ==> STANDARD TITLE BAR
        if GLOBAL_TITLE_BAR:
            self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
            self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
            self.ui.frame_label_top_btns.mouseDoubleClickEvent = dobleClickMaximizeRestore
        else:
            self.ui.hori_layout_central_widget.setContentsMargins(0, 0, 0, 0)
            self.ui.frame_label_top_btns.setContentsMargins(8, 0, 0, 5)
            self.ui.frame_label_top_btns.setMinimumHeight(42)
            self.ui.frame_icon_top_bar.hide()
            self.ui.frame_btns_right.hide()
            self.ui.frame_size_grip.hide()

        # SHOW ==> DROP SHADOW
        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(17)
        self.shadow.setXOffset(0)
        self.shadow.setYOffset(0)
        self.shadow.setColor(QColor(0, 0, 0, 150))
        self.ui.frame_main.setGraphicsEffect(self.shadow)

        self.sizegrip = QSizeGrip(self.ui.frame_size_grip)
        self.sizegrip.setStyleSheet("width: 20px; height: 20px; margin 0px; padding: 0px;")

        self.ui.btn_minimize.clicked.connect(lambda: self.showMinimized())
        self.ui.btn_maximize_restore.clicked.connect(lambda: UIFunctions.maximize_restore(self))
