from app.frames.common_widget import *
from PySide6.QtWidgets import(
    QGridLayout, QLabel,
    QWidget, QSlider)
from PySide6.QtCore import Qt

class SliderLabel(QWidget):
 
    def __init__(self, layout, offset_width):
        super(SliderLabel, self).__init__()

        main_layout = layout
        ''' left side: = to tab size width and then place the layout'''
        layout_slider = createVerticalLayout(left=offset_width, bottom =5)
        main_layout.addLayout(layout_slider)

        self.slider = QSlider(Qt.Horizontal)
        self.slider.setTickPosition(QSlider.TicksBelow)

        grid_layout = QGridLayout()

        self.min_label = QLabel()
        self.min_label.setAlignment(Qt.AlignLeft)
        self.min_label.setAlignment(Qt.AlignTop)
        self.min_label.setDisabled(False)

        self.max_label = QLabel()
        self.max_label.setAlignment(Qt.AlignRight)
        self.max_label.setAlignment(Qt.AlignTop)
        self.max_label.setDisabled(False)

        self.value_label = QLabel()
        self.value_label.setAlignment(Qt.AlignCenter)
        self.value_label.setAlignment(Qt.AlignVCenter)
        self.value_label.setDisabled(False)

        self.setMinimum(0.0)

        grid_layout.addWidget(self.min_label, 0, 1, Qt.AlignLeft)
        grid_layout.addWidget(self.value_label, 0, 2, Qt.AlignCenter)
        grid_layout.addWidget(self.max_label, 0, 3, Qt.AlignRight)

        layout_slider.addLayout(grid_layout)
        layout_slider.addWidget(self.slider)
        layout_slider.addWidget(QLabel())

    def setMinimum(self, value):
        self.slider.setMinimum(value)
        self.min_label.setText("{}".format(value))

    def setMaximum(self, value):
        self.slider.setMaximum(value)
        self.max_label.setText("{:.3f}".format(value))

    def setValue(self, value):
        self.slider.setValue(int(value))
        self.value_label.setText("{:.3f}".format(value))

    def setTickInterval(self, value):
        self.slider.setTickInterval(int(value)/5)
