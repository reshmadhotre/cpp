from app.frames.common_widget import *
from app.frames.scroll_label import ScrollLabel
from PySide6.QtWidgets import QMainWindow, QMessageBox

import ast


class ParamInputFrame(QMainWindow):
    def __init__(self, param_name, param_value,
                 value_type="string", value_options=[]):
        super(ParamInputFrame, self).__init__()
        self.param_name = param_name
        self.param_value = param_value
        self.value_type = value_type
        self.value_options = value_options
        self.user_entry = str(self.param_name)
        self.box_type = None

    def get(self):
        user_input = self.user_entry
        if user_input == 0:
            QMessageBox.critical(self, "Value Error",
                                 f"Please enter a value for param"
                                 ": {self.param_name}")
            return None

        elif self.value_type == "double":
            try:
                user_input = float(self.param_value)
            except ValueError:
                QMessageBox.critical(self, "Value Error",
                                     f"Expected a double for param"
                                     ": {self.param_name}")
                return None
        elif self.value_type == "int":
            try:
                user_input = int(self.param_value)
            except ValueError:
                QMessageBox.critical(self, "Value Error",
                                     f"Expected an integer for param"
                                     ": {self.param_name}")
                return None
        elif self.value_type == "bool":
            self.param_value = self.check_box.isChecked()
            user_input = self.param_value

        elif self.value_type == 'string_array':
            user_input = self.param_value
        elif self.value_type == 'string':
            if self.box_type == 'combobox':
                self.param_value=str(self.combo_box.currentText())
                user_input = str(self.param_value)
            elif self.box_type == 'text_box':
                user_input = str(self.param_value)
        else:
            try:
                user_input = str(self.param_value)
            except ValueError:
                QMessageBox.critical(self, "Value Error",
                                     f"Expected a string for param"
                                     ": {self.param_name}")
                return None
        return user_input

    def createInputFrame(self, tooltip="", combo_box=False,
                         check_box=False, scroll_box=False,
                         spin_box=False, double_spin_box=False,
                         text_box=False, check_box_object=None,
                         label_side='left'):
        if label_side == 'left':
            label_text = self.param_name + " :  "
        else:
            label_text = self.param_name

        label = createLabel(label_text, tooltip)

        if combo_box:
            self.combo_box = createComboBox(self.param_name,
                                            self.param_value,
                                            tooltip,
                                            self.value_options)
            self.box_type = "combobox"
            return label, self.combo_box
        elif check_box:
            if (isinstance(self.param_value, str)):
                checkedState = ast.literal_eval(self.param_value)
            elif (isinstance(self.param_value, bool)):
                checkedState = self.param_value
            self.box_type = "checkbox"

            if check_box_object is None:
                if label_side=='left':
                    self.check_box, label = createLabelCheckbox(label_text, tooltip, checkedState)
                    window = None
                else:
                    self.check_box, label, window = createCheckBox(text=label_text,
                                                                tooltip=tooltip,
                                                                checkedState=checkedState,
                                                                label_side=label_side)
            else:
                self.check_box = check_box_object
                label = None
                window = None

            return self.check_box, label, window
        elif scroll_box:
            self.scroll_box = ScrollLabel()
            self.box_type = "scrollbox"
            return label, self.scroll_box
        elif spin_box:
            self.spin_box = createSpinBox(self.param_value)
            self.spin_box.valueChanged.connect(lambda: self.spin_box_value())
            self.box_type = "spinbox"
            return label, self.spin_box
        elif double_spin_box:
            self.double_spin_box = createDoubleSpinBox(self.param_value)
            self.double_spin_box.valueChanged.connect(lambda: self.double_spin_box_value())
            self.box_type = "double_spinbox"
            return label, self.double_spin_box
        elif text_box:
            self.text_box = createText(self.param_value, tooltip)
            self.box_type = "text_box"
            return label, self.text_box

    def resetInputFrame(self, param_name, param_value,
                        value_type, value_options):
        self.param_name = param_name
        self.param_value = param_value
        self.value_type = value_type
        self.value_options = value_options
        self.user_entry = str(self.param_name)

        if self.box_type == "combobox":
            self.combo_box.blockSignals(True)
            self.combo_box.clear()
            if len(self.value_options):
                self.combo_box.addItems(value_options)
            else:
                self.combo_box.addItem(str(param_value))
            self.combo_box.setCurrentText(str(param_value))

            self.combo_box.blockSignals(False)
        elif self.box_type == "checkbox":
            self.check_box.setChecked(param_value)
        elif self.box_type == "spinbox":
            self.spin_box.blockSignals(True)
            self.spin_box.setValue(param_value)
            self.spin_box.blockSignals(False)
        elif self.box_type == "double_spinbox":
            self.double_spin_box.blockSignals(True)
            self.double_spin_box.setValue(param_value)
            self.double_spin_box.blockSignals(False)
        elif self.box_type == 'text_box':
            self.text_box.setText(str(param_value))
        elif self.box_type == None:
            return

    ''' used only when radar_type is changed in radar panel'''
    def resetWidgetbox(self, update_value):
        self.param_value = update_value
        self.user_entry = str(self.param_value)

        if self.box_type == "combobox":
            self.combo_box.blockSignals(True)
            all_items = [self.combo_box.itemText(i) for i in range(self.combo_box.count())]
            if update_value not in all_items:
                self.combo_box.addItem(str(update_value))
            self.combo_box.setCurrentText(str(update_value))
            self.combo_box.blockSignals(False)
        elif self.box_type == "checkbox":
            self.check_box.setChecked(update_value)
        elif self.box_type == "scrollbox":
            self.scroll_box.setText(update_value)
        elif self.box_type == "spinbox":
            self.spin_box.blockSignals(True)
            self.spin_box.setValue(update_value)
            self.spin_box.blockSignals(False)
        elif self.box_type == "double_spinbox":
            self.double_spin_box.blockSignals(True)
            self.double_spin_box.setValue(update_value)
            self.double_spin_box.blockSignals(False)
        elif self.box_type == 'text_box':
            self.text_box.setText(str(update_value))
        elif self.box_type == None:
            return

    def set(self, value):
        self.check_box.setChecked(value)
        self.param_value = value

    def setParamOptions(self, value_options):
        self.value_options = value_options

    def setParamValue(self, value):
        self.param_value = value

    def spin_box_value(self):
        self.param_value = self.spin_box.value()

    def double_spin_box_value(self):
        self.param_value = self.double_spin_box.value()
