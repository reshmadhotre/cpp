from PySide6.QtWidgets import (
    QMainWindow, QGridLayout, QFormLayout,
    QMessageBox, QWidget, QVBoxLayout,
    QSpacerItem, QSizePolicy)
from PySide6.QtCore import Qt

from app.frames.param_input_frame import ParamInputFrame
from .filepath_button import FilepathButton
from app.frames.common_widget import *
from app.frames.scroll_label import ScrollLabel
from app.utils.replay_utils import *
from app.utils.yaml_utils import *


class SwcParametersFrame(QMainWindow):

    def __init__(self, nodename, package_name,
                 tabwidget, controller, overview,
                 replay_tool, node_config: dict, 
                 subcriber_list= [], radar_frame = None):

        super(SwcParametersFrame, self).__init__()

        self.tabwidget = tabwidget
        self.controller = controller
        self.overview = overview
        self.replay_tool = replay_tool
        if radar_frame != None:
            self.radar_frame = radar_frame
        self.node_config = node_config.copy()
        self.ROS_PACKAGE_NAME = self.node_config['ros_package']
        self.ROS_NODE_NAME = nodename
        self.package_name = package_name
        self.subcriber_list = subcriber_list

        self.user_entries = {}
        self.parameters = {}
        self.sync_subscribe_cb_list = {}

        self.createInputFrame()
        self.overview.midw_rdc3_selection.connect(self.setCompleteTriggerNode)

    def createInputFrame(self):
        pagelayout = QVBoxLayout()
        data_ver_layout = QVBoxLayout()
        data_ver_layout.setContentsMargins(10, 10, 0, 10)
        gridlayout = QGridLayout()

        self.ros_package_names = self.controller.getRosPackageNames()

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        self.createParametersDescription()

        data_value_layout = QFormLayout()
        data_value_layout.setContentsMargins(10, 20, 0, 20)
        layout_sync = None

        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            if "trigger_cyclic_node" in param_name or "completetrigger_node" in param_name:
                value_options = self.ros_package_names
            else:
                value_options = self.getValueOptionsFromInfoConfig(param_name)

            if param_name == 'dsp_app_filepath':
                label = createLabel("Select Dsp App File")
                label.setFixedSize(QSize(130, 20))
                gridlayout.addWidget(label, 0, 0)

                select_dsp_app_button = createButton("...",
                                                     "Choose the dsp app file")
                select_dsp_app_button.setFixedSize(QSize(20, 20))
                gridlayout.addWidget(select_dsp_app_button, 0, 1, Qt.AlignLeft | Qt.AlignHCenter)

                select_dsp_app_file_input = ScrollLabel(self)
                gridlayout.addWidget(select_dsp_app_file_input, 1, 0, 2, 3)

                self.dsp_app_filepath_frame = FilepathButton(select_dsp_app_file_input,
                                                             select_dsp_app_button, self.user_entries, "", param_name,
                                                             param_value, multiple_file=False)
                self.user_entries[param_name] = self.dsp_app_filepath_frame
                self.dsp_app_filepath_frame.file_path_selected.connect(self.SetDspAppPath)

            elif param_name == 'shared_library_filepath':
                dsp_label = createLabel("Select Shared Library File")
                dsp_label.setFixedSize(QSize(175, 20))
                gridlayout.addWidget(dsp_label, 3, 0)

                select_shared_lib_button = createButton("...",
                                                        "Choose the shared library file")
                select_shared_lib_button.setFixedSize(QSize(20, 20))
                gridlayout.addWidget(select_shared_lib_button, 3, 1, Qt.AlignLeft | Qt.AlignHCenter)

                select_shared_lib_file_input = ScrollLabel(self)
                gridlayout.addWidget(select_shared_lib_file_input, 4, 0, 2, 3)

                self.shared_lib_filepath_frame = FilepathButton(select_shared_lib_file_input,
                                                                select_shared_lib_button, self.user_entries, "so", param_name,
                                                                param_value, multiple_file=False)
                self.user_entries[param_name] = self.shared_lib_filepath_frame

            else:
                param_input_frame = ParamInputFrame(param_name, param_value,
                                                    value_type, value_options)
                self.user_entries[param_name] = param_input_frame
                if value_type == 'bool':
                    if "record_output_parquets" in param_name or "record_input_parquets" in param_name : 
                        if self.replay_tool == Tool.Mf4:
                            if self.ROS_NODE_NAME not in ['VOA', "CLOCK"]:
                                self.getOverviewCheckbox(param_input_frame, param_name, 
                                                         param_value)

                        else:
                            self.createCheckboxSetup(param_input_frame, param_name, data_value_layout)

                    else:
                        self.createCheckboxSetup(param_input_frame, param_name, data_value_layout)

                elif value_type == 'int' or value_type == 'double':
                    label, text_box = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                         text_box=True)

                    text_box.textChanged[str].connect(lambda text,
                                                      param=param_name: self.widgetBoxChanged(text, param))
                    data_value_layout.addRow(label, text_box)
                    data_value_layout.addWidget(createSpacerLabel())

                elif value_type == "string_array":
                    if "sync_subscriber_list" in param_name:
                        layout_sync_header = layoutHeader("Synchronisation")
                        sync_scroll_area = self.updateCheckboxList(param_value)

                        layout_sync = createVerticalLayout()
                        layout_sync.addLayout(layout_sync_header)
                        layout_sync.addWidget(sync_scroll_area)

                else:
                    label, self.previous_node_combo_box = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                          combo_box=True)
                    self.previous_node_combo_box.currentTextChanged.connect(self.setPreviousNode())

                    data_value_layout.addRow(label, self.previous_node_combo_box)
                    data_value_layout.addWidget(createSpacerLabel())

        layout_trigger = createVerticalLayout()
        layout_trigger.setContentsMargins(0, 10, 0, 10)
        layout_header = layoutHeader("Trigger properties")
        layout_trigger.addLayout(layout_header)
        layout_trigger.addLayout(data_value_layout)
        layout_trigger.addLayout(data_ver_layout)
        if layout_sync != None:
            layout_trigger.addLayout(layout_sync)

        layout_trigger.insertStretch(-1, 1)
        pagelayout.addLayout(layout_trigger)
        pagelayout.insertStretch(-1, 1)

        swc_merdrdatacubemidw= QWidget()
        swc_merdrdatacubemidw.setObjectName(self.ROS_PACKAGE_NAME)
        swc_merdrdatacubemidw.setLayout(pagelayout)
        if self.ROS_NODE_NAME != "CLOCK":
            self.index = self.tabwidget.addTab(swc_merdrdatacubemidw, self.ROS_NODE_NAME)
            self.tabwidget.setTabEnabled(self.index, False)

        return swc_merdrdatacubemidw

    def resetInputFrame(self, node_config):
        self.node_config = node_config.copy()

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            if "trigger_cyclic_node" in param_name or "completetrigger_node" in param_name:
                value_options = self.ros_package_names
            else:
                value_options = self.getValueOptionsFromInfoConfig(param_name)

            if param_name == 'dsp_app_filepath':
                self.dsp_app_filepath_frame.addFilepathtoEntry(param_value)
                self.user_entries[param_name] = self.dsp_app_filepath_frame

            elif param_name == 'shared_library_filepath':
                self.shared_lib_filepath_frame.addFilepathtoEntry(param_value)
                self.user_entries[param_name] = self.shared_lib_filepath_frame

            elif (("record_output_parquets" in param_name or "record_input_parquets" in param_name) and
                  (self.ROS_NODE_NAME in ['VOA', 'CLOCK'])):
                continue

            else:
                param_input_frame = self.user_entries[param_name]
                if "sync_subscriber_list" in param_name:
                    self.updateCheckboxListValues(param_value)

                param_input_frame.resetInputFrame(param_name, param_value, value_type, value_options)
                self.user_entries[param_name] = param_input_frame

    def getValueTypeFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['type']

        return "string"

    def getValueOptionsFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['values']

        return []

    def getConfig(self):
        if self.updateConfig():
            return self.node_config.copy()
        return None

    def setConfig(self, node_config):
        self.node_config = node_config.copy()
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name in params_config[node_name]['ros__parameters'].keys():
            if param_name != 'dsp_app_filepath' or param_name != 'shared_libray_filepath':
                param_input_frame = self.user_entries[param_name]
                param_input_frame.resetWidgetbox((params_config[node_name]['ros__parameters'][param_name]))

    def updateConfig(self):
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]
        for param_name in params_config[node_name]['ros__parameters'].keys():
            if (("record_output_parquets" in param_name or "record_input_parquets" in param_name) and
                  (self.ROS_NODE_NAME in ['VOA', 'CLOCK'])):
                continue
            elif "sync_subscriber_list" in param_name:
                self.updateSyncSubscriberListInPackageConfigFile(param_name)
            user_value = self.user_entries[param_name].get()
            if user_value is None or user_value == "":
                QMessageBox.critical(self, "Value Error",
                                     f"Expected a value for param : {param_name}",
                                     QMessageBox.Ok)

                return False
            self.node_config['params_config'][node_name]['ros__parameters'][param_name] = user_value
        return True

    def widgetBoxChanged(self, text, param_name):
        param_input_frame = self.user_entries[param_name]
        param_input_frame.param_value = text
        self.user_entries[param_name] = param_input_frame

    def nodeEnabled(self):
        '''clock should be enabled only when COA is enabled'''
        #print(f"self.ROS_NODE_NAME: {self.ROS_NODE_NAME}, self.package_name: {self.package_name}")
        if self.ROS_NODE_NAME == "CLOCK":
            coa_node_enabled =  self.overview.getCheckbox(node = Nodes[Nodes.swc_mecanoutpadpr]).isChecked()
            if coa_node_enabled:
                return True
            else:
                return False
        else:
            node_enabled =  self.overview.getCheckbox(node = Nodes[self.package_name]).isChecked()
            return node_enabled

    def SetDspAppPath(self):
        self.controller.dsp_app_filepath = self.dsp_app_filepath_frame.filepath

    def updateCheckboxList(self, selected_data):
        sync_scroll_panel = QWidget()
        layout_sync_item = createVerticalLayout(parent=sync_scroll_panel, left=10, top=10)
        sync_scroll_area = QScrollArea()
        sync_scroll_area.setWidgetResizable(True)
        sync_scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        sync_scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sync_scroll_area.setWidget(sync_scroll_panel)
        
        if self.replay_tool == Tool.Mf4:
            sync_sub_list = self.controller.node_config_util.getSyncSubscriberListFromHppFile(self.package_name)
        elif self.replay_tool == Tool.Rosbag:
            sync_sub_list = self.subcriber_list

        '''create checkboxes list'''
        for index in range(len(sync_sub_list)):
            param_value = False
            if sync_sub_list[index] in selected_data:
                param_value = True
            horizontal_layout = createHorizontalLayout()
            check_box = createPlainCheckbox(sync_sub_list[index], sync_sub_list[index],
                                            sync_sub_list[index], param_value)
            horizontal_layout.addWidget(check_box)
            horizontal_layout.setContentsMargins(20, 8, 0, 0)
            layout_sync_item.addLayout(horizontal_layout)
            self.sync_subscribe_cb_list[sync_sub_list[index]] = check_box
        return sync_scroll_area

    def updateCheckboxListValues(self, param_value):
        ''' sync subcriber list fetched from replayconfig
        update the corresponding synchronisation checkboxes'''
        if len(param_value) and param_value[0] != '':
            for sync_sub_name in param_value:
                check_box = self.sync_subscribe_cb_list[sync_sub_name]
                check_box.setChecked(True)

    def addWidgetsToLayout(self, layout, widget1, widget2):
        layout.addWidget(widget1)
        layout.addSpacing(8)
        layout.addWidget(widget2)
        layout.addSpacerItem(
            QSpacerItem(20, 7, QSizePolicy.Minimum, QSizePolicy.Minimum))

    def createParametersDescription(self):
        self.parameters['param_trigger_cyclic_immediate'] = "Trigger cyclic immediate"
        self.parameters["param_trigger_cyclic_counter"] = "Trigger cyclic counter"
        self.parameters["param_previous_node"] = "Previous node"
        self.parameters["param_sync_subscriber_list"] = "Sync subscriber list"
        self.parameters["param_timer_ms"] = "Timer in ms"
        self.parameters["param_record_input_parquets"] = "Record input Parquet"
        self.parameters["param_record_output_parquets"] = "Record output Parquet"
        self.parameters["param_ocal_timer"] = "Ocal timer"

    """Update sync subscriber list component in swc_components's config file  """
    def updateSyncSubscriberListInPackageConfigFile(self, param_name):
        selected_list = []
        for sync_sub_name, check_box in self.sync_subscribe_cb_list.items():
            if check_box.isChecked():
                selected_list.append(sync_sub_name)

        if not selected_list:
            selected_list.append("")
        else:
            selected_list.sort()

        '''update param_value'''
        param_input_frame = self.user_entries[param_name]
        param_input_frame.param_value.sort()

        ''' update the config yaml, only if both lists are not identical'''
        if param_input_frame.param_value != selected_list:
            param_input_frame.param_value = selected_list
            config_file_path = self.controller.node_config_util.getPackagePath(self.package_name)
            ret_value = search_and_replace(search_key=param_name,
                                config_file=config_file_path,
                                replace_text = selected_list)

    def setPreviousNode(self):
        previous_node = ""
        if self.package_name == Nodes.swc_mecanoutpadpr:
            previous_node = Nodes.swc_clock
            enabled_nodes_set = set()
        else:
            enabled_nodes_set = self.overview.getEnabledNodes()
            weight_of_nodes = createWeightDictOfNodes()
            
            node_value = weight_of_nodes.get(self.package_name)
            previous_node = Nodes.server_replay_mrr
            for node, weight in weight_of_nodes.items():
                if (node_value > weight and
                    node in enabled_nodes_set and
                    node != Nodes.swc_mecanoutpadpr):
                    previous_node = node

        self.previous_node_combo_box.blockSignals(True)
        self.previous_node_combo_box.clear()
        if len(enabled_nodes_set):
            self.previous_node_combo_box.addItems(enabled_nodes_set)
        self.previous_node_combo_box.setCurrentText(previous_node)
        self.previous_node_combo_box.blockSignals(False)
        
        param_input_frame = self.user_entries['param_previous_node']
        param_input_frame.param_value = previous_node

    def setCompleteTriggerNode(self):
        if self.radar_frame != None and self.ROS_NODE_NAME == "MIDW":
            self.radar_frame.uhdpCompleteTriggerNode()

    def checkbox_state_changed(self, text, param_name):
        param_input_frame = self.user_entries[param_name]
        param_input_frame.param_value = text
        self.user_entries[param_name] = param_input_frame

    def abilityTab(self, value):
        self.tabwidget.setTabEnabled(self.index, value)


    def getOverviewCheckbox(self, param_input_frame, param_name, param_value):
        parquet = ""
        if "record_output_parquets" in param_name:
            parquet = "OutputParquet"
        elif "record_input_parquets" in param_name:
            parquet = "InputParquet"

        check_box = self.overview.getCheckbox(self.package_name + parquet)
        check_box, label, window = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                check_box=True,
                                                                check_box_object=check_box)
        check_box.setChecked(param_value)



    def createCheckboxSetup(self, param_input_frame, param_name, data_value_layout):
        check_box, label, window = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                                    check_box=True)
        check_box.stateChanged.connect(lambda text,
                                param=param_name: self.checkbox_state_changed(text, param))
        data_value_layout.addWidget(createSpacerLabel())
        data_value_layout.addRow(label, check_box)
        data_value_layout.addWidget(createSpacerLabel())
