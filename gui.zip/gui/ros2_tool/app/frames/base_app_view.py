
from app.utils.yaml_utils import *

from PySide6.QtWidgets import QMessageBox


class BaseAppView():
    def __init__(self):
        super(BaseAppView, self).__init__()

    def setReplayConfig(self, file_path):
        replay_config = parseYamlFile(file_path)
        if len(replay_config) > 0:
            self.resetOverviewPanel()
            self.input_frame = self.resetInputFrame(replay_config)

    def saveReplayConfig(self, file_path):
        self.resetPreviousNodeAndTriggerNode()
        replay_config = self.generateReplayConfig()

        if replay_config != False and replay_config != None and len(replay_config):
            data_replay_config = replay_config.copy()
            if writeYamlFile(file_path, data_replay_config):
                QMessageBox.information( self, "Save",
                                         f"Replay config saved to : {file_path}",
                                         QMessageBox.Ok  )
            else:
                QMessageBox.critical( self, "Save",
                                      f"Error saving config to : {file_path}",
                                      QMessageBox.Ok )
