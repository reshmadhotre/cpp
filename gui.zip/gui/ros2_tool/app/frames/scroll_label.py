from app.movable_app.ui_styles import Style
from app.frames.common_widget import *

from PySide6.QtWidgets import (
    QLabel, QWidget)
from PySide6.QtCore import Qt, QSize


class ScrollLabel(QWidget):

    def __init__(self, *args, **kwargs):
        QWidget.__init__(self, *args, **kwargs)

        self.setContentsMargins(0, 0, 0, 0)
        self.setMinimumHeight(31)
        ''' rounded frame'''
        self.setStyleSheet(Style.style_widget)

        lay = createVerticalLayout(self)

        self.label = QLabel(self)
        self.label.setDisabled(False)
        self.label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.label.setTextInteractionFlags(Qt.TextSelectableByKeyboard)
        self.label.setStyleSheet(Style.style_label)

        self.label.setAlignment(Qt.AlignLeft)
        self.label.setAlignment(Qt.AlignTop)

        # label multi-line
        self.label.setWordWrap(True)

        lay.addWidget(self.label)

    def setText(self, text):
        rectangle = self.label.fontMetrics().boundingRect(text)
        self.label.setText(text)
        self.label.setMinimumSize(rectangle.width(), rectangle.height())

    def clear(self):
        self.label.clear()

    def setSize(self, height, width):
        self.label.setFixedSize(QSize(height, width))
