from app.frames.animated_checkbox import AnimatedCheckbox
from app.movable_app.ui_styles import Style

from PySide6.QtWidgets import (
    QLabel, QComboBox, QPushButton,
    QHBoxLayout, QRadioButton, QWidget,
    QFrame, QTabWidget, QSpinBox, QDoubleSpinBox,
    QScrollArea, QLineEdit, QStyleOptionTab,
    QTabBar, QStyle, QStylePainter, QTreeWidget,
    QHeaderView, QTreeWidgetItem, QVBoxLayout,
    QSizePolicy,QCheckBox)

from PySide6.QtGui import (
    QFont, QIcon, QColor)

from PySide6.QtCore import QSize, Qt

'''This combo box scrolls only if opened before.
if the mouse is over the combobox and the mousewheel is turned,
the mousewheel event of the scrollWidget is triggered'''


class ScrollHandleQComboBox(QComboBox):
    def __init__(self, scrollWidget=None, *args, **kwargs):
        super(ScrollHandleQComboBox, self).__init__(*args, **kwargs)
        self.scrollWidget = scrollWidget
        self.setFocusPolicy(Qt.StrongFocus)
        self.setStyleSheet(Style.style_combobox)

    def wheelEvent(self, event):
        if self.hasFocus():
            return QComboBox.wheelEvent(self, event)
        else:
            return event.ignore()

def createLabel(label_text, tooltip=""):
    label = QLabel()
    label.setText(label_text)
    label.setToolTip(tooltip)
    ''' duration for 5 secs'''
    label.setToolTipDuration(500)
    label.setTextInteractionFlags(Qt.TextSelectableByMouse)
    label.setTextInteractionFlags(Qt.TextSelectableByKeyboard)
    return label

def CreateFontLabel(parent=None, label_text="", point=10.5,
                    style=u"color: rgb(98, 103, 111); ",
                    size=True):
    if parent:
        label_top_info = QLabel(parent)
    else:
        label_top_info = QLabel()
    label_top_info.setText(label_text)
    if size:
        label_top_info.setMaximumSize(QSize(16777215, 15))
    font = createFont(point)
    label_top_info.setFont(font)
    label_top_info.setStyleSheet(style)
    return label_top_info


def createText(text="", tooltip=""):
    text_item = QLineEdit()
    text_item.setText(str(text))
    text_item.setToolTip(tooltip)
    text_item.setToolTipDuration(500)
    text_item.setStyleSheet(Style.style_lineedit)

    return text_item

def createComboBox(name, textvar, tooltip, options):
    scrollArea = QScrollArea()
    frmScroll = QFrame(scrollArea)
    combo_box = ScrollHandleQComboBox(frmScroll)
    combo_box.setToolTip(tooltip)
    combo_box.setToolTipDuration(500)
    combo_box.setEditable(True)
    combo_box.setAccessibleName(name)

    if len(options):
        combo_box.addItems(options)
    elif textvar != "":
        combo_box.addItem(str(textvar))

    combo_box.setCurrentText(str(textvar))

    return combo_box


class LabelAsNote(QLabel):
    def __init__(self, text):
        super().__init__(text=text)
        #label_top_info.setMaximumSize(QSize(16777215, 15))
        font = QFont()
        font.setFamily(u"Segoe UI")
        font.setPointSize(8)
        self.setFont(font)
        self.setStyleSheet(u"color: rgb(98, 103, 111); ")


class PushButton(QPushButton):
    def __init__(self, text, tooltip, icon_png=None) -> None:
        super().__init__()
        self.setText(text)
        self.setToolTip(tooltip)
        self.setToolTipDuration(1000)

        font = QFont()
        font.setFamily(u"Segoe UI")
        font.setPointSize(9)

        self.setMinimumSize(QSize(150, 30))
        self.setFont(font)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setStyleSheet(Style.style_pushbutton)
        if icon_png:
            icon = QIcon()
            icon.addFile(icon_png, QSize(), QIcon.Normal, QIcon.Off)
            self.setIcon(icon)
        self.clicked.connect(self.on_clicked)

    def on_clicked(self):
        pass


def createButton(text, tooltip, icon_flag=False):
    button = QPushButton()
    button.setText(text)
    button.setToolTip(tooltip)
    button.setToolTipDuration(500)

    font = QFont()
    font.setFamily(u"Segoe UI")
    font.setPointSize(9)

    button.setMinimumSize(QSize(150, 30))
    button.setFont(font)
    button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
    button.setStyleSheet(Style.style_pushbutton)
    if icon_flag:
        icon = QIcon()
        icon.addFile(u":/16x16/icons/16x16/cil-folder-open.png", QSize(), QIcon.Normal, QIcon.Off)
        button.setIcon(icon)

    return button


def createCheckBox(text, tooltip, checkedState=False,
                   disabledState=False, label_side='right'):
    check_box, lbl = createLabelCheckbox(text, tooltip, checkedState, disabledState)
    window = QWidget()
    layout = QHBoxLayout()
    layout.setContentsMargins(0, 0, 0, 0)
    window.setLayout(layout)
    window.setToolTip(tooltip)
    window.setToolTipDuration(500)

    if label_side == 'right':
        window.layout().addWidget(check_box)
        window.layout().addWidget(lbl)
    elif label_side == 'left':
        # window.layout().addWidget(lbl, Qt.AlignTop)
        # window.layout().addWidget(check_box, Qt.AlignBottom | Qt.AlignBaseline)
        window.layout().addWidget(lbl)
        window.layout().addWidget(check_box)

    ''' compactly arrange the widgets in it'''
    layout.insertStretch(-1, 1)

    return check_box, lbl, window


def createLabelCheckbox(text, tooltip, checkedState=False,
                        disabledState=False):
    check_box = createAnimatedCheckbox(text, tooltip,
                                       checkedState,
                                       disabledState)
    lbl = createLabel(text, tooltip)
    return check_box, lbl


def createAnimatedCheckbox(text, tooltip, checkedState=False,
                           disabledState=False):
    check_box = AnimatedCheckbox(
        checked_color="#34AAFF",
        pulse_checked_color="#55AAFF")
    check_box.setFixedSize(31, 15)
    check_box.setToolTip(tooltip)
    check_box.setToolTipDuration(500)

    check_box.setText(text)
    check_box.setAccessibleName(text)
    check_box.setAutoFillBackground(False)
    check_box.setDisabled(disabledState)
    check_box.setChecked(checkedState)
    return check_box


''' set the tab color of tabwidget'''
class FingerTabBar(QTabBar):

    def __init__(self, *args, **kwargs):
        self.tabSize = QSize(kwargs.pop('width'), kwargs.pop('height'))
        super(FingerTabBar, self).__init__(*args, **kwargs)
        self.setStyleSheet(Style.style_tabbar)
        self.pressedIndex = -1

    def setPressedIndex(self, index):
        self.pressedIndex = index

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        if event.button() == Qt.LeftButton:
            self.pressedIndex = self.tabAt(event.pos())
            if self.pressedIndex < 0:
                return
            self.startPos = event.pos()

    def paintEvent(self, event):
        style_painter = QStylePainter(self)
        option = QStyleOptionTab()

        for index in range(self.count()):
            self.initStyleOption(option, index)
            tabRect = self.tabRect(index)
            tabRect.moveLeft(10)
            if index == self.pressedIndex and self.isTabEnabled(index):
                ''' white'''
                style_painter.setPen(QColor(255, 255, 255))
            else:
                ''' grey'''
                style_painter.setPen(QColor(112, 112, 112))

            if self.isTabEnabled(index) == False:
                style_painter.setPen(QColor(0, 0, 0))

            style_painter.drawControl(QStyle.CE_TabBarTabShape, option)
            style_painter.drawText(tabRect, Qt.AlignVCenter |
                                   Qt.TextDontClip,
                                   self.tabText(index))

    def tabSizeHint(self, index):
        return self.tabSize


def createTabWidget(selectedTab, width=150, height=30):
    tab_widget = QTabWidget()
    tab_widget.setTabBar(FingerTabBar(width=width, height=height))
    tab_widget.tabBar().setPressedIndex(selectedTab)
    tab_widget.setTabPosition(QTabWidget.West)
    tab_widget.setTabShape(QTabWidget.Rounded)
    tab_widget.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
    tab_widget.setStyleSheet(Style.style_tabwidget)
    tab_widget.width = width
    tab_widget.height = height
    return tab_widget


def createFont(size, bold=False):
    font = QFont()
    font.setFamily(u"Segoe UI")
    font.setPointSize(size)
    font.setBold(bold)
    return font


def createTreeWidget(first_col_name):
    treeWidget = QTreeWidget()
    treeWidget.setExpandsOnDoubleClick(False)
    treeWidget.clicked.connect(lambda: treeSingleClick(treeWidget))
    treeWidget.resizeColumnToContents(0)
    treeWidget.setFocusPolicy(Qt.NoFocus)
    treeWidget.setStyleSheet(Style.style_treewidget)
    treeWidget.setColumnCount(2)
    Headers = (first_col_name, "")
    treeWidget.setHeaderLabels(Headers)
    treewidget_header = treeWidget.header()
    treewidget_header.setStyleSheet(Style.style_treewidget_header)
    treewidget_header.setFixedHeight(40)
    treewidget_header.setStretchLastSection(True)
    treewidget_header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
    return treeWidget


def treeSingleClick(treeWidget):
    if (treeWidget.isExpanded(treeWidget.currentIndex())):
        treeWidget.collapse(treeWidget.currentIndex())
    else:
        treeWidget.expand(treeWidget.currentIndex())


def CreateTreeWidgetItem(item_key, param_name, tooltip=""):
    tree_item = QTreeWidgetItem(item_key, [str(param_name)])
    tree_item.setText(0, str(param_name))
    tree_item.setToolTip(tooltip)
    tree_item.setSizeHint()
    return tree_item


def CreateTreeWidgetItem(tree_widget, header_name):
    child = QTreeWidgetItem(tree_widget)
    child.setText(0, header_name)
    child.setFlags(Qt.ItemIsEnabled)
    return child


def createHorizontalLayout(parent=None, left=0, top=0,
                           right=0, bottom=0):
    if parent is None:
        horizontal_layout = QHBoxLayout()
    else:
        horizontal_layout = QHBoxLayout(parent)
    horizontal_layout.setSpacing(0)
    horizontal_layout.setContentsMargins(left, top, right, bottom)
    return horizontal_layout


def createVerticalLayout(parent=None, left=0, top=0,
                         right=0, bottom=0):
    if parent is None:
        vertical_layout = QVBoxLayout()
    else:
        vertical_layout = QVBoxLayout(parent)

    vertical_layout.setSpacing(0)
    vertical_layout.setContentsMargins(left, top, right, bottom)
    return vertical_layout


def createFrame(parent, size=False, style=None):
    frame = QFrame(parent)
    if size:
        frame.setMinimumSize(QSize(0, 65))
        frame.setMaximumSize(QSize(16777215, 65))
    frame.setStyleSheet(style)
    frame.setFrameShape(QFrame.NoFrame)
    frame.setFrameShadow(QFrame.Raised)
    return frame


def createTitlePushButton(parent=None, icon_png=None, style=None,
                          size=True, hori_policy=QSizePolicy.Minimum):
    if parent:
        button = QPushButton(parent)
    else:
        button = QPushButton()

    sizePolicy = QSizePolicy(hori_policy, QSizePolicy.Expanding)
    sizePolicy.setHorizontalStretch(0)
    sizePolicy.setVerticalStretch(0)
    sizePolicy.setHeightForWidth(button.sizePolicy().hasHeightForWidth())

    button.setSizePolicy(sizePolicy)
    if size:
        button.setMinimumSize(QSize(40, 0))
        button.setMaximumSize(QSize(40, 16777215))
    button.setStyleSheet(style)
    icon = createIcon(icon_png)
    button.setIcon(icon)

    return button

def layoutHeader(text):
    layout = createHorizontalLayout()
    label = createLabel(text)
    font = createFont(size=11)
    label.setFont(font)
    layout.addWidget(label)
    return layout

def createIcon(icon_png=None):
    icon = QIcon()
    icon.addFile(icon_png, QSize(), QIcon.Normal, QIcon.Off)
    return icon

def createSizePolicy(widget, hori_policy=QSizePolicy.Expanding,
                     ver_policy=QSizePolicy.Expanding):
    sizePolicy = QSizePolicy(hori_policy, ver_policy)
    sizePolicy.setHorizontalStretch(0)
    sizePolicy.setVerticalStretch(0)
    sizePolicy.setHeightForWidth(widget.sizePolicy().hasHeightForWidth())
    return sizePolicy

def createSpinBox(value):
    spinbox = QSpinBox()
    spinbox.setValue(value)
    spinbox.setStyleSheet(Style.style_spinbox)
    return spinbox


def createDoubleSpinBox(value):
    spinbox = QDoubleSpinBox()
    spinbox.setValue(value)
    spinbox.setStyleSheet(Style.style_doubleSpinbox)
    return spinbox


def createRadioButton(text):
    radio_button = QRadioButton()
    radio_button.setText(text)
    radio_button.setStyleSheet(Style.style_overview_radio_btn)
    #BUTTON_SIZE = QSize(170, 35)
    radio_button.setChecked(False)
    #radio_button.setFixedSize(BUTTON_SIZE)
    return radio_button

def setWidgetIcon(widget, icon_png=None):
    icon = QIcon()
    icon.addFile(icon_png, QSize(), QIcon.Normal, QIcon.Off)
    widget.setIcon(icon)

def createPlainCheckbox(text, tooltip, objectname, param_value):
    checkbox = QCheckBox(text)

    checkbox.setToolTip(tooltip)
    checkbox.setObjectName(objectname)
    checkbox.setStyleSheet(Style.style_overview_checkbox)
    checkbox.setChecked(param_value)

    return checkbox

def createSpacerLabel(height=5):
    label = QLabel()
    label.setFixedHeight(height)
    return label
