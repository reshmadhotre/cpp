from app.frames.common_widget import *
from app.utils.yaml_utils import *
from app.utils.replay_utils import *

from PySide6.QtWidgets import (
    QWidget,QHBoxLayout,QCheckBox)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QResizeEvent
from itertools import islice

class Overview (QWidget):

    overview_node_checked = Signal(object)
    midw_parquet_checked = Signal(bool)
    midw_rdc3_selection = Signal()

    def __init__(self, controller, tabwidget, app_config,
                 replay_tool):
        super(Overview, self).__init__()

        self.tabwidget = tabwidget
        self.app_config = app_config
        self.controller = controller
        self.replay_tool = replay_tool
        REPLAY_NODE = self.app_config['REPLAY_NODE']

        self.check_box_list = {}
        self.feature_str = "Features"
        self.server_str = "Servers"
        self.rosbag_str = "Rosbag"
        self.parquet_op_str = "Output_Parquet"
        self.parquet_ip_str = "Input_Parquet"

        self.nodes_names = getNodesNames(self.app_config)

        self.parameters = {}
        self.createParametersDescription()
        self.signal_emitted = ""
        self.createFrame()

    def resizeEvent(self, event: QResizeEvent) -> None:
        # TODO: here add/remove component according to the size
        # TODO: set a minimal size
        return super().resizeEvent(event)

    def createFrame(self):
        self.main_layout = createVerticalLayout(left=10, top=10, right=10, bottom=10)
        self.main_layout.setAlignment(Qt.AlignLeft | Qt.AlignTop)

        layout_overview = self.layoutScroll()

        layout_features = createVerticalLayout()
        layout_header = layoutHeader(self.feature_str)
        if self.replay_tool == Tool.Mf4:
            layout_all_feature = self.layoutAllComponent(self.feature_str)

        ''' count from nodes in getNodesNames in replay_utils.py'''
        layout_component1 = self.layoutMultipleComponent(start=8, stop=23, range=4)
        layout_component2 = self.layoutMultipleComponent(start=24, stop=37, range=4)
        ''' clock need not to be there in tabs'''

        layout_features.addLayout(layout_header)
        if self.replay_tool == Tool.Mf4:
            layout_features.addLayout(layout_all_feature)
        layout_features.addLayout(layout_component1)
        layout_features.addLayout(layout_component2)
        layout_overview.addLayout(layout_features)

        if self.replay_tool == Tool.Mf4:
            layout_servers = createVerticalLayout()
            layout_servers.setContentsMargins(0, 40, 0, 0)
            layout_header = layoutHeader(self.server_str )
            layout_all_server = self.layoutAllComponent(self.server_str )
            layout_component = self.layoutMultipleComponent(stop=7, all_nodes=True)
            layout_servers.addLayout(layout_header)
            layout_servers.addLayout(layout_all_server)
            layout_servers.addLayout(layout_component)
            layout_overview.addLayout(layout_servers)
            self.disableRecordRosbagsForSwc()
            self.disableCOAInputParquet()

        layout_overview.insertStretch(-1,1)
        self.setLayout(self.main_layout)
        self.setObjectName("Overview")
        self.tabwidget.addTab(self, "Overview")

    def layoutScroll(self):
        layout_overview = createVerticalLayout()
        overview_widget = QWidget()
        overview_scroll_area = QScrollArea(widgetResizable=True)
        overview_scroll_area.setWidgetResizable(True)
        overview_scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        overview_scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        overview_scroll_area.setWidget(overview_widget)
        overview_widget.setLayout(layout_overview)

        self.main_layout.addWidget(overview_scroll_area)

        return layout_overview

    def overviewCheckbox(self, text, nodename):
        horizontal_layout = createHorizontalLayout()
        second_text = None
        if text.find(":") != -1:
            second_text = text.split(":")[1]
            text = text.replace(":", "")
        if second_text in [self.rosbag_str, self.parquet_op_str, self.parquet_ip_str]:
            second_text = second_text.replace('_', ' ')
            second_text = "Record " + second_text
        else:
            second_text = text

        list_key_name = text
        tooltip = self.parameters[text]
        horizontal_layout = self.constructCheckbox(second_text,
                                             tooltip, list_key_name,
                                             nodename)
        return horizontal_layout

    def constructCheckbox(self, text, tooltip, list_key_name, nodename):
        horizontal_layout = createHorizontalLayout()

        checkbox = QCheckBox(text)

        if list_key_name in ['server_replay_mrr', 'CAN']:
            checkbox.setChecked(True)

        checkbox.stateChanged.connect(lambda checked: self.checkbox_state_changed(checkbox))
        checkbox.setToolTip(tooltip)
        checkbox.setObjectName(nodename)
        checkbox.setStyleSheet(Style.style_overview_checkbox)

        horizontal_layout.addWidget(checkbox)
        self.check_box_list[list_key_name] = checkbox
        return horizontal_layout

    def layoutMultipleComponent(self, start=0, stop=0, 
                                range=3, all_nodes=False) -> QHBoxLayout:

        horizontal_layout = createHorizontalLayout()

        ros_package_names = self.controller.getRosPackageNames()
        for text in islice(self.nodes_names, start, stop, range):
            package = Nodes(text).name
            if all_nodes == False and package not in ros_package_names:
                pass
            else:
                layout_single = self.layoutSingleComponent(self.nodes_names[text], package)
                layout_single.setContentsMargins(0, 0, 30, 10)
                horizontal_layout.addLayout(layout_single)
        return horizontal_layout

    def layoutSingleComponent(self, text, nodename):
        vertical_layout = createVerticalLayout()
        cb_main = self.overviewCheckbox(text, nodename)
        cb_main.setContentsMargins(10, 10, 0, 0)
        vertical_layout.addLayout(cb_main)

        if self.replay_tool == Tool.Mf4:

            cb_rosbag = self.overviewCheckbox(text + ":" + self.rosbag_str,
                                              nodename)
            cb_rosbag.setContentsMargins(20, 8, 0, 0)
            vertical_layout.addLayout(cb_rosbag)

            ''' No output parquet for Video and VOA'''
            if (text not in 
                [self.nodes_names[Nodes.Video], 
                 self.nodes_names[Nodes.swc_mevehoutpadpracp]]):

                cb_parquet = self.overviewCheckbox(text + ":" + self.parquet_op_str, nodename)
                cb_parquet.setContentsMargins(20, 5, 0, 0)
                vertical_layout.addLayout(cb_parquet)

            ''' No Input parquet for radar, can, video and VOA'''
            if text not in [self.nodes_names[Nodes.server_replay_mrr],
                            self.nodes_names[Nodes.CAN],
                            self.nodes_names[Nodes.Video],
                            self.nodes_names[Nodes.swc_mevehoutpadpracp]]:
                cb_parquet = self.overviewCheckbox(text + ":" + self.parquet_ip_str, nodename)
                cb_parquet.setContentsMargins(20, 5, 0, 0)
                vertical_layout.addLayout(cb_parquet)

        vertical_layout.insertStretch(-1,1)
        return vertical_layout

    def layoutAllComponent(self, text ):
        vertical_layout = createVerticalLayout()
        cb_all = self.constructCheckbox(text = "All " + text,
                                             tooltip = "Enable/Disable all " + text,
                                             list_key_name = text,
                                             nodename = text)
        cb_all.setContentsMargins(20, 5, 0, 15)
        vertical_layout.addLayout(cb_all)
        return vertical_layout

    def checkbox_state_changed(self, state):
        main_key_enum = state.objectName()
        text = state.text()
        if text.find(" ") != -1:
            length_of_number_words = len(text.split())
            data = text.split(" ")[1]
            if length_of_number_words == 2:
                text = data
            elif length_of_number_words == 3:
                data1 = text.split(" ")[2]
                text = data + "_" + data1

        if main_key_enum in [self.feature_str, self.server_str]:
            self.setAbilityOfAllCheckBox(main_key_enum, state)
        else:
            if text not in [self.rosbag_str, self.parquet_op_str, self.parquet_ip_str]:
                checked_value = self.check_box_list[text].isChecked()
                tuple_checkbox_state = (text, checked_value)
                self.overview_node_checked.emit(tuple_checkbox_state)
                if self.replay_tool == Tool.Mf4 and checked_value == False:
                    self.verifyParquetRosbagUnchecked(text)

            else:
                main_key_value = self.nodes_names[main_key_enum]
                main_checkbox = self.check_box_list[main_key_value]
                if main_checkbox.isChecked():
                    sub_checkbox = self.check_box_list[main_key_value+text]
                    checked_value = sub_checkbox.isChecked()
                    ''' Midw parquet signal connected to Radar parquet subscriber'''
                    if main_key_value == "MIDW" and text == self.parquet_op_str:
                        self.midw_parquet_checked.emit(checked_value)

    def getCheckbox(self, node :Nodes):
        text = self.getText(node)
        return self.check_box_list[text]

    def setCheckbox(self, node :Nodes, value):
        text = self.getText(node)
        return self.check_box_list[text].setChecked(value)

    def getText(self, node :Nodes):
        text = self.nodes_names[node]
        return text

    def resetOverviewPanel(self):
        for check_box in self.check_box_list.values():
            check_box.setChecked(False)

    def createParametersDescription(self):
        self.parameters[self.nodes_names[Nodes.server_replay_mrr]] = "Radar node is always required"
        self.parameters[self.nodes_names[Nodes.server_replay_mrrRosbag]] = "Record the Radar Rosbags"
        self.parameters[self.nodes_names[Nodes.server_replay_mrrOutputParquet]] = "Record the Radar Output Parquet"
        
        self.parameters[self.nodes_names[Nodes.CAN]] = "CAN node is always required"
        self.parameters[self.nodes_names[Nodes.CanRosbag]] = "Record the Can Rosbags"
        self.parameters[self.nodes_names[Nodes.CanOutputParquet]] = "Record the Can Output Parquet"
        
        self.parameters[self.nodes_names[Nodes.Video]] = "Enable Video node"
        self.parameters[self.nodes_names[Nodes.VideoRosbag]] = "Record the Video Rosbags"

        self.parameters[self.nodes_names[Nodes.swc_merdrdatacubemidw]] = "Enable Middleware node"
        self.parameters[self.nodes_names[Nodes.swc_merdrdatacubemidwRosbag]] = "Record the Middleware Rosbags"
        self.parameters[self.nodes_names[Nodes.swc_merdrdatacubemidwOutputParquet]] = "Record the Middleware Output Parquet"
        self.parameters[self.nodes_names[Nodes.swc_merdrdatacubemidwInputParquet]] = "Record the Middleware Input Parquet"

        self.parameters[self.nodes_names[Nodes.swc_meblkgdetn]] = "Enable the block detection node"
        self.parameters[self.nodes_names[Nodes.swc_meblkgdetnRosbag]] = "Record the block detection Rosbags"
        self.parameters[self.nodes_names[Nodes.swc_meblkgdetnOutputParquet]] = "Record the block detection Output Parquet"
        self.parameters[self.nodes_names[Nodes.swc_meblkgdetnInputParquet]] = "Record the block detection Input Parquet"

        self.parameters[self.nodes_names[Nodes.swc_mecanoutpadpr]] = "Enable Can vehicle output adapter node"
        self.parameters[self.nodes_names[Nodes.swc_mecanoutpadprRosbag]] = "Record the Can vehicle output adapter Rosbags"
        self.parameters[self.nodes_names[Nodes.swc_mecanoutpadprOutputParquet]] = "Record the Can vehicle output adapter Output Parquet"
        self.parameters[self.nodes_names[Nodes.swc_mecanoutpadprInputParquet]] = "Record the Can vehicle input adapter Output Parquet"

        self.parameters[self.nodes_names[Nodes.swc_meegomtnestimn]] = "Enable ego motion estimator node"
        self.parameters[self.nodes_names[Nodes.swc_meegomtnestimnRosbag]] = "Record the ego motion estimator Rosbags"
        self.parameters[self.nodes_names[Nodes.swc_meegomtnestimnOutputParquet]] = "Record the ego motion estimator Output Parquet"
        self.parameters[self.nodes_names[Nodes.swc_meegomtnestimnInputParquet]] = "Record the ego motion estimator input Parquet"

        self.parameters[self.nodes_names[Nodes.swc_memplobjtrckng]] = "Enable tracker node"
        self.parameters[self.nodes_names[Nodes.swc_memplobjtrckngRosbag]] = "Record the tracker Rosbags"
        self.parameters[self.nodes_names[Nodes.swc_memplobjtrckngOutputParquet]] = "Record the tracker Output Parquet"
        self.parameters[self.nodes_names[Nodes.swc_memplobjtrckngInputParquet]] = "Record the tracker input Parquet"

        self.parameters[self.nodes_names[Nodes.swc_meroadbrdrestimn]] = "Enable the road block detection node"
        self.parameters[self.nodes_names[Nodes.swc_meroadbrdrestimnRosbag]] = "Record the road block detection Rosbags"
        self.parameters[self.nodes_names[Nodes.swc_meroadbrdrestimnOutputParquet]] = "Record the road block detection Output Parquet"
        self.parameters[self.nodes_names[Nodes.swc_meroadbrdrestimnInputParquet]] = "Record the road block detection input Parquet"

        self.parameters[self.nodes_names[Nodes.swc_metunneldetn]] = "Enable tunnel detection node"
        self.parameters[self.nodes_names[Nodes.swc_metunneldetnRosbag]] = "Record the tunnel detection Rosbags"
        self.parameters[self.nodes_names[Nodes.swc_metunneldetnOutputParquet]] = "Record the tunnel detection Output Parquet"
        self.parameters[self.nodes_names[Nodes.swc_metunneldetnInputParquet]] = "Record the tunnel detection input Parquet"

        self.parameters[self.nodes_names[Nodes.swc_mevehoutpadpracp]] = "Enable vehicle output adapter node"
        self.parameters[self.nodes_names[Nodes.swc_mevehoutpadpracpRosbag]] = "Record the vehicle output adapter Rosbags"


    def setReplayData(self, replay_data):
        ''' Flag to set the replay mode. '''
        ''' replay_data/UHDP Node|Publishers|Required nodes|can standalone|UhnderSimulator'''
        ''' rdc3                |radar/rdr pqt     |radar,can,midw|false  | Yes needed'''
        ''' pre_midw            |radar/rdr pqt     |radar,can,midw|false  | not needed'''
        ''' post_midw           |Midw/midw pqt|radar,can,(can be any node(do you mean swc_node) except midw)|false|not needed'''
        '''                          can      | true'''

        if replay_data == True:
            self.setAbilityOfMidw(True)
            midw_check_box = self.check_box_list[self.nodes_names[Nodes.swc_merdrdatacubemidw]]
            if midw_check_box.isChecked():
                midw_check_box.setChecked(False)
            self.midw_rdc3_selection.emit()
            return
        elif replay_data == False:
            self.setAbilityOfMidw(False)
            midw_check_box = self.check_box_list[self.nodes_names[Nodes.swc_merdrdatacubemidw]]
            midw_check_box.setChecked(True)
            self.midw_rdc3_selection.emit()
            return

    def setAbilityOfMidw(self, value):
        midw_check_box = self.check_box_list[self.nodes_names[Nodes.swc_merdrdatacubemidw]]
        midw_rosbag_check_box = self.check_box_list[self.nodes_names[Nodes.swc_merdrdatacubemidwRosbag]]
        midw_parquet_check_box = self.check_box_list[self.nodes_names[Nodes.swc_merdrdatacubemidwOutputParquet]]
        radar_parquet_chk_box = self.check_box_list[self.nodes_names[Nodes.server_replay_mrrOutputParquet]]
        toggle_value = not value
        midw_check_box.setDisabled(value)
        midw_check_box.setChecked(toggle_value)
        midw_rosbag_check_box.setDisabled(value)
        midw_parquet_check_box.setDisabled(value)
        midw_parquet_check_box.setChecked(toggle_value)
        radar_parquet_chk_box.setChecked(value)

    def requiredCheckboxAbility(self, value):
        radar_check_box = self.check_box_list[self.nodes_names[Nodes.server_replay_mrr]]
        radar_check_box.setChecked(value)
        can_check_box = self.check_box_list[self.nodes_names[Nodes.CAN]]
        can_check_box.setChecked(value)

    def getEnabledNodes(self):
        nodes_set = set()
        for node, checkbox in self.check_box_list.items():
            if checkbox.isChecked() :
                main_key_enum = checkbox.objectName()
                text = checkbox.text()
                if "All" in text or " Replay" in text:
                    continue
                elif (self.rosbag_str in text
                     or self.parquet_op_str in text
                     or self.parquet_ip_str in text):
                    continue
                elif main_key_enum in [ Nodes.CAN, Nodes.Video]:
                    continue
                nodes_set.add(main_key_enum)
        return nodes_set

    def getLaunchEnabledNodes(self):
        '''Need only DspApp nodes'''
        nodes_set = set()
        for node, checkbox in self.check_box_list.items():
            if checkbox.isChecked() :
                main_key_enum = checkbox.objectName()
                text = checkbox.text()
                if "All" in text or " Replay" in text:
                    continue
                elif (self.rosbag_str in text
                      or self.parquet_op_str in text
                      or self.parquet_ip_str in text):
                    continue
                elif main_key_enum in [Nodes.swc_memplobjtrckng, Nodes.swc_merdrdatacubemidw]:
                    nodes_set.add(main_key_enum)
        return nodes_set

    def setAbilityOfAllCheckBox(self, text, state):
        if self.feature_str == text:
            search_txt = "swc_"
        elif self.server_str == text:
            search_txt = "server"
        set_value = state.isChecked()
        for node, checkbox in self.check_box_list.items():
            main_key_enum = checkbox.objectName()
            chk_box_text = checkbox.text()
            if "All" in chk_box_text:
                continue
            elif chk_box_text not in ("Record " + self.rosbag_str,
                                      "Record Output Parquet", # + self.parquet_op_str,
                                      "Record Input Parquet",  # + self.parquet_ip_str,
                                    self.nodes_names[Nodes.swc_merdrdatacubemidw],
                                    self.nodes_names[Nodes.server_replay_mrr],
                                    self.nodes_names[Nodes.CAN]):
                if self.feature_str == text and search_txt in main_key_enum:
                    checkbox.setChecked(set_value)
                if self.server_str == text and chk_box_text in (self.nodes_names[Nodes.Video]):
                    checkbox.setChecked(set_value)

    ''' Among the enabled nodes, node with maximum value in the dictionary 
    is set as complete trigger node of Radar panel'''
    def getNodeOfMaximumWeight(self):
        enabled_nodes_set = self.getEnabledNodes()
        if not enabled_nodes_set:
            return Nodes.server_replay_mrr

        weightOfNodes = createWeightDictOfNodes()

        value = 0
        node_name = Nodes.server_replay_mrr
        for node in enabled_nodes_set:
            node_value = weightOfNodes[node]
            if node_value > value:
                value = node_value
                node_name = node
        return node_name

    '''Record rosbags for swc_components unselected and disabled'''
    def disableRecordRosbagsForSwc(self):
        checkbox = self.check_box_list.get(self.nodes_names[Nodes.swc_meblkgdetnRosbag])
        if checkbox is not None:
            checkbox.setDisabled(True)
        checkbox =self.check_box_list.get(self.nodes_names[Nodes.swc_mecanoutpadprRosbag])
        if checkbox is not None:
            checkbox.setDisabled(True)
        checkbox =self.check_box_list.get(self.nodes_names[Nodes.swc_meegomtnestimnRosbag])
        if checkbox is not None:
            checkbox.setDisabled(True)
        checkbox =self.check_box_list.get(self.nodes_names[Nodes.swc_memplobjtrckngRosbag])
        if checkbox is not None:
            checkbox.setDisabled(True)
        checkbox =self.check_box_list.get(self.nodes_names[Nodes.swc_meroadbrdrestimnRosbag])
        if checkbox is not None:
            checkbox.setDisabled(True)
        checkbox =self.check_box_list.get(self.nodes_names[Nodes.swc_metunneldetnRosbag])
        if checkbox is not None:
            checkbox.setDisabled(True)
        checkbox =self.check_box_list.get(self.nodes_names[Nodes.swc_mevehoutpadpracpRosbag])
        if checkbox is not None:
            checkbox.setDisabled(True)

    '''Uncheck Parquet/Rosbag check box if its main checkbox is unchecked'''
    def verifyParquetRosbagUnchecked(self, text):
        op_pqt_checkbox = self.check_box_list.get(text+self.parquet_op_str)
        if op_pqt_checkbox is not None and op_pqt_checkbox.isChecked():
            op_pqt_checkbox.setChecked(False)
        ip_pqt_checkbox = self.check_box_list.get(text+self.parquet_ip_str)
        if ip_pqt_checkbox is not None and ip_pqt_checkbox.isChecked():
            ip_pqt_checkbox.setChecked(False)
        rosbag_checkbox = self.check_box_list.get(text+self.rosbag_str)
        if rosbag_checkbox is not None and rosbag_checkbox.isChecked():
            rosbag_checkbox.setChecked(False)


    def disableCOAInputParquet(self):
        checkbox =self.check_box_list.get(self.nodes_names[Nodes.swc_mecanoutpadprInputParquet])
        if checkbox is not None:
            checkbox.setDisabled(True)
    
    #FileselectionPreviousandCurrentSelection
