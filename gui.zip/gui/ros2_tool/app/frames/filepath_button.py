from PySide6.QtWidgets import (
    QMainWindow, QFileDialog,
    QMessageBox, QDialog)

from PySide6.QtCore import Signal, QUrl
import os


class FilepathButton(QMainWindow):
    ''' File select Signal sent from filepath button click to
    launch DSP process '''
    file_path_selected = Signal()

    def __init__(self, select_file_input, select_button,
                 user_entries, file_type, param_name, param_value: str, folder_or_multiple_file=True):
        super(FilepathButton, self).__init__()

        self.param_value = param_value
        self.user_entries = user_entries
        self.param_name = param_name
        self.file_type = file_type

        self.select_file_input = select_file_input
        self.select_button = select_button
        self.folder_or_multiple_file = folder_or_multiple_file
        self.dir_path = ''

        self.filepath = ''

        if folder_or_multiple_file == 'Folder':
            self.select_button.clicked.connect(lambda checked: self.selectFolderClicked())
            if (len(param_value)) and self.isFileExist(param_value):
                self.filepath = param_value
                self.select_file_input.setText(self.filepath)
            else:
                self.param_value = ""
        elif folder_or_multiple_file == True:
            self.select_button.clicked.connect(lambda checked: self.selectMultipleFileClicked())
            if (len(param_value)):
                self.addFilepathsToEntry(param_value)
        else:
            self.select_button.clicked.connect(lambda checked: self.selectSingleFileClicked())
            if (len(param_value)):
                self.addFilepathtoEntry(param_value)

    def selectMultipleFileClicked(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog

        msg = "Select " + str(self.file_type).upper() + " File(s)"
        filetype = "*." + str(self.file_type)
        mf4_file_paths = QFileDialog.getOpenFileNames(None, str(msg), self.dir_path, filetype,
                                                      options=options)
        if len(mf4_file_paths[0]) == 0:
            return

        mf4_file_paths = list(mf4_file_paths[0])
        self.dir_path = os.path.dirname(mf4_file_paths[0])
        num_files_selected = len(mf4_file_paths)

        self.param_value = mf4_file_paths
        confirm = QMessageBox.question(self, "Confirm",
                                       f"Selected  {num_files_selected} files"
                                       " for processing, Continue?",
                                       QMessageBox.Yes | QMessageBox.No)
        if not confirm:
            return

        self.addFilepathsToEntry(mf4_file_paths)

    def selectSingleFileClicked(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog

        if (self.file_type == ""):
            msg = "Select DSP App Path"
            filetype = '*'
        else:
            msg = "Select " + str(self.file_type).upper() + " File(s)"
            filetype = "*." + str(self.file_type)

        file_path = QFileDialog.getOpenFileName(
            None, str(msg), self.dir_path, filetype, options=options)

        if len(file_path[0]) == 0:
            print(f"{file_path[0]} len(file_path[0]) {len(file_path[0])} ")
            return

        self.filepath = file_path[0]
        self.dir_path = os.path.dirname(self.filepath)
        self.select_file_input.setText(self.filepath)
        self.param_value = self.filepath

        if (len(self.file_type) == 0):
            self.file_path_selected.emit()

    def selectFolderClicked(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        options |= QFileDialog.DontUseCustomDirectoryIcons

        dialog = QFileDialog(self, "Select Folder")
        dialog.setOptions(options)
        dialog.setFileMode(QFileDialog.Directory)
        dialog.setDirectory(str(self.dir_path))
        dialog.setSidebarUrls([QUrl.fromLocalFile(os.getcwd())])

        if dialog.exec_() == QDialog.Accepted:
            folder_path = dialog.selectedFiles()[0]

        if len(folder_path) == 0:
            print(f"{folder_path} len(folder_path[0]) {len(folder_path)} ")
            return

        self.file_type = "Rosbag"
        self.filepath = folder_path
        self.dir_path = os.path.dirname(self.filepath)
        self.select_file_input.setText(self.filepath)
        self.param_value = self.filepath

    def get(self):
        if len(self.param_value) == 0:
            msg = "Please select a valid " + str(self.file_type)
            if self.folder_or_multiple_file == 'Folder':
                msg = msg + " folder."
            else:
                msg = msg + " file."
            QMessageBox.critical(self, "File Input Error",
                                 msg, QMessageBox.Ok)
            return None
        return (self.param_value)

    def addFilepathsToEntry(self, file_paths):
        self.select_file_input.clear()
        file_num = 1
        file_collection_with_index = ""
        for index in range(len(file_paths)):
            if self.isFileExist(file_paths[index]):
                file_collection_with_index += (str(file_num) + ". " + file_paths[index] + "\n")
                file_num += 1
        self.select_file_input.setText(file_collection_with_index)
        if file_collection_with_index == "":
            self.param_value = ""
        else:
            self.param_value = file_paths

    def addFilepathtoEntry(self, file_path):
        if self.isFileExist(file_path):
            self.filepath = file_path
            self.select_file_input.setText(self.filepath)
            self.param_value = self.filepath

            if (self.file_type == ""):
                self.file_path_selected.emit()
        else:
            self.param_value = ""

    def isFileExist(self, file):
        return os.path.exists(file)
