from app.frames.common_widget import *

from PySide6.QtWidgets import (
    QFileDialog,
    QWidget,
    QMessageBox,
    QSpacerItem
)

from PySide6.QtCore import Signal, QSortFilterProxyModel
from app.frames.scroll_label import ScrollLabel
import os


class BtnSaveFile(PushButton):

    on_click_dialog = Signal(str)

    def __init__(self, text, tooltip, icon_png, dialog_title, dialog_help, filter, suffix) -> None:
        super().__init__(text, tooltip, icon_png)
        self.dialog_title = dialog_title
        self.dialog_help = dialog_help
        self.suffix = suffix
        self.filter = filter
        self.open = open

    def on_clicked(self):
        file_dialog = QFileDialog(self)
        file_dialog.setWindowTitle(self.dialog_title)
        file_dialog.setMinimumSize(400, 240)
        file_dialog.setDefaultSuffix(self.suffix)
        file_dialog.setNameFilter(self.filter)
        # file_dialog.setOptions(QFileDialog.DontUseNativeDialog)
        file_dialog.setAcceptMode(QFileDialog.AcceptSave)
        if file_dialog.exec_() == QFileDialog.Accepted:
            config_file_path = str(file_dialog.selectedFiles()[0])
            if len(config_file_path[0]) != 0:
                self.on_click_dialog.emit(config_file_path)


class BtnOpenFile(PushButton):

    OPEN_FILE_SINGLE = 1
    OPEN_FILE_MULTI = 2
    OPEN_FOLDER = 3

    on_click_file_single = Signal(str)
    on_click_file_multi = Signal(list)
    on_click_folder = Signal(str)

    def __init__(self, text, tooltip, icon_png, dialog_title, dialog_help, filter,
                 suffix, open_type=OPEN_FILE_SINGLE) -> None:
        super().__init__(text, tooltip, icon_png)
        self.dialog_title = dialog_title
        self.dialog_help = dialog_help
        self.suffix = suffix
        self.filter = filter
        self.open_type = open_type
        self.dir_path = ''

    def on_clicked(self):
        file_dialog = QFileDialog(self)
        file_dialog.setWindowTitle(self.dialog_title)
        file_dialog.setMinimumSize(400, 240)

        if self.open_type == self.OPEN_FILE_SINGLE:
            file_dialog.setFileMode(QFileDialog.ExistingFile)
            file_dialog.setDefaultSuffix(self.suffix)
            file_dialog.setNameFilter(self.filter)

        elif self.open_type == self.OPEN_FILE_MULTI:
            file_dialog.setFileMode(QFileDialog.ExistingFiles)
            file_dialog.setDefaultSuffix(self.suffix)
            file_dialog.setNameFilter(self.filter)
            ''' sort by filename'''
            sorter = QSortFilterProxyModel() 
            file_dialog.setProxyModel(sorter)
            sorter.setDynamicSortFilter(True)
            sorter.sort(1, Qt.SortOrder.AscendingOrder)
            file_dialog.setProxyModel(sorter)

        elif self.open_type == self.OPEN_FOLDER:
            file_dialog.setFileMode(QFileDialog.Directory)

        file_dialog.setAcceptMode(QFileDialog.AcceptOpen)
        file_dialog.setDirectory(str(self.dir_path))

        if file_dialog.exec_() == QFileDialog.Accepted:
            file_path = str(file_dialog.selectedFiles()[0])

            if len(file_path) != 0:
                if self.open_type == self.OPEN_FILE_SINGLE:
                    self.dir_path = os.path.dirname(file_path)
                    self.selectSingleFileClicked(file_path)

                elif self.open_type == self.OPEN_FILE_MULTI:
                    self.dir_path = os.path.dirname(file_dialog.selectedFiles()[0])
                    self.selectMultipleFileClicked(file_dialog.selectedFiles())

                elif self.open_type == self.OPEN_FOLDER:
                    self.dir_path = os.path.dirname(file_path)
                    self.selectFolderClicked(file_path)

                else:
                    raise NotImplementedError(f"{self.open_type} undefined")

    def selectMultipleFileClicked(self, selected_files: list) -> None:
        num_files_selected = len(selected_files)
        reply = QMessageBox.question(self, "Confirm",
                                       f"Selected  {num_files_selected} files"
                                       " for processing, Continue?",
                                       QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.on_click_file_multi.emit(selected_files)
        elif reply == QMessageBox.No:
            selected_files.clear()

    def selectSingleFileClicked(self, file_path: str) -> None:
        self.on_click_file_single.emit(file_path)

    def selectFolderClicked(self, folder_path: str) -> None:
        self.on_click_folder.emit(folder_path)

    def getFolderpath(self):
        return self.dir_path

class BtnFile(QWidget):

    def __init__(self, **kwargs) -> None:
        QWidget.__init__(self)
        self.widget_button = None
        self.label_note = None
        for key, value in kwargs.items():
            if key == 'widget_button':
                self.widget_button = value
            elif key == 'label_note':
                self.label_note = value
            else:
                raise NotImplementedError
        self.createLayout()
        return

    def createLayout(self):
        self.param_value = ""
        if self.widget_button is not None:
            layout_widget = createVerticalLayout()
            btn = self.widget_button
            btn.on_click_file_single.connect(self.addFileToEntry)
            btn.on_click_file_multi.connect(self.addFilesToEntry)
            btn.on_click_folder.connect(self.addFolderToEntry)
            layout_widget.addWidget(btn)
            ''' Files list '''
            layout_widget.addSpacing(5)
            self.widget_label_selected_files = ScrollLabel(self)
            layout_widget.addWidget(self.widget_label_selected_files)
            if self.label_note is not None:
                ''' Notes '''
                self.widget_label_note = LabelAsNote(self.label_note)
                self.widget_label_note.setContentsMargins(0, 2, 0, 0)
                layout_widget.addWidget(self.widget_label_note)

            self.setLayout(layout_widget)
        else:
            print("No selected button")
            raise NotImplementedError

    def addFileToEntry(self, file_path):
        if os.path.exists(file_path):
            self.filepath = file_path
            self.widget_label_selected_files.setText(self.filepath)
            self.param_value = self.filepath
        else:
            self.param_value = ""

    def addFilesToEntry(self, file_paths):
        self.widget_label_selected_files.clear()
        file_num = 1
        file_collection_with_index = ""
        for index in range(len(file_paths)):
            if os.path.exists(file_paths[index]):
                file_collection_with_index += (str(file_num) + ". " + file_paths[index] + "\n")
                file_num += 1
        self.widget_label_selected_files.setText(file_collection_with_index)
        if file_collection_with_index == "":
            self.param_value = ""
        else:
            self.param_value = file_paths

    def addFolderToEntry(self, folder_path) -> None:
        if os.path.exists(folder_path):
            self.widget_label_selected_files.setText(folder_path)
            self.param_value = folder_path

    def get(self):
        if len(self.param_value) == 0:
            msg = "Please select a valid file"
            QMessageBox.critical(self, "File Input Error",
                                 msg, QMessageBox.Ok)
            return None
        return (self.param_value)


class BtnOpenConfig(BtnOpenFile):

    def __init__(self,
                 text='  Open Config',
                 tooltip='Open saved configuration',
                 icon_png=u":/16x16/icons/16x16/cil-folder-open.png",
                 dialog_title='Open config file',
                 dialog_help="",
                 filter='Replay config (*.replayconfig)',
                 suffix='replayconfig') -> None:
        super().__init__(text, tooltip, icon_png, dialog_title, dialog_help,
                         filter, suffix)


class BtnOpenMf4(BtnOpenFile):

    def __init__(self,
                 text='  Select Mf4 file(s)',
                 tooltip='Select mf4 file(s)',
                 icon_png=u":/16x16/icons/16x16/cil-folder-open.png",
                 dialog_title='Select the Rdc3 mf4 file(s)',
                 dialog_help="",
                 filter='Recording(s) (*.mf4)',
                 suffix='mf4',
                 width=150) -> None:
        super().__init__(text, tooltip, icon_png, dialog_title, dialog_help,
                         filter, suffix, open_type=self.OPEN_FILE_MULTI)
        self.setFixedWidth(width)


class BtnOpenFolder(BtnOpenFile):
    def __init__(self,
                 text='  Select Rosbag folder ',
                 tooltip='Choose Rosbag folder',
                 icon_png=u":/16x16/icons/16x16/cil-folder-open.png",
                 dialog_title='Select Folder',
                 dialog_help="",
                 filter='',
                 suffix='',
                 width=170) -> None:
        super().__init__(text, tooltip, icon_png, dialog_title, dialog_help,
                         filter, suffix, open_type=self.OPEN_FOLDER)
        self.setFixedWidth(width)


class BtnOpenSingleFile(BtnOpenFile):
    def __init__(self,
                 text='  Select File ',
                 tooltip='Choose file',
                 icon_png=u":/16x16/icons/16x16/cil-folder-open.png",
                 dialog_title='Select File',
                 dialog_help="",
                 filter='',
                 suffix='') -> None:
        super().__init__(text, tooltip, icon_png, dialog_title, dialog_help,
                         filter, suffix, open_type=self.OPEN_FILE_SINGLE)
        self.setFixedWidth(150)


class BtnSaveConfig(BtnSaveFile):

    def __init__(self,
                 text='  Save Config',
                 tooltip='Save the configuration into *.replayconfig file',
                 icon_png=u":/16x16/icons/16x16/cil-save.png",
                 dialog_title='Save config file',
                 dialog_help="",
                 filter='Replay config (*.replayconfig)',
                 suffix='replayconfig') -> None:
        super().__init__(text, tooltip, icon_png, dialog_title, dialog_help, filter, suffix)


class BtnMediaPlay(PushButton):

    def __init__(self) -> None:
        super().__init__(
            text="  Play",
            tooltip="Replay the selected mf4 files",
            icon_png=u":/16x16/icons/16x16/cil-media-play.png")


class LayoutBtnConfig(QHBoxLayout):
    def __init__(self, button_config, offset_width) -> None:
        super().__init__()
        if offset_width:
            ''' set the label size to tab size width and then place the btn'''
            lbl = createLabel(label_text="")
            lbl.setMinimumSize(offset_width, 0)
        self.addWidget(lbl)
        self.addWidget(button_config)

    def addBtnWidget(self, widget):
        self.addSpacerItem(QSpacerItem(10, 20, QSizePolicy.Minimum, QSizePolicy.Expanding))
        self.addWidget(widget)
