
from app.utils.subprocess_util import SubprocessUtil
from app.ros_launch_generator import RosLaunchGenerator
from app.controller.app_controller import AppController
from app.utils.live_utils import *

import os


class LiveAdapterController(AppController):

    def __init__(self, can_live=False):
        super(LiveAdapterController, self).__init__()

        self.ros_launch_process = None
        self.can_live = can_live

        if can_live:
            self.PARAMS_FILE_NAME = self.app_config['PARAMS_CAN_LIVE_FILE_NAME']
            self.ROS_PACKAGE = self.app_config['CAN_ROS_PACKAGE']
            self.ROS_NODE_NAME = self.app_config['CAN_LIVE_ROS_NODE_NAME']
        else:
            self.PARAMS_FILE_NAME = self.app_config['PARAMS_LIVE_FILE_NAME']
            self.ROS_PACKAGE = self.app_config['RADAR_ROS_PACKAGE']
            self.ROS_NODE_NAME = self.app_config['RADAR_LIVE_ROS_NODE_NAME']

            self.PARAMS_LRR_LIVE_FILE_NAME = self.app_config['PARAMS_LRR_LIVE_FILE_NAME']
            self.LRR_RADAR_ROS_PACKAGE = self.app_config['LRR_RADAR_ROS_PACKAGE']
            self.LRR_LIVE_ROS_NODE_NAME = self.app_config['LRR_LIVE_ROS_NODE_NAME']

    def launch(self, replay_config):
        if replay_config:

            self.launchRviz()

            ros_launch_generator = RosLaunchGenerator(replay_config, live_adapter=True)
            if self.can_live:
                launch_file_path = os.path.abspath(
                    self.TMP_FOLDER_PATH / "roslaunch_live_can.py")
            else:
                launch_file_path = os.path.abspath(
                    self.TMP_FOLDER_PATH / "roslaunch_live_ethernet.py")

            ros_launch_generator.generateLaunchFile(launch_file_path)

            cmd = ['ros2', 'launch', launch_file_path]

            self.ros_launch_process = SubprocessUtil(cmd)
            return self.ros_launch_process.launch()

        return False

    def stop(self):
        #print(f"Can {self.can_live} Live adapter app controller stop called\n")
        super().stop()
        if self.ros_launch_process:
            return self.ros_launch_process.stop()
        return True

    def getReplayConfig(self, device_type):
        config = []
        default_device_params_config = self.node_config_util.getConfig(package_name=self.ROS_PACKAGE,
                                                                      file_name=self.PARAMS_FILE_NAME)

        device_params_info_config = self.node_config_util.getConfig(package_name=self.ROS_PACKAGE,
                                                                   file_name=self.PARAMS_INFO_FILE_NAME)

        if (default_device_params_config and device_params_info_config):
            radar_config = {}
            radar_config['ros_package'] = self.ROS_PACKAGE
            radar_config['ros_node_name'] = self.ROS_NODE_NAME
            radar_config['params_config'] = default_device_params_config
            radar_config['params_info_config'] = device_params_info_config
            config.append(radar_config)
            
        if device_type == DeviceType.MRRRadar:
            '''If device type is Radar, add one tab for LRR radar'''
            default_device_params_config = self.node_config_util.getConfig(package_name=self.LRR_RADAR_ROS_PACKAGE,
                                                                        file_name=self.PARAMS_LRR_LIVE_FILE_NAME)

            device_params_info_config = self.node_config_util.getConfig(package_name=self.LRR_RADAR_ROS_PACKAGE,
                                                                    file_name=self.PARAMS_INFO_FILE_NAME)

            if (default_device_params_config and device_params_info_config):
                lrr_radar_config = {}
                lrr_radar_config['ros_package'] = self.LRR_RADAR_ROS_PACKAGE
                lrr_radar_config['ros_node_name'] = self.LRR_LIVE_ROS_NODE_NAME
                lrr_radar_config['params_config'] = default_device_params_config
                lrr_radar_config['params_info_config'] = device_params_info_config
                config.append(lrr_radar_config)

        return config
