# This Python file uses the following encoding: utf-8
from .frames.app_view import AppView
from .live_adapter_controller import LiveAdapterController

import sys

class LiveAdapter():

    def __init__(self, can_live=False):
        self.live_adapter_app_controller = LiveAdapterController(can_live)
        self.can_live = can_live

    def liveAdapterView(self):
        try:
            live_adapter_view = AppView(self.live_adapter_app_controller,
                                        self.can_live)
            return live_adapter_view

        except BaseException:
            print(f"Live Adapter BaseException {sys.stderr}")
            raise

    def getAppController(self):
        return self.live_adapter_app_controller
