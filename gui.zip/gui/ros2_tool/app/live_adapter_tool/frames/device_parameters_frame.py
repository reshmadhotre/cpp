from app.frames.common_widget import *
from app.frames.param_input_frame import ParamInputFrame
from app.frames.menu_button import BtnOpenFolder, BtnFile, BtnOpenSingleFile
from app.utils.live_utils import *

from PySide6.QtWidgets import (
    QMainWindow, QFormLayout, QSpacerItem,
    QWidget, QMessageBox, QVBoxLayout)
from PySide6.QtCore import Qt, QLocale, QRegularExpression
from PySide6.QtGui import QDoubleValidator, QRegularExpressionValidator, QIntValidator


class DeviceParametersFrame(QMainWindow):
    ''' Add : Add device : True
        Remove : Remove Device : False'''
    def __init__(self, appview, node_config: dict, 
                 add_device_flag:bool, name_space="",
                 device_type=DeviceType.NoneType):
        super(DeviceParametersFrame, self).__init__()

        self.appview = appview

        if device_type==DeviceType.NoneType:
            self.device_type = appview.device_type
        else:
            self.device_type = device_type

        self.tabwidget = appview.tab_widget
        self.add_device_flag = add_device_flag
        self.name_space = name_space
        self.node_config = node_config.copy()
        self.tab_count = 0

        self.user_entries = {}
        self.parameters = {}
        self.name_spaces = []
        self.createInputFrame()

    def createInputFrame(self):
        if self.device_type == DeviceType.CAN:
            self.device = "CAN"
        else:
            self.device = "Radar"

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]
        self.LRR = " (LRR)"

        if self.add_device_flag:
            ''' Add new device tab'''
            self.current_node = "Add " + self.device + " Device"
        else:
            if self.device_type == DeviceType.CAN:
                if self.name_space == "":
                    ''' fetch the name_space from replay config saved file'''
                    self.name_space = self.node_config['params_config']['server_live_can_node']['name_space']
                else:
                    ''' name_space does not exist, add it'''
                    self.node_config['params_config']['server_live_can_node']['name_space'] = self.name_space

            elif self.device_type == DeviceType.MRRRadar:
                self.device = "Radar"
                if self.name_space == "":
                    self.name_space = self.node_config['params_config']['server_live_mrr_node']['name_space']
                else:
                    self.node_config['params_config']['server_live_mrr_node']['name_space'] = self.name_space

            elif self.device_type == DeviceType.LRRRadar:
                self.device = "Radar"
                if self.name_space == '':
                    self.name_space = self.node_config['params_config']['server_replay_lrr_node']['name_space']
                else:
                    self.node_config['params_config']['server_replay_lrr_node']['name_space'] = self.name_space

            ''' Add actual device tab'''
            if self.device_type == DeviceType.LRRRadar:
                self.current_node = self.name_space + self.LRR
            else:
                self.current_node = self.name_space
            self.name_spaces.append(self.current_node)

        self.insertDevice(device_config = self.node_config['params_config'][node_name])

    def insertDevice(self, device_config):

        layout_device = QVBoxLayout()

        if self.device_type == DeviceType.LRRRadar:
            self.addIsLRRSelected(layout_device)

        if self.device_type == DeviceType.CAN:
            self.btn_open_dbc = BtnFile(widget_button=BtnOpenSingleFile(text="  Open DBC file",
                                                                    tooltip="Choose the DBC file",
                                                                    dialog_title='Select the dbc file',
                                                                    filter='DBC (*.dbc)',
                                                                    suffix='dbc'),
                                                label_note='Select dbc file Ex:/home/path/vector.dbc')
            layout_device.addWidget(self.btn_open_dbc)

        self.btn_open_folder = BtnFile(widget_button=BtnOpenFolder(text="  Open rosbag folder",
                                                                    tooltip="Choose the Rosbag folder",
                                                                    dialog_title='Select the folder of rosbag file'),
                                                label_note='Select folder Ex:/home/path')
        layout_device.addWidget(self.btn_open_folder)

        self.createParametersDescription()

        ''' Layout for labels/button'''
        layout_properties = createVerticalLayout()
        widget_properties = QWidget()
        scroll_properties = QScrollArea(widgetResizable=True)
        scroll_properties.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_properties.setWidgetResizable(True)

        scroll_properties.setWidget(widget_properties)
        layout_device.addWidget(scroll_properties)

        widget_properties.setLayout(layout_properties)

        formlayout = QFormLayout()
        if self.add_device_flag:
            param_name = "name_space"
            if self.device_type == DeviceType.LRRRadar:
                param_value = "front_center" + self.LRR
            else:
                param_value = "front_right"

            value_type = "string"
            value_options = []
            param_input_frame = ParamInputFrame(param_name, param_value,
                                                    value_type, value_options)
            self.user_entries[param_name] = param_input_frame
            label, text_box = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                         text_box=True)
            text_box.textChanged[str].connect(lambda text,
                                                      param=param_name: self.textBoxChanged(text, param))
            formlayout.addRow(label, text_box)

        for param_name, param_value in device_config['ros__parameters'].items():
            if param_name != 'record_rosbags' and (param_value is True or param_value is False):
                continue

            value_type = self.getValueTypeFromInfoConfig(param_name)
            value_options = self.getValueOptionsFromInfoConfig(param_name)

            if param_name == 'rosbag_path':
                self.user_entries[param_name] = self.btn_open_folder
                if len(param_value):
                    self.btn_open_folder.addFolderToEntry(param_value)

            elif param_name == 'dbc_filepath':
                self.user_entries[param_name] = self.btn_open_dbc
                if len(param_value):
                    self.btn_open_dbc.addFileToEntry(param_value)

            else:
                param_input_frame = ParamInputFrame(param_name, param_value,
                                                    value_type, value_options)
                self.user_entries[param_name] = param_input_frame

                if (param_name == 'adapter_ip_address' or
                    param_name == 'radar_ip_address'):

                    label, text_box = param_input_frame.createInputFrame(
                        tooltip=self.parameters[param_name],
                        text_box=True)
                    text_box.textChanged[str].connect(lambda text,
                                                      param=param_name: self.textBoxChanged(text, param))

                    formlayout.addWidget(createSpacerLabel(2))
                    formlayout.addRow(label, text_box)
                    formlayout.addWidget(createSpacerLabel(2))

                    ip_range = "(?:[0-1]?[0-9]?[0-9]|2[0-4][0-9]|25[0-5])"
                    ip_valid = "^" + ip_range + "(\\." + ip_range + ")" + \
                            "(\\." + ip_range + ")" + "(\\." + ip_range + ")$"
                    ip_regex = QRegularExpression(ip_valid)
                    validator = QRegularExpressionValidator(ip_regex)
                    text_box.setValidator(validator)

                elif value_type == 'bool':
                    self.rosbag_path_check_box, label, window = param_input_frame.createInputFrame(
                        tooltip=self.parameters[param_name],
                        check_box=True)

                    formlayout.addWidget(createSpacerLabel(2))
                    formlayout.addRow(label, self.rosbag_path_check_box)
                    formlayout.addWidget(createSpacerLabel(2))

                elif value_type == 'string':
                    label, combo_box = param_input_frame.createInputFrame(
                                    tooltip=self.parameters[param_name],
                                    combo_box=True)
                    combo_box.currentTextChanged.connect(
                                    lambda text,
                                    param=param_name: self.widget_box_changed(text, param))

                    formlayout.addWidget(createSpacerLabel(2))
                    formlayout.addRow(label, combo_box)
                    formlayout.addWidget(createSpacerLabel(2))

                else:
                    label, text_box = param_input_frame.createInputFrame(
                        tooltip=self.parameters[param_name],
                        text_box=True)
                    text_box.textChanged[str].connect(lambda text,
                                                      param=param_name: self.textBoxChanged(text, param))

                    formlayout.addWidget(createSpacerLabel(2))
                    formlayout.addRow(label, text_box)
                    formlayout.addWidget(createSpacerLabel(2))

                    if value_type == 'double':
                        validator = QDoubleValidator(0.1, 9990, 2)
                        locale = QLocale(QLocale.English, QLocale.UnitedStates)

                        validator.setLocale(locale)
                        validator.setNotation(QDoubleValidator.StandardNotation)
                    elif value_type == 'int':
                        validator = QIntValidator(1, 2,)
                        locale = QLocale(QLocale.English, QLocale.UnitedStates)

                        validator.setLocale(locale)

                    text_box.setValidator(validator)

        layout_properties.addLayout(formlayout)

        if self.device_type != DeviceType.LRRRadar:
            layout_btn = self.createButtonFrame()
            layout_properties.addLayout(layout_btn)

        layout_properties.addSpacerItem(QSpacerItem(10, 10, QSizePolicy.Expanding, QSizePolicy.Minimum))
        layout_properties.insertStretch(-1, 1)

        widget_device = QWidget()
        widget_device.setLayout(layout_device)

        self.tabwidget.addTab(widget_device, self.current_node)
        #print(f"add tab name {self.current_node} count {self.tabwidget.count()}")


    def getValueTypeFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['type']

        return "string"

    def getValueOptionsFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['values']

        return []

    def getConfig(self):
        if self.updateConfig():
            return self.node_config.copy()
        return None

    def setConfig(self, node_config):
        self.node_config = node_config.copy()
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        index = 0
        for node in params_config[node_name]:
            for param_name in node['ros__parameters'].keys():
                param_input_frame = self.user_entries[param_name]
                param_input_frame.resetWidgetbox(
                    (params_config[node_name][index]['ros__parameters'][param_name]))
            index = index + 1

    def updateConfig(self):
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name in params_config[node_name]['ros__parameters'].keys():
            ''' String objects'''
            if self.user_entries.get(param_name):
                if self.rosbag_path_check_box.isChecked() == False and param_name == 'rosbag_path':
                    user_value = ''
                else:
                    user_value = self.user_entries[param_name].get()
                    if user_value is None:
                        return False
                    elif user_value == "" or user_value == ' ':
                        QMessageBox.critical(self, "Value Error",
                                            f"Expected a value for param {self.name_space} : {param_name}",
                                            QMessageBox.Ok)
                        return False
                self.node_config['params_config'][node_name]['ros__parameters'][param_name] = user_value

        if self.device_type == DeviceType.MRRRadar:
            publish_flags = self.appview.check_box_frame.getConfig()
            for node in params_config[node_name]:
                self.node_config['params_config'][node_name]['ros__parameters'].update(publish_flags)

        return True

    def checkNamespaceInConfig(self, name_space):
        for node_index in range(len(self.name_spaces)):
            if self.name_spaces[node_index] == name_space:
                return True
        return False

    def removeDeviceClicked(self):
        current_tab_index = self.tabwidget.currentIndex()
        tab_count = self.tabwidget.count()
        self.appview.removeDeviceConfig(index=current_tab_index, tab_count=tab_count)
        self.tabwidget.removeTab(current_tab_index)

    def textBoxChanged(self, text, param_name):
        param_input_frame = self.user_entries[param_name]
        param_input_frame.param_value = text
        self.user_entries[param_name] = param_input_frame

    def createParametersDescription(self):
        self.parameters["name_space"] = "Add new device within the mentioned name_space"
        self.parameters["record_rosbags"] = "Record the live rosbags"
        self.parameters["adapter_ip_address"] = "Add the Ip address of MRR Radar"
        self.parameters["sensor_position_x"] = "Specify sensor_position_x value"
        self.parameters["sensor_position_y"] = "Specify sensor_position_y value"
        self.parameters["sensor_position_z"] = "Specify sensor_position_z value"
        self.parameters["sensor_pitch"] = "Specify sensor_pitch"
        self.parameters["sensor_roll"] = "Specify sensor_roll"
        self.parameters["sensor_yaw"] = "Specify sensor_yaw"
        self.parameters["dbc_filepath"] = "Specify file path of *.dbc file"
        self.parameters["can_channel"] = "Specify CAN channel"
        self.parameters["radar_ip_address"] = "Specify the Ip address of LRR Radar"
        self.parameters["radar_scan_rate_micro_secs"] = "Specify scan rate in micro secs"
        self.parameters["radar_scan_loop_count"] = "Specify scan loop count"
        self.parameters["radar_scan_preset_1"] = "Specify scan preset for scan 1"
        self.parameters["radar_scan_preset_2"] = "Specify scan preset for scan 2"
        self.parameters["radar_detection_threshold_preset"] = "Specify Detection threshold preset"
        self.parameters["radar_antenna_config_1"] = "Specify Antenna config enum for scan 1"
        self.parameters["radar_antenna_config_2"] = "Specify Antenna config enum for scan 2"

    def createButtonFrame(self):
        horizontal_layout = QHBoxLayout()
        horizontal_layout.setContentsMargins(0,10,0,0)
        if self.add_device_flag:
            add_button = PushButton(text="  Add " + self.device,
                                    tooltip="Add " + self.device + " Device",
                                    icon_png=u":/16x16/icons/16x16/cil-library-add.png")
            add_button.clicked.connect(lambda checked: self.addDeviceClicked())

            horizontal_layout.addWidget(add_button)
        else:

            btn_remove_device = PushButton(text="  Remove " + self.device,
                                        tooltip="Remove the " + self.device +" device",
                                        icon_png=u":/20x20/icons/20x20/cil-trash.png")
            btn_remove_device.clicked.connect(lambda checked: self.removeDeviceClicked())
            horizontal_layout.addWidget(btn_remove_device, Qt.AlignCenter)

        return horizontal_layout

    def addDeviceClicked(self):
        if self.appview.addDeviceConfig() == False:
            QMessageBox.critical(self,
            "Name space error",
            "Device Name space already exists, Please specify another name_space name")

    def widget_box_changed(self, text, param_name):
        param_input_frame = self.user_entries[param_name]
        param_input_frame.param_value = text
        self.user_entries[param_name] = param_input_frame


    def addIsLRRSelected(self, layout_device):
        self.isSelected, label =  createLabelCheckbox("Add LRR Radar? ", "Would you like to add LRR radar")
        formlayout = QFormLayout()
        formlayout.setContentsMargins(0,10,0,20)
        formlayout.addRow(label, self.isSelected)
        layout_device.addLayout(formlayout)


    def nodeEnabled(self):
        if (self.device_type == DeviceType.MRRRadar or
            self.device_type == DeviceType.CAN):
            return True

        elif self.device_type == DeviceType.LRRRadar:
            if  self.isSelected.isChecked() == True:
                return True
            else:
                return False

    def enableLRRNode(self):
        self.isSelected.setChecked(True)

