from app.frames.common_widget import *

from PySide6.QtWidgets import (
    QMainWindow,
    QSpacerItem, QSizePolicy)


class CheckBoxFrame(QMainWindow):
    def __init__(self, app_view, node_config: dict):
        super(CheckBoxFrame, self).__init__()

        self.node_config = node_config.copy()
        self.user_entries = {}
        self.app_view = app_view
        self.verticalLayout = self.app_view.layout_main
        self.parameters = {}
        self.node_config['publish_flags'] = {}
        self.createInputFrame()

    def createInputFrame(self):

        layout_1 = createHorizontalLayout(top=20)
        layout_1.addSpacerItem(QSpacerItem(380, 40, QSizePolicy.Maximum, QSizePolicy.Expanding))

        node_name = self.node_config['ros_node_name']
        ros_parameters = self.node_config['params_config'][node_name]

        self.createParametersDescription()
        for param_name, param_value in ros_parameters['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            if  value_type == 'bool' and param_name != 'record_rosbags':
                check_box, label, window = createCheckBox(text=param_name, tooltip=self.parameters[param_name],
                                                        checkedState=param_value)
                layout_1.addWidget(window)
                layout_1.addSpacerItem(QSpacerItem(210, 40, QSizePolicy.Expanding, QSizePolicy.Expanding))

                check_box.stateChanged.connect(lambda text,
                                            param=param_name: self.checkbox_state_changed(text, param))

                self.user_entries[param_name] = check_box
                self.node_config['publish_flags'][param_name] = ""

        self.verticalLayout.addLayout(layout_1)

    def getConfig(self):
        for param_name, param_value in self.user_entries.items():
            self.node_config['publish_flags'][param_name] = param_value.isChecked()
        return self.node_config['publish_flags'].copy()

    def checkbox_state_changed(self, text, param):
        self.app_view.launchSetParameterCommand(param, text)

    def createParametersDescription(self):
        self.parameters["midw_1d_data"] = "Enable/Disable midw 1d data"
        self.parameters["midw_2d_data"] = "Enable/Disable midw 2d data"
        self.parameters["objects_data"] = "Enable/Disable Objects data"

    def getValueTypeFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['type']

        return "string"
