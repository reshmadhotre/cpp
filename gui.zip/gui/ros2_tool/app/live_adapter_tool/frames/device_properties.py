from app.frames.common_widget import *
from app.utils.live_utils import *

from PySide6.QtWidgets import QWidget

class DeviceProperties(QWidget):
    RADAR_PARAMS = {'name_space': [],
                    'rosbag_path': [],
                    'record_rosbags': [],
                    'adapter_ip_address': [],
                    'sensor_position_x': [],
                    'sensor_position_y': [],
                    'sensor_position_z': [],
                    'sensor_roll': [],
                    'sensor_pitch': [],
                    'sensor_yaw': []
                    }

    DEFAULT_RADAR_CONFIG = {
        'name_space': 'radar_left',
        'ros__parameters': {
            'rosbag_path': '',
            'record_rosbags': False,
            'adapter_ip_address': ' ',
            'sensor_position_x': '3.6',
            'sensor_position_y': '0.2',
            'sensor_position_z': '-0.7',
            'sensor_roll': '0.0',
            'sensor_pitch': '0.0',
            'sensor_yaw': '0.0',
        }
    }

    LRR_RADAR_PARAMS = {'name_space': [],
                    'rosbag_path': [],
                    'record_rosbags': [],
                    'radar_ip_address': [],
                    'radar_scan_rate_micro_secs': [],
                    'radar_scan_loop_count': [],
                    'radar_scan_preset_1': [],
                    'radar_scan_preset_2': [],
                    'radar_detection_threshold_preset': [],
                    'radar_antenna_config_1': [],
                    'radar_antenna_config_2': [],
                    'sensor_position_x': [],
                    'sensor_position_y': [],
                    'sensor_position_z': [],
                    'sensor_roll': [],
                    'sensor_pitch': [],
                    'sensor_yaw': []
                    }

    DEFAULT_LRR_RADAR_CONFIG = {
        'name_space': 'front_center',
        'ros__parameters': {
            'rosbag_path': '',
            'record_rosbags': False,
            'radar_ip_address': ' ',
            'radar_scan_rate_micro_secs': 60000,
            'radar_scan_loop_count': 1,
            'radar_scan_preset_1': 'VP104',
            'radar_scan_preset_2': 'VP105',
            'radar_detection_threshold_preset': 'LOW_SENSITIVITY',
            'radar_antenna_config_1': 'LowerTxAzimuth',
            'radar_antenna_config_2': 'AllTxElevation',
            'sensor_position_x': '3.6',
            'sensor_position_y': '0.2',
            'sensor_position_z': '-0.7',
            'sensor_roll': '0.0',
            'sensor_pitch': '0.0',
            'sensor_yaw': '0.0',
        }
    }

    CAN_PARAMS = {'name_space': [],
                  'dbc_filepath': [],
                  'rosbag_path': [],
                  'record_rosbags': []
                 }

    DEFAULT_CAN_CONFIG = {
        'name_space': 'front_center',
        'ros__parameters': {
            'dbc_filepath': ' ',
            'rosbag_path': '',
            'record_rosbags': False,
        }
    }

    def __init__(self, user_entries, device_type=False):
        super(DeviceProperties, self).__init__()

        self.device_type = device_type
        self.user_entries = user_entries

    def getDeviceConfig(self):
        if self.device_type == DeviceType.CAN:
            device_config = self.DEFAULT_CAN_CONFIG.copy()
        elif self.device_type == DeviceType.MRRRadar:
            device_config = self.DEFAULT_RADAR_CONFIG.copy()
        elif self.device_type == DeviceType.LRRRadar:
            device_config = self.DEFAULT_LRR_RADAR_CONFIG.copy()

        device_config['name_space'] = self.user_entries["name_space"].param_value

        if self.device_type == DeviceType.CAN:
            keys = self.DEFAULT_CAN_CONFIG["ros__parameters"].keys()
        elif self.device_type == DeviceType.MRRRadar:
            keys = self.DEFAULT_RADAR_CONFIG["ros__parameters"].keys()
        elif self.device_type == DeviceType.LRRRadar:
            keys = self.DEFAULT_LRR_RADAR_CONFIG["ros__parameters"].keys()

        for key in keys:
            device_config['ros__parameters'][key] = self.user_entries[key].param_value

        return device_config
