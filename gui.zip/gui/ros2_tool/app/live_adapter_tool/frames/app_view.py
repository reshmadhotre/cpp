from app.frames.base_app_view import BaseAppView
from .device_parameters_frame import DeviceParametersFrame
from .device_properties import DeviceProperties

from app.frames.common_widget import *
from app.utils.yaml_utils import *
from .check_box_frame import CheckBoxFrame
from app.frames.menu_button import BtnOpenConfig, BtnSaveConfig, LayoutBtnConfig
from app.utils.subprocess_util import SubprocessUtil
from app.utils.live_utils import *

from PySide6.QtWidgets import (
    QMessageBox, QWidget)

from PySide6.QtCore import Signal, Slot

import copy

class AppView(QWidget, BaseAppView):
    ''' Signal sent from Live adapter window to
    - Main window on launch/stop event '''
    live_adapter_window_launch_stop_clicked= Signal(bool)

    def __init__(self, app_controller,
                 can_live=False, parent=None):
        super(AppView, self).__init__(parent)

        BaseAppView.__init__(self)

        self.controller = app_controller

        if can_live:
            self.device_type = DeviceType.CAN
        else:
            self.device_type = DeviceType.MRRRadar

        self.app_config = app_controller.app_config

        if self.device_type == DeviceType.CAN:
            self.ROS_PACKAGE = self.app_config['CAN_ROS_PACKAGE']
            self.ROS_NODE_NAME = self.app_config['CAN_LIVE_ROS_NODE_NAME']
            self.device = "CAN"
        else:
            self.ROS_PACKAGE = self.app_config['RADAR_ROS_PACKAGE']
            self.ROS_NODE_NAME = self.app_config['RADAR_LIVE_ROS_NODE_NAME']
            self.device = "Radar"
            self.LRR_ROS_PACKAGE = self.app_config['LRR_RADAR_ROS_PACKAGE']
            self.LRR_ROS_NODE_NAME = self.app_config['LRR_LIVE_ROS_NODE_NAME']

        self.replay_config = self.controller.getReplayConfig(self.device_type)
        self.createLiveAdapterFrame()

    def addCheckBoxes(self):
        self.check_box_frame = CheckBoxFrame(self,
                                             node_config=self.replay_config[0])

    def createInputFrame(self):
        if len(self.replay_config) == 0:
            QMessageBox.critical(self,
                                "Config Error",
                                "Error parsing node config files. Is the terminal sourced?")
            return False

        node_config = self.replay_config[0]
        ''' Add MRR Radar Device Tab creation'''
        self.add_device_frame = DeviceParametersFrame(self, node_config=node_config,
                                    add_device_flag=True)

        if node_config['ros_package'] == self.ROS_PACKAGE:
            if self.device_type == DeviceType.CAN:
                name_space="front_center"
            elif self.device_type == DeviceType.MRRRadar:
                name_space="radar_left"

            device_parameters_frame = DeviceParametersFrame(self,
                                                            node_config=node_config,
                                                            add_device_flag=False,
                                                            name_space=name_space)
            self.input_frames.append(device_parameters_frame)

        ''' Add LRR radar device tab to Live Ethernet'''
        if self.device_type == DeviceType.MRRRadar:
            node_config = self.replay_config[1]
            name_space="front_center"
            device_parameters_frame = DeviceParametersFrame(self,
                                                            node_config=node_config,
                                                            add_device_flag=False,
                                                            name_space=name_space,
                                                            device_type = DeviceType.LRRRadar)
            self.input_frames.append(device_parameters_frame)

        return True

    def resetInputFrame(self, replay_config):
        if len(replay_config) == 0:
            QMessageBox.critical(self,
                                 "Config Error",
                                 "Error parsing node config files. Is the terminal sourced?")
            return

        ''' remove all tabs except first: "Add device"'''
        for index in range(self.tab_widget.count(), 1, -1):
           #print(f"index {index-1} name {self.tab_widget.tabText(index-1)} count {self.tab_widget.count()}")
            self.tab_widget.removeTab(index-1)

        self.input_frames = []
        device_type = DeviceType.NoneType
        for index in range(len(replay_config)):
            node_config = replay_config[index]
            if (node_config['ros_package'] == self.ROS_PACKAGE or
                node_config['ros_package'] == self.LRR_ROS_PACKAGE):
                if (self.device_type == DeviceType.MRRRadar and
                    node_config['ros_package'] == self.LRR_ROS_PACKAGE):
                    device_type = DeviceType.LRRRadar
                device_parameters_frame = DeviceParametersFrame(self,
                                                              node_config=node_config,
                                                              add_device_flag=False,
                                                              device_type = device_type)
                if (self.device_type == DeviceType.MRRRadar and
                    node_config['ros_package'] == self.LRR_ROS_PACKAGE):
                    device_parameters_frame.enableLRRNode()
                self.input_frames.append(device_parameters_frame)

    def generateReplayConfig(self):
        replay_config = []

        for frame in self.input_frames:
            if frame.nodeEnabled():
                config = frame.getConfig()
                if config is None:
                    return None
                replay_config.append(config)

        return replay_config


    def launchClicked(self):
        # Get current set of values from param frames
        replay_config = self.generateReplayConfig()
        if replay_config is not None and len(replay_config) > 0:
            if self.controller.launch(replay_config):
                self.live_adapter_window_launch_stop_clicked.emit(True)
                self.stateChangeOfButtons(True)
            else:
                QMessageBox.critical(self, "Launch Error",
                                     "Error launching replay nodes.",
                                     QMessageBox.Ok)

    def stopClicked(self):
        if self.controller.stop():
            self.live_adapter_window_launch_stop_clicked.emit(False)
            self.stateChangeOfButtons(False)
        else:
            QMessageBox.critical(self, "Stop Error",
                                 "Error stopping live adapter.",
                                 QMessageBox.Ok)

    def addDeviceConfig(self):
        device_properties = DeviceProperties(self.add_device_frame.user_entries,
                                             device_type=self.device_type)
        device_config = device_properties.getDeviceConfig()

        # check if device name already exists
        for frame in self.input_frames:
            if frame.checkNamespaceInConfig(device_config['name_space']):
                return False

        node_config = copy.deepcopy(self.replay_config[0])

        if self.device_type == DeviceType.CAN:
            ''' name_space does not exist, add it'''
            node_config['params_config']['server_live_can_node']['name_space'] = device_config['name_space']
        else:
            node_config['params_config']['server_live_mrr_node']['name_space'] = device_config['name_space']

        for param_name in device_config['ros__parameters'].keys():
            if self.device_type == DeviceType.CAN:
                node_config['params_config']['server_live_can_node']['ros__parameters'][param_name] = device_config['ros__parameters'][param_name]
            else:
                node_config['params_config']['server_live_mrr_node']['ros__parameters'][param_name] = device_config['ros__parameters'][param_name]

        device_parameters_frame = DeviceParametersFrame(self,
                                                      node_config=node_config,
                                                      add_device_flag=False,
                                                      name_space=device_config['name_space'])
        self.input_frames.append(device_parameters_frame)

        return True

    def removeDeviceConfig(self, index, tab_count):
        del self.input_frames[index - 1]
        if (tab_count - 1 == 1):
            ''' disable the save config button'''
            self.btn_save_config.setDisabled(True)

    def createLiveAdapterFrame(self):
        ''' Main layout'''
        self.layout_main = createVerticalLayout(parent=self,
                                                left=10, top=10, right=10, bottom=10)

        ''' Tabwidget sub widget layout'''
        self.tab_widget = createTabWidget(selectedTab=1)
        self.layout_tab = createHorizontalLayout(top=20)
        self.layout_tab.addWidget(self.tab_widget)

        ''' Button "Open Config" '''
        self.btn_open_config = BtnOpenConfig()
        self.btn_open_config.on_click_file_single.connect(self.on_click_open_config)
        layout_btn_open_config = LayoutBtnConfig(self.btn_open_config, self.tab_widget.width)

        ''' Button "Save Config" '''
        self.btn_save_config = BtnSaveConfig()
        self.btn_save_config.on_click_dialog.connect(self.on_click_save_config)
        layout_btn_save_config = LayoutBtnConfig(self.btn_save_config, self.tab_widget.width)
        layout_btn_save_config.setContentsMargins(0, 20, 0, 0)

        ''' Button "Launch" '''
        self.btn_launch = PushButton(text="  Launch",
                                     tooltip="Launch the " + self.device + " live nodes",
                                     icon_png=u":/16x16/icons/16x16/cil-media-play.png")
        self.btn_launch.clicked.connect(self.launchClicked)

        ''' Button "Stop" '''
        self.btn_stop = PushButton(text="  Stop",
                                   tooltip="Stop the launched live nodes",
                                   icon_png=u":/16x16/icons/16x16/cil-media-stop.png")
        self.btn_stop.clicked.connect(self.stopClicked)

        layout_btns = LayoutBtnConfig(self.btn_launch, self.tab_widget.width)
        layout_btns.addBtnWidget(self.btn_stop)
        layout_btns.setContentsMargins(0, 15, 0, 0)

        self.layout_main.addLayout(layout_btn_open_config, 1)
        self.layout_main.addLayout(self.layout_tab, 30)

        self.input_frames = []
        if self.device_type == DeviceType.MRRRadar:
            self.addCheckBoxes()
        if self.createInputFrame() == False:
            return

        self.layout_main.addLayout(layout_btn_save_config, 1)
        self.layout_main.addLayout(layout_btns, 1)

        self.tab_widget.setCurrentIndex(1)

    @Slot(str)
    def on_click_open_config(self, file: str) -> None:
        self.setReplayConfig(file)

    @Slot(str)
    def on_click_save_config(self, file: str) -> None:
        self.saveReplayConfig(file)

    def stateChangeOfButtons(self, value):
        self.btn_launch.setDisabled(value)

        self.btn_open_config.setDisabled(value)
        self.btn_save_config.setDisabled(value)
        self.tab_widget.setDisabled(value)

        toggle_value = not value
        self.btn_stop.setDisabled(toggle_value)

    def launchSetParameterCommand(self,
                                  check_box_param_name,
                                  check_box_value):
        node_list = []
        replay_config = self.generateReplayConfig()
        if replay_config is not None and len(replay_config) > 0:
            for index in range(len(replay_config)):
                node_config = replay_config[index]

                params_config = node_config['params_config']
                node_name = list(node_config['params_config'].keys())[0]
                name_space= params_config[node_name]['name_space']
                node_name_with_namespace = "/" + name_space + "/" + node_name
                node_list.append(node_name_with_namespace)
            if check_box_value == 0:
                check_box_value = 'False'
            else:
                check_box_value = 'True'

            for index in range(len(node_list)):
                node_name = node_list[index]
                cmd = ['ros2', 'param', 'set', node_name,
                       check_box_param_name, check_box_value]
                print(" cmd: {0}".format(cmd))
                self.ros_launch_set_parameter = SubprocessUtil(cmd)
                self.ros_launch_set_parameter.launch()
                
    def resetOverviewPanel(self):
        ''' called in base class so it is empty class'''
        ''' no functionality in live adapter'''
        pass


    def resetPreviousNodeAndTriggerNode(self):
        ''' called in base class so it is empty class'''
        ''' no functionality in live adapter'''
        pass
