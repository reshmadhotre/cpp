from app.utils.subprocess_util import SubprocessUtil
from app.ros_launch_generator import RosLaunchGenerator
from app.controller.app_controller import AppController

from msg_swc_common.msg import MsgNodeFeedbackType
from server_replay_video.msg import MsgVideoReplayStatus

from server_replay_rosbag.msg import MsgSetPauseMode as RosbagMsgSetPauseMode
from server_replay_rosbag.msg import MsgRosbagPlayStatus
from server_replay_rosbag.msg import MsgTriggerSingleFrame as RosbagMsgTriggerSingleFrame

from msg_replay_status.msg import MsgReplayToolRvizPlugin

from app.utils.replay_utils import Device

import os, subprocess

from rclpy.node import Node


class Ros2Controller(Node, AppController):

    def __init__(self):
        super(Ros2Controller, self).__init__('ros2_tool_nodes')

        AppController.__init__(self)

        self.ros_launch_process = []
        self.node_feedback = MsgNodeFeedbackType()
        self.node_video_feedback = MsgVideoReplayStatus()
        self.node_rosbag_feedback = MsgRosbagPlayStatus()
        self.node_replay_tool_rviz_plugin_feedback = MsgReplayToolRvizPlugin()

        self.DEFAULT_RADAR_TYPE = self.app_config['DEFAULT_RADAR_TYPE']
        self.RADAR_ROS_PACKAGE = self.app_config['RADAR_ROS_PACKAGE']
        self.RADAR_ROS_NODE_NAME = self.app_config['RADAR_ROS_NODE_NAME']
        self.VIDEO_ROS_PACKAGE = self.app_config['VIDEO_ROS_PACKAGE']
        self.VIDEO_ROS_NODE_NAME = self.app_config['VIDEO_ROS_NODE_NAME']
        self.CAN_ROS_PACKAGE = self.app_config['CAN_ROS_PACKAGE']
        self.CAN_ROS_NODE_NAME = self.app_config['CAN_ROS_NODE_NAME']
        self.PARAM_FILE_NAMES_MAP = self.app_config['PARAM_FILE_NAMES_MAP']
        self.ROSBAG_PLAYER_PACKAGE = self.app_config['ROSBAG_PLAYER_PACKAGE']
        self.ROSBAG_PLAYER_NODE = self.app_config['ROSBAG_PLAYER_NODE']
        self.ALLOWED_TOPIC_TYPES = self.app_config['ALLOWED_TOPIC_TYPES']

        self.createFeedbackSubscriber()
        self.createPublishers()
        self.dsp_app_filepath = ''
        self.dsp_app_processes_launched = []
        self.rviz_launched = False
        self.subprocesses_launched = []
        self.midw_dsp_app = False
        self.trck_dsp_app = False

        '''Rosbag player'''
        self.bag_duration = 0
        self.duration_played = 0
        self.current_published_time = 0
        self.status = self.node_rosbag_feedback.IN_PROGRESS
        self.finished = self.node_rosbag_feedback.FINISHED

    def createFeedbackSubscriber(self):
        feedback_subscriber = self.create_subscription(
            MsgNodeFeedbackType, '/topic_node_feedback', self.nodeFeedbackCB, 1)

        feedback_video_subscriber = self.create_subscription(
            MsgVideoReplayStatus, '/topic_server_replay_video_status', self.nodeVideoFeedbackCB, 1)

        feedback_rosbag_subscriber = self.create_subscription(
            MsgRosbagPlayStatus, '/topic_rosbag_play_status', self.nodeRosbagFeedbackCB, 1)
        
        replay_tool_data_subscriber = self.create_subscription(
            MsgReplayToolRvizPlugin, '/topic_replay_tool_data', 
            self.nodeReplayToolRvizPluginFeedbackCB, 1)

    def nodeFeedbackCB(self, msg):
        self.node_feedback = msg
        #print(f"Callback file processed: {self.node_feedback.status:}")

    def nodeVideoFeedbackCB(self, msg):
        #print(f"Video Callback file processed: {self.node_video_feedback.file_under_process}")
        self.node_video_feedback = msg

    def nodeReplayToolRvizPluginFeedbackCB(self, msg):
        self.node_replay_tool_rviz_plugin_feedback = msg
        self.node_replay_tool_rviz_plugin_feedback.status_mode = msg.status_mode

    def nodeRosbagFeedbackCB(self, msg):
        self.node_rosbag_feedback = msg
        feedback = self.node_rosbag_feedback
        self.current_published_time = feedback.current_published_time
        self.bag_duration = feedback.bag_duration_sec
        self.duration_played = feedback.duration_played_sec
        self.status = feedback.status
        self.finished = feedback.FINISHED

    def createReplayToolPublisher(self):
        self.replay_tool_data_publisher = self.create_publisher(MsgReplayToolRvizPlugin,
                                                '/topic_replay_tool_data', 10)

    def createRosbagReplayPublishers(self):
        self.rosbag_replay_next_frame_publisher = self.create_publisher(RosbagMsgTriggerSingleFrame,
                                                "topic_trigger_rosbag_play_next_frame", 10)
        self.rosbag_replay_pause_mode_publisher = self.create_publisher(RosbagMsgSetPauseMode, 
                                                 '/topic_set_rosbag_play_pause_mode', 10)

    def createPublishers(self):
        self.createRosbagReplayPublishers()
        self.createReplayToolPublisher()
    
    def getReplayToolStatusMode(self):
        return self.node_replay_tool_rviz_plugin_feedback

    def getNextFramePublisher(self, device):
        if device == Device.Rosbag:
            return self.rosbag_replay_next_frame_publisher

    def getPauseModePublisher(self, device):
        if device == Device.Rosbag:
            return self.rosbag_replay_pause_mode_publisher

    def getDurationPlayed(self):
        return self.duration_played

    def getBagDuration(self):
        return self.bag_duration

    def getCurrentPublishedTime(self):
        return self.current_published_time
    
    def getReplayToolDataPublisher(self):
        return self.replay_tool_data_publisher

    def getNodeFeedback(self):
        #print(f"can/rdc3 controller file processed: {self.node_feedback.file_under_process}")
        #print(f"controller files done: {self.node_feedback.num_files_processed} still left: {self.node_feedback.num_files_to_process}")
        return self.node_feedback

    def getVideoNodeFeedback(self):
        #print(f"video file processed: {self.node_video_feedback.file_under_process}")
        return self.node_video_feedback

    def checkIfBagFinished(self):
        ret_value = False
        if self.status == self.finished:
            ret_value = True
        return ret_value

    def launch(self, replay_config, stand_alone_device, enabled_swc_features):
        if stand_alone_device == Device.Radar:
            can_execute = self.launchDSPApps(enabled_swc_features)
            if can_execute:
                if replay_config:
                    self.launchRviz()
                    ros_launch_generator = RosLaunchGenerator(replay_config, stand_alone_device)
                    launch_file_path = os.path.abspath(
                        self.TMP_FOLDER_PATH / "roslaunch_mf4_replay.py")
                    ros_launch_generator.generateLaunchFile(launch_file_path)

                    cmd = ['ros2', 'launch', launch_file_path]

                    ros_launch = SubprocessUtil(cmd)
                    self.ros_launch_process.append(ros_launch)
                    return ros_launch.launch()

            return False
        else:
            return self.launchVideoOrCanStandalone(replay_config, stand_alone_device)

    def playRosbag(self, replay_config, resume):
        self.launchRviz()

        if not resume:
            self.stopRosbag()

            ros_launch_generator = RosLaunchGenerator(
                replay_config,rosbag_replay=True)
            launch_file_path = os.path.abspath(
                self.TMP_FOLDER_PATH / "roslaunch_rosbag_replay.py")
            ros_launch_generator.generateLaunchFile(launch_file_path)

            cmd = ['ros2', 'launch', launch_file_path]
            ros_launch = SubprocessUtil(cmd)
            self.ros_launch_process.append(ros_launch)
            return ros_launch.launch()

        return False

    def launchVideoOrCanStandalone(self, replay_config, stand_alone_device):
        if replay_config:
            if not self.rviz_launched and not self.isRvizRunning():
                rviz_launch_cmd = ['rviz2']
                rviz_process = SubprocessUtil(rviz_launch_cmd)
                rviz_process.launch()
                self.subprocesses_launched.append(rviz_process)
                self.rviz_launched = True

            ros_launch_generator = RosLaunchGenerator(replay_config, stand_alone_device)
            if stand_alone_device == Device.CANVideo:
                launch_file_path = os.path.abspath(
                    self.TMP_FOLDER_PATH / "roslaunch_can_standalone_video_player.py")
            else:
                if stand_alone_device == Device.Video:
                    launch_file_path = os.path.abspath(
                        self.TMP_FOLDER_PATH / "roslaunch_video_standalone_player.py")
                elif stand_alone_device == Device.CAN:
                    launch_file_path = os.path.abspath(
                        self.TMP_FOLDER_PATH / "roslaunch_can_standalone_player.py")

            ros_launch_generator.generateLaunchFile(launch_file_path)

            cmd = ['ros2', 'launch', launch_file_path]

            ros_launch = SubprocessUtil(cmd)
            self.ros_launch_process.append(ros_launch)
            return ros_launch.launch()

        return False

    def stopRosbag(self):
        self.node_rosbag_feedback = None
        self.node_rosbag_feedback = MsgRosbagPlayStatus()
        self.status = self.node_rosbag_feedback.IN_PROGRESS
        for process in self.ros_launch_process:
            process.stop()

        return True

    def stop(self):
        self.node_feedback = None
        self.node_feedback = MsgNodeFeedbackType()
        self.node_video_feedback = None
        self.node_video_feedback = MsgVideoReplayStatus()
        self.node_rosbag_feedback = None
        self.node_rosbag_feedback = MsgRosbagPlayStatus()
        self.node_replay_tool_rviz_plugin_feedback = None
        self.node_replay_tool_rviz_plugin_feedback = MsgReplayToolRvizPlugin()
        super().stop()
        self.stopRosbag()
        for process in self.dsp_app_processes_launched:
            process.stop()
        for process in self.subprocesses_launched:
            self.rviz_launched = False
            process.stop()
        return True

    def getReplayConfig(self):
        config = []

        default_radar_params_config = self.node_config_util.getConfig(
            package_name=self.RADAR_ROS_PACKAGE,
            file_name=self.PARAM_FILE_NAMES_MAP[self.DEFAULT_RADAR_TYPE])
        radar_params_info_config = self.node_config_util.getConfig(
            package_name=self.RADAR_ROS_PACKAGE,
            file_name=self.PARAMS_INFO_FILE_NAME)

        if (default_radar_params_config and radar_params_info_config):
            radar_config = {}
            radar_config['ros_package'] = self.RADAR_ROS_PACKAGE
            radar_config['ros_node_name'] = self.RADAR_ROS_NODE_NAME
            radar_config['params_config'] = default_radar_params_config
            radar_config['params_info_config'] = radar_params_info_config
            config.append(radar_config)

        video_params_config = self.node_config_util.getConfig(
            package_name=self.VIDEO_ROS_PACKAGE, file_name="config_"+self.VIDEO_ROS_PACKAGE+".yaml")
        video_params_info_config = self.node_config_util.getConfig(
            package_name=self.VIDEO_ROS_PACKAGE,
            file_name=self.PARAMS_INFO_FILE_NAME)

        if (video_params_config and video_params_info_config):
            video_config = {}
            video_config['ros_package'] = self.VIDEO_ROS_PACKAGE
            video_config['ros_node_name'] = self.VIDEO_ROS_NODE_NAME
            video_config['params_config'] = video_params_config
            video_config['params_info_config'] = video_params_info_config
            config.append(video_config)

        can_params_config = self.node_config_util.getConfig(
            package_name=self.CAN_ROS_PACKAGE, file_name="config_"+self.CAN_ROS_PACKAGE+".yaml")
        can_params_info_config = self.node_config_util.getConfig(
            package_name=self.CAN_ROS_PACKAGE,
            file_name=self.PARAMS_INFO_FILE_NAME)

        if (can_params_config and can_params_info_config):
            can_config = {}
            can_config['ros_package'] = self.CAN_ROS_PACKAGE
            can_config['ros_node_name'] = self.CAN_ROS_NODE_NAME
            can_config['params_config'] = can_params_config
            can_config['params_info_config'] = can_params_info_config
            config.append(can_config)

        config = config + AppController.getReplayConfig(self)
        return config

    def getRadarConfig(self, package_name: str, radar_type: str):
        radar_config = {}
        radar_config['ros_package'] = package_name
        radar_config['ros_node_name'] = self.RADAR_ROS_NODE_NAME
        radar_params_config = self.node_config_util.getConfig(package_name=self.RADAR_ROS_PACKAGE,
                                                              file_name=self.PARAM_FILE_NAMES_MAP[radar_type])
        radar_params_info_config = self.node_config_util.getConfig(package_name=package_name,
                                                                   file_name=self.PARAMS_INFO_FILE_NAME)
        radar_config['params_config'] = radar_params_config
        radar_config['params_info_config'] = radar_params_info_config
        return radar_config

    def getRosbagReplayConfig(self):
        config = []

        rosbag_player_config = {}
        rosbag_player_config['ros_package'] = self.ROSBAG_PLAYER_PACKAGE
        rosbag_player_config['ros_node_name'] = self.ROSBAG_PLAYER_NODE
        params_config = self.node_config_util.getConfig(
            package_name=self.ROSBAG_PLAYER_PACKAGE, file_name="params.yaml")
        params_info_config = self.node_config_util.getConfig(
            package_name=self.ROSBAG_PLAYER_PACKAGE,
            file_name=self.PARAMS_INFO_FILE_NAME)
        rosbag_player_config['params_config'] = params_config
        rosbag_player_config['params_info_config'] = params_info_config

        config.append(rosbag_player_config)

        config = config + AppController.getReplayConfig(self)
        return config

    def isDspAppRunning(self, dspapp_name):
        process = subprocess.Popen("ps -f | grep " + dspapp_name +" | awk '{print $NF}'",
                                   stdout=subprocess.PIPE, shell=True)

        while True:
            line = process.stdout.readline()
            if not line:
                break

            str_line = str(line)
            if str_line == "b'"+dspapp_name+"\\n'":
                return True

        return False

    def fetchDSPAppPath(self, enabled_node):
        for swc_package in self.swc_package_names:
            if enabled_node == swc_package:
                if swc_package == "swc_merdrdatacubemidw":
                    self.midw_dsp_app = True
                if swc_package == "swc_memplobjtrckng":
                    self.trck_dsp_app = True
                dsp_app_path = self.node_config_util.getDspAppPath(swc_package)
                if dsp_app_path != None:
                    return dsp_app_path

    def launchProcess(self, dsp_app_path):
        chmod_cmd = ['chmod', '+x', dsp_app_path]
        chmod_process = SubprocessUtil(chmod_cmd)
        chmod_process.launch()
        self.dsp_app_processes_launched.append(chmod_process)

        dsp_app_launch_cmd = [dsp_app_path]
        print(f"dsp_app_launch_cmd {dsp_app_launch_cmd}")
        dsp_app_process = SubprocessUtil(dsp_app_launch_cmd)
        dsp_app_process.launch()
        self.dsp_app_processes_launched.append(dsp_app_process)

    def launchDSPApps(self, enabled_swc_features):
        if not enabled_swc_features:
            return True

        cluster_ret = False
        obj_tracking_ret = False

        for node in enabled_swc_features:
            dsp_app_path = self.node_config_util.getDspAppPath(node)
            print(f"dsp_app_path {dsp_app_path}")
            if dsp_app_path:
                self.launchProcess(dsp_app_path)

            if node == "swc_merdrdatacubemidw":
                cluster_ret = self.isDspAppRunning("Clustering_DspApp")
                if len(enabled_swc_features) == 1:
                    return cluster_ret
            elif node == "swc_memplobjtrckng":
                obj_tracking_ret = self.isDspAppRunning("MEMplObjTrckng_DspApp")
                if len(enabled_swc_features) == 1:
                    return obj_tracking_ret

        return (cluster_ret and obj_tracking_ret)
