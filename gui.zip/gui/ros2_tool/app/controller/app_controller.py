from app.utils.node_config_util import NodeConfigUtil
from app.utils.subprocess_util import SubprocessUtil
from app.utils.yaml_utils import *

import subprocess
import os
import shutil
from pathlib import Path
from PySide6.QtCore import Signal


class AppController(object):

    def __init__(self, text=' '):
        super(AppController, self).__init__()

        self.app_config = parseYamlFile("app/app.settings")
        self.node_config_util = NodeConfigUtil()

        self.rviz_launched = False
        self.subprocesses_launched = []

        self.TMP_FOLDER_PATH = Path(self.app_config['TMP_FOLDER_PATH'])
        self.PARAMS_FILE_NAME = self.app_config['PARAMS_FILE_NAME']
        self.PARAMS_INFO_FILE_NAME = self.app_config['PARAMS_INFO_FILE_NAME']

        self.swc_pkg_process, self.swc_package_names = self.node_config_util.getSwcPackageNames()
        self.createTmpFolder()

    def createTmpFolder(self):
        """Create a /tmp folder to store logs and launch files"""
        try:

            if not os.path.exists(self.TMP_FOLDER_PATH):
                os.mkdir(self.TMP_FOLDER_PATH)
            os.environ['ROS_LOG_DIR'] = os.path.abspath(self.TMP_FOLDER_PATH)
        except BaseException as e:
            print(e)
            print("Error : Cannot create /tmp folder. Cannot store launch data!")

    def deleteTmpFolder(self):
        if os.path.exists(self.TMP_FOLDER_PATH):

            try:
                shutil.rmtree(self.TMP_FOLDER_PATH)
            except BaseException:
                print(
                    f"Error : Cannot delete {self.TMP_FOLDER_PATH} directory!!")

    def getRosPackageNames(self):
        package_names = self.swc_package_names.copy()
        package_names.append("server_replay_mrr")
        return package_names

    def getReplayConfig(self):
        config = []

        for swc_package in self.swc_package_names:

            if swc_package.startswith(
                    'swc_') and 'parquet' not in swc_package:

                file_name=self.getParamsFile(swc_package)
                params_config = self.node_config_util.getConfig(package_name=swc_package,
                                                                file_name=file_name)
                file_name=self.getParamsInfoFile(swc_package)
                params_info_config = self.node_config_util.getConfig(
                    package_name=swc_package, file_name=file_name)

                if (params_config and params_info_config):
                    swc_config = {}
                    swc_config['ros_package'] = swc_package
                    swc_config['ros_node_name'] = swc_package + "_app"
                    swc_config['params_config'] = params_config
                    swc_config['params_info_config'] = params_info_config

                    config.append(swc_config)
        return config

    def getParamsFile(self, swc_package:str):
        file_name=self.PARAMS_FILE_NAME + swc_package.replace('swc_', '') + ".yaml"
        return file_name

    def getParamsInfoFile(self, swc_package:str):
        file_name=self.PARAMS_FILE_NAME + "info_" + swc_package.replace('swc_', '') + ".yaml"
        return file_name

    def stop(self):
        #print(f"Appcontroller stop")
        process_util = SubprocessUtil(['ros2', 'pkg', 'list'])
        process_util.setProcess(self.swc_pkg_process)
        process_util.stop()
        for process in self.subprocesses_launched:
            #print(f"[INFO] : process stopped with pid ")
            process.stop()
            self.rviz_launched = False

    def onQuit(self, delete_tmp_folder=True):
        self.stop()
        if delete_tmp_folder:
            self.deleteTmpFolder()

    def isRvizRunning(self):
        process = subprocess.Popen(['ps', '-ef'],
                                   stdout=subprocess.PIPE,
                                   universal_newlines=True,
                                   bufsize=1)

        while True:
            line = process.stdout.readline()
            if not line:
                break

            node_name = line.rstrip()

            if "rviz2" in line.strip():
                return True

        return False

    def launchRviz(self):
        if not self.rviz_launched and not self.isRvizRunning():
            #print(f"RViz launched")
            rviz_launch_cmd = ['rviz2']
            rviz_process = SubprocessUtil(rviz_launch_cmd)
            rviz_process.launch()
            self.subprocesses_launched.append(rviz_process)
            print(f"[INFO] [rviz2]: Process started with pid [{rviz_process.process.pid}]")

            self.rviz_launched = True
