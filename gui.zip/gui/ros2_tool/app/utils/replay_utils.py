import enum

class Nodes(str, enum.Enum):
   server_replay_mrr = "server_replay_mrr"
   server_replay_mrrRosbag ="server_replay_mrrRosbag"
   server_replay_mrrOutputParquet ="server_replay_mrrOutputParquet" 

   CAN ="CAN"
   CanRosbag ="CanRosbag"
   CanOutputParquet ="CanOutputParquet"

   Video ="Video"
   VideoRosbag ="VideoRosbag"

   swc_merdrdatacubemidw ="swc_merdrdatacubemidw"
   swc_merdrdatacubemidwRosbag ="swc_merdrdatacubemidwRosbag"
   swc_merdrdatacubemidwOutputParquet ="swc_merdrdatacubemidwOutputParquet"
   swc_merdrdatacubemidwInputParquet ="swc_merdrdatacubemidwInputParquet"

   swc_meblkgdetn ="swc_meblkgdetn"
   swc_meblkgdetnRosbag ="swc_meblkgdetnRosbag"
   swc_meblkgdetnOutputParquet ="swc_meblkgdetnOutputParquet"
   swc_meblkgdetnInputParquet ="swc_meblkgdetnInputParquet"

   swc_mecanoutpadpr ="swc_mecanoutpadpr"
   swc_mecanoutpadprRosbag ="swc_mecanoutpadprRosbag"
   swc_mecanoutpadprOutputParquet ="swc_mecanoutpadprOutputParquet"
   swc_mecanoutpadprInputParquet ="swc_mecanoutpadprInputParquet"

   swc_meegomtnestimn ="swc_meegomtnestimn"
   swc_meegomtnestimnRosbag ="swc_meegomtnestimnRosbag"
   swc_meegomtnestimnOutputParquet ="swc_meegomtnestimnOutputParquet"
   swc_meegomtnestimnInputParquet ="swc_meegomtnestimnInputParquet"

   swc_memplobjtrckng ="swc_memplobjtrckng"
   swc_memplobjtrckngRosbag ="swc_memplobjtrckngRosbag"
   swc_memplobjtrckngOutputParquet ="swc_memplobjtrckngOutputParquet"
   swc_memplobjtrckngInputParquet ="swc_memplobjtrckngInputParquet"

   swc_meroadbrdrestimn ="swc_meroadbrdrestimn"
   swc_meroadbrdrestimnRosbag ="swc_meroadbrdrestimnRosbag"
   swc_meroadbrdrestimnOutputParquet ="swc_meroadbrdrestimnOutputParquet"
   swc_meroadbrdrestimnInputParquet ="swc_meroadbrdrestimnInputParquet"

   swc_metunneldetn ="swc_metunneldetn"
   swc_metunneldetnRosbag ="swc_metunneldetnRosbag"
   swc_metunneldetnOutputParquet ="swc_metunneldetnOutputParquet"
   swc_metunneldetnInputParquet ="swc_metunneldetnInputParquet"

   swc_mevehoutpadpracp ="swc_mevehoutpadpracp"
   swc_mevehoutpadpracpRosbag ="swc_mevehoutpadpracpRosbag"

   swc_clock ="swc_clock"

   def describe(self):
        return self.name, self.value

   def __str__(self):
        return 'value: {0}'.format(self.value)

def getMf4NodeNames(app_config):
     nodes_list = []
     REPLAY_NODE = app_config['REPLAY_NODE']
     ''' get the key if not found use default(2nd param)'''
     radar_str = REPLAY_NODE.get('server_replay_mrr_app', 'server_replay_mrr_app')
     video_str = REPLAY_NODE.get('server_replay_video_node', 'server_replay_video_node')
     can_str = REPLAY_NODE.get('server_replay_can_node', 'server_replay_can_node')

     swc_merdrdatacubemidw_str = REPLAY_NODE.get('swc_merdrdatacubemidw_app', 'swc_merdrdatacubemidw_app')
     blk_detn_str = REPLAY_NODE.get('swc_meblkgdetn_app', 'swc_meblkgdetn_app')
     can_out_adptr_str = REPLAY_NODE.get('swc_mecanoutpadpr_app', 'swc_mecanoutpadpr_app')
     ego_mtn_estim_str = REPLAY_NODE.get('swc_meegomtnestimn_app', 'swc_meegomtnestimn_app')
     tracker_str = REPLAY_NODE.get('swc_memplobjtrckng_app', 'swc_memplobjtrckng_app')
     rbe_str = REPLAY_NODE.get('swc_meroadbrdrestimn_app', 'swc_meroadbrdrestimn_app')
     tunnel_detn_str = REPLAY_NODE.get('swc_metunneldetn_app', 'swc_metunneldetn_app')
     veh_op_adptr_str = REPLAY_NODE.get('swc_mevehoutpadpracp_app', 'swc_mevehoutpadpracp_app')
     clock_str = REPLAY_NODE.get('swc_clock_app', 'swc_clock_app')

     nodes_list.append(radar_str)
     nodes_list.append(video_str)
     nodes_list.append(can_str)

     nodes_list.append(swc_merdrdatacubemidw_str)
     nodes_list.append(blk_detn_str)
     nodes_list.append(can_out_adptr_str)
     nodes_list.append(ego_mtn_estim_str)
     nodes_list.append(tracker_str)
     nodes_list.append(rbe_str)
     nodes_list.append(tunnel_detn_str)
     nodes_list.append(veh_op_adptr_str)
     nodes_list.append(clock_str)
     
     return nodes_list

def getNodesNames(app_config):
     nodes_list = getMf4NodeNames(app_config)

     nodes_names = {}
     rosbag_str = "Rosbag"
     parquet_op_str = "Output_Parquet"
     parquet_ip_str = "Input_Parquet"

     radar_str = nodes_list[0]
     nodes_names[Nodes.server_replay_mrr] = radar_str
     nodes_names[Nodes.server_replay_mrrRosbag] = radar_str + rosbag_str
     nodes_names[Nodes.server_replay_mrrOutputParquet] = radar_str + parquet_op_str
     
     can_str = nodes_list[2]
     nodes_names[Nodes.CAN] = can_str
     nodes_names[Nodes.CanRosbag] = can_str + rosbag_str
     nodes_names[Nodes.CanOutputParquet] = can_str + parquet_op_str

     video_str = nodes_list[1]
     nodes_names[Nodes.Video] = video_str 
     nodes_names[Nodes.VideoRosbag] = video_str + rosbag_str

     midw_str = nodes_list[3]
     nodes_names[Nodes.swc_merdrdatacubemidw] = midw_str
     nodes_names[Nodes.swc_merdrdatacubemidwRosbag] = midw_str + rosbag_str
     nodes_names[Nodes.swc_merdrdatacubemidwOutputParquet] = midw_str + parquet_op_str
     nodes_names[Nodes.swc_merdrdatacubemidwInputParquet] = midw_str + parquet_ip_str

     blkdetn_str = nodes_list[4]
     nodes_names[Nodes.swc_meblkgdetn] = blkdetn_str
     nodes_names[Nodes.swc_meblkgdetnRosbag] = blkdetn_str + rosbag_str
     nodes_names[Nodes.swc_meblkgdetnOutputParquet] = blkdetn_str + parquet_op_str
     nodes_names[Nodes.swc_meblkgdetnInputParquet] = blkdetn_str + parquet_ip_str

     canopadpt_str = nodes_list[5]
     nodes_names[Nodes.swc_mecanoutpadpr] = canopadpt_str
     nodes_names[Nodes.swc_mecanoutpadprRosbag] = canopadpt_str + rosbag_str
     nodes_names[Nodes.swc_mecanoutpadprOutputParquet] = canopadpt_str + parquet_op_str
     nodes_names[Nodes.swc_mecanoutpadprInputParquet] = canopadpt_str + parquet_ip_str

     egomtnestim_str = nodes_list[6]
     nodes_names[Nodes.swc_meegomtnestimn] = egomtnestim_str
     nodes_names[Nodes.swc_meegomtnestimnRosbag] = egomtnestim_str + rosbag_str
     nodes_names[Nodes.swc_meegomtnestimnOutputParquet] = egomtnestim_str + parquet_op_str
     nodes_names[Nodes.swc_meegomtnestimnInputParquet] = egomtnestim_str + parquet_ip_str

     tarcker_str = nodes_list[7]
     nodes_names[Nodes.swc_memplobjtrckng] = tarcker_str
     nodes_names[Nodes.swc_memplobjtrckngRosbag] = tarcker_str + rosbag_str
     nodes_names[Nodes.swc_memplobjtrckngOutputParquet] = tarcker_str + parquet_op_str
     nodes_names[Nodes.swc_memplobjtrckngInputParquet] = tarcker_str + parquet_ip_str

     rde_str = nodes_list[8]
     nodes_names[Nodes.swc_meroadbrdrestimn] = rde_str
     nodes_names[Nodes.swc_meroadbrdrestimnRosbag] = rde_str + rosbag_str
     nodes_names[Nodes.swc_meroadbrdrestimnOutputParquet] = rde_str + parquet_op_str
     nodes_names[Nodes.swc_meroadbrdrestimnInputParquet] = rde_str + parquet_ip_str

     tunneldetn = nodes_list[9]
     nodes_names[Nodes.swc_metunneldetn] = tunneldetn
     nodes_names[Nodes.swc_metunneldetnRosbag] = tunneldetn + rosbag_str
     nodes_names[Nodes.swc_metunneldetnOutputParquet] = tunneldetn + parquet_op_str
     nodes_names[Nodes.swc_metunneldetnInputParquet] = tunneldetn + parquet_ip_str
     
     vehopadpt = nodes_list[10]
     nodes_names[Nodes.swc_mevehoutpadpracp] = vehopadpt
     nodes_names[Nodes.swc_mevehoutpadpracpRosbag] = vehopadpt + rosbag_str

     clock_str = nodes_list[11]
     nodes_names[Nodes.swc_clock] = clock_str

     return nodes_names

def createWeightDictOfNodes():
     weightOfNodes = {}
     weightOfNodes[Nodes.server_replay_mrr] = 0
     weightOfNodes[Nodes.swc_merdrdatacubemidw] = 1
     weightOfNodes[Nodes.swc_meegomtnestimn] = 2
     weightOfNodes[Nodes.swc_meroadbrdrestimn] = 3
     weightOfNodes[Nodes.swc_memplobjtrckng] = 4
     #weightOfNodes[Nodes.swc_meobjclassn] = 5
     weightOfNodes[Nodes.swc_metunneldetn] = 6
     weightOfNodes[Nodes.swc_meblkgdetn] = 7
     weightOfNodes[Nodes.swc_mevehoutpadpracp] = 8

     '''Can output adapter is a special case, is used internal 
     testing and validation. It does not send any feedback.
     Only till VOA will send feedback     '''
     weightOfNodes[Nodes.swc_mecanoutpadpr] = -1
     return weightOfNodes

class Device(str, enum.Enum):
     Radar = "Radar"
     CAN ="CAN"
     Video = "Video"
     CANVideo = "CANVideo"
     Rosbag = "Rosbag"
     NoneType=""

class Tool(str, enum.Enum):
     Mf4 = "Mf4"
     Rosbag = "Rosbag"
