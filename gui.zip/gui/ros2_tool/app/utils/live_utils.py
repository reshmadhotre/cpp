import enum


class DeviceType(str, enum.Enum):
     MRRRadar = "MRR_Radar"
     CAN ="CAN"
     LRRRadar = "LRR_Radar"
     NoneType=""