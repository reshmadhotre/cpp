from app.utils.yaml_utils import *
from app.utils.subprocess_util import *
from ament_index_python.packages import get_package_share_directory, get_package_prefix
import os, re
import subprocess


class NodeConfigUtil():

    """
    Parse the params.yaml and params_info.yaml from the config folder of ros packages
    """

    def getConfig(self, package_name: str, file_name: str):

        try:

            package_share_dir = get_package_share_directory(package_name)

            config_file_path = os.path.join(
                package_share_dir, "config", file_name)
            return parseYamlFile(config_file_path)

        except Exception as e:
            print(f"Error getting config info for package: {package_name}, filename : {file_name}")
            return None

    def getSwcPackageNames(self):
        swc_package_names = []
        cmd = ['ros2', 'pkg', 'list']
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, 
                                            universal_newlines=True, 
                                            bufsize=1)
        while True:
            line = process.stdout.readline()
            if not line:
                break

            package_name = line.rstrip()
            if package_name.startswith(
                    'swc_') and 'rviz' not in package_name and "csv" not in package_name:
                swc_package_names.append(package_name)

        return process,swc_package_names

    def getDspAppPath(self, package_name: str):
        package_share_dir = get_package_prefix(package_name)
        dsp_app_dir = os.path.join(package_share_dir, 'lib', package_name)

        if os.path.isdir(dsp_app_dir):
            filenames = os.listdir(dsp_app_dir)
            for filename in filenames:
                if 'DspApp' in filename:
                    return os.path.join(dsp_app_dir, filename)

        print(f'No DspApp found for package : {package_name}')
        return None

    def getFilePathInPackage(self,  package_name: str):
        package_dir = get_package_prefix(package_name)
        file_name = "_NodeBase.hpp"
        file_folder = os.path.join(package_dir, 'include', package_name, 'include/node' )
        file_list = os.listdir(file_folder)
        file_path = ""
        for file in file_list:
            if file_name in file:
                file_path = os.path.join(file_folder, file)
                break
        return file_path

    def getPackagePath(self, package_name: str):
        package_dir = get_package_share_directory(package_name)
        file_name="config_" + package_name.replace('swc_', '') + ".yaml"
        config_file_path = os.path.join(package_dir, 'config', file_name)

        return config_file_path

    def getSyncSubscriberListFromHppFile(self, package_name: str):
        file_name = package_name.split("swc_")[1]
        file_path = self.getFilePathInPackage(package_name)
        sync_sub_list = []
        if os.path.exists(file_path):
            sync_sub_list_from_file = []
            with open(file_path) as file:
                sync_sub_list_from_file = re.findall("{\"sub_[a-z_0-9]*", file.read())

            #print(sync_sub_list_from_file)

            ''' remove {" from the subscriber name'''
            for index in range(len(sync_sub_list_from_file)):
                subscriber_name = sync_sub_list_from_file[index].replace("{\"", "")
                sync_sub_list.append(subscriber_name)

        return sync_sub_list
