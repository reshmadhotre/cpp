import os
import subprocess
import signal
import time


class SubprocessUtil:

    def __init__(self, cmd: list):
        self.process = None
        self.cmd = cmd

    def setProcess(self, process):
        self.process = process

    def launch(self):
        try:
            self.process = subprocess.Popen(
                self.cmd,
                stderr=subprocess.STDOUT,
                preexec_fn=os.setsid)
            return True

        except Exception as e:
            print(e)
            print(f"Could not launch process : {self.cmd}")

            return False

    def launchWithStdout(self):
        try:
            self.process = subprocess.Popen(
                self.cmd, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                start_new_session=True)
            return True

        except Exception as e:
            print(e)
            print(f"Could not launch_with_stdout process : {self.cmd}")

            return False

    def launchwithBufSize(self):
        try:
            self.process = subprocess.Popen(self.cmd, stdout=subprocess.PIPE,
                                            universal_newlines=True,
                                            bufsize=1)
            return True

        except Exception as e:
            print(e)
            print(f"Could not launchwithBufSize process : {self.cmd}")

            return False

    def stop(self):
        if self.process:
            self.process.poll()

        if (self.process.returncode is None):
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
                os.kill(self.process.pid, signal.SIGTERM)
                time.sleep(1)
                self.process.wait()
                print(f"[INFO] : Process stopped with pid [{self.process.pid}]")

                return True
            except BaseException as e:
                print(f"Error : Process with pid {self.process.pid} could not be killed")
                print(f"{e.message}, {e.args}")

                return False

        return True
