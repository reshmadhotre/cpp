import yaml
import fileinput
import click
import os
import json

def parseYamlFile(file_path):
    try:
        with open(file_path, 'r') as file:
            return yaml.safe_load(file)
    except BaseException:
        print(f"Cannot parse {file_path} as yaml!")
        return dict()

def writeYamlFile(file_path, yaml_data):
    yaml.Dumper.ignore_aliases = lambda *args: True
    try:
        with open(file_path, 'w') as file:
            yaml.dump(yaml_data, file, sort_keys=False)
            return True
    except Exception as e:
        print(e)
        print(f"Error saving replay config at : {file_path}")
        return False

def writeJsonFile(file_path, dict_data):
    try:
        with open(file_path, 'w') as file:
            file.write(json.dumps(dict_data))
        return True
    except Exception as e:
        print(e)
        print(f"Error writing dict at : {file_path}")
        return False

def readJsonFile(file_path):
    try:
        with open(file_path, 'r') as file:
            dict = json.load(file)
        return dict
    except Exception as e:
        print(e)
        print(f"Error reading dict at : {file_path}")
        return {False}
    
def search_and_update_filepath(search_key: str, config_file:str, file_path:str)->bool:
    """
        Args:
            search_key (str): word/string to be searched
            config_file (str): file name on which updation is to be performed
            file_path (str): absolute path of the file in which search is to be performed

        Returns:
            bool: returns True on success
    """
    is_error = False
    if os.path.isfile(file_path):
        formatted_file_str = f'["{file_path}"]'
    else:
        click.secho(f'{file_path} is not valid', fg='red')
        is_error = True

    if is_error:
        formatted_file_str = f'[""]'
        search_and_replace(search_key, config_file, formatted_file_str)
        return False
    
    return search_and_replace(search_key, config_file, formatted_file_str)

def search_and_replace(search_key:str, config_file:str, replace_text)->bool:
    """Search-replace in a given file

    Args:
        search_key (str): word/string to be searched
        config_file (str): absolute path of the file in which search is to be performed
        replace_text (str): word/string to be replace

    Returns:
        bool: returns True if search was successful
    """
    search_result = search_word(config_file, search_key)
    if search_result != "":
        replace_str = f"{search_key}: {replace_text}"
        replace_word(search_result, replace_str, config_file)
    else:
        click.secho(f'[WARNING] {search_key} not found in {config_file}', fg='red')
        return False
    return True

def search_word(file_name:str, search_key:str)->str:
    """Searches a given search key in the given file name and 
       return the matched line

    Args:
        file_name (str): absolute path of the file name
        search_key (str): word to search

    Returns:
        str: If match is found, returns the matched line else empty string
    """
    result = ""
    try:
        with open(file_name, 'r') as file:
            lines = file.readlines()
            for i, line in enumerate(lines):
                if search_key in line:
                    result = line.strip()
                    break
    except FileNotFoundError:
        click.secho(f'{file_name} not found', fg='red')
    return result

def replace_word(search_key:str, replace_line:str, file_name:str)->None:
    """Replaces a given word in a file if a given search key is found

    Args:
        search_key (str): word to search in the file.
        replace_line (str): line to be replace if match is found
        file_name (str): file name on which search/replace is to be performed
    
    Returns:
        str: returns None
    """
    for line in fileinput.input(file_name, inplace=True):
        print(line.replace(search_key, replace_line), end="")
