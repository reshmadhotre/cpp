from app.frames.common_widget import *
from app.utils.yaml_utils import *
from app.utils.replay_utils import *

from app.frames.swc_parameters_frame import SwcParametersFrame

from .status_frame import StatusFrame

from .radar_parameters_frame import RadarParametersFrame
from .video_parameters_frame import VideoParametersFrame
from .can_parameters_frame import CanParametersFrame
from  app.frames.overview_frame import Overview

from app.frames.base_app_view import BaseAppView
from app.frames.menu_button import BtnOpenConfig, BtnSaveConfig, LayoutBtnConfig

from PySide6.QtWidgets import (
    QMessageBox, QWidget)

from PySide6.QtCore import Signal, Slot

import os, time


class AppView(QWidget, BaseAppView):

    ''' Signal sent from Mf4Replay window to
    - Main window on launch/stop event '''
    mf4_replay_window_launch_stop_clicked = Signal(bool)

    def __init__(self, app_controller,
                 app_config,
                 parent=None):
        super(AppView, self).__init__(parent)

        BaseAppView.__init__(self)

        self.controller = app_controller
        self.app_config = app_config
        self.RADAR_ROS_PACKAGE = self.app_config['RADAR_ROS_PACKAGE']
        self.RADAR_ROS_NODE_NAME = self.app_config['RADAR_ROS_NODE_NAME']
        self.VIDEO_ROS_PACKAGE = self.app_config['VIDEO_ROS_PACKAGE']
        self.VIDEO_ROS_NODE_NAME = self.app_config['VIDEO_ROS_NODE_NAME']
        self.CAN_ROS_PACKAGE = self.app_config['CAN_ROS_PACKAGE']
        self.CAN_ROS_NODE_NAME = self.app_config['CAN_ROS_NODE_NAME']
        self.TMP_FOLDER_PATH = self.app_config['TMP_FOLDER_PATH']

        self.stand_alone_device = Device.NoneType

        replay_config = self.controller.getReplayConfig()
        self.createMf4ReplayFrame(replay_config)

    def createInputFrame(self, replay_config):

        self.overview = Overview(controller=self.controller,
                                 tabwidget=self.tab_widget,
                                 app_config=self.app_config,
                                 replay_tool = Tool.Mf4)

        self.enabled_nodes = set()
        self.overview.overview_node_checked.connect(self.setTabwigetsTabsAbility)

        if len(replay_config) == 0:
            QMessageBox.critical(self,
                                 "Config Error",
                                 "Error parsing node config files. Is the terminal sourced?")

        ''' create the dictionary and store in file by Mf4 tool
        use it in rosbag process'''
        package_subscribe_dict = {}
        nodes_names = getNodesNames(self.app_config)
        for node_config in replay_config:
            node_package_name = node_config['ros_package']
            node_name = node_config['ros_node_name']

            if node_package_name == self.RADAR_ROS_PACKAGE:
                radar_parameters_frame = RadarParametersFrame(nodename=nodes_names[Nodes.server_replay_mrr],
                                                              tabwidget=self.tab_widget,
                                                              controller=self.controller,
                                                              overview=self.overview,
                                                              node_config=node_config)
                self.radar_parameters_frame = radar_parameters_frame
                self.input_frames[node_name] = radar_parameters_frame

            elif node_package_name == self.VIDEO_ROS_PACKAGE:
                self.video_parameters_frame = VideoParametersFrame(self, nodename=nodes_names[Nodes.Video],
                                                              node_config=node_config)
                self.input_frames[node_name] =  (self.video_parameters_frame)

            elif node_package_name == self.CAN_ROS_PACKAGE:
                self.can_parameters_frame = CanParametersFrame(self, nodename=nodes_names[Nodes.CAN],
                                                               node_config=node_config)
                self.input_frames[node_name] = (self.can_parameters_frame)
                self.overview.requiredCheckboxAbility(True)
                self.enabled_nodes.add(nodes_names[Nodes.CAN])

            else:
                key_node_name = nodes_names[Nodes[node_package_name]]
                swc_parameters_frame = SwcParametersFrame(nodename=key_node_name,
                                                          package_name = Nodes[node_package_name],
                                                          tabwidget=self.tab_widget,
                                                          controller=self.controller,
                                                          overview=self.overview,
                                                          replay_tool = Tool.Mf4,
                                                          node_config=node_config,
                                                          radar_frame = radar_parameters_frame)
                if key_node_name == "MIDW":
                    if self.radar_parameters_frame.getReplayData() in ["pre_midw", "rdc3"]:
                        swc_parameters_frame.abilityTab(True)
                        self.overview.setReplayData(False)
                self.input_frames[node_name] = swc_parameters_frame
                subcriber_list = list(swc_parameters_frame.sync_subscribe_cb_list.keys())
                if len(subcriber_list):
                    package_subscribe_dict[node_package_name] = subcriber_list

        ''' save the subcriber dictionary to file
        Rosbag replay can read it'''
        file_path = os.path.abspath(self.TMP_FOLDER_PATH)
        subscriber_dict_file_path = os.path.join(file_path, "sync_subcriber_list.txt")
        writeJsonFile(subscriber_dict_file_path, package_subscribe_dict)

    def resetInputFrame(self, replay_config):
        if len(replay_config) == 0:
            QMessageBox.critical(self,
                                 "Config Error", "Error parsing node config files. Is the terminal sourced?")

        for node_config in replay_config:
            node_package_name = node_config['ros_package']
            node_name = node_config['ros_node_name']
            if node_config['ros_package'] == self.RADAR_ROS_PACKAGE:
                self.overview.setCheckbox(node=Nodes.server_replay_mrr, value=True)
            elif node_config['ros_package'] == self.CAN_ROS_PACKAGE:
                self.overview.setCheckbox(node=Nodes.CAN, value=True)
            elif node_config['ros_package'] == self.VIDEO_ROS_PACKAGE:
                self.overview.setCheckbox(node=Nodes.Video, value=True)
            elif node_package_name == 'swc_clock':
                continue
            else:
                self.overview.setCheckbox(node=Nodes[node_package_name], value=True)

            param_input_frame = self.input_frames[node_name]
            param_input_frame.resetInputFrame(node_config=node_config)

    def getRosPackageNames(self):
        return self.controller.getRosPackageNames()

    def getRadarConfig(self, package_name: str, radar_type: str):
        return self.controller.getRadarConfig(package_name, radar_type)

    def getDeviceConfig(self, device:str):
        for data_frame in self.input_frames:
            frame = self.input_frames[data_frame]
            if frame.ROS_NODE_NAME == device:
                return frame.getConfig()

    def generateReplayConfig(self):
        replay_config = []

        for data_frame in self.input_frames:
            frame = self.input_frames[data_frame]
            if frame.nodeEnabled():
                config = frame.getConfig()
                if config is None:
                    return None
                replay_config.append(config)

        return replay_config

    def getConfig(self):
        if self.stand_alone_device == Device.Video:
            replay_config = (self.getDeviceConfig(device="Video"))
        elif self.stand_alone_device == Device.CAN:
            replay_config = (self.getDeviceConfig(device="CAN"))
        elif self.stand_alone_device == Device.CANVideo:
            replay_config = []
            replay_config.append(self.getDeviceConfig(device="CAN"))
            replay_config.append(self.getDeviceConfig(device="Video"))
        elif self.stand_alone_device == Device.Radar:
            replay_config=(self.generateReplayConfig())
        return replay_config

    def launchClicked(self):
        reply = QMessageBox.Yes
        if self.stand_alone_device == Device.Radar and self.radar_parameters_frame.getReplayData() in ["rdc3"]:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Question)
            msg.setWindowTitle("Uhnder Simulator")
            msg.setText("Is Uhnder Simulator Running?")
            msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            reply = msg.exec()

        if reply == QMessageBox.Yes:

            self.resetPreviousNodeAndTriggerNode()
            ''' Get current set of values from param frames'''
            replay_config = self.getConfig()
            if replay_config is not None and len(replay_config) > 0:

                enabled_swc_features = self.overview.getLaunchEnabledNodes()
                if self.controller.launch(replay_config, self.stand_alone_device, enabled_swc_features):
                    self.mf4_replay_window_launch_stop_clicked.emit(True)

                    self.btn_launch_nodes.setDisabled(True)
                    self.stateChangeofControls(False)
                    self.hide()

                    create_rosbag_flag = False
                    if self.stand_alone_device == Device.Radar:
                        create_rosbag_flag = self.overview.getCheckbox(Nodes.server_replay_mrrRosbag).isChecked()

                    self.status_frame = StatusFrame(app_view=self,
                                                    stand_alone_device=self.stand_alone_device,
                                                    create_rosbag_flag=create_rosbag_flag,
                                                    controller=self.controller)
                else:
                    QMessageBox.critical(self, "Launch Error",
                                         "Error launching replay nodes.",
                                         QMessageBox.Ok)

        else:
            QMessageBox.warning(self, "Uhnder Simulator",
                                      "Please run the simulator and click Launch again.",
                                QMessageBox.Ok)

    def getNodeFeedback(self):
        return self.controller.getNodeFeedback()

    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Quit',
                                     "Delete /tmp folder with logs on exit?",
                                     QMessageBox.Yes | QMessageBox.No |
                                     QMessageBox.Cancel,
                                     QMessageBox.No)

        if reply != QMessageBox.Cancel:
            response = True if reply == QMessageBox.Yes else False
            event.accept()
            self.controller.onQuit(response)
        else:
            event.ignore()

    def windowSwitchedinMainPanel(self):
        self.controller.onQuit(False)

    def createMf4ReplayFrame(self, replay_config):
        ''' Main layout'''
        self.layout_main = createVerticalLayout(self, 10, 10, 10, 10)

        ''' Tabwidget sub widget layout'''
        self.tab_widget = createTabWidget(selectedTab=0)
        self.tab_widget.currentChanged.connect(self.onTabWidgetTabChange) 

        self.layout_tab = createHorizontalLayout(top=20)
        self.layout_tab.addWidget(self.tab_widget)

        ''' Button "Open Config" '''
        self.btn_open_config = BtnOpenConfig()
        self.btn_open_config.on_click_file_single.connect(self.on_click_open_config)
        layout_btn_open_config = LayoutBtnConfig(self.btn_open_config, self.tab_widget.width)

        ''' Button "Save Config" '''
        self.btn_save_config = BtnSaveConfig()
        self.btn_save_config.on_click_dialog.connect(self.on_click_save_config)
        layout_btn_save_config = LayoutBtnConfig(self.btn_save_config, self.tab_widget.width)
        layout_btn_save_config.setContentsMargins(0, 20, 0, 0)

        ''' Button "Play" '''
        self.btn_launch_nodes = PushButton(text="  Launch",
                                           tooltip="Launch the Ros nodes",
                                           icon_png=u":/16x16/icons/16x16/cil-media-play.png")
        self.btn_launch_nodes.clicked.connect(self.launchClicked)

        layout_btns = LayoutBtnConfig(self.btn_launch_nodes, self.tab_widget.width)
        layout_btns.setContentsMargins(0, 15, 0, 0)

        self.layout_main.addLayout(layout_btn_open_config, 1)
        self.layout_main.addLayout(self.layout_tab, 30)
        self.layout_main.addLayout(layout_btn_save_config, 1)
        self.layout_main.addLayout(layout_btns, 1)

        self.input_frames = {}
        self.radar_parameters_frame = None
        self.createInputFrame(replay_config)
        self.tab_widget.setCurrentIndex(0)

    @Slot(str)
    def on_click_open_config(self, file: str) -> None:
        self.setReplayConfig(file)

    @Slot(str)
    def on_click_save_config(self, file: str) -> None:
        self.saveReplayConfig(file)

    def stateChangeOfButtons(self, value):
        self.btn_launch_nodes.setDisabled(value)
        self.tab_widget.setDisabled(value)

    def setTabwigetsTabsAbility(self, tuple_checkbox_state):
        checkbox_name = tuple_checkbox_state[0]
        checked_value = tuple_checkbox_state[1]
        for index in range(self.tab_widget.count()):
            tabname = self.tab_widget.tabText(index)

            if tabname == checkbox_name:
                self.tab_widget.setTabEnabled(index, checked_value)

                ''' maintain collection of nodes for below cases
                1. RDC3 + CAN + Video => RDC3 is the source, video and can standalone set to false
                2. CAN + Video => CAN is the source, so standalone to true, video standalone to false
                3. Only CAN => standalone to true
                4. Only Video => standalone to true'''
                if checked_value:
                    self.enabled_nodes.add(tabname)
                else:
                    if len(self.enabled_nodes):
                        self.enabled_nodes.remove(tabname)

                self.isVideoOrCanStandalone()
                break

    def resetOverviewPanel(self):
        self.overview.resetOverviewPanel()

    def isVideoOrCanStandalone(self):
        if (len(self.enabled_nodes) == 1):
            node = list(self.enabled_nodes)[0]
            if node == "Video":
               self.stand_alone_device = Device.Video
            elif node == "CAN":
               self.stand_alone_device = Device.CAN
            elif node == "Radar":
               self.stand_alone_device = Device.Radar

        elif len(self.enabled_nodes) == 2:
            sorted(self.enabled_nodes)
            node1 = list(self.enabled_nodes)[0]
            node2 = list(self.enabled_nodes)[1]
            if node1 == "CAN" and node2 == "Video":
               self.stand_alone_device = Device.CANVideo
            elif node1 == "CAN" and node2 == "Radar":
                   self.stand_alone_device = Device.Radar
        else:
            self.stand_alone_device = Device.Radar

    def stateChangeofControls(self, able_value):
        '''disable overview panel'''
        self.tab_widget.setTabEnabled(0, able_value)

        toggled = not able_value
        self.btn_open_config.setDisabled(toggled)
        self.btn_save_config.setDisabled(toggled)

    def onTabWidgetTabChange(self, index):
        tab_name = self.tab_widget.currentWidget().objectName()
        if tab_name == "Overview":
            return None
        elif "swc_" in tab_name:
            node_name = tab_name + "_app"
            input_frame = self.input_frames[node_name]
            input_frame.setPreviousNode()
        elif tab_name == "server_replay_mrr":
            self.radar_parameters_frame.uhdpCompleteTriggerNode()
            
    def resetPreviousNodeAndTriggerNode(self):
        '''previous node of swc and triggernode of radar
        will be calculated on every main checkbox checked/unchecked'''

        for index in range(self.tab_widget.count()):
            object_name = self.tab_widget.widget(index).objectName()
            if "swc_" in object_name:
                #print(f"object_name {object_name} index {index}")
                node_name = object_name + "_app"
                input_frame = self.input_frames[node_name]
                input_frame.setPreviousNode()
            elif object_name == "server_replay_mrr":
                self.radar_parameters_frame.uhdpCompleteTriggerNode()
