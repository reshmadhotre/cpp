# This Python file uses the following encoding: utf-8
from app.mf4_replay_tool.app_view import AppView

import sys

class Mf4Replay():

    def __init__(self, app_config, app_controller):
        
        self.mf4_app_controller = app_controller
        self.app_config = app_config

    def mf4ReplayView(self):
        try:
            mf4_replay_view = AppView(self.mf4_app_controller,
                                      self.app_config)
            return mf4_replay_view

        except BaseException:
            print(f"Mf4 Replay BaseException {sys.stderr}")
            self.mf4_app_controller.destroy_node()
            raise

    def getAppController(self):
        return self.mf4_app_controller
