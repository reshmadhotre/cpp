
from app.frames.common_widget import *
from app.frames.param_input_frame import ParamInputFrame
from app.frames.menu_button import BtnOpenMf4, BtnFile
from app.utils.replay_utils import *

from PySide6.QtWidgets import (
    QWidget, QMessageBox,
    QScrollArea)
from PySide6.QtCore import Qt
import os


class RadarParametersFrame(QWidget):

    def __init__(self, nodename, tabwidget, controller, overview, node_config: dict):
        super(RadarParametersFrame, self).__init__()

        self.tabwidget = tabwidget
        self.controller = controller
        self.overview = overview
        self.node_config = node_config.copy()
        self.ROS_PACKAGE_NAME = self.node_config['ros_package']
        self.ROS_NODE_NAME = nodename

        self.user_entries = {}
        self.parameters = {}
        self.ros_package_names = self.controller.getRosPackageNames()
        self.input_frame = self.createInputFrame()

    def createInputFrame(self):
        layout_radar_uhdp = QVBoxLayout()

        ''' Open Mf4 button '''
        self.btn_open_mf4 = BtnFile(widget_button=BtnOpenMf4(),
                                    label_note='Select Mf4 file(s) Ex:/home/path/RADAR.mf4')
        layout_radar_uhdp.addWidget(self.btn_open_mf4)

        ''' Layout for labels/button'''
        layout_radar_properties = createVerticalLayout()
        widget_radar_properties = QWidget()
        scroll_radar_properties = QScrollArea(widgetResizable=True)
        scroll_radar_properties.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_radar_properties.setWidgetResizable(True)
        scroll_radar_properties.setWidget(widget_radar_properties)

        layout_radar_uhdp.addWidget(scroll_radar_properties)
        widget_radar_properties.setLayout(layout_radar_properties)

        ''' layout for uhdp params'''
        treeWidget_uhdp = createTreeWidget("Radar Properties")
        # treeWidget_uhdp.setFixedHeight(800)
        item_key_uhdp = CreateTreeWidgetItem(tree_widget=treeWidget_uhdp,
                                             header_name="Uhdp Properties")
        item_key_uhdp.setExpanded(True)
        item_key_scan = CreateTreeWidgetItem(tree_widget=treeWidget_uhdp,
                                             header_name="Scan Properties")
        item_key_scan.setExpanded(True)
        layout_radar_properties.addWidget(treeWidget_uhdp)

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]
        prev_scan_num_param_name = ""

        self.createParametersDescription()

        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)

            if param_name == "param_uhdp_completetrigger_node":
                value_options = self.ros_package_names
            else:
                value_options = self.getValueOptionsFromInfoConfig(param_name)

            label_text = param_name + " :"
            if param_name == 'replay_mf4_filepaths':
                self.user_entries[param_name] = self.btn_open_mf4
                if len(param_value):
                    self.btn_open_mf4.addFilesToEntry(file_paths=param_value)

            elif param_name in ['rosbag_path']:
                self.user_entries[param_name] = ""

            elif param_name == "radar_type":
                self.user_entries[param_name] = (str(param_value))

                self.radar_type_cb = createComboBox(name=param_value,
                                                    tooltip=self.parameters[param_name],
                                                    textvar=param_value,
                                                    options=value_options)
                self.radar_type_cb.setEditable(False)
                self.radar_type_cb.currentTextChanged.connect(
                    self.radarTypeChanged)

                child = CreateTreeWidgetItem(item_key_uhdp, label_text)
                treeWidget_uhdp.setItemWidget(child, 1, self.radar_type_cb)

            else:
                param_input_frame = ParamInputFrame(param_name, param_value,
                                                    value_type, value_options)
                self.user_entries[param_name] = param_input_frame

                if param_name in ['record_rosbags', "param_record_output_parquets"]:
                    if param_name == 'record_rosbags':
                        check_box = self.overview.getCheckbox(Nodes.server_replay_mrrRosbag)
                        check_box.setChecked(param_value)
                        widget = check_box
                    elif param_name == "param_record_output_parquets":
                        parquet_check_box = self.overview.getCheckbox(Nodes.server_replay_mrrOutputParquet)
                        parquet_check_box.setChecked(param_value)
                        widget = parquet_check_box

                    record_check_box, record__label, record_window = param_input_frame.createInputFrame(self.parameters[param_name],
                                                                                check_box=True,
                                                                                check_box_object=widget)
                else:
                    scan_num_param_name = param_name.split(".")[0]
                    parameter_name = param_name.split(".")[1] if scan_num_param_name.startswith('scan') else param_name
                    if value_type == 'int' or value_type == 'double' or param_name == 'radar_name':
                        label, text_box = param_input_frame.createInputFrame(tooltip=self.parameters[parameter_name],
                                                                             text_box=True)
                        text_box.textChanged[str].connect(lambda text,
                                                          param=param_name: self.widget_box_changed(text, param))
                        widget = text_box

                    elif value_type == 'string':
                        if param_name in ["param_uhdp_completetrigger_node", "replay_data"]:
                            if param_name == "param_uhdp_completetrigger_node":
                                label, self.completetrigger_node_combo = param_input_frame.createInputFrame(
                                    tooltip=self.parameters[parameter_name],
                                    combo_box=True)
                                widget = self.completetrigger_node_combo
                                self.uhdpCompleteTriggerNode()

                            elif param_name == "replay_data":
                                if param_value == "":
                                    param_value = "rdc3"
                                label, self.replay_data_combo = param_input_frame.createInputFrame(
                                    tooltip=self.parameters[parameter_name],
                                    combo_box=True)
                                widget = self.replay_data_combo
                            widget.currentTextChanged.connect(
                                    lambda text,
                                    param=param_name: self.widget_box_changed(text, param))
                    elif value_type == 'bool':
                        check_box, label, window = param_input_frame.createInputFrame(
                            tooltip=self.parameters[param_name],
                            check_box=True)

                        check_box.stateChanged.connect(lambda text,
                                                    param=param_name: self.widget_box_changed(text, param))
                        widget = check_box

                    if scan_num_param_name.startswith('scan') or 'ss_doppler' in param_name:
                        if 'ss_doppler' in param_name and param_name == 'ss_doppler_near_range':
                            item_key_doppler = CreateTreeWidgetItem(tree_widget=item_key_scan,
                                                                    header_name="ss_doppler_range")

                            child = CreateTreeWidgetItem(item_key_doppler, label_text)
                            treeWidget_uhdp.setItemWidget(child, 1, widget)

                        elif 'ss_doppler' in param_name and param_name == 'ss_doppler_far_range':
                            child = CreateTreeWidgetItem(item_key_doppler, label_text)
                            treeWidget_uhdp.setItemWidget(child, 1, widget)

                        else:
                            later_part_param_name = param_name.split(".")[1]

                            if (scan_num_param_name != prev_scan_num_param_name):
                                item_key = CreateTreeWidgetItem(tree_widget=item_key_scan,
                                                                header_name=scan_num_param_name)

                                prev_scan_num_param_name = scan_num_param_name

                            label_text = later_part_param_name + " :"
                            child = CreateTreeWidgetItem(item_key, label_text)
                            treeWidget_uhdp.setItemWidget(child, 1, widget)

                    else:
                        child = CreateTreeWidgetItem(item_key_uhdp, label_text)
                        treeWidget_uhdp.setItemWidget(child, 1, widget)

        widget_radar_uhdp = QWidget()
        widget_radar_uhdp.setObjectName(self.ROS_PACKAGE_NAME)
        widget_radar_uhdp.setLayout(layout_radar_uhdp)
        self.tabwidget.addTab(widget_radar_uhdp, self.ROS_NODE_NAME)

    def resetInputFrame(self, node_config):
        self.node_config = node_config.copy()

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            if param_name == "param_uhdp_completetrigger_node":
                value_options = self.ros_package_names
            else:
                value_options = self.getValueOptionsFromInfoConfig(param_name)

            if param_name == 'replay_mf4_filepaths':
                if len(param_value):
                    self.btn_open_mf4.addFilesToEntry(file_paths=param_value)
                self.user_entries[param_name] = self.btn_open_mf4

            elif param_name == 'rosbag_path':
                self.user_entries[param_name] = ""

            elif param_name == "radar_type":
                self.user_entries[param_name] = (str(param_value))

                self.radar_type_cb.blockSignals(True)
                self.radar_type_cb.clear()
                if len(value_options):
                    self.radar_type_cb.addItems(value_options)
                else:
                    self.radar_type_cb.addItem(str(param_value))
                self.radar_type_cb.blockSignals(False)

            elif param_name == "replay_data":
                self.replay_data_combo.blockSignals(True)
                self.replay_data_combo.clear()
                if len(value_options):
                    self.replay_data_combo.addItems(value_options)
                    self.replay_data_combo.setCurrentText(str(param_value))
                else:
                    self.replay_data_combo.addItem(str(param_value))
                self.replay_data_combo.blockSignals(False)
                self.widget_box_changed(param_value,param_name)
            else:
                param_input_frame = self.user_entries[param_name]

                param_input_frame.resetInputFrame(param_name, param_value,
                                                  value_type, value_options)
                self.user_entries[param_name] = param_input_frame

    def updateRosbagDir(self):
        if self.overview.getCheckbox(Nodes.server_replay_mrrRosbag).isChecked():
            mf4_filepaths = self.user_entries['replay_mf4_filepaths'].get()
            if mf4_filepaths is None:
                return False

            mf4_dir = os.path.dirname(mf4_filepaths[0])

            # If one file, create rosbag with same name as file
            if mf4_filepaths and len(mf4_filepaths) == 1:
                mf4_file_name = os.path.splitext(os.path.basename(mf4_filepaths[0]))[0]
                rosbag_name = mf4_file_name + ".ros2bag"
                rosbag_dir = os.path.join(mf4_dir, rosbag_name)
                self.user_entries['rosbag_path'] = (rosbag_dir)

            # If multiple files, create rosbag with folder name
            elif mf4_filepaths and len(mf4_filepaths) > 1:
                rosbag_name = os.path.basename(mf4_dir) + ".ros2bag"
                rosbag_dir = os.path.join(mf4_dir, rosbag_name)
                self.user_entries['rosbag_path'] = (rosbag_dir)
        else:
            self.user_entries['rosbag_path'] = ""

    def radarTypeChanged(self, event):
        radar_type = str(self.radar_type_cb.currentText())
        params_config = self.controller.getRadarConfig(package_name=self.ROS_PACKAGE_NAME,
                                                       radar_type=radar_type)
        self.setConfig(params_config)

    def getValueTypeFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['type']

        return "string"

    def getValueOptionsFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['values']

        return []

    def getConfig(self):
        if self.updateConfig():
            return self.node_config.copy()
        return None

    def setConfig(self, node_config):
        self.node_config = node_config.copy()
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name in params_config[node_name]['ros__parameters'].keys():
            if param_name not in ['replay_mf4_filepaths']:
                if param_name in [ 'rosbag_path' ,'radar_type'] :
                    self.user_entries[param_name] = (params_config[node_name]['ros__parameters'][param_name])
                elif param_name == 'replay_data':
                    if params_config[node_name]['ros__parameters'][param_name] == "":
                        params_config[node_name]['ros__parameters'][param_name] = "rdc3"
                    self.overview.setReplayData(False)
                    param_input_frame = self.user_entries[param_name]
                    param_input_frame.resetWidgetbox((params_config[node_name]['ros__parameters'][param_name]))
                    self.widget_box_changed(params_config[node_name]['ros__parameters'][param_name],param_name)
                else:
                    param_input_frame = self.user_entries[param_name]
                    param_input_frame.resetWidgetbox((params_config[node_name]['ros__parameters'][param_name]))
        self.uhdpCompleteTriggerNode()

    def updateConfig(self):
        if self.updateRosbagDir() == False:
            return False
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]
        for param_name in params_config[node_name]['ros__parameters'].keys():
            ''' String objects'''
            if param_name in ["rosbag_path","radar_type"]:
                user_value = self.user_entries[param_name]
            elif param_name in ["replay_data"]:
                user_value = self.getReplayData()
            else:
                user_value = self.user_entries[param_name].get()
            if user_value is None:
                return False
            elif user_value == "" and param_name != "rosbag_path":
                QMessageBox.critical(self, "Value Error",
                                     f"Expected a value for param : {param_name}",
                                     QMessageBox.Ok)
                return False
            self.node_config['params_config'][node_name]['ros__parameters'][param_name] = user_value
        return True

    def nodeEnabled(self):
        return self.overview.getCheckbox(Nodes.server_replay_mrr).isChecked()

    def uhdpCompleteTriggerNode(self):
        item_list =  [self.completetrigger_node_combo.itemText(i) for i in 
                      range(self.completetrigger_node_combo.count())]

        item_uhdp = self.overview.getNodeOfMaximumWeight()
        if item_uhdp in item_list:
            self.completetrigger_node_combo.setCurrentText(item_uhdp)

    def createParametersDescription(self):
        self.parameters["record_rosbags"] = "Record the video rosbags"
        self.parameters["radar_type"] = "Type of radar"
        self.parameters["radar_name"] = "Radar name"
        self.parameters["param_uhdp_completetrigger_node"] = "Complete trigger node"
        self.parameters["ss_doppler_near_range"] = "Doppler near range"
        self.parameters["ss_doppler_far_range"] = "Doppler far range"
        self.parameters["sensor_position_x"] = "Sensor Mount Position X"
        self.parameters["sensor_position_y"] = "Sensor Mount Position Y"
        self.parameters["sensor_position_z"] = "Sensor Mount Position Z"
        self.parameters["sensor_yaw"] = "Sensor Mount Yaw"
        self.parameters["sensor_pitch"] = "Sensor Mount Pitch"
        self.parameters["sensor_roll"] = "Sensor Mount Roll"
        self.parameters["detection_thresh_snr_dB"] = "Detection threshold snr DB"
        self.parameters["clutter_image_thresh_snr_dB"] = "Clutter image threshold snr DB"
        self.parameters["point_cloud_thresh_snr_dB"] = "Point cloud threshold snr DB"
        self.parameters["scale_det_thresh_max_range"] = "scale_det_thresh_max_range"
        self.parameters["scale_det_thresh_snr_adj"] = "scale_det_thresh_snr_adj"
        self.parameters["ego_zero_stationary_threshold_mps"] = "ego_zero_stationary_threshold_mps"
        self.parameters["ego_nonz_stationary_threshold_mps"] = "ego_nonz_stationary_threshold_mps"
        self.parameters["notch_width_radians"] = "notch_width_radians"
        self.parameters["notch_depth_dB"] = "notch_depth_dB"
        self.parameters["outer_depth_dB"] = "outer_depth_dB"
        self.parameters["param_record_output_parquets"] = "Record output Parquet"
        self.parameters["replay_data"] = "Replay midw int alldata"

    def widget_box_changed(self, text, param_name):
        param_input_frame = self.user_entries[param_name]
        param_input_frame.param_value = text
        self.user_entries[param_name] = param_input_frame

        if param_name == "replay_data" and text in ["rdc3", "pre_midw"] :
            self.overview.setReplayData(False)
        elif param_name == "replay_data" and text == "post_midw":
            self.overview.setReplayData(True)

        return

    def getReplayData(self):
        param_input_frame = self.user_entries["replay_data"]
        return param_input_frame.param_value 
