from app.frames.param_input_frame import ParamInputFrame
from app.frames.common_widget import *
from app.frames.menu_button import BtnOpenMf4, BtnFile
from ..utils.replay_utils import *
#from .player_frame import *
from app.utils.subprocess_util import SubprocessUtil

from PySide6.QtWidgets import (
    QMainWindow, QMessageBox)
from PySide6.QtCore import Qt, Signal


class VideoParametersFrame(QMainWindow):
    ''' Signal sent from video standalone window to
    - Main window on launch/stop event '''
    video_standalone_window_launched = Signal()
    video_standalone_window_stop_clicked = Signal()

    def __init__(self, appview, nodename, node_config: dict):
        super(VideoParametersFrame, self).__init__()

        self.appview = appview
        self.tabwidget = appview.tab_widget
        self.controller = appview.controller
        self.overview = appview.overview
        self.enabled_nodes = appview.enabled_nodes
        self.node_config = node_config.copy()
        self.ROS_PACKAGE_NAME = self.node_config['ros_package']
        self.ROS_NODE_NAME = nodename

        self.user_entries = {}
        self.parameters = {}
        self.createInputFrame()
        self.player_frame = None

    def createInputFrame(self):
        ''' Main layout'''
        self.main_layout = QVBoxLayout()

        ''' Open Mf4 button '''
        self.btn_open_mf4 = BtnFile(widget_button=BtnOpenMf4(text="  Open Mf4 Video file(s)",
                                                             tooltip="Choose the Mf4 Video files",
                                                             dialog_title='Select the Video mf4 file(s)',
                                                             width=180),
                                    label_note='Select Mf4 Video file(s) Ex:/home/path/RADAR.mf4')
        self.main_layout.addWidget(self.btn_open_mf4)

        layout_check_box = createHorizontalLayout(top=15, right=5)

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        self.createParametersDescription()
        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            value_options = self.getValueOptionsFromInfoConfig(param_name)

            if param_name == 'replay_mf4_video_filepaths':
                self.parameters[param_name] = "Mf4 Video filepaths"
                self.user_entries[param_name] = self.btn_open_mf4
                if len(param_value):
                    self.btn_open_mf4.addFilesToEntry(file_paths=param_value)

            else:
                param_input_frame = ParamInputFrame(param_name, param_value,
                                                    value_type, value_options)
                self.user_entries[param_name] = param_input_frame

                if param_name == 'record_rosbags':
                    check_box = self.overview.getCheckbox(Nodes.VideoRosbag)
                    check_box, label, window = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                                  check_box=True,
                                                                                  check_box_object=check_box)
                elif value_type == 'bool':

                    check_box, label, window = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                                  check_box=True, label_side='right')
                    check_box.stateChanged.connect(lambda text,
                                                   param=param_name: self.checkbox_state_changed(text, param))
                    layout_check_box.addWidget(window)

                    if param_name == 'standalone_mode':
                        ''' hide it on app view, it is always False'''
                        check_box.setChecked(False)
                        window.setVisible(False)

        self.main_layout.addLayout(layout_check_box)
        '''compactly arrange all the widgets '''
        self.main_layout.insertStretch(-1, 1)

        widget_video_node = QWidget()
        widget_video_node.setObjectName(self.ROS_PACKAGE_NAME)
        widget_video_node.setLayout(self.main_layout)
        index = self.tabwidget.addTab(widget_video_node, self.ROS_NODE_NAME)
        self.tabwidget.setTabEnabled(index, False)

    def resetInputFrame(self, node_config):
        self.node_config = node_config.copy()

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            value_options = self.getValueOptionsFromInfoConfig(param_name)

            if param_name == 'replay_mf4_video_filepaths':
                self.btn_open_mf4.addFilesToEntry(file_paths=param_value)
                self.user_entries[param_name] = self.btn_open_mf4
            else:
                param_input_frame = self.user_entries[param_name]
                param_input_frame.resetInputFrame(param_name,
                                                  param_value,
                                                  value_type,
                                                  value_options)
                self.user_entries[param_name] = param_input_frame

    def getValueTypeFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['type']

        return "string"

    def getValueOptionsFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        param_name_end = param_name.split(".")[-1]
        if param_name_end in params_info_config:
            return params_info_config[param_name_end]['values']

        return []

    def getConfig(self):
        if self.updateConfig():
            return self.node_config.copy()
        return None

    def setConfig(self, node_config):
        self.node_config = node_config.copy()
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name in params_config[node_name]['ros__parameters'].keys():
            if param_name != 'replay_mf4_video_filepaths':
                self.user_entries[param_name].set(params_config[node_name]['ros__parameters'][param_name])

    def updateConfig(self):
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]
        for param_name in params_config[node_name]['ros__parameters'].keys():
            ''' if this is only node enabled make it standalone'''
            if param_name == "standalone_mode" and len(self.enabled_nodes) == 1:
                self.user_entries[param_name].set(value=True)

            user_value = self.user_entries[param_name].get()
            if user_value is None:
                return False
            elif user_value == "":
                QMessageBox.critical(self, "Value Error", f"Expected a value for param : {param_name}")
                return False
            self.node_config['params_config'][node_name]['ros__parameters'][param_name] = user_value
        return True

    def nodeEnabled(self):
        return self.overview.getCheckbox(Nodes.Video).isChecked()

    def comboBoxChanged(self, text, param_name):
        param_input_frame = self.user_entries[param_name]
        param_input_frame.param_value = text
        self.user_entries[param_name] = param_input_frame

    def launchSetParameterCommand(self, param_name, is_checked):
        check_value = 'False' if is_checked == 0 else 'True'
        cmd = ['ros2', 'param', 'set', self.ROS_NODE_NAME,
               param_name, check_value]
        print(" cmd: {0}".format(cmd))
        self.ros_launch_set_parameter = SubprocessUtil(cmd)
        self.ros_launch_set_parameter.launch()

    def checkbox_state_changed(self, text, param_name):
        if param_name == 'show_timestamp':
            self.launchSetParameterCommand(param_name, text)

    def createParametersDescription(self):
        self.parameters["record_rosbags"] = "Record the video rosbags"
        self.parameters["standalone_mode"] = "Flag to show video replay server as stand alone app"
        self.parameters["show_timestamp"] = "Flag to show the timestamp from the mdf file on the image"

    def getRosbagPathFolder(self):
        return self.btn_open_mf4.widget_button.getFolderpath()

    def isChecked(self, flag_to_be_checked):
        param_name = flag_to_be_checked
        param_input_frame = self.user_entries[param_name]
        return param_input_frame.check_box.isChecked()
