from PySide6.QtWidgets import  QMessageBox
from PySide6.QtCore import QTimer

from app.frames.common_widget import *
from app.utils.replay_utils import Device

from msg_swc_common.msg import MsgNodeFeedbackType
from server_replay_video.msg import MsgVideoReplayStatus
from msg_replay_status.msg import MsgReplayToolRvizPlugin


from rclpy.node import Node

class StatusFrame:

    def __init__(self, app_view, stand_alone_device,
                 create_rosbag_flag, controller):
        super(StatusFrame, self).__init__()

        self.app_view = app_view
        self.stand_alone_device = stand_alone_device
        self.controller = controller

        self.create_rosbag_flag = create_rosbag_flag
        self.replay_tool_publish = self.controller.getReplayToolDataPublisher()
        
        self.timer = QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.start(10)

    def update(self):
        self.publishReplayToolData()
        self.getReplayToolStatusMode()

    def getReplayToolStatusMode(self):
        node_replay_tool_rviz_plugin_feedback: MsgReplayToolRvizPlugin = self.controller.getReplayToolStatusMode()
        stop_status_mode = "  Stop"
        if node_replay_tool_rviz_plugin_feedback.status_mode == stop_status_mode:
            self.stopClicked()

    def getNodeFeedback(self):
        if self.stand_alone_device == Device.Radar:
            node_feedback: MsgNodeFeedbackType = self.controller.getNodeFeedback()
            finished_msg = MsgNodeFeedbackType.FINISHED
        elif self.stand_alone_device == Device.Video:
            node_feedback: MsgVideoReplayStatus = self.controller.getVideoNodeFeedback()
            finished_msg = MsgVideoReplayStatus.FINISHED
        elif self.stand_alone_device in [Device.CANVideo]:
            node_feedback: MsgNodeFeedbackType = self.controller.getNodeFeedback() 
            finished_msg = MsgNodeFeedbackType.FINISHED

        if node_feedback.status == finished_msg:
            self.stopClicked()
            
    def stopClicked(self):
        self.player_mode = "STOP"
        self.closeAllHandles()

    def closeAllHandles(self):
        if self.timer.isActive():
            self.timer.stop()

        if self.controller.stop():
            self.app_view.mf4_replay_window_launch_stop_clicked.emit(False)
            self.app_view.show()
            self.app_view.btn_launch_nodes.setDisabled(False)
            self.app_view.stateChangeofControls(True)
        else:
            QMessageBox.critical(self, "Stop Error",
                                 "Error stopping replay nodes.",
                                 QMessageBox.Ok)

    def closeEvent(self, event):
        self.closeAllHandles()
        event.accept()

    def getRosbagPathFolder(self):
        return self.panel_view.getRosbagPathFolder()

    def publishReplayToolData(self):
        replay_tool_data = MsgReplayToolRvizPlugin()
        replay_tool_data.device_name = self.stand_alone_device
        replay_tool_data.create_rosbag_flag = self.create_rosbag_flag

        self.replay_tool_publish.publish(replay_tool_data)
