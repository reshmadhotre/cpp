from app.frames.param_input_frame import ParamInputFrame
from app.frames.common_widget import *
from app.frames.menu_button import BtnOpenMf4, BtnOpenSingleFile, BtnFile
from ..utils.replay_utils import *


from PySide6.QtWidgets import (
    QMainWindow, QFormLayout,
    QWidget, QMessageBox)
from PySide6.QtCore import Qt, Signal


class CanParametersFrame(QMainWindow):
    ''' Signal sent from can standalone window to
    - Main window on launch/stop event '''
    can_standalone_window_launched = Signal()
    can_standalone_window_stop_clicked = Signal()

    def __init__(self, appview, nodename, node_config: dict):
        super(CanParametersFrame, self).__init__()

        self.appview = appview
        self.tabwidget = appview.tab_widget
        self.controller = appview.controller
        self.overview = appview.overview
        self.enabled_nodes = appview.enabled_nodes
        self.node_config = node_config.copy()
        self.ROS_PACKAGE_NAME = self.node_config['ros_package']
        self.ROS_NODE_NAME = nodename

        self.user_entries = {}
        self.parameters = {}
        self.createInputFrame()
        self.player_frame = None

    def createInputFrame(self):

        self.main_layout = QVBoxLayout()

        layout_can_properties = createVerticalLayout()
        widget_can_properties = QWidget()
        scroll_can_properties = QScrollArea(widgetResizable=True)
        scroll_can_properties.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_can_properties.setWidgetResizable(True)
        scroll_can_properties.setWidget(widget_can_properties)

        self.main_layout.addWidget(scroll_can_properties)
        widget_can_properties.setLayout(layout_can_properties)

        ''' Open Mf4 button '''
        self.btn_open_mf4 = BtnFile(widget_button=BtnOpenMf4(text="  Open Mf4 CAN file(s)",
                                                             tooltip="Choose the Mf4 Can files",
                                                             dialog_title='Select the Can mf4 file(s)',
                                                             width=180),
                                    label_note='Select Mf4 Can file(s) Ex:/home/path/CAN.mf4')

        self.btn_open_dbc = BtnFile(widget_button=BtnOpenSingleFile(text="  Open DBC file",
                                                                    tooltip="Choose the DBC file",
                                                                    dialog_title='Select the dbc file',
                                                                    filter='DBC (*.dbc)',
                                                                    suffix='dbc'),
                                    label_note='Select dbc file Ex:/home/path/vector.dbc')
        layout_can_properties.addWidget(self.btn_open_mf4)
        layout_can_properties.addSpacing(10)
        layout_can_properties.addWidget(self.btn_open_dbc)

        formlayout = QFormLayout()
        formlayout.setContentsMargins(0, 10, 0, 5)

        layout_check_box = createHorizontalLayout(top=15, right=5)

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]
        self.createParametersDescription()
        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            value_options = self.getValueOptionsFromInfoConfig(param_name)

            if param_name == 'replay_mf4_CAN_filepaths':
                self.user_entries[param_name] = self.btn_open_mf4

            elif param_name == 'dbc_filepath':
                self.user_entries[param_name] = self.btn_open_dbc

            else:
                param_input_frame = ParamInputFrame(param_name, param_value,
                                                    value_type, value_options)
                self.user_entries[param_name] = param_input_frame

                if param_name in ['record_rosbags' , 'param_record_output_parquets']:
                    if param_name == 'record_rosbags':
                        check_box = self.overview.getCheckbox(Nodes.CanRosbag)
                    else:
                        check_box = self.overview.getCheckbox(Nodes.CanOutputParquet)
                    check_box, label, window = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                                  check_box=True,
                                                                                  check_box_object=check_box)
                elif value_type == 'bool':
                    check_box, label, window = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                                  check_box=True, label_side='right')
                    layout_check_box.addWidget(window)
                    if param_name == 'standalone_mode':
                        ''' hide it on app view, it is always False'''
                        check_box.setChecked(False)
                        window.setVisible(False)

                elif value_type == 'int' or value_type == 'double':
                    label, text_box = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                         text_box=True)

                    text_box.textChanged[str].connect(lambda text,
                                                      param=param_name: self.widgetBoxChanged(text, param))

                    formlayout.addWidget(createSpacerLabel(2))
                    formlayout.addRow(label, text_box)
                    formlayout.addWidget(createSpacerLabel(2))

                else:
                    label, combo_box = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                          combo_box=True)

                    combo_box.currentTextChanged.connect(
                        lambda text,
                        param=param_name: self.widgetBoxChanged(text, param))

                    formlayout.addRow(label, combo_box)

        layout_can_properties.addLayout(layout_check_box)
        layout_can_properties.addLayout(formlayout)

        #layout_can_properties.insertStretch(-1, 1)

        widget_can_node = QWidget()
        widget_can_node.setObjectName(self.ROS_PACKAGE_NAME)
        widget_can_node.setLayout(self.main_layout)
        self.tabwidget.addTab(widget_can_node, self.ROS_NODE_NAME)

    def resetInputFrame(self, node_config):
        self.node_config = node_config.copy()

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            value_options = self.getValueOptionsFromInfoConfig(param_name)

            param_input_frame = self.user_entries[param_name]

            if param_name == 'replay_mf4_CAN_filepaths':
                self.btn_open_mf4.addFilesToEntry(file_paths=param_value)
            elif param_name == 'dbc_filepath':
                self.btn_open_dbc.addFileToEntry(file_path=param_value)
            else:
                param_input_frame.resetInputFrame(param_name, param_value, value_type, value_options)

            self.user_entries[param_name] = param_input_frame

    def getValueTypeFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        if param_name in params_info_config:
            return params_info_config[param_name]['type']

        return "string"

    def getValueOptionsFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        if param_name in params_info_config:
            return params_info_config[param_name]['values']

        return []

    def getConfig(self):
        if self.updateConfig():
            return self.node_config.copy()
        return None

    def setConfig(self, node_config):
        self.node_config = node_config.copy()
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        for param_name in params_config[node_name]['ros__parameters'].keys():
            if param_name != 'replay_mf4_CAN_filepaths':
                self.user_entries[param_name].set(params_config[node_name]['ros__parameters'][param_name])

    def updateConfig(self):
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]
        for param_name in params_config[node_name]['ros__parameters'].keys():

            ''' if this is only node enabled make it standalone'''
            if param_name == "standalone_mode":
                if len(self.enabled_nodes) == 1:
                    self.user_entries[param_name].set(value=True)
                    '''CAN + Video => CAN is the source, so standalone to true,
                video standalone to false'''
                elif len(self.enabled_nodes) >= 2:
                    sorted(self.enabled_nodes)
                    node1 = list(self.enabled_nodes)[0]
                    node2 = list(self.enabled_nodes)[1]
                    if node1 == "CAN" and node2 == "Video":
                        self.user_entries[param_name].set(value=True)

            user_value = self.user_entries[param_name].get()
            if user_value is None:
                return False
            elif user_value == "":
                QMessageBox.critical(self, "Value Error", f"Expected a value for param : {param_name}")
                return False
            self.node_config['params_config'][node_name]['ros__parameters'][param_name] = user_value
        return True

    def nodeEnabled(self):
        return self.overview.getCheckbox(node=Nodes.CAN).isChecked()

    def widgetBoxChanged(self, text, param_name):
        param_input_frame = self.user_entries[param_name]
        param_input_frame.param_value = text
        self.user_entries[param_name] = param_input_frame

    def createParametersDescription(self):
        self.parameters['record_rosbags'] = "Record the Can rosbags"
        self.parameters["param_record_output_parquets"] = "Record output Parquet"
        self.parameters['publish_can_obj_list'] = "Publish can object list"
        self.parameters['publish_road_border_data'] = "Publish Road Border Data"
        self.parameters['standalone_mode'] = "When True, the node publishes messages at a constant rate.otherwise, it publishes messages in sync with a radar_uhdp_node"
        self.parameters["sensor_position_x"] = "Specify sensor_position_x value"
        self.parameters["sensor_position_y"] = "Specify sensor_position_y value"
        self.parameters["sensor_position_z"] = "Specify sensor_position_z value"
        self.parameters["sensor_pitch"] = "Specify sensor_pitch"
        self.parameters["sensor_roll"] = "Specify sensor_roll"
        self.parameters["sensor_yaw"] = "Specify sensor_yaw"

    def getRosbagPathFolder(self):
        return self.btn_open_mf4.widget_button.getFolderpath()

    def isChecked(self, flag_to_be_checked):
        param_name = flag_to_be_checked
        param_input_frame = self.user_entries[param_name]
        return param_input_frame.check_box.isChecked()

    def getVideoConfig(self):
        return self.appview.getVideoConfig()
