import autopep8
import os
from jinja2 import Environment, FileSystemLoader
from pathlib import Path


class NodeLaunchAction:
    """Create a single Node LaunchAction definition from the provided config.

    Used to serialize the python function used to create a single launch
    action string. String is used to populate the jinja templates to create
    the final launch file.
    """

    TEMPLATE_NAME = "node_definition.j2"

    def __init__(self, config):
        self.config = config

    def serialize(self):
        """Serialize the launch action defined in self.config as a pep8 formatted string.
           Convert the launch action into pep8 formatted python function
           that can be inserted into launch actions array in the final
           launch file.
        """

        # Open definition template file using jinja2
        template_dir_path = Path(os.path.dirname(__file__)) / '../templates'
        env = Environment(loader=FileSystemLoader(searchpath=os.path.abspath(template_dir_path)))
        template = env.get_template(self.TEMPLATE_NAME)

        rendered_template = template.render(
            name=self.serialize_value(self.config['name'], render_as_string=True),
            namespace=self.serialize_value(self.config['namespace'], render_as_string=True),
            package=self.serialize_value(self.config['package'], render_as_string=True),
            executable=self.serialize_value(self.config['executable'], render_as_string=True),
            output=self.serialize_value(self.config['output'], render_as_string=True),
            parameters=self.serialize_value(self.config['parameters'], render_as_string=True),
            arguments=self.serialize_value(self.config['arguments'], render_as_string=True)
        )

        return autopep8.fix_code(rendered_template).rstrip()

    def serialize_value(self, value, render_as_string=False):
        """Serialize a value for launch action.
            Used to correctly serialize dicts and lists as python code.
        """

        if isinstance(value, list):
            serialized = "[\n"
            item_strings = []
            for item in value:
                item_strings.append(self.serialize_value(item, render_as_string))
            serialized += ",\n".join(item_strings)
            serialized += "\n]"
            return serialized

        if isinstance(value, dict):
            serialized = "{\n"
            item_strings = []
            for key, val in value.items():
                val_serialized = self.serialize_value(val, render_as_string)
                item_strings.append(f"'{key}':{val_serialized}")

            serialized += ",\n".join(item_strings)
            serialized += "\n}"
            return serialized

        if isinstance(value, int):
            return value

        if isinstance(value, float):
            return value

        if isinstance(value, str):
            # If boolean, return boolean
            if value == "True":
                return True
            elif value == "False":
                return False

            # check if it is a integer value
            if(value.isdigit()):
                return int(str(value))

            # check if is floating point
            try:
                num_value = float(str(value))
                return num_value

            except BaseException:
                # return as string
                if render_as_string:
                    return f"'{value}'"
                else:
                    return str(value)
