from app.frames.common_widget import *
from app.frames.menu_button import BtnOpenSingleFile, BtnFile
from app.frames.param_input_frame import ParamInputFrame

from PySide6.QtWidgets import QMessageBox, QFormLayout
from PySide6.QtGui import QResizeEvent

import os

class RosbagInputFrame(QWidget):
    def __init__(self, tabwidget, node_config: dict):
        super(RosbagInputFrame, self).__init__()

        self.node_config = node_config.copy()
        self.tabwidget = tabwidget

        self.createInputFrame()

    # def resizeEvent(self, event: QResizeEvent) -> None:
    #     return super().resizeEvent(event)

    def createInputFrame(self):

        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        self.setMinimumHeight(900)

        ''' Main layout'''
        self.main_vertical_layout = QVBoxLayout()
        self.main_vertical_layout.setContentsMargins(10, 10, 10, 10)

        self.createParametersDescription()

        self.btn_open_dbc = BtnFile(widget_button=BtnOpenSingleFile(text="  Open Rosbag file",
                                                                    tooltip=self.parameters["rosbag_folder_path"],
                                                                    dialog_title='Select the Rosbag file',
                                                                    filter='DB3 (*.db3)',
                                                                    suffix='db3'),
                                    label_note='Select db3 file Ex:/home/path/*.ros2bag/*.db3')

        self.main_vertical_layout.addWidget(self.btn_open_dbc)

        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]

        formlayout = QFormLayout()
        formlayout.setContentsMargins(0, 20, 0, 0)

        self.user_entries = {}
        for param_name, param_value in params_config[node_name]['ros__parameters'].items():
            value_type = self.getValueTypeFromInfoConfig(param_name)
            value_options = self.getValueOptionsFromInfoConfig(param_name)
            
            if param_name == 'rosbag_folder_path':
                self.user_entries[param_name] = self.btn_open_dbc
                if len(param_value):
                    self.btn_open_dbc.addFileToEntry(param_value)

            elif param_name == 'rosbag_type':
                param_input_frame = ParamInputFrame(param_name, param_value,
                                                    value_type, value_options)
                self.user_entries[param_name] = param_input_frame
                label, combo_box = param_input_frame.createInputFrame(tooltip=self.parameters[param_name],
                                                                            combo_box=True)
                combo_box.currentTextChanged.connect(
                        lambda text,
                        param=param_name: self.widgetBoxChanged(text, param))
                formlayout.addRow(label, combo_box)

        self.main_vertical_layout.addLayout(formlayout)
        self.main_vertical_layout.insertStretch(-1,1)

        self.setLayout(self.main_vertical_layout)
        self.tabwidget.addTab(self, "Replay Rosbag")

    def getRosbagFolder(self):
        self.rosbag_filename = self.btn_open_dbc.get()
        self.rosbag_filepath = os.path.dirname(self.rosbag_filename)
        if len(self.rosbag_filepath) == 0:
            QMessageBox.critical(self, "File Input Error",
                                "Please select a valid db3 file from a rosbag.",
                                QMessageBox.Ok)
            return None

        return str(self.rosbag_filepath)

    def getConfig(self):
        if self.updateConfig():
            return self.node_config.copy()
        return None

    def updateConfig(self):
        params_config = self.node_config['params_config']
        node_name = list(params_config.keys())[0]
        for param_name in params_config[node_name]['ros__parameters'].keys():
            if param_name == 'rosbag_folder_path':
                user_value = self.getRosbagFolder()
            else:
                user_value = self.user_entries[param_name].get()
            if user_value is None:
                return False
            elif user_value == "":
                QMessageBox.critical(self, "Value Error", f"Expected a value for param : {param_name}")
                return False
            self.node_config['params_config'][node_name]['ros__parameters'][param_name] = user_value
        return True

    def getValueTypeFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        if param_name in params_info_config:
            return params_info_config[param_name]['type']

        return "string"

    def getValueOptionsFromInfoConfig(self, param_name: str):
        params_info_config = self.node_config['params_info_config']
        if param_name in params_info_config:
            return params_info_config[param_name]['values']

        return []

    def createParametersDescription(self):
        self.parameters = {}
        self.parameters['rosbag_folder_path'] = "Rosbag db3 file path"
        self.parameters['rosbag_type'] = "Rosbag filetype"
        self.parameters['topics_to_publish'] = "Interested topics to publish"

    def widgetBoxChanged(self, text, param_name):
        param_input_frame = self.user_entries[param_name]
        param_input_frame.param_value = text
        self.user_entries[param_name] = param_input_frame
