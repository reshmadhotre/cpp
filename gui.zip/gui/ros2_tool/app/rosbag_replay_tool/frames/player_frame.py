from app.frames.slider_label import SliderLabel
from app.frames.common_widget import *
from app.frames.menu_button import LayoutBtnConfig

from PySide6.QtWidgets import QMessageBox
from PySide6.QtCore import QTimer

from server_replay_rosbag.msg import MsgSetPauseMode
from server_replay_rosbag.msg import MsgTriggerSingleFrame

from app.utils.replay_utils import Device

class PlayerFrame(QWidget):

    def __init__(self, appview):
        super(PlayerFrame, self).__init__()

        self.appview = appview
        self.main_layout = appview.layout_main
        self.rosbag_input_frame = appview.rosbag_input_frame
        self.controller = appview.controller

        self.createPlayerFrame()

    def createPlayerFrame(self):
        self.player_mode = "STOP"

        self.layout_player = QVBoxLayout()
        self.layout_player.setContentsMargins(0,25,0,10)

        self.createSlider()
        self.createPlayerButtonsFrame()
        self.layout_player.insertStretch(-1,1)
        self.main_layout.addLayout(self.layout_player)

    def createSlider(self):
        self.slider = SliderLabel(layout = self.layout_player,
                                  offset_width = self.appview.tab_widget.width)

        self.timerUpdateSliderTime = QTimer()
        self.timerUpdateSliderTime.timeout.connect(self.updateSliderTime)

    def createPlayerButtonsFrame(self):
        self.play_pause_btn = PushButton(text="  Play",
                                         tooltip="Play the rosbag file",
                                         icon_png=u":/16x16/icons/16x16/cil-media-play.png")

        self.next_frame_btn = PushButton(text="  Next Frame",
            tooltip="Choose the next frame of the rosbag file",
            icon_png=u":/16x16/icons/16x16/cil-media-step-forward.png")
        self.next_frame_btn.setDisabled(True)

        self.stop_btn = PushButton(text="  Stop",
                                   tooltip="Stop the rosbag replay",
                                   icon_png=u":/16x16/icons/16x16/cil-media-stop.png")
        self.stop_btn.setDisabled(True)

        self.play_pause_btn.clicked.connect(lambda checked: self.playPauseClicked())
        self.next_frame_btn.clicked.connect(lambda checked: self.nextFrameClicked())
        self.stop_btn.clicked.connect(lambda checked: self.stopClicked())

        layout_btns = LayoutBtnConfig(self.play_pause_btn, offset_width = self.appview.tab_widget.width)
        layout_btns.addBtnWidget(self.next_frame_btn)
        layout_btns.addBtnWidget(self.stop_btn)

        self.layout_player.addLayout(layout_btns)
        self.flagTimerStarted = False

    def playPauseClicked(self):
        if self.player_mode == "STOP":
            config = self.getRosbagPath()
            if config is None:
                return

            ''' start the rosbag player client'''
            #self.disableWidget(self.play_pause_btn)
            self.appview.play(resume=False)
            #self.enablePlayMode()
            self.enablePauseMode()

        elif self.player_mode == "PLAY":
            #self.disableWidget(self.play_pause_btn)
            self.enablePauseMode()
            self.setPauseMsgAndPublish(pause_playback_value = False)

        elif self.player_mode == "PAUSE":
            #self.disableWidget(self.play_pause_btn)
            #self.appview.play(resume=True)
            self.enablePlayMode()
            self.setPauseMsgAndPublish(pause_playback_value = True)

    def nextFrameClicked(self):
        self.disableWidget(self.next_frame_btn)

        if self.player_mode == "PLAY":
            ''' param_name = 'pause_playback'''
            pausePlayValue = False

            publish_msg = MsgTriggerSingleFrame()
            publish_msg.publish_next_frame = pausePlayValue

            result = f'{ "pauseplayvalue :"} {pausePlayValue}'
            next_frame_publisher = self.controller.getNextFramePublisher(Device.Rosbag)
            next_frame_publisher.publish(publish_msg)
            print(f"next frame publish_msg.publish_next_frame: {pausePlayValue}")
        self.enableWidget(self.next_frame_btn)
        self.enableWidget(self.play_pause_btn)
        self.enableWidget(self.stop_btn)

    def stopClicked(self):
        self.enableStopMode()

    def enablePlayMode(self):
        self.player_mode = "PLAY"
        self.play_pause_btn.setText("Play")
        setWidgetIcon(widget=self.play_pause_btn,
                      icon_png = u":/16x16/icons/16x16/cil-media-play.png")
        self.enableWidget(self.stop_btn)
        self.enableWidget(self.next_frame_btn)

    def enablePauseMode(self):
        self.player_mode = "PAUSE"
        self.play_pause_btn.setText("Pause")
        setWidgetIcon(widget=self.play_pause_btn,
                      icon_png = u":/16x16/icons/16x16/cil-media-pause.png")
        self.updateSliderTime()
        self.checkIfBagFinished()
        self.enableWidget(self.stop_btn)
        self.disableWidget(self.next_frame_btn)

    def enableStopMode(self):
        self.player_mode = "STOP"
        self.appview.stop()
        self.play_pause_btn.setText("Play")
        setWidgetIcon(widget=self.play_pause_btn,
                      icon_png = u":/16x16/icons/16x16/cil-media-play.png")
        self.enableWidget(self.play_pause_btn)
        self.stopTimerUpdateSliderTime()
        self.flagTimerStarted = False
        self.slider.setMinimum(0)
        self.slider.setMaximum(0)
        self.slider.setValue(0)
        self.disableWidget(self.stop_btn)
        self.disableWidget(self.next_frame_btn)

    def updateSliderTime(self):
        rosbag_duration = self.controller.getBagDuration()
        self.setSliderDuration(rosbag_duration)
        duration = self.controller.getDurationPlayed()
        self.slider.setValue(duration)
        if round(duration, 1) >= round(rosbag_duration, 1):
            self.checkIfBagFinished()
        if self.player_mode == "PAUSE" and self.flagTimerStarted == False:
            self.startTimerUpdateSliderTime()
            self.flagTimerStarted = True
        if self.player_mode == "STOP":
            self.slider.setMinimum(0)

    def checkIfBagFinished(self):
        bag_finished = self.controller.checkIfBagFinished()
        if bag_finished:
            self.player_mode = "STOP"

            ''' stop all timers'''
            self.stopTimerUpdateSliderTime()
            self.appview.rosbag_window_launch_stop_clicked.emit(False)
            QMessageBox.information(self, "Done",
                                    "Finished processing the Ros-bag",
                                    QMessageBox.Ok)

            self.flagTimerStarted = False
            self.enableStopMode()

    def enableWidget(self, widget):
        widget.setDisabled(False)

    def disableWidget(self, widget):
        widget.setDisabled(True)

    def setSliderDuration(self, duration):
        self.slider.setValue(duration)
        self.slider.setMaximum(duration)
        self.slider.setTickInterval(duration)

    def enablePlayBtn(self):
        self.enableWidget(self.play_pause_btn)

    def disablePlayBtn(self):
        self.disableWidget(self.play_pause_btn)

    def getRosbagPath(self):
        return self.rosbag_input_frame.getConfig()

    def startTimerUpdateSliderTime(self):
        self.timerUpdateSliderTime.start(50)

    def stopTimerUpdateSliderTime(self):
        if self.timerUpdateSliderTime.isActive():
            self.timerUpdateSliderTime.stop()

    def setPauseMsgAndPublish(self, pause_playback_value):
        pause_msg = None
        pause_msg = MsgSetPauseMode()
        pause_msg.pause_playback = pause_playback_value

        pause_playback = self.controller.getPauseModePublisher(Device.Rosbag)
        pause_playback.publish(pause_msg)

        print(f"pause_msg.pause_playback: {pause_msg.pause_playback}")
