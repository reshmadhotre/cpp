from app.rosbag_replay_tool.frames.rosbag_input_frame import RosbagInputFrame
from app.frames.swc_parameters_frame import SwcParametersFrame
from app.rosbag_replay_tool.frames.player_frame import PlayerFrame
from app.frames.common_widget import *
from app.frames.overview_frame import Overview
from app.utils.replay_utils import *
from app.utils.yaml_utils import *

from PySide6.QtWidgets import(
    QMessageBox,
    QWidget, QWidget)

from PySide6.QtCore import Signal

import os


class AppView(QWidget):
    ''' Signal sent from Rosbag Replay window to
    - Main window on Launch/stop event '''
    rosbag_window_launch_stop_clicked = Signal(bool)

    def __init__(self, app_controller, parent = None):
        super(AppView, self).__init__(parent)

        self.controller = app_controller
        self.app_config = app_controller.app_config
        self.ROSBAG_PLAYER_PACKAGE = self.app_config['ROSBAG_PLAYER_PACKAGE']
        self.TMP_FOLDER_PATH = self.app_config['TMP_FOLDER_PATH']

        replay_config = self.controller.getRosbagReplayConfig()

        self.input_frames = []
        self.rosbag_input_frame = None

        self.input_frame = self.createInputFrame(replay_config)

    def createInputFrame(self, replay_config):
        ''' Main layout'''
        self.layout_main = createVerticalLayout(self, 0, 10)

        if len(replay_config) == 0:
            QMessageBox.critical(self,
                "Config Error", "Error parsing node"
                " config files. Is the terminal sourced?")

        ''' Tabwidget sub widget layout'''
        self.tab_widget = createTabWidget(selectedTab=0)
        self.layout_tab = createHorizontalLayout()
        self.layout_tab.addWidget(self.tab_widget)
        
        self.overview = Overview(controller=self.controller,
                                 tabwidget=self.tab_widget,
                                 app_config=self.app_config,
                                 replay_tool = Tool.Rosbag)
        self.overview.overview_node_checked.connect(self.setTabwigetsTabsAbility)

        ''' Read the subcriber dictionary from file
        Rosbag replay can read it'''
        file_path = os.path.abspath(self.TMP_FOLDER_PATH)
        subscriber_dict_file_path = os.path.join(file_path,  "sync_subcriber_list.txt")
        package_subscribe_dict = readJsonFile(subscriber_dict_file_path)

        nodes_names = getNodesNames(self.app_config)
        for node_config in replay_config:
            node_package_name = node_config['ros_package']

            if node_config['ros_package'] == self.ROSBAG_PLAYER_PACKAGE:
                rosbag_input_frame = RosbagInputFrame(tabwidget=self.tab_widget,
                                                      node_config=node_config)
                self.rosbag_input_frame = rosbag_input_frame
                self.input_frames.append(rosbag_input_frame)
            else:
                subcriber_list = package_subscribe_dict.get(node_package_name)
                swc_parameters_frame = SwcParametersFrame(nodename=nodes_names[Nodes[node_package_name]],
                                                          package_name = Nodes[node_package_name],
                                                          tabwidget=self.tab_widget,
                                                          controller=self.controller,
                                                          overview=self.overview,
                                                          replay_tool = Tool.Rosbag,
                                                          node_config=node_config,
                                                          subcriber_list=subcriber_list)

                self.input_frames.append(swc_parameters_frame)

        self.layout_main.addLayout(self.layout_tab)
        #self.layout_main.addStretch(20)

        PlayerFrame(appview = self)

    def generateReplayConfig(self):
        replay_config = []

        for frame in self.input_frames:
            config = frame.getConfig()
            if config is None:
                return []
            replay_config.append(config)

        return replay_config

    def play(self, resume):
        replay_config = self.generateReplayConfig()
        if replay_config:
            self.rosbag_window_launch_stop_clicked.emit(True)
            self.controller.playRosbag(replay_config, resume)

    def stop(self):
        self.rosbag_window_launch_stop_clicked.emit(False)
        self.controller.stopRosbag()

    def setTabwigetsTabsAbility(self, tuple_checkbox_state):
        checkbox_name = tuple_checkbox_state[0]
        checked_value = tuple_checkbox_state[1]
        for index in range(self.tab_widget.count()):
            tabname = self.tab_widget.tabText(index)
            if tabname == checkbox_name:
                self.tab_widget.setTabEnabled(index, checked_value)
