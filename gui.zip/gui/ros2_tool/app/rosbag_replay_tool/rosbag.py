
from app.rosbag_replay_tool.frames.app_view import AppView


import rclpy, sys

rosbag_player_server_process = None

class RosbagReplay():
    def __init__(self, app_controller):

        self.rosbag_app_controller = app_controller

    def rosbagReplay(self):

        try:
            rosbag_window = AppView(self.rosbag_app_controller)
            return rosbag_window

        except BaseException:
            print(f"RosbagReplay Exception {sys.stderr}")

    def getAppController(self):
        return self.rosbag_app_controller
