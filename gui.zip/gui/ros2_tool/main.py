# This Python file uses the following encoding: utf-8

from app.frames.splash_screen import SplashScreen
from signal_wakeup_handler import SignalWakeupHandler
from app.controller.ros2_controller import Ros2Controller
from app.movable_app.ui_styles import Style

from PySide6.QtWidgets import QApplication

import rclpy
import sys
import signal
from rclpy.executors import ExternalShutdownException


def main():
    rclpy.init()
    app = QApplication(sys.argv)
    app.setStyleSheet(Style.style_message)

    try:
        ros2_node_controller = Ros2Controller()
        app_view = SplashScreen(ros2_node_controller)

        while rclpy.ok():
            app.processEvents()
            rclpy.spin_once(ros2_node_controller, timeout_sec=0.001)

        SignalWakeupHandler(app_view)
        signal.signal(signal.SIGINT, lambda sig, _: app_view.close())

    except ExternalShutdownException:
        sys.exit(1)
    except BaseException:
        print(f"App Closed {sys.stderr}")
        raise
    finally:
        #print(f"App Closed Finally {sys.stderr}")
        ros2_node_controller.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
