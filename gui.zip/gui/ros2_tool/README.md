# Tool : Ros2_tool

*Version : **Ros2_tool_v1.0.0***<br/>
*Release : 27.03.2023*<br/>
*Uhnder Simulation: cervelo-mrr-sim-081.3*<br/>
*OS: Ubuntu 20.04*
<br/><br/>
![ros2_tool](./doc/images/overview_panel_active_gui.png)

## Introduction

- Python3-Qt based GUI helper tools to 
  - Mf4 Replay
  - Live ethernet
  - Live Can
  - Rosbag Replay

-  Mf4 Replay
     - Mf4 Replay Tool has been developed to help the user to replay the mf4 files.
     - Replays the specified radar-mf4, video-mf4, can-mf4 files on Rviz for visualisation purpose.
     - Converts the specified radar-mf4, video-mf4, can-mf4 files to Ros2 ros-bag.
-  Live Ethernet
   -  Connects to live Radar device/s and replays the data on Rviz2.
-  Live CAN
   -  Connects to live CAN device/s and replays the data on Rviz2.
-  Rosbag Replay
   -  Rosbag Replay Tool has been developed to help the user to replay the Ros2 rosbag files.
   -  Replays the specified  Ros2 rosbag files on Rviz2 for visualisation purpose.

## Requirements

- Python 3.8+

## Dependencies
PySide6
To install *PySide6*:
```shell
$ pip3 install PySide6==6.3.0
```
```shell
$ pip install markupsafe==2.1.0
```
```shell
$ pip install Jinja2==3.0.3

```

## Mf4-Replay

![ros2_tool](./doc/images/overview_panel_active_gui_1.png)

  - On the `Overview` panel, Enable the needed Ros2 nodes under `Features` and `Servers` sections, corresponding tabs gets active.
  - `All Features` enables\disables all swc components. `All Servers` enables\disables all server components
  - Replay MIDW data radio button in `Servers` under `Radar` enables to replay RDC3 data only
  - Replay RDC3 Data radio button in `Servers` under `Radar` enables MIDW under `Features`, so this combination of Radar with MIDW requires
  Uhnder Simulator to replay the Mf4 files.
  - Replay RDC2 data replays RDC2 binary data.
![ros2_tool](./doc/images/rdc3_gui.png)
  - Radar Panel: param_uhdp_completetrigger_node.
    Based on below nodes enabled in `Overview Panel` the node with highest weight happens to be value for
    param_uhdp_completetrigger_node
    - Weight of Nodes
      -  server_replay_mrr = 0
      -  swc_merdrdatacubemidw = 1
      -  swc_meegomtnestimn = 2
      -  swc_memplobjtrckng = 3
      -  swc_meobjclassn = 4 `Future component, not yet added to SIL`
      -  swc_meroadbrdrestimn = 5
      -  swc_metunneldetn = 6
      -  swc_meblkgdetn = 7
      -  swc_mevehoutpadpracp = 8
      -  Can output adapter is a special case, is used for internal testing and validation. It does not send any feedback.Only till VOA will send feedback
      -  Note: The Daisy - chaining of the nodes is the responsibility of the user

  - CAO (Can Output Adapter) if enabled, Clock gets activated.
  - Similarly provide the relevant data for Video, Can Panels.
  - On Clicking the `Rosbag` checkboxes in overview Panel, the rosbags would get created for the mf4 files for that particular ros2 node.
  -  On Clicking the `Parquet` checkboxes in overview Panel, that particular Parquet node is enabled.

![ros2_tool](./doc/images/swc_component.png)

  - `param_swc_ROS_PACKAGE_NAME_previous_node` has the values as `Features` and `Radar` that are enabled on `Overview`
  - `Synchronisation` lists the checkboxes as values that are searched from specific `swc_component` corresponding hpp file located in the path of following form
    `features/swc_ros_package/include/swc_ros_package/include/node/RosPackage_NodeBase.hpp`
    The string beginning with `"{sub_*"` are picked from the *.hpp file.
    This list forms the checkboxes list. The enabled checkboxes are then written to its
    corresponding `Feature` config file `params.yaml` under the param name `param_swc_ros_package_sync_subscriber_list`
    when the nodes are Launched.


## Usage

### Step 1 - Launch the simulator
Open a new terminal and let run the simulation:
```shell
$ cd FE_RADAR_MERdrDataCubeMidW/Test/UhnderSimulation/linux/cervelo-mrr-sim-081.3
```
```python
$ python3 simulation-boot.py
```

### Step 2 - Launch the GUI :

On another terminal, run the command:

```python
$ python3 main.py
```

The tool opens with no files added. Select the mf4 file to be replayed. Set the parameters according to the recordings. And click the *Launch* Button. Rviz2 opens up.
If the box *Rosbag* is checked, a rosbag is created at the path of the specified mf4 file.

To open a previously saved configuration: click on `Open Config...` <br/>
To save the current configuration: click on `Save Config ` <br/>
To launch with current configuration: click on `Launch` <br/>
Status frame gets opened up, showing the current Radar file being processed. And Rviz2 opens up.
![ros2_tool](./doc/images/status_gui.png)

To Play and Pause the replay, click `Play/Pause` button <br/>
To replay the Mf4 files frame by frame, set `Pause` button mode on and click`Next Frame` button <br/>
To Stop currently running configuration click on `Stop` button <br/>


### Launch the Video Node as Standalone
  - Enable the Video checkbox on Overview panel.
![ros2_tool](./doc/images/video_standalone_gui.png)
  - Provide the video Mf4 file/s for replaying on Rviz2 and click `Launch`. 
  - Video Status shows the current processing file, timestamp, and elapsed time since launch as shown below.
![ros2_tool](./doc/images/video_status_gui.png)
  - Click on `Pause` button, it gets changed to `Play`, video pauses now, If you click now on Next frame button, Rviz2 Image shows the next frame in the video.
  - Click `Play/Pause` to start playing again, and `Stop` to stop the playing.


  Note: Uhnder Simulator is not needed in this combination.
  
### Launch the CAN Node as Standalone
  - Enable the CAN checkbox on Overview panel.
  - Provide the CAN Mf4 file/s, dbc file for replaying on Rviz2
![ros2_tool](./doc/images/can_standalone_gui.png)
  - CAN Status shows the current processing file, timestamp as shown below.
![ros2_tool](./doc/images/can_status_gui.png)
  - Click on `Pause` button, it gets changed to `Play`, CAN pauses now, If you click now on Next frame button, Rviz2 Image shows the next frame in the CAN, since the changes in millisecs, you may have to click mulitple times to see the change.
  - Click `Play/Pause` to start playing again, and `Stop` to stop the playing.
  

Note: Uhnder Simulator is not needed in this combination.

### Launch the Video and CAN Node
  - In this combination Can is in Standalone mode
  - Enable the CAN, Video checkboxes on Overview panel.
  - Provide the Video, CAN Mf4 file/s, dbc file for replaying on Rviz2
  - Click on `Launch` button
![ros2_tool](./doc/images/video_can_gui.png)
  - CAN Status shows the current processing file, timestamp as shown below.
![ros2_tool](./doc/images/can_status_gui.png)
  - Click on `Pause` button, it gets changed to `Play`, CAN pauses now, If you click now on Next frame button, Rviz2 Image shows the next frame in the CAN, since the changes in millisecs, you may have to click mulitple times to see the change.
  - Click `Play/Pause` to start playing again, and `Stop` to stop the playing.


Note: Uhnder Simulator is not needed in this combination.

## Live Ethernet

![ros2_tool](./doc/images/live_ethernet_gui.png)

 - Add the Radar Ip address, sensor details, check record_rosbags if rosbags are needed, provide the rosbag folder path.
 - Click on `Add Radar`, new radar device tab gets added.

![ros2_tool](./doc/images/live_ethernet_data.png)
- Click on ` Launch button`, Rviz2 opens up.
- If now you click on `midw_1d_data`, `midw_2d_data`, `objects_data` checkboxes at run time 1d, 2d, objects data gets enabled or disabled.
- Click on ` Stop button` to stop
- To open a previously saved configuration: click on `Open Config...` 
- To save the current configuration: click on `Save Config ` 

## Live CAN

![ros2_tool](./doc/images/live_can_gui.png)

 - Provide the dbc file, check record_rosbags if rosbags are needed, provide the rosbag folder path.
 - Click on `Add CAN`, new CAN device tab gets added.

![ros2_tool](./doc/images/live_can_data.png)
- Click on ` Launch button`, Rviz2 opens up.

- Click on ` Stop button` to stop
- To open a previously saved configuration: click on `Open Config...` 
- To save the current configuration: click on `Save Config `

## Rosbag Replay

- Python3 based GUI helper tool to replay rosbag file.
- Rosbag Replay Tool has been developed to help the user to replay the rosbag file.

![ros2_tool](./doc/images/rosbag_replay_overview.png)
- `Overview` panel of Rosbag replay

![ros2_tool](./doc/images/rosbag_replay_gui.png)

The tool opens with no files added. Select the Rosbag file to be replayed. Set the parameters according to the recordings. And click the Play Button. Rviz2 opens up, playing the selected rosbag file data.

Replay tool processing rosbag file showing its current duration played on Rviz2 and total ros bag duration.
To stop the currently running configuration ,click on STOP.

To pause the currently running configuration ,click on PAUSE.


## How to Debug
- When you close the Ros2_tool window, below window pops up.
  In order to debug we would need the /tmp folder, in that case click  `No` button, So that we can check the logs in `ros2_tool/tmp/` folder.
![ros2_tool](./doc/images/delete_window.png)

Open below corresponding file that has been created, when specific tool has been launched.

`ros2_tool/tmp/roslaunch_mf4_replay.py`

`ros2_tool/tmp/roslaunch_can_standalone_player.py`

`ros2_tool/tmp/roslaunch_video_standalone_player.py`

`ros2_tool/tmp/roslaunch_can_standalone_video_player.py`

`ros2_tool/tmp/roslaunch_live_ethernet.py`

`ros2_tool/tmp/roslaunch_live_can.py`

Check for the parameter values if they are the same data that you have provided or is there a divergence in it.

- Click on `Yes` button if you do not intend to check the logs
- Click on `Cancel` button if you have hit the close button accidently
