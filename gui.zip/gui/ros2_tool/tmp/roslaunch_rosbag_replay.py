from launch import LaunchDescription
from launch_ros.actions import Node

server_replay_rosbag_node = Node(
    name='server_replay_rosbag_node',
    namespace='',
    package='server_replay_rosbag',
    executable='server_replay_rosbag_node',
    output='screen',
    parameters=[
        {
            'rosbag_folder_path': '/home/kpit/magna/bag/RADAR_BenchRadar01_20221026_083850_Sabine-0-2-1_RRWFC_000000.ros2bag'
        },
        {
            'rosbag_type': 'ALL'
        }
    ],
    arguments=[

    ]
)
swc_merdrdatacubemidw_app = Node(
    name='swc_merdrdatacubemidw_app',
    namespace='',
    package='swc_merdrdatacubemidw',
    executable='swc_merdrdatacubemidw_app',
    output='screen',
    parameters=[
        {
            'param_trigger_cyclic_immediate': True
        },
        {
            'param_previous_node': 'server_replay_mrr'
        },
        {
            'param_sync_subscriber_list': [
                'sub_completetrigger_',
                'sub_midw_int_all_data_',
                'sub_trigger_cyclic_'
            ]
        },
        {
            'param_record_output_parquets': False
        },
        {
            'param_record_input_parquets': False
        }
    ],
    arguments=[

    ]
)


def generate_launch_description():

    return LaunchDescription([

        server_replay_rosbag_node,
        swc_merdrdatacubemidw_app

    ])


if __name__ == '__main__':
    generate_launch_description()