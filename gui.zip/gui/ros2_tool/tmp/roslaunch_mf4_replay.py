from launch import LaunchDescription
from launch_ros.actions import Node

server_replay_mrr_node = Node(
    name='server_replay_mrr_node',
    namespace='',
    package='server_replay_mrr',
    executable='server_replay_mrr_app',
    output='screen',
    parameters=[
        {
            'replay_mf4_filepaths': [
                '/home/kpit/magna/mf4/BenchRadar01_20230523_082826_pre_midw/RRWFC/RADAR_BenchRadar01_20230523_082826_Sabine-0-2-1_RRWFC_000001.mf4'
            ]
        },
        {
            'record_rosbags': False
        },
        {
            'radar_type': 'SST_MRR_FRONT_CENTER'
        },
        {
            'radar_name': 'radr'
        },
        {
            'replay_data': 'rdc3'
        },
        {
            'param_uhdp_completetrigger_node': 'swc_merdrdatacubemidw'
        },
        {
            'param_record_output_parquets': False
        },
        {
            'sensor_position_x': 0.0
        },
        {
            'sensor_position_y': 0.0
        },
        {
            'sensor_position_z': 0.0
        },
        {
            'sensor_yaw': 0.0
        },
        {
            'sensor_pitch': 0.0
        },
        {
            'sensor_roll': 0.0
        },
        {
            'ss_doppler_near_range': 5.0
        },
        {
            'ss_doppler_far_range': 9.0
        },
        {
            'scan0.detection_thresh_snr_dB': 15.0
        },
        {
            'scan0.clutter_image_thresh_snr_dB': 15.0
        },
        {
            'scan0.point_cloud_thresh_snr_dB': 15.0
        },
        {
            'scan0.scale_det_thresh_max_range': 0.0
        },
        {
            'scan0.scale_det_thresh_snr_adj': 0.0
        },
        {
            'scan0.ego_zero_stationary_threshold_mps': 0.05
        },
        {
            'scan0.ego_nonz_stationary_threshold_mps': 0.4
        },
        {
            'scan0.notch_width_radians': 0.53
        },
        {
            'scan0.notch_depth_dB': 12.0
        },
        {
            'scan0.outer_depth_dB': 7.0
        },
        {
            'scan1.detection_thresh_snr_dB': 15.0
        },
        {
            'scan1.clutter_image_thresh_snr_dB': 15.0
        },
        {
            'scan1.point_cloud_thresh_snr_dB': 15.0
        },
        {
            'scan1.scale_det_thresh_max_range': 0.0
        },
        {
            'scan1.scale_det_thresh_snr_adj': 0.0
        },
        {
            'scan1.ego_zero_stationary_threshold_mps': 0.05
        },
        {
            'scan1.ego_nonz_stationary_threshold_mps': 0.4
        },
        {
            'scan1.notch_width_radians': 0.53
        },
        {
            'scan1.notch_depth_dB': 12.0
        },
        {
            'scan1.outer_depth_dB': 7.0
        },
        {
            'scan2.detection_thresh_snr_dB': 15.0
        },
        {
            'scan2.clutter_image_thresh_snr_dB': 15.0
        },
        {
            'scan2.point_cloud_thresh_snr_dB': 15.0
        },
        {
            'scan2.scale_det_thresh_max_range': 0.0
        },
        {
            'scan2.scale_det_thresh_snr_adj': 0.0
        },
        {
            'scan2.ego_zero_stationary_threshold_mps': 0.05
        },
        {
            'scan2.ego_nonz_stationary_threshold_mps': 0.4
        },
        {
            'scan2.notch_width_radians': 0.53
        },
        {
            'scan2.notch_depth_dB': 12.0
        },
        {
            'scan2.outer_depth_dB': 7.0
        },
        {
            'scan3.detection_thresh_snr_dB': 15.0
        },
        {
            'scan3.clutter_image_thresh_snr_dB': 15.0
        },
        {
            'scan3.point_cloud_thresh_snr_dB': 15.0
        },
        {
            'scan3.scale_det_thresh_max_range': 0.0
        },
        {
            'scan3.scale_det_thresh_snr_adj': 0.0
        },
        {
            'scan3.ego_zero_stationary_threshold_mps': 0.05
        },
        {
            'scan3.ego_nonz_stationary_threshold_mps': 0.4
        },
        {
            'scan3.notch_width_radians': 0.53
        },
        {
            'scan3.notch_depth_dB': 12.0
        },
        {
            'scan3.outer_depth_dB': 7.0
        }
    ],
    arguments=[

    ]
)
server_replay_video_node = Node(
    name='server_replay_video_node',
    namespace='',
    package='server_replay_video',
    executable='server_replay_video_node',
    output='screen',
    parameters=[
        {
            'replay_mf4_video_filepaths': [
                '/home/kpit/magna/mf4/BenchRadar01_20230523_082826_pre_midw/RFC01/RADAR_BenchRadar01_20230523_082826_Sabine-0-2-1_RFC01_000001.mf4'
            ]
        },
        {
            'record_rosbags': False
        },
        {
            'standalone_mode': False
        },
        {
            'show_timestamp': True
        }
    ],
    arguments=[

    ]
)
server_replay_can_node = Node(
    name='server_replay_can_node',
    namespace='',
    package='server_replay_can',
    executable='server_replay_can_node',
    output='screen',
    parameters=[
        {
            'replay_mf4_CAN_filepaths': [
                '/home/kpit/magna/mf4/BenchRadar01_20230523_082826_pre_midw/RCAFC/RCAFC_2023_05_23-08-30-56.000001.mf4'
            ]
        },
        {
            'dbc_filepath': '/home/kpit/magna/mf4/Radar_Hydra_private_CANFD_Sys_Description_1.11.1.16.dbc'
        },
        {
            'record_rosbags': False
        },
        {
            'param_record_output_parquets': False
        },
        {
            'publish_can_obj_list': True
        },
        {
            'publish_road_border_data': True
        },
        {
            'standalone_mode': False
        },
        {
            'sensor_position_x': 0.0
        },
        {
            'sensor_position_y': 0.0
        },
        {
            'sensor_position_z': 0.0
        },
        {
            'sensor_yaw': 0.0
        },
        {
            'sensor_pitch': 0.0
        },
        {
            'sensor_roll': 0.0
        }
    ],
    arguments=[

    ]
)
swc_merdrdatacubemidw_app = Node(
    name='swc_merdrdatacubemidw_app',
    namespace='',
    package='swc_merdrdatacubemidw',
    executable='swc_merdrdatacubemidw_app',
    output='screen',
    parameters=[
        {
            'param_trigger_cyclic_immediate': True
        },
        {
            'param_previous_node': 'server_replay_mrr'
        },
        {
            'param_sync_subscriber_list': [
                'sub_completetrigger_',
                'sub_midw_int_all_data_',
                'sub_trigger_cyclic_'
            ]
        },
        {
            'param_record_output_parquets': True
        },
        {
            'param_record_input_parquets': False
        }
    ],
    arguments=[

    ]
)


def generate_launch_description():

    return LaunchDescription([

        server_replay_mrr_node,
        server_replay_video_node,
        server_replay_can_node,
        swc_merdrdatacubemidw_app

    ])


if __name__ == '__main__':
    generate_launch_description()