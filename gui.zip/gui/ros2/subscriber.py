import rclpy
from rclpy.node import Node

from std_msgs.msg import String
import time

class MinimalSubscriber(Node):

    def __init__(self):
        super().__init__('minimal_subscriber')
        self.subscription = self.create_subscription(
            String,
            'topic',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning

    def listener_callback(self, msg):
        self.get_logger().info('I heard: "%s"' % msg.data)


class Subcriber():
    def subscriber_start(self):
        print(f"sub start")
        rclpy.init()
        self.minimal_subscriber = MinimalSubscriber()
        while(1):
            rclpy.spin_once(self.minimal_subscriber, timeout_sec=0)
        print(f"sub start end")
        
    def subscriber_stop(self):

        # Destroy the node explicitly
        # (optional - otherwise it will be done automatically
        # when the garbage collector destroys the node object)
        print(f"sub stop")
        self.minimal_subscriber.destroy_node()
        rclpy.shutdown()
        print(f"sub stop end")

def main(args=None):
    time.sleep(1)
    sub = Subcriber()
    sub.subscriber_start()
    #sub.subscriber_stop()
    
    print(f"sleep start")
    time.sleep(1)
    print(f"sleep stop")
    
    #sub.subscriber_start()
    #sub.subscriber_stop()

if __name__ == '__main__':
    main()
