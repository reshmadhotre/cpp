
from PySide6.QtWidgets import (QLabel,
    QMainWindow, QPushButton,QWidget,QVBoxLayout,QApplication)
from PySide6.QtCore import QTimer

import sys

class Timer(QMainWindow):
    def __init__(self, parent=None):
        super(Timer, self).__init__(parent)
        
        self.centralwidget = QWidget()

        ''' Main layout'''
        self.main_layout = QVBoxLayout()

        self.setCentralWidget(self.centralwidget)
        self.centralwidget.setLayout(self.main_layout)

        start_btn = QPushButton("Start")
        start_btn.clicked.connect(lambda checked: self.startClicked())
        stop_btn = QPushButton("Stop")
        stop_btn.clicked.connect(lambda checked: self.stopClicked())
        
        self.main_layout.addWidget(start_btn)
        self.main_layout.addWidget(stop_btn)
        
        self.label = QLabel()
        self.main_layout.addWidget(self.label)
        
        self.timer = QTimer() 
        self.timer.timeout.connect(self.update)
        milliseconds = 1000 
        #timer.start(milliseconds) 
        self.index = 0
        self.show()
    
    def update(self):
        print(f"index {self.index}")
        self.label.setText(str(self.index))
        self.index = self.index + 1
    
    def startClicked(self):
        self.timer.start()
        
    def stopClicked(self):
        self.timer.stop()
        
def main():
    app = QApplication(sys.argv)
    window = Timer()
    sys.exit(app.exec())
    
if __name__ == "__main__":
    main()