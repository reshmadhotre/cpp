import sys
from PySide6.QtWidgets import QMainWindow, QApplication, QTreeWidget, QTreeWidgetItem, QLabel, QComboBox, QVBoxLayout, QMessageBox
from PySide6.QtCore import Qt

data = {
          "scan0": {
          "detection_thresh_snr_dB": 15,
          "clutter_image_thresh_snr_dB": 15,
          "point_cloud_thresh_snr_dB": 15,
          "scale_det_thresh_max_range": 0,
          "scale_det_thresh_snr_adj": 0,
          "ego_zero_stationary_threshold_mps": 0.05,
          "ego_nonz_stationary_threshold_mps": 0.4,
          "notch_width_radians": 0.53,
          "notch_depth_dB": 12,
          "outer_depth_dB": 7
                    },
          "scan1": {
          "detection_thresh_snr_dB": 15,
          "clutter_image_thresh_snr_dB": 15,
          "point_cloud_thresh_snr_dB": 15,
          "scale_det_thresh_max_range": 0,
          "scale_det_thresh_snr_adj": 0,
          "ego_zero_stationary_threshold_mps": 0.05,
          "ego_nonz_stationary_threshold_mps": 0.4,
          "notch_width_radians": 0.53,
          "notch_depth_dB": 12,
          "outer_depth_dB": 7
                    }
        }
        
        
class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        # tree = QTreeWidget()
        # tree.setColumnCount(2)
        # tree.setHeaderLabels(["Name", "Type"])        
        # items = []
        # for key, value in data.items():
        #     print(f"key : {key} \nvalue : {value}")
        #     item = QTreeWidgetItem([key, "value"])
        #     for k, v in value.items():
        #         print(f"key : {k}")
        #         print(f"value : {v}")

        #         child = QTreeWidgetItem([k, str(v)])

        #         item.addChild(child)
        #     items.append(item)

        # tree.insertTopLevelItems(0, items)

        # tree.show()

        # treeWidget = QTreeWidget()
        # treeWidget.setColumnCount(2)
        # treeWidget.setHeaderLabels(["Name", "Type"])

        # child1 = QTreeWidgetItem({"Field 2"})
        # combo_box = QComboBox()
        # combo_box.setEditable(True)
        # combo_box.addItem("abc")

        # treeWidget.addTopLevelItem(child1);

        # treeWidget.setItemWidget(child1, 1, combo_box)
        # #treeWidget.expandAll()
        # treeWidget.show()

        vertical_layout = QVBoxLayout()
        # treeWidget = QTreeWidget()
        # treeWidget.setColumnCount(2)
        # treeWidget.setHeaderLabels(["Name", "Value"])
        # vertical_layout.addWidget(treeWidget)

        # items = []
        # for key, value in data.items():
            # print(f"key : {key} \nvalue : {value}")
            # item = QTreeWidgetItem(treeWidget)
            # item.setText(0, key)
            # item.setFlags(Qt.ItemIsEnabled)
            # for k, v in value.items():
                # print(f"key : {k}")
                # print(f"value : {v}")

                # child = QTreeWidgetItem(item, [k])
                # child.setText(0, k)
                
                # combo_box = QComboBox()
                # combo_box.setEditable(True)
                # combo_box.addItem(str(v))

                #item.addChild(child)
                # treeWidget.setItemWidget(child, 1, combo_box)

        # treeWidget.expandAll()
        # treeWidget.show()
        create_rosbag_flag = True
        rosbag_path = "path"
        rosbag_text=""
        if create_rosbag_flag:
            rosbag_text = f"Rosbag saved to : {rosbag_path}"

        QMessageBox.information(self, "Rosbag",
                f"Finished processing all files. {rosbag_text}",
                QMessageBox.Ok  )


if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)

    w = MainWindow()
    w.show()

    sys.exit(app.exec())