#ifndef HELLO_GUI_H
#define HELLO_GUI_H

#include <QWidget>
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include <qtimer.h>

namespace Ui {
class HelloGui;
}

class HelloGui : public QWidget, public rclcpp::Node
{
    Q_OBJECT

public:
    //HelloGui(std::shared_ptr<rclcpp::Node> node, QWidget *parent = nullptr);
    explicit HelloGui(QWidget *parent = nullptr);
    ~HelloGui();

    void chatterCallback(const std_msgs::msg::String::SharedPtr& msg) const;

public slots:
    void spinOnce();

private:
    Ui::HelloGui *ui;
    QTimer *ros_timer;

    std::shared_ptr<rclcpp::Node> node_;
    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr chatter_sub_;
};

#endif // HELLO_GUI_H
