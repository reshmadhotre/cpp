#include "hello_gui.h"
#include "ui_hello_gui.h"
#include <QDebug>
const constexpr int QUEUE_SIZE = 10;

//HelloGui::HelloGui(std::shared_ptr<rclcpp::Node> node, QWidget *parent):
//    QWidget(parent),
//    node_(node),
//    ui(new Ui::HelloGui)
//{
HelloGui::HelloGui(QWidget *parent):
    QWidget(parent),
    ui(new Ui::HelloGui),
    rclcpp::Node("Hello_Gui_Node")
{
    std::cout<<" Hello 1 "<<std::endl;
    ui->setupUi(this);

    std::cout<<" Hello 2 "<<std::endl;
    // setup the timer that will signal ros stuff to happen
    ros_timer = new QTimer(this);
    connect(ros_timer, SIGNAL(timeout()), this, SLOT(spinOnce()));
    ros_timer->start(1000);

    std::string topic("/talker/chatter");

//    auto callback = [&](const std_msgs::msg::String::SharedPtr& msg) -> void
//    {
//        auto qstring_msg = QString::fromStdString(msg->data.c_str());
//        RCLCPP_INFO(node_->get_logger(), "I heard: '%s'", msg->data.c_str());
//        ui->chatter->setText(msg->data.c_str());
//    };

//    chatter_sub_ = node_->create_subscription<std_msgs::msg::String>
//            (topic.c_str(), QUEUE_SIZE, std::bind(&HelloGui::chatterCallback, node_, std::placeholders::_1));

    chatter_sub_ = this->create_subscription<std_msgs::msg::String>
            (topic.c_str(), QUEUE_SIZE, [&](const std_msgs::msg::String::SharedPtr msg)
    {
        qDebug() << "I heard: "<< msg->data.c_str() ;
        std::cout<<"I heard: "<< msg->data.c_str() <<std::endl;
        ui->chatter->setText(msg->data.c_str());
    });
}

HelloGui::~HelloGui()
{
    delete ui;
    delete ros_timer;
    std::cout<<" Destructor Hello 5 "<<std::endl;
}

void HelloGui::spinOnce()
{
    if (rclcpp::ok())
    {
        //rclcpp::spin_some(this);
        qDebug() << "@"  "ms : QTimer timeout from thread : " ;
    }
    else {
        QApplication::quit();
    }
}

void HelloGui::chatterCallback(const std_msgs::msg::String::SharedPtr& msg) const
{
    auto qstring_msg = QString::fromStdString(msg->data.c_str());
    RCLCPP_INFO(node_->get_logger(), "I heard: '%s'", msg->data.c_str());
    ui->chatter->setText(msg->data.c_str());
}
