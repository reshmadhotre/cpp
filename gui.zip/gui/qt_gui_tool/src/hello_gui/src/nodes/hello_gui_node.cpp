#include <QApplication>
#include "hello_gui.h"

#include <rclcpp/executor.hpp>

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);

    QApplication hello_app(argc, argv);

    //HelloGui hello_gui(node);
    //HelloGui hello_gui;

    auto hello_gui = std::make_shared<HelloGui>();
//    hello_gui.setWindowTitle("Hello_Gui_Node");
//    hello_gui.show();

    rclcpp::executor::QtExecutor executor;
    executor.add_node(hello_gui);

    executor.start();

    std::cout<<" Hello 3 "<<std::endl;
    auto res = hello_app.exec();
    std::cout<<" Hello 4 "<<std::endl;
    rclcpp::shutdown();

    return res;
}
