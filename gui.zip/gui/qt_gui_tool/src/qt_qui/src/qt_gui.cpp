#include "qt_gui.h"
#include "ui_qt_gui.h"

#include <iostream>

QtGui::QtGui(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QtGui)
{
    ui->setupUi(this);
}

QtGui::~QtGui()
{
    delete ui;

    std::cout<<" Destructor Hello 5 "<<std::endl;
}
