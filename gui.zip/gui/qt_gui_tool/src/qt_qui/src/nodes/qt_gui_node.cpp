#include <QApplication>
#include "qt_gui.h"

#include <iostream>
int main(int argc, char *argv[])
{
    std::cout<<" Hello 1 "<<std::endl;
    QApplication hello_app(argc, argv);

    std::cout<<" Hello 2 "<<std::endl;

    QtGui hello_gui;
    hello_gui.setWindowTitle("hello_gui_node");

    std::cout<<" Hello 3 "<<std::endl;
    hello_gui.show();

    std::cout<<" Hello 4 "<<std::endl;
    return hello_app.exec();

    std::cout<<"never:  After return  Hello 5 "<<std::endl;
}
