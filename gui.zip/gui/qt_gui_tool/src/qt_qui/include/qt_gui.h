#ifndef QT_GUI_H
#define QT_GUI_H

#include <QWidget>

namespace Ui {
class QtGui;
}

class QtGui : public QWidget
{
    Q_OBJECT

public:
    explicit QtGui(QWidget *parent = nullptr);
    ~QtGui();

private:
    Ui::QtGui *ui;
};

#endif // QT_GUI_H
