#!/bin/env python
 
# ------------------------------------------------------------------------------
# Imports
# ------------------------------------------------------------------------------
import sys

from PySide6.QtWidgets import QMainWindow,QMessageBox,QVBoxLayout, QApplication, QTreeWidget, QTreeWidgetItem, QSpinBox, QLabel
from PySide6.QtWidgets import QTabWidget,QWidget,QPushButton,QHBoxLayout, QScrollArea
from PySide6.QtCore import QSize
from PySide6.QtGui import  QIcon, Qt
 
# ------------------------------------------------------------------------------
# Open UI
# ------------------------------------------------------------------------------
def openUI():
    '''
    Open UI.
    '''
    app = QApplication(sys.argv)
    ex = UI()
    ex.show()
    sys.exit(app.exec_())
 
# ------------------------------------------------------------------------------
# UI
# ------------------------------------------------------------------------------

data = {
          "scan0": {
          "detection_thresh_snr_dB": 15,
          "clutter_image_thresh_snr_dB": 15,
          "point_cloud_thresh_snr_dB": 15,
          "scale_det_thresh_max_range": 0,
          "scale_det_thresh_snr_adj": 0,
          "ego_zero_stationary_threshold_mps": 0.05,
          "ego_nonz_stationary_threshold_mps": 0.4,
          "notch_width_radians": 0.53,
          "notch_depth_dB": 12,
          "outer_depth_dB": 7
                    }
        }

class UI(QMainWindow):
 
    def __init__( self, parent=None ):
 
        ## Init:
        super(UI, self).__init__( parent )
 
        # ----------------
        # Create Simple UI with QTreeWidget
        # ----------------
        self.centralwidget = QWidget()
        self.verticalLayout = QVBoxLayout()
        
        header = QLabel("Header")
        self.verticalLayout.addWidget(header)
        
        maintreeWidget = QTreeWidget()
        
        
        treeWidget = QTreeWidget()
        treeWidget.setFixedHeight(50)
        treeWidget.resizeColumnToContents(0)
        
        item_key_uhdp = CreateTreeWidgetItem(tree_widget = treeWidget,
                                             header_name = "some name")
        
        item_key_uhdp.setExpanded(True)
        radar_type_cb = QLabel("Hello my text")
        child = CreateTreeWidgetItem(item_key_uhdp, "Hello")
        treeWidget.setItemWidget(child, 1, radar_type_cb)
        
                 
        #self.verticalLayout.addWidget(treeWidget)
        
        #header1 = QLabel("Below Header")
        #self.verticalLayout.addWidget(header1)
        
        treeWidget1 = QTreeWidget()
        item_key_uhdp1 = CreateTreeWidgetItem(tree_widget = treeWidget1,
                                             header_name = "Name")
        
        radar_type_cb1 = QLabel("Hello my text")
        child1 = CreateTreeWidgetItem(item_key_uhdp1, "Hello")
        treeWidget1.setItemWidget(child1, 1, radar_type_cb1)
         
        self.verticalLayout.addWidget(treeWidget1)
   
        
        self.centralwidget.setLayout(self.verticalLayout)
        self.setCentralWidget(self.centralwidget)
        #self.show()
 
        # # ----------------
        # # Set TreeWidget Headers
        # # ----------------
        # HEADERS = ( "column 1", "column 3", "column 2" )
        # self.treeWidget.setColumnCount( len(HEADERS) )
        # self.treeWidget.setHeaderLabels( HEADERS )
 
        # # ----------------
        # # Add Custom QTreeWidgetItem
        # # ----------------
        # ## Add Items:
        # for name in [ 'rock', 'paper', 'scissors' ]:
        #     item = CustomTreeItem( self.treeWidget, name )
        #     seconditem = CustomTreeItem( item, "paper" )
 
        # ## Set Columns Width to match content:
        # for column in range( self.treeWidget.columnCount() ):
        #     self.treeWidget.resizeColumnToContents( column )
 
# ------------------------------------------------------------------------------
# Custom QTreeWidgetItem
# ------------------------------------------------------------------------------
class CustomTreeItem( QTreeWidgetItem ):
    '''
    Custom QTreeWidgetItem with Widgets
    '''
 
    def __init__( self, parent, name ):
        '''
        parent (QTreeWidget) : Item's QTreeWidget parent.
        name   (str)         : Item's name. just an example.
        '''
 
        ## Init super class ( QtGui.QTreeWidgetItem )
        super( CustomTreeItem, self ).__init__( parent )
 
        ## Column 0 - Text:
        self.setText( 0, name )
 
        ## Column 1 - SpinBox:
        self.spinBox = QSpinBox()
        self.spinBox.setValue( 0 )
        self.treeWidget().setItemWidget( self, 1, self.spinBox )
 
        ## Column 2 - Button:
        self.button = QPushButton()
        self.button.setText( "button %s" %name )
        self.treeWidget().setItemWidget( self, 2, self.button )
 
        ## Signals
        self.button.clicked.connect(self.buttonPressed )
 
    @property
    def name(self):
        '''
        Return name ( 1st column text )
        '''
        return self.text(0)
 
    @property
    def value(self):
        '''
        Return value ( 2nd column int)
        '''
        return self.spinBox.value() 
 
    def buttonPressed(self):
        '''
        Triggered when Item's button pressed.
        an example of using the Item's own values.
        '''
        print(f"This Item name:{0} value:{1}" .format( self.name,self.value ))
 
 
def CreateTreeWidgetItem(item_key, param_name):
    tree_item = QTreeWidgetItem(item_key, [str(param_name)])
    tree_item.setText(0, str(param_name))
    return tree_item

def CreateTreeWidgetItem(tree_widget, header_name):
    child = QTreeWidgetItem(tree_widget)
    child.setText(0, header_name)
    child.setFlags(Qt.ItemIsEnabled)
    return child

# ------------------------------------------------------------------------------
# __name__
# ------------------------------------------------------------------------------
if __name__ == '__main__':
    openUI()
    
    
    
    tabWidget.setStyleSheet(u"QTabWidget {	\n"
    "	border: 2px solid rgb(FF,FF,FF);\n"
    "	border-radius: 5px;	\n"
    "	background-color: rgb(FF,FF,FF);\n"
    "}\n"
    "QTabWidget:hover {\n"
    "	background-color: rgb(52, 59, 72);\n"
    "}\n"
    "QTabWidget:pressed {	\n"
    "	background-color: rgb(85, 170, 255);\n"
    "}"
    "QTabWidget:pane {	\n"
    "	border: 3px solid rgb(39, 44, 54); "
    "   border-radius: 5px;"
    "}"
    "QTabBar::tab:!selected {"
    "   background-color: rgb(00, 00, 00)"
     "	border-top-right-radius: 5px;\n"
    "	border-top-left-radius: 5px;\n"
     "	border-bottom-right-radius: 5px;\n"
    "	border-bottom-left-radius: 5px;\n"
    "}"
    "QTabBar::tab:selected {"
    "   background-color: rgb(85, 170, 255)"
    "	border: 2px solid rgb(85, 170, 255);\n"
    "	border-top-right-radius: 5px solid  rgb(85, 170, 255);\n"
    "	border-top-left-radius: 5px solid  rgb(85, 170, 255);\n"
    "	border-bottom-right-radius: 5px solid  rgb(85, 170, 255);\n"
    "	border-bottom-left-radius: 5px solid  rgb(85, 170, 255);\n"
    "}" )
    
     "QTabBar::tab:!selected {"
    "   background: rgb(61, 70, 86)"
    "}"