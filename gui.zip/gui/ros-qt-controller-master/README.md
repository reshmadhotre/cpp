Description
===========
This is a simple controller built with ROS and Qt5 libraries. This is implemented here as a part of the ROS Complete Handbook.