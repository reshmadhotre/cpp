import sys
import threading


from PySide6.QtWidgets import (
QApplication, QVBoxLayout, QPushButton,QDialog,
QCheckBox,QRadioButton,QInputDialog )
from PySide6.QtCore import QSize

class Dialog(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        button = QPushButton("test")
        layout = QVBoxLayout()
        layout.addWidget(button)
        self.setLayout(layout)

app = QApplication(sys.argv)
toast = Dialog()
toast.show()

t = threading.Thread(target = lambda: app.exec())
t.daemon = True
t.start()
print("App freezes the main process!")




# class Dialog(QDialog):
#     def __init__(self):
#         QDialog.__init__(self)
#         button = QPushButton("test")
#         layout = QVBoxLayout()
#         layout.addWidget(button)
#         self.setLayout(layout)

# app = QApplication(sys.argv)
# toast = Dialog()
# toast.show()
# app.exec()
# print("App freezes the main process!")