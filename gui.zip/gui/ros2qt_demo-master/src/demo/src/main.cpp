#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <iostream>
int main(int argc, char *argv[])
{
	std::cout<<"Hello3" <<std::endl;
	QGuiApplication app(argc, argv);
    std::cout<<"Hello1" <<std::endl;
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    std::cout<<"Hello2" <<std::endl;
    
    QQmlApplicationEngine engine;
    std::cout<<"Hello4" <<std::endl;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;
    int a = 1;
    std::cin>>a;
    std::cout<<"Hello5" <<std::endl;
    return app.exec();
}
